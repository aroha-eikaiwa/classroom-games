const foods = [
  ['Cheeseburger','チーズバーガー','./images/food-0.svg'],['Pizza','ピザ','./images/food-1.svg'],
  ['Sandwich','サンドイッチ','./images/food-2.svg'],['Sushi','すし','./images/food-3.svg'],
  ['French fries','フライドポテト','./images/food-4.svg'],['Salad','サラダ','./images/food-5.svg'],
  ['Orange juice','オレンジジュース','./images/food-6.svg'],['Iced tea','アイスティー','./images/food-7.svg'],
];
const groups = [['Main dishes / メイン',0,4],['Side dishes / サイド',4,6],['Drinks / ドリンク',6,8]];
const prices = [500,600,400,600,250,300,200,150];
const fresh = () => ({name:'My restaurant',items:foods.map((food,i)=>({food:i,name:food[0],price:prices[i]})),balance:2000,orders:[]});
const $ = id => document.getElementById(id);
const escape = value => String(value).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state;
try { state=JSON.parse(localStorage.getItem('aroha.local-restaurant-review-v2')) || fresh(); } catch { state=fresh(); }
let mode='builder', pending;
function save(){ try { localStorage.setItem('aroha.local-restaurant-review-v2',JSON.stringify(state)); } catch {} }
function buildItem(item, index, start, end) {
  const [,,image]=foods[item.food];
  const options=foods.slice(start,end).map(([en,ja],i)=>`<option value="${start+i}" ${item.food===start+i?'selected':''}>${en} / ${ja}</option>`).join('');
  return `<div class="item"><img src="${image}" alt=""><label>Food picture / 絵<select data-index="${index}" data-key="food">${options}</select></label><label>Menu name / 名前<input data-index="${index}" data-key="name" value="${escape(item.name)}" maxlength="60"></label><label>Price in yen / 値段<input data-index="${index}" data-key="price" type="number" step="50" min="100" max="2000" value="${item.price}"></label></div>`;
}
function shopItem(item,index) {
  const [,ja,image]=foods[item.food];
  return `<div class="item"><img src="${image}" alt=""><h3>${escape(item.name || foods[item.food][0])}</h3><p>${ja} · ¥${item.price}</p><button data-buy="${index}" ${state.balance<item.price?'disabled':''}>Order / 注文</button></div>`;
}
function render() {
  for(const tab of ['builder','wallet']) $(tab).setAttribute('aria-pressed',String(tab===mode));
  const isBuilder=mode==='builder';
  const items=isBuilder?state.items:fresh().items;
  $('restaurant').innerHTML=(isBuilder
    ? `<label class="name">Restaurant name / お店の名前<input id="name" maxlength="60" value="${escape(state.name)}"></label>`
    : `<section class="sample"><h2>Aloha Café</h2><p>Wallet / おさいふ <strong>¥${state.balance}</strong></p><button id="reset-wallet">Refill demo wallet / おさいふをリセット</button></section>`)
    +groups.map(([title,start,end])=>`<h3 class="menu-heading">${title}</h3><div class="menu">${items.slice(start,end).map((item,i)=>isBuilder?buildItem(item,start+i,start,end):shopItem(item,start+i)).join('')}</div>`).join('')
    +(isBuilder?'<div class="tools"><button id="reset-menu">Reset menu / メニューをリセット</button></div>':`<h3 class="menu-heading">Orders / 注文履歴</h3><ul>${state.orders.map(i=>`<li>${foods[i][0]} · ¥${prices[i]}</li>`).join('')}</ul>`);
}
for(const button of ['builder','wallet']) $(button).onclick=()=>{mode=button;render();};
$('restaurant').addEventListener('change',event=>{
  const el=event.target;
  if(el.id==='name')state.name=el.value;
  else if(el.dataset.key){
    const item=state.items[Number(el.dataset.index)], key=el.dataset.key;
    if(key==='food'){
      item.food=Number(el.value);item.name=foods[item.food][0];render();
    } else if(key==='price'){
      item.price=Math.min(2000,Math.max(100,Math.round((Number(el.value)||100)/50)*50));el.value=item.price;
    } else item.name=el.value;
  } else return;
  save();
});
$('restaurant').addEventListener('click',event=>{
  const button=event.target.closest('button');
  if(!button)return;
  if(button.id==='reset-wallet'){state.balance=2000;state.orders=[];save();render();}
  if(button.id==='reset-menu'&&confirm('Reset this demo menu? / メニューをリセットしますか？')){
    const next=fresh();state.name=next.name;state.items=next.items;save();render();
  }
  if(button.dataset.buy!==undefined){
    pending=Number(button.dataset.buy);
    $('order').returnValue='';
    $('order-copy').textContent=`I'd like ${foods[pending][0]}, please. · ¥${prices[pending]}`;
    $('order').showModal();
  }
});
$('order').addEventListener('close',()=>{
  if($('order').returnValue==='pay'&&prices[pending]<=state.balance){
    state.balance-=prices[pending];state.orders.push(pending);save();render();
  }
});
render();
