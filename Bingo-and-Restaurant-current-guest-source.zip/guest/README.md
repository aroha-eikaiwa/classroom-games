# Aroha guest source: updated local review
Not a copy of the live website or the complete classroom games. Private review only. No redistribution license has been chosen.

Run from this folder with Node 22 or later: `node server.mjs`. Open the printed address (normally `http://127.0.0.1:8000/`). For two Bingo players, use two separate browser profiles or a normal and private window on the same computer. Two normal tabs in the same browser profile share one browser guest identity. The server intentionally listens only on this computer. Do not expose this review server to an internet host.

**Bingo:** This version uses the game’s actual guest room logic and spinner. It restores six-character room codes, join links, board creation, random fill on start, calls/marking and Bingo detection. Select **Other word sets → Around town** for a synthetic deck large enough for 5 × 5. Other sets use smaller example word lists. Original publisher-linked data and imagery were replaced. Speech works only when the browser has a local English voice; otherwise there is a visual reveal. Rooms expire or disappear when you stop the server. Browser preferences remain in that browser; classroom selection and sign-in are not present.

**Restaurant:** This uses the current guest practice client, with replacement local icons. The built-in sample wallet uses the built-in café, not the menu you edit. There is no shared classroom shop, account upload or AI. Drafts and practice progress stay in your browser.

**Local check:** With the server running, run `node test-local.mjs` in another terminal (pass the same `PORT` if changed). The test starts a room in the local process, simulates a second browser identity, checks restricted actions and confirms a winning row. It does not contact your website or create a real class. Visual and audio playback checks on a regular browser remain separate.
