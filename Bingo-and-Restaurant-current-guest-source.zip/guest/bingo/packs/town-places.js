export const pack = {
  "id": "town-places",
  "title": "Around town",
  "items": [
    {
      "id": "park",
      "label": "park",
      "meaning": "こうえん",
      "symbol": "⛲"
    },
    {
      "id": "bank",
      "label": "bank",
      "meaning": "ぎんこう",
      "symbol": "🏦"
    },
    {
      "id": "hospital",
      "label": "hospital",
      "meaning": "びょういん",
      "symbol": "🏥"
    },
    {
      "id": "station",
      "label": "station",
      "meaning": "えき",
      "symbol": "🚉"
    },
    {
      "id": "stadium",
      "label": "stadium",
      "meaning": "きょうぎじょう",
      "symbol": "🏟️"
    },
    {
      "id": "school",
      "label": "school",
      "meaning": "がっこう",
      "symbol": "🏫"
    },
    {
      "id": "museum",
      "label": "museum",
      "meaning": "はくぶつかん",
      "symbol": "🏛️"
    },
    {
      "id": "supermarket",
      "label": "supermarket",
      "meaning": "スーパー",
      "symbol": "🛒"
    },
    {
      "id": "library",
      "label": "library",
      "meaning": "としょかん",
      "symbol": "📚"
    },
    {
      "id": "train",
      "label": "train",
      "symbol": "🚆"
    },
    {
      "id": "bicycle",
      "label": "bicycle",
      "symbol": "🚲"
    },
    {
      "id": "scooter",
      "label": "scooter",
      "symbol": "🛴"
    },
    {
      "id": "clock",
      "label": "clock",
      "symbol": "🕰️"
    },
    {
      "id": "book",
      "label": "book",
      "symbol": "📖"
    },
    {
      "id": "paint",
      "label": "paint",
      "symbol": "🎨"
    },
    {
      "id": "lamp",
      "label": "lamp",
      "symbol": "💡"
    },
    {
      "id": "bus",
      "label": "bus",
      "symbol": "🚌"
    },
    {
      "id": "cat",
      "label": "cat",
      "symbol": "🐱"
    },
    {
      "id": "dog",
      "label": "dog",
      "symbol": "🐶"
    },
    {
      "id": "sun",
      "label": "sun",
      "symbol": "☀️"
    },
    {
      "id": "moon",
      "label": "moon",
      "symbol": "🌙"
    },
    {
      "id": "tree",
      "label": "tree",
      "symbol": "🌳"
    },
    {
      "id": "tent",
      "label": "tent",
      "symbol": "⛺"
    },
    {
      "id": "apple",
      "label": "apple",
      "symbol": "🍎"
    },
    {
      "id": "carrot",
      "label": "carrot",
      "symbol": "🥕"
    },
    {
      "id": "bread",
      "label": "bread",
      "symbol": "🍞"
    },
    {
      "id": "glove",
      "label": "glove",
      "symbol": "🧤"
    },
    {
      "id": "hat",
      "label": "hat",
      "symbol": "🧢"
    },
    {
      "id": "star",
      "label": "star",
      "symbol": "⭐"
    },
    {
      "id": "watch",
      "label": "watch",
      "symbol": "⌚"
    }
  ]
};
