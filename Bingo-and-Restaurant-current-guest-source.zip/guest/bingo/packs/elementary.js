export const elementaryUnits = [
  {
    "id": "review-examples",
    "grade": 3,
    "title": "Sample vocabulary",
    "book": "Offline sample sets",
    "categories": [
      {
        "id": "food",
        "title": "Snack shelf",
        "items": [
          {
            "id": "toast",
            "label": "toast",
            "meaning": "トースト",
            "symbol": "🍞"
          },
          {
            "id": "yogurt",
            "label": "yogurt",
            "meaning": "ヨーグルト",
            "symbol": "🥣"
          },
          {
            "id": "cheese",
            "label": "cheese",
            "meaning": "チーズ",
            "symbol": "🧀"
          },
          {
            "id": "peach",
            "label": "peach",
            "meaning": "もも",
            "symbol": "🍑"
          },
          {
            "id": "banana",
            "label": "banana",
            "meaning": "バナナ",
            "symbol": "🍌"
          },
          {
            "id": "pear",
            "label": "pear",
            "meaning": "なし",
            "symbol": "🍐",
            "additional": true
          },
          {
            "id": "nut",
            "label": "nut",
            "meaning": "ナッツ",
            "symbol": "🥜",
            "additional": true
          }
        ]
      },
      {
        "id": "outside",
        "title": "Outside",
        "items": [
          {
            "id": "kite",
            "label": "kite",
            "meaning": "たこ",
            "symbol": "🪁"
          },
          {
            "id": "leaf",
            "label": "leaf",
            "meaning": "はっぱ",
            "symbol": "🍃"
          },
          {
            "id": "rainbow",
            "label": "rainbow",
            "meaning": "にじ",
            "symbol": "🌈"
          },
          {
            "id": "shell",
            "label": "shell",
            "meaning": "かいがら",
            "symbol": "🐚"
          },
          {
            "id": "binoculars",
            "label": "binoculars",
            "meaning": "そうがんきょう",
            "symbol": "🔭",
            "additional": true
          }
        ]
      }
    ]
  }
];
