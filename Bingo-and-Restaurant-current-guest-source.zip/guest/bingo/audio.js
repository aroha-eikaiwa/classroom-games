const speech = window.speechSynthesis;
const REPEAT_GAP = 350;
let context;
let englishVoice;
let finishSpeech;
let voiceEnabled = true;
try { voiceEnabled = localStorage.getItem('aroha.local-bingo-v2.voice') !== 'off'; } catch { /* Storage is optional. */ }

export function isVoiceEnabled() { return voiceEnabled; }

export function setVoiceEnabled(enabled) {
  voiceEnabled = Boolean(enabled);
  if (!voiceEnabled) stopVoice();
  try { localStorage.setItem('aroha.local-bingo-v2.voice', voiceEnabled ? 'on' : 'off'); } catch { /* Storage is optional. */ }
}

function loadVoice() {
  const voices = speech?.getVoices() || [];
  const english = voice => /^en\b/i.test(voice.lang);
  englishVoice = voices.find(voice => voice.localService && /^en[-_]NZ$/i.test(voice.lang))
    || voices.find(voice => voice.localService && /^en[-_]GB$/i.test(voice.lang))
    || voices.find(voice => voice.localService && english(voice));
}
loadVoice();
speech?.addEventListener('voiceschanged', loadVoice);

export function stopVoice() {
  finishSpeech?.(false);
  speech?.cancel();
}

export function enableAudio() {
  speech?.resume();
  const Audio = window.AudioContext || window.webkitAudioContext;
  if (!Audio) return;
  try {
    context ||= new Audio();
    if (context.state === 'suspended') context.resume().catch(() => {});
  } catch { /* The wheel still runs when device audio is unavailable. */ }
}

function tone(frequency, at, duration, volume, type = 'sine', endFrequency = frequency) {
  if (!context || context.state !== 'running') return;
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.type = type;
  oscillator.frequency.setValueAtTime(frequency, at);
  oscillator.frequency.exponentialRampToValueAtTime(endFrequency, at + duration);
  gain.gain.setValueAtTime(0, at);
  gain.gain.linearRampToValueAtTime(volume, at + .004);
  gain.gain.exponentialRampToValueAtTime(.0001, at + duration);
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  oscillator.start(at);
  oscillator.stop(at + duration + .01);
}

export function tick() {
  if (context) tone(1250, context.currentTime, .035, .10, 'triangle', 650);
}

export function removeSound() {
  if (context) tone(600, context.currentTime, .22, .13, 'sine', 180);
}

export function landingSound() {
  if (context) {
    const now = context.currentTime;
    [659.25, 830.61, 987.77].forEach((frequency, index) => {
      tone(frequency, now + index * .055, .18, .09);
    });
  }
}

export function speakWord(label, { repetitions = 1, delay = 0 } = {}) {
  if (!voiceEnabled || !speech || !window.SpeechSynthesisUtterance) return null;
  stopVoice();
  loadVoice();
  if (!englishVoice) return null;
  return new Promise(resolve => {
    let settled = false;
    let remaining = repetitions;
    let heard = false;
    let timer;
    let utterance;

    function finish(spoken) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      finishSpeech = undefined;
      resolve(spoken);
    }
    finishSpeech = finish;

    function speakNext() {
      let started = false;
      timer = window.setTimeout(() => {
        // Some devices never report a speech event when their voice is unavailable.
        finish(heard || started);
        speech.cancel();
      }, 5000);

      function speakWith(voice) {
        const answer = new window.SpeechSynthesisUtterance(label);
        utterance = answer;
        answer.lang = voice?.lang || 'en-GB';
        if (voice) answer.voice = voice;
        answer.rate = .88;
        answer.pitch = 1;
        const active = () => !settled && utterance === answer;
        answer.onstart = () => { if (active()) started = true; };
        answer.onend = () => {
          if (!active()) return;
          heard = true;
          remaining--;
          if (!remaining) {
            finish(true);
            return;
          }
          utterance = undefined;
          clearTimeout(timer);
          timer = window.setTimeout(speakNext, REPEAT_GAP);
        };
        answer.onerror = event => {
          if (!active()) return;
          finish(heard || started);
        };
        try { speech.speak(answer); }
        catch { finish(heard); }
      }

      speakWith(englishVoice);
    }
    if (delay) timer = window.setTimeout(speakNext, delay);
    else speakNext();
  });
}
