// Pure vocabulary selection helpers. Ordinary words are case-insensitive;
// individual alphabet letters retain their printed upper/lower case.
export function vocabularyKey(item) {
  const label = String(item.label).normalize('NFKC').trim().replace(/\s+/g, ' ');
  return /^[A-Za-z]$/.test(label) ? 'letter:' + label : 'word:' + label.toLowerCase();
}

export function selectedCategories(categories, requested) {
  const defaults = categories.filter(category => !category.optIn).map(category => category.id);
  if (requested === undefined || requested === null) return defaults;
  const ids = new Set(requested);
  const matching = categories.filter(category => ids.has(category.id)).map(category => category.id);
  // A saved selection may refer only to topics removed from this unit.
  return ids.size && !matching.length ? defaults : matching;
}

export function combineCategories(categories, requested, additional = false) {
  const selected = new Set(selectedCategories(categories, requested));
  const identities = new Map();
  const owners = new Map();
  for (const category of categories) {
    for (const item of category.items) {
      const key = vocabularyKey(item);
      if (identities.has(key)) continue;
      const proposed = String(item.id || item.label).trim();
      identities.set(key, proposed);
      if (!owners.has(proposed)) owners.set(proposed, new Set());
      owners.get(proposed).add(key);
    }
  }
  // A source may give A and a the same slug. Resolve collisions consistently
  // against the full unit so toggling a category never changes an item's ID.
  for (const [key, proposed] of identities) {
    if (owners.get(proposed).size > 1) identities.set(key, proposed + '~' + encodeURIComponent(key));
  }
  const words = new Map();
  for (const category of categories) {
    if (!selected.has(category.id)) continue;
    for (const item of category.items) {
      if (item.additional && !additional) continue;
      const key = vocabularyKey(item);
      if (!words.has(key)) {
        words.set(key, { ...item, id: identities.get(key), meanings: new Set(), legacyIds: new Set() });
      }
      const word = words.get(key);
      if (!item.additional) delete word.additional;
      if (item.meaning) word.meanings.add(item.meaning);
      if (item.id) word.legacyIds.add(item.id);
      // The earlier elementary wheel used a lower-case label slug as its ID.
      // Keep those aliases when the expanded source uses more descriptive IDs.
      const oldId = String(item.label).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/-$/, '');
      if (oldId) word.legacyIds.add(oldId);
      for (const legacyId of item.legacyIds || []) word.legacyIds.add(legacyId);
    }
  }
  return [...words.values()].map(({ meanings, legacyIds, ...item }) => ({
    ...item, meaning: [...meanings].join(' / '), legacyIds: [...legacyIds]
  }));
}

export function roundStorageKey(pack, categoryIds, additional = false) {
  const base = 'aroha.local-bingo-v2.v1.' + pack.id + (additional ? '.additional' : '');
  if (!pack.categories) return base;
  const ids = selectedCategories(pack.categories, categoryIds);
  if (ids.length === pack.categories.length) return base;
  return base + '.categories.' + (ids.slice().sort().map(encodeURIComponent).join('+') || 'none');
}

export function restoreRound(stored, items, legacyAlphabetCase) {
  const empty = { called: [], selectedId: null };
  if (!stored || !Array.isArray(stored.called)) return empty;
  const byId = new Map(items.map(item => [item.id, item]));
  function resolve(id) {
    if (byId.has(id)) return id;
    const matches = items.filter(item => item.legacyIds?.includes(id));
    if (matches.length === 1) return matches[0].id;
    if (legacyAlphabetCase && /^[a-z]$/.test(id)) {
      const letter = legacyAlphabetCase === 'upper' ? id.toUpperCase() : id;
      return matches.find(item => item.label === letter)?.id;
    }
    return undefined;
  }
  const called = [...new Set(stored.called.map(resolve).filter(id => id !== undefined))];
  const selectedId = stored.selectedId === undefined ? called.at(-1) : resolve(stored.selectedId);
  return { called, selectedId: selectedId !== undefined && selectedId === called.at(-1) ? selectedId : null };
}
