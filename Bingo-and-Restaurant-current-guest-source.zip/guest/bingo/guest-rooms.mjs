import {RoomStore, RoomError, ensure} from './room-rules.mjs';
import { combineCategories } from './selection.js';
import { elementaryUnits } from './packs/elementary.js';
import { pack as town } from './packs/town-places.js';

const packs = new Map([...elementaryUnits, town].map(pack => [pack.id, pack]));
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const uuid = /^[\da-f]{8}-(?:[\da-f]{4}-){3}[\da-f]{12}$/i;
const codePattern = /^[A-HJ-NP-Z2-9]{6}$/;
const actions = new Set(['join','board','random','mark','start','call','end']);

function selection(body) {
  const pack = packs.get(body.pack);
  ensure(pack && [3,4,5].includes(body.size),400,'Choose a unit and board size.');
  ensure(Array.isArray(body.categories) && body.categories.every(id => pack.categories?.some(cat => cat.id === id)),400,'Choose valid topics.');
  const pool = pack.categories ? combineCategories(pack.categories, body.categories, body.additional === true) : pack.items;
  ensure(Array.isArray(body.ids) && body.ids.length <= pool.length,400,'Choose vocabulary for the room.');
  const ids = new Set(body.ids);
  const words = pool.filter(w => ids.has(w.id)).map(({id,label,symbol,image,meaning,spoken}) => ({id,label,symbol,image,meaning,spoken}));
  ensure(words.length === ids.size && words.length >= body.size ** 2,400,'Select enough words for every square.');
  return {pack:pack.id,title:pack.title,categories:body.categories,additional:body.additional===true,size:body.size,words};
}

export class GuestBingoRooms {
  rooms = new Map();

  handle(action, id, code, body) {
    try {
      const actor = {id};
      if (action === 'create') {
        for (const [key, store] of this.rooms) if (Date.now() >= store.room.expires) this.rooms.delete(key);
        ensure(uuid.test(body.nonce || ''),400,'Please try again.');
        const owned = [...this.rooms.values()].filter(store => store.room.host === id);
        const retry = owned.find(store => store.room.nonce === body.nonce);
        if (retry) return retry.handle('create',actor,{nonce:body.nonce});
        ensure(owned.filter(store => store.room.stage !== 'ended').length < 3 && owned.length < 10,429,'End an open room or wait before opening another one.');
        ensure(this.rooms.size < 200,429,'Room capacity reached. Try again later.');
        const config = selection(body);
        do {
          code = Array.from(crypto.getRandomValues(new Uint8Array(6)), byte => alphabet[byte & 31]).join('');
        } while (this.rooms.has(code));
        const store = new RoomStore();
        const result = store.handle('create', actor, {code,nonce:body.nonce,config});
        this.rooms.set(code,store);
        return result;
      }
      const room = this.rooms.get(code);
      ensure(room,404,'Room unavailable. Check the code. / コードを確認してください。');
      return room.handle(action,actor,body);
    } catch (error) {
      if (error instanceof RoomError) return {status:error.status,error:error.message};
      throw error;
    }
  }
}

export const json = (data,status=200) => new Response(data === null ? null : JSON.stringify(data),{
  status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}
});

async function requestBody(request) {
  ensure(request.headers.get('Content-Type')?.split(';')[0] === 'application/json',415,'Expected JSON.');
  const reader = request.body?.getReader();
  ensure(reader,400,'Missing request body.');
  const chunks = [];
  let size = 0;
  for (;;) {
    const {done,value} = await reader.read();
    if (done) break;
    size += value.length;
    if (size > 32768) {
      await reader.cancel();
      throw new RoomError(413,'Request too large.');
    }
    chunks.push(value);
  }
  let body;
  try { body = JSON.parse(await new Blob(chunks).text()); } catch {}
  ensure(body && typeof body === 'object' && !Array.isArray(body),400,'Invalid request.');
  return body;
}

export async function bingoRooms(request, url, rooms) {
  try {
    const [code,action,...extra] = url.pathname.slice('/api/bingo-room/'.length).split('/');
    const create = code === 'create' && !action;
    const read = !create && !action;
    ensure(!extra.length && (create || codePattern.test(code) && (read || actions.has(action))),404,'Room unavailable.');
    ensure(request.method === (read ? 'GET' : 'POST'),405,'Method not allowed.');
    if (!read) ensure(request.headers.get('Origin') === url.origin,403,'Open the demo to use rooms.');
    const id = request.headers.get('X-Bingo-Guest');
    ensure(id && uuid.test(id),401,'Open the demo to use rooms.');
    const body = read ? {since:url.searchParams.get('since'),full:url.searchParams.get('full') === '1'} : await requestBody(request);
    const room = rooms.getByName('temporary-rooms');
    const result = await room.handle(create ? 'create' : read ? 'state' : action,id,code,body);
    return json(result.error ? {error:result.error} : result.view,result.status);
  } catch (error) {
    if (error instanceof RoomError) return json({error:error.message},error.status);
    return json({error:'Room connection interrupted. / 通信を確認してください。'},503);
  }
}
