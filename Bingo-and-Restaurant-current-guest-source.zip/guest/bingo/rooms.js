import {wordPicture} from './word-pictures.js';
let guestId;
const $ = id => document.getElementById(id);
const apiRoot = '/api/bingo-room/';
const validCode = /^[A-HJ-NP-Z2-9]{6}$/;
function node(tag,text,cls) {
  const n=document.createElement(tag);
  if (text !== undefined) n.textContent=text;
  if (cls) n.className=cls;
  return n;
}
async function api(path,body) {
  const options={credentials:'omit',cache:'no-store',signal:AbortSignal.timeout(13000),headers:{'X-Bingo-Guest':guestId}};
  if (body !== undefined) Object.assign(options,{method:'POST',headers:{...options.headers,'Content-Type':'application/json'},body:JSON.stringify(body)});
  let response;
  try { response=await fetch(apiRoot+path,options); } catch { throw new Error('Connection interrupted. Please try again. / 通信を確認してもう一度試してください。'); }
  if (response.status===204) return null;
  const data=await response.json().catch(()=>({}));
  if (!response.ok) {const e=new Error(data.error || 'Room connection interrupted. / 接続できませんでした。');e.status=response.status;throw e;}
  return data;
}
export function classroom(account,wheel) {
  const teacher=account.role==='guest-host';
  guestId=account.profile.id;
  const toast=node('div',undefined,'bingo-toast');
  toast.setAttribute('role','status');toast.setAttribute('aria-live','polite');toast.hidden=true;
  document.body.append(toast);
  let toastTimer;
  const key='aroha.bingo.room.'+account.role+'.'+account.profile.id;
  let state=null,setup=null,chosen=null,busy=false,open=false,timer,nonce=null,nonceSpec,selected=null;
  let deckSignature='',boardSignature='',hostSignature='',bannerTimer;
  let byId=new Map(),drag=null,swallowClick=false,actionInProgress=false;
  const lobby=()=>state?.stage==='lobby';
  const notice=(msg='')=>{$('room-notice').textContent=msg;clearTimeout(bannerTimer); if(msg)bannerTimer=setTimeout(()=>{if($('room-notice').textContent===msg)$('room-notice').textContent='';},12000);};
  function remember(code) {
    try {if(code)localStorage.setItem(key,code);else localStorage.removeItem(key);} catch {}
    const url=new URL(location.href);
    if(code) url.searchParams.set('room',code);else url.searchParams.delete('room');
    history.replaceState(null,'',url);
  }
  function setOpen(value) {
    open=value;$('room-panel').hidden=!value;$('room-open').setAttribute('aria-expanded',String(value));
    $('room-setup').hidden=!teacher || !!state;$('room-join').hidden=teacher || !!state;
    if(!state) $('room-subtitle').textContent=teacher?'Share the code with players. Rooms last up to two hours. / コードを共有しよう。ルームは最長2時間です。':'Enter the room code. / ルームコードを入力してね。';
    if(value && teacher && !state) refreshChoices();
  }
  function refreshChoices() {
    if (!teacher || state) return;
    const pool=wheel.pool();
    const sig=JSON.stringify([pool.pack,pool.ids]);
    if(sig!==deckSignature) {
      deckSignature=sig; chosen=new Set(pool.ids);
      $('room-words').replaceChildren(...pool.words.map(w=>{
        const label=node('label'), input=node('input');input.type='checkbox';input.value=w.id;input.checked=true;
        label.append(input,wordPicture(w,pool.pack),node('span',w.label));return label;
      }));
    }
    controls();
  }
  function controls() {
    if(!state){
      const n=chosen?.size || 0,need=Number($('room-size').value)**2;
      $('room-word-count').textContent='('+n+')';
      const tooFew=wheel.pool().ids.length<need;
      $('room-need').textContent=tooFew?'Choose a unit or topics with at least '+need+' words. / '+need+'語以上になるように選んでね。'
        :n<need?'Choose '+(need-n)+' more / あと'+(need-n)+'語':n+' words / '+n+'語';
      $('room-create').disabled=busy||wheel.isMoving()||n<need;
    }
    $('room-start').disabled=busy;$('room-end').disabled=busy||wheel.isMoving();$('room-replay').disabled=busy||wheel.isMoving();
    $('room-random').disabled=busy;$('room-remove').disabled=busy||!state?.player?.board.includes(selected)||!selected;
    $('room-open').disabled=wheel.isMoving()||busy;
  }
  function planPoll(delay=2100+Math.random()*500) {
    clearTimeout(timer);
    if(state && state.stage!=='ended' && !document.hidden) timer=setTimeout(poll,delay);
  }
  async function poll() {
    if(!state || busy || actionInProgress || document.hidden) {planPoll();return;}
    const {code,version}=state;
    try {
      const v=await api(code+'?since='+version);
      if(state?.code===code && !busy && !actionInProgress && v) apply(v);
      planPoll();
    } catch(e){if(state?.code!==code)return;notice(e.message);if([401,403,404,410].includes(e.status)){exitRoom(false);return;}planPoll(5500);}
  }
  function apply(v) {
    if(!v || (state?.code===v.code && v.version<state.version)) return;
    const prev=state, first=prev?.code!==v.code;
    if(v.setup){setup=v.setup;byId=new Map(setup.words.map(w=>[w.id,w]));}
    state=v;
    if(first){boardSignature=hostSignature='';selected=null;$('word-filter').value='';remember(v.code);setOpen(true);}
    const active=v.stage!=='ended';
    document.body.classList.add('room-active');
    document.body.classList.toggle('room-student',!v.host);
    document.body.classList.toggle('room-wait',v.host && v.stage!=='playing');
    $('room-host').hidden=!v.host;$('room-student').hidden=v.host;
    const invite=new URL('./',location.href);invite.searchParams.set('join','1');invite.searchParams.set('room',v.code);
    $('room-code-show').hidden=false;$('room-code-show').textContent=v.code;
    $('room-invite').hidden=!v.host;$('room-invite').href=invite.href;
    $('room-heading').textContent=v.className || 'Bingo room / ビンゴルーム';
    $('room-subtitle').textContent=setup.title+' · '+v.size+' × '+v.size+' · '+(v.stage==='lobby'?'Preparing boards / カード作り':active?'Playing / ゲーム中':'Room ended / 終了');
    $('room-exit').hidden=active;
    if(v.host) {
      if(first)wheel.enter(setup);
      if(!wheel.isMoving())wheel.sync(v.called);
      if(first || !prev?.host || prev.stage!==v.stage)wheel.buttons();
      $('room-start').hidden=!lobby();$('room-end').hidden=!active;$('room-replay').hidden=!active||!v.count;
      const sig=JSON.stringify([v.stage,v.players]);
      if(sig!==hostSignature){
        hostSignature=sig;
        const ready=v.players.filter(p=>p.filled===v.size**2).length;
        $('room-roster-summary').textContent=v.players.length+' joined / 参加 · '+ready+' complete / カード完成';
        $('room-roster').replaceChildren(...v.players.map(p=>node('li',p.username+' · '+(p.win?'Bingo!':p.filled+'/'+v.size**2))));
        const wins=v.players.filter(p=>p.win).sort((a,b)=>a.win-b.win);
        $('room-winners').hidden=!wins.length;$('room-winner-list').replaceChildren(...wins.map(p=>node('li',p.username)));
        const newWins=wins.filter(p=>!prev?.players?.some(old=>old.username===p.username&&old.win));
        if(newWins.length && prev?.code===v.code) {
          const names=newWins.map(p=>p.username).join(', ');
          toast.textContent=toast.hidden?'Bingo! '+names:toast.textContent+', '+names;
          toast.hidden=false;clearTimeout(toastTimer);
          toastTimer=setTimeout(()=>{toast.hidden=true;toast.textContent='';},10000);
        }
      }
    } else {renderBoard();}
    controls();planPoll();
  }
  function exitRoom(clearNotice=true) {
    clearTimeout(timer);clearTimeout(toastTimer);toast.hidden=true;toast.textContent='';const wasHost=state?.host;
    state=setup=null;byId=new Map();nonce=null;selected=null;remember(null);endPointer();
    document.body.classList.remove('room-active','room-student','room-wait');
    $('room-host').hidden=$('room-student').hidden=$('room-exit').hidden=$('room-code-show').hidden=true;
    $('room-invite').hidden=true;
    $('room-heading').textContent='Bingo room / ビンゴルーム';
    if(wasHost) wheel.leave();
    setOpen(!teacher);if(clearNotice)notice();controls();
  }
  async function act(fn) {
    if(busy || actionInProgress)return;
    busy=true;controls();notice();
    try{const v=await fn();if(v)apply(v);}
    catch(e){notice(e.message);if(state && e.status===409) {try{apply(await api(state.code+'?full=1'));}catch{}}}
    finally{busy=false;controls();wheel.buttons();planPoll();}
  }
  function mutation(name,body={}) {return act(()=>api(state.code+'/'+name,body));}
  function renderBoard() {
    const p=state.player,isLobby=lobby(),n=state.size;
    const sig=JSON.stringify([state.stage,p.revision]);
    if(sig===boardSignature)return;
    const focused=document.activeElement?.closest('#bingo-sheet button,#word-bank button');
    const oldSlot=focused?.dataset.slot,oldWord=focused?.dataset.word;
    boardSignature=sig;endPointer();selected=null;
    $('student-win').hidden=!p.win;
    $('student-help').textContent=isLobby?'Drag a word onto a square, or tap a word and then a square. Empty squares fill when play starts. / 単語をドラッグ、または単語→マスの順にタップ。空いたマスは開始時にうまります。':state.stage==='playing'?'Tap a word when you hear it. / 聞こえた単語をタップして丸をつけよう。':'Game over. / ゲームは終了しました。';
    $('student-actions').hidden=$('word-tray').hidden=!isLobby;
    $('bingo-sheet').style.setProperty('--size',n);
    $('bingo-sheet').replaceChildren(...p.board.map((id,i)=>{
      const w=byId.get(id),el=node('button',undefined,'square');el.type='button';el.dataset.slot=i;
      if(w){el.dataset.word=id;el.append(wordPicture(w,setup.pack),node('span',w.label));}else{el.textContent='＋';el.dataset.empty='';}
      const marked=p.marks.includes(id);
      el.classList.toggle('marked',marked);
      el.setAttribute('aria-label',(Math.floor(i/n)+1)+'–'+(i%n+1)+' '+(w?.label || 'Empty square / 空きマス'));
      el.setAttribute('aria-pressed',String(!isLobby&&marked));el.disabled=state.stage==='ended';
      if(isLobby&&w)el.classList.add('move-word');
      return el;
    }));
    $('word-filter').hidden = !isLobby || setup.words.length < 20;
    $('word-bank').replaceChildren(...(isLobby?setup.words.filter(w=>!p.board.includes(w.id)).map(w=>{
      const b=node('button',undefined,'bank-word move-word');b.type='button';
      const handle=node('span','⠿','word-grip');handle.setAttribute('aria-hidden','true');b.append(handle,wordPicture(w,setup.pack),node('span',w.label,'bank-label'));b.dataset.word=w.id;b.setAttribute('aria-pressed','false');return b;
    }):[]));
    filterWords();
    if(oldSlot!==undefined)$('bingo-sheet').children[Number(oldSlot)]?.focus({preventScroll:true});
    else if(oldWord)Array.from($('word-bank').children).find(el=>el.dataset.word===oldWord)?.focus({preventScroll:true});
  }
  function filterWords() {
    const q=$('word-filter').value.trim().toLowerCase();
    for (const el of $('word-bank').children) {
      const w=byId.get(el.dataset.word);el.hidden=Boolean(q) && !(w.label+' '+(w.meaning||'')).toLowerCase().includes(q);
    }
  }
  $('word-filter').addEventListener('input',filterWords);
  function choose(id) {
    selected=selected===id?null:id;
    for(const w of $('room-student').querySelectorAll('.move-word'))w.setAttribute('aria-pressed',String(w.dataset.word===selected));
    controls();
  }
  function place(id,slot) {
    if(!lobby()||busy||!id)return;
    const {board,revision}=state.player, next=board.slice(),i=next.indexOf(id);
    if(i===slot)return;
    if(i>=0)next[i]=next[slot];
    next[slot]=id;void mutation('board',{board:next,revision});
  }
  $('room-student').addEventListener('click',e=>{
    if(swallowClick){swallowClick=false;return;}
    const el=e.target.closest('[data-slot],[data-word]');
    if(!el||!state||busy)return;
    const id=el.dataset.word,slot=el.dataset.slot;
    if(lobby()){
      if(slot!==undefined && selected && id!==selected)place(selected,Number(slot));
      else if(id)choose(id);
    }else if(state.stage==='playing' && id && !state.player.marks.includes(id))void mutation('mark',{word:id});
  });
  function endPointer() {
    if(!drag)return;
    drag.ghost?.remove();drag.target?.classList.remove('drop-target');
    drag=null;
  }
  const surface=$('room-student');
  surface.addEventListener('pointerdown',e=>{
    const el=e.target.closest('.move-word');
    if(!el||busy||!lobby()||!e.isPrimary||e.button!==0)return;
    if(e.pointerType==='touch' && el.classList.contains('bank-word') && !e.target.closest('.word-grip'))return;
    endPointer();swallowClick=false;drag={pid:e.pointerId,id:el.dataset.word,x:e.clientX,y:e.clientY,el};
  });
  window.addEventListener('pointermove',e=>{
    if(!drag||e.pointerId!==drag.pid)return;
    if(!drag.ghost && Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<7)return;
    if(!drag.ghost){const w=byId.get(drag.id);drag.ghost=node('div',undefined,'drag-ghost');drag.ghost.append(wordPicture(w,setup.pack),node('span',w.label));drag.ghost.setAttribute('aria-hidden','true');document.body.append(drag.ghost);drag.el.setPointerCapture(e.pointerId);}
    e.preventDefault();drag.ghost.style.left=e.clientX+'px';drag.ghost.style.top=e.clientY+'px';
    const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('#bingo-sheet [data-slot]');
    if(drag.target!==target){drag.target?.classList.remove('drop-target');target?.classList.add('drop-target');drag.target=target;}
  },{passive:false});
  window.addEventListener('pointerup',e=>{
    if(!drag||e.pointerId!==drag.pid)return;
    if(drag.ghost){swallowClick=true;setTimeout(()=>{swallowClick=false;},350);if(drag.target)place(drag.id,Number(drag.target.dataset.slot));}
    endPointer();
  });
  window.addEventListener('pointercancel',endPointer);
  $('room-open').addEventListener('click',()=>{setOpen(!open);if(open)$('room-panel').scrollIntoView({block:'nearest'});});
  $('room-size').addEventListener('change',controls);
  $('room-words').addEventListener('change',e=>{if(e.target.checked)chosen.add(e.target.value);else chosen.delete(e.target.value);controls();});
  for(const [id,on] of [['room-all',true],['room-none',false]])$(id).addEventListener('click',()=>{
    for(const input of $('room-words').querySelectorAll('input')){input.checked=on;if(on)chosen.add(input.value);else chosen.delete(input.value);}
    controls();
  });
  $('room-create').addEventListener('click',()=>act(()=>{
    const p=wheel.pool();
    const data={pack:p.pack,categories:p.categories,additional:p.additional,ids:[...chosen],size:Number($('room-size').value)};
    const fingerprint=JSON.stringify(data);
    if(!nonce || fingerprint!==nonceSpec){nonce=crypto.randomUUID();nonceSpec=fingerprint;}
    return api('create',{...data,nonce});
  }));
  $('room-join').addEventListener('submit',e=>{
    e.preventDefault();const code=$('room-code-input').value.trim().toUpperCase();
    if(!validCode.test(code)){notice('Enter the six-character room code. / 6文字のコードを入力してね。');return;}
    void act(()=>api(code+'/join',{}));
  });
  $('room-random').addEventListener('click',()=>mutation('random',{revision:state.player.revision}));
  $('room-remove').addEventListener('click',()=>{
    const p=state.player;void mutation('board',{board:p.board.map(id=>id===selected?null:id),revision:p.revision});
  });
  $('room-start').addEventListener('click',()=>mutation('start'));
  $('room-end').addEventListener('click',()=>{if(confirm('End this room for everyone? / 全員のルームを終了しますか？'))void mutation('end');});
  $('room-replay').addEventListener('click',()=>wheel.replay(byId.get(state.called.at(-1))));
  $('room-back').addEventListener('click',()=>exitRoom());
  window.addEventListener('online',poll);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void poll();});
  $('room-open').hidden=false;
  return {
    get host(){return !!state?.host;},get locked(){return !!state && (state.stage!=='playing'||!state.host||busy);},
    get state(){return state;},controls,refreshChoices,
    async call(word,index) {
      if(!state?.host)return true;
      actionInProgress=true;controls();
      try {
        const v=await api(state.code+'/call',{word,index});
        apply(v);
        return v.called.length===index+1 && v.called[index]===word;
      } catch(e){notice(e.message);return false;}
      finally {actionInProgress=false;planPoll(50);}
    },
    resync(){if(state?.host){wheel.sync(state.called);void poll();}},
    async init(){
      const param=new URL(location.href).searchParams.get('room');
      let saved;try{saved=localStorage.getItem(key);}catch{}
      const code=(param || saved || '').trim().toUpperCase();
      setOpen(!teacher);
      if(code && !validCode.test(code)){remember(null);notice('Check the six-character room code. / コードを確認してね。');}
      if(validCode.test(code))await act(async()=>{
        try{
          const v=await api(code+'/join',{});
          if(!param && v.stage==='ended'){remember(null);return null;}
          return v;
        }catch(e){if([403,404,410].includes(e.status))remember(null);throw e;}
      });
    }
  };
}
