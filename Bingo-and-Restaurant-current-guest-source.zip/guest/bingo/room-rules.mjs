export class RoomError extends Error {
  constructor(status,message) { super(message); this.status = status; }
}
export function ensure(ok,status,message) { if (!ok) throw new RoomError(status,message); }
function shuffled(values) {
  const result = values.slice();
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}
export function fill(board, words) {
  const available = shuffled(words.map(w => w.id).filter(id => !board.includes(id)));
  return board.map(id => id ?? available.pop());
}
export function completedLine(board,marks,n) {
  const marked = new Set(marks);
  const complete = (start,step) => Array.from({length:n},(_,i) => board[start + i*step]).every(id => marked.has(id));
  for (let i=0; i<n; i++) if (complete(i*n,1) || complete(i,n)) return true;
  return complete(0,n+1) || complete(n-1,n-1);
}
const missing = 'Room unavailable. Check the code. / コードを確認してください。';
const closed = 'This room has ended. / このルームは終了しました。';
const stale = 'Your board changed on another screen. Try again. / カードが更新されました。';
export class RoomStore {
  constructor() {
    this.room = null;
    this.players = new Map();
  }
  handle(action,a,input) {
    let r = this.room;
    const create = action === 'create';
    if (create) {
      if (r) ensure(r.nonce === input.nonce && r.host === a.id,409,'Code already in use.');
      else {
        r = {...input.config,code:input.code,host:a.id,nonce:input.nonce,
          stage:'lobby',version:1,called:[],expires:Date.now()+2*3600000};
        this.room = r;
      }
    }
    ensure(r && Date.now()<r.expires,404,missing);
    const host = r.host === a.id;
    const getPlayers = () => [...this.players];
    let p = !host && this.players.get(a.id);
    const length = r.size ** 2, blank = () => Array(length).fill(null);
    const changedPlayer = () => { p.revision++; this.players.set(a.id,p); };
    if (action === 'join' && !host && !p) {
      ensure(r.stage !== 'ended',410,closed);
      ensure(this.players.size < 40,409,'This room is full.');
      p = {name:"Player "+(this.players.size+1),board:r.stage === 'lobby' ? blank() : fill(blank(),r.words),marks:[],win:null,revision:0};
      this.players.set(a.id,p);
      r.version++;
    }
    ensure(host || p,404,missing);
    if (['start','call','end'].includes(action)) ensure(host,403,'Only the room host can do that.');
    if (['board','random','mark'].includes(action)) ensure(!host,403,'Student board required.');
    if (action === 'start' && r.stage === 'lobby') {
      for (const [id,student] of getPlayers()) {
        if (student.board.includes(null)) {
          student.board = fill(student.board,r.words);
          student.revision++;
          this.players.set(id,student);
        }
      }
      r.stage = 'playing'; r.version++;
    } else if (action === 'end' && r.stage !== 'ended') {
      r.stage = 'ended'; r.version++;
    } else if (action === 'board' || action === 'random') {
      ensure(r.stage === 'lobby',409,'The game has started. Your board is locked. / ゲームが始まりました。');
      ensure(input.revision === p.revision,409,stale);
      if (action === 'random') p.board = fill(blank(),r.words);
      else {
        const board = input.board, ids = new Set(r.words.map(w=>w.id));
        ensure(Array.isArray(board) && board.length === length && board.every(id=>id === null || ids.has(id)),400,'Invalid board.');
        const used = board.filter(id => id !== null);
        ensure(new Set(used).size === used.length,400,'Use each word only once.');
        p.board = board;
      }
      changedPlayer(); r.version++;
    } else if (action === 'call') {
      ensure(r.stage === 'playing',409,closed);
      ensure(input.index === r.called.length || (Number.isInteger(input.index) && input.index>=0 && r.called[input.index] === input.word),409,'Another screen called a word. The wheel has been updated.');
      ensure(r.words.some(w => w.id === input.word),400,'Word unavailable.');
      if (input.index === r.called.length) {
        ensure(!r.called.includes(input.word),409,'This word has already been called.');
        r.called.push(input.word); r.version++;
      }
    } else if (action === 'mark') {
      ensure(r.stage === 'playing',409,r.stage === 'ended' ? closed : 'Wait for the teacher to start. / 開始まで待ってね。');
      ensure(typeof input.word === 'string' && p.board.includes(input.word),400,'Choose a square on your board.');
      ensure(r.called.includes(input.word),422,'That word hasn’t been called yet. / その単語はまだ出ていません。');
      if (!p.marks.includes(input.word)) {
        p.marks.push(input.word);
        if (!p.win && completedLine(p.board,p.marks,r.size)) p.win = Date.now();
        changedPlayer(); r.version++;
      }
    }
    if (action === 'state' && input.since === String(r.version) && !input.full) return {status:204,view:null};
    const view = {code:r.code,stage:r.stage,size:r.size,version:r.version,host,expires:r.expires,count:r.called.length};
    if (create || action === 'join' || input.full === true) {
      view.setup = {pack:r.pack,title:r.title,categories:r.categories,additional:r.additional,words:r.words};
    }
    if (host) {
      view.called = r.called;
      view.players = getPlayers().map(([,s])=>({username:s.name,filled:s.board.filter(Boolean).length,win:s.win}));
    } else view.player = {board:p.board,marks:p.marks,revision:p.revision,win:p.win};
    return {status:200,view};
  }
}
