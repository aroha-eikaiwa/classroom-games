const namespace='http://www.w3.org/2000/svg';
export function wordPicture(word) {
  const svg=document.createElementNS(namespace,'svg'),text=document.createElementNS(namespace,'text');
  for(const [k,v] of Object.entries({class:'word-picture',viewBox:'0 0 112 112','aria-hidden':'true'}))svg.setAttribute(k,v);
  for(const [k,v] of Object.entries({x:'56',y:'78','text-anchor':'middle','font-size':'62'}))text.setAttribute(k,v);
  text.textContent=word.symbol||word.label;svg.append(text);return svg;
}
