import {wordPicture} from './word-pictures.js';
import { classroom } from './rooms.js';
import { pack as townPack } from './packs/town-places.js';
import { elementaryUnits } from './packs/elementary.js';
import { combineCategories, selectedCategories, roundStorageKey, restoreRound } from './selection.js';
import { enableAudio, tick, removeSound, landingSound, speakWord, stopVoice, isVoiceEnabled, setVoiceEnabled } from './audio.js';

const $ = id => document.getElementById(id);
const NS = 'http://www.w3.org/2000/svg';
const CENTER = 260, RADIUS = 225;
const FULL_LABEL_LIMIT = 40;
const THINK_TIME = 2200;
const palette = ['#ffe28a', '#a6e4d2', '#ffaba0', '#b9def3', '#f7bfda', '#d7eaa5', '#ffcb8d'];
const guestMode = new URLSearchParams(location.search).has('join');
let guestId;
try {
  guestId=localStorage.getItem('aroha.local-bingo-v2.guest');
  if(!guestId){guestId=crypto.randomUUID();localStorage.setItem('aroha.local-bingo-v2.guest',guestId);}
} catch { guestId ||= crypto.randomUUID(); }
const sharedAccount = {role:guestMode?'guest-player':'guest-host',profile:{id:guestId}};
const studentGrade = null;
const elementaryPacks = elementaryUnits.filter(unit => !studentGrade || unit.grade === studentGrade)
  .map(unit => ({ ...unit, categories: unit.categories.filter(category => category.items.length) }));
const defaultPack = elementaryPacks.find(unit => unit.grade === (studentGrade || 3)) || elementaryPacks[0] || townPack;
const packs = new Map([townPack, ...elementaryPacks].map(pack => [pack.id, pack]));
const preferenceKey = 'aroha.local-bingo-v2.active-pack';
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
let items, byId, allIds, wordNumbers, storageKey, called, selectedId, remaining, rotation;
let activePack, activeCategoryIds = [], includeAdditional = false;
const extraPreferences = new Map();
function rememberedAdditional(pack) {
  if (extraPreferences.has(pack.id)) return extraPreferences.get(pack.id);
  try { return localStorage.getItem('aroha.local-bingo-v2.additional.' + pack.id) === '1'; }
  catch { return false; }
}
let rooms, previousSelection;
let spinning = false;
let activeFrame = 0;
let drag = null;
let suppressWheelClick = false;

function option(value, title) {
  const node = document.createElement('option');
  node.value = value;
  node.textContent = title;
  return node;
}
function packTitle(pack) {
  return pack.title;
}
function populateGrades() {
  const grades = [...new Set(elementaryPacks.map(pack => pack.grade))];
  $('grade-select').replaceChildren(...grades.map(grade => {
    const unit = elementaryPacks.find(pack => pack.grade === grade);
    return option(String(grade), unit.book);
  }), option('other', 'Other word sets / その他'));
}
function populateSets(pack) {
  $('grade-select').value = pack.grade ? String(pack.grade) : 'other';
  const available = pack.grade ? elementaryPacks.filter(unit => unit.grade === pack.grade) : [townPack];
  const group = document.createElement('optgroup');
  group.label = pack.grade ? pack.book : 'Other word sets';
  for (const unit of available) {
    const count = unit.categories ? combineCategories(unit.categories, undefined, unit.id === activePack?.id ? includeAdditional : rememberedAdditional(unit)).length : unit.items.length;
    group.append(option(unit.id, packTitle(unit) + ' (' + count + ')'));
  }
  $('pack-select').replaceChildren(group);
  $('pack-select').value = pack.id;
}
function initialPackId() {
  const requested = new URLSearchParams(location.search).get('pack');
  if (requested) return packs.has(requested) ? requested : defaultPack.id;
  try { const saved = localStorage.getItem(preferenceKey); return packs.has(saved) ? saved : defaultPack.id; }
  catch { return defaultPack.id; }
}
function rememberedCategories(pack) {
  if (!pack.categories) return [];
  try {
    const ids = JSON.parse(localStorage.getItem('aroha.local-bingo-v2.categories.' + pack.id) || 'null');
    if (!Array.isArray(ids)) return undefined;
    if (!localStorage.getItem('aroha.local-bingo-v2.categories-v2.' + pack.id) && pack.previousCategories?.length === ids.length && pack.previousCategories.every(id => ids.includes(id))) return undefined;
    return selectedCategories(pack.categories, ids);
  } catch { return undefined; }
}
function initialCategories(pack) {
  const params = new URLSearchParams(location.search);
  if (params.has('categories') && (!params.get('pack') || params.get('pack') === pack.id)) {
    return params.get('categories').split(',').filter(Boolean);
  }
  return params.has('pack') ? undefined : rememberedCategories(pack);
}
function renderCategories(pack) {
  $('category-panel').hidden = !pack.categories;
  if (!pack.categories) { $('category-options').replaceChildren(); return; }
  const hasExtras = pack.categories.some(category => category.items.some(item => item.additional));
  $('additional-toggle').checked = includeAdditional;
  $('additional-toggle').disabled = !hasExtras;
  $('additional-label').textContent = 'Include additional vocabulary / 補充語を含める';
  const labels = pack.categories.map(category => {
    const label = document.createElement('label');
    label.className = 'category-choice';
    const input = document.createElement('input');
    input.type = 'checkbox'; input.value = category.id; input.name = 'category';
    const title = document.createElement('span');
    title.textContent = category.title;
    const count = document.createElement('span');
    count.className = 'category-count';
    count.textContent = combineCategories([category], [category.id], includeAdditional).length;
    label.hidden = count.textContent === '0';
    count.setAttribute('aria-label', count.textContent + ' words');
    label.append(input, title, count);
    return label;
  });
  $('category-options').replaceChildren(...labels);
}
function updateCategorySelection() {
  for (const input of $('category-options').querySelectorAll('input')) input.checked = activeCategoryIds.includes(input.value);
  if (activePack.categories) {
    $('category-summary').textContent = Array.from($('category-options').querySelectorAll('label:not([hidden]) input:checked')).length + ' / ' + $('category-options').querySelectorAll('label:not([hidden])').length + ' categories · ' + items.length + ' words';
  }
}
function updateWordList() {
  $('set-word-count').textContent = items.length;
  $('set-empty').hidden = Boolean(items.length);
  $('set-word-list').replaceChildren(...items.map(item => {
    const li = document.createElement('li');
    const word = document.createElement('span');
    word.textContent = item.label;
    li.append(wordPicture(item,activePack.id),word);
    if (item.additional) {
      const badge = document.createElement('small');
      badge.className = 'extra-word';
      badge.textContent = activePack.grade <= 4 ? '復習' : '＋';
      badge.setAttribute('aria-label', activePack.grade <= 4 ? 'Review word' : 'Additional vocabulary');
      li.append(badge);
    }
    if (item.meaning) {
      const meaning = document.createElement('small');
      meaning.textContent = item.meaning;
      meaning.lang = 'ja';
      li.append(meaning);
    }
    return li;
  }));
}
function activatePack(id, requestedCategories, additional, roomWords) {
  if (spinning || drag) return;
  const pack = packs.get(id) || defaultPack;
  const unitChanged = activePack?.id !== pack.id;
  const nextAdditional = Boolean(pack.categories?.some(category => category.items.some(item => item.additional))) &&
    (additional ?? (unitChanged ? rememberedAdditional(pack) : includeAdditional));
  const modeChanged = includeAdditional !== nextAdditional;
  activePack = pack;
  includeAdditional = nextAdditional;
  activeCategoryIds = pack.categories ? selectedCategories(pack.categories, requestedCategories) : [];
  stopVoice();
  items = roomWords || (pack.categories ? combineCategories(pack.categories, activeCategoryIds, includeAdditional) : pack.items);
  byId = new Map(items.map(item => [item.id, item]));
  allIds = items.map(item => item.id);
  wordNumbers = new Map(allIds.map((id, index) => [id, index + 1]));
  storageKey = roundStorageKey(pack, activeCategoryIds, includeAdditional);
  ({ called, selectedId } = roomWords ? {called:[],selectedId:null} : readRound());
  remaining = items.filter(item => !called.includes(item.id) || item.id === selectedId);
  rotation = selectedId ? -remaining.findIndex(item => item.id === selectedId) * 360 / remaining.length
    : remaining.length > 1 ? -180 / remaining.length : 0;
  document.body.dataset.theme = pack.theme || 'town';
  if (unitChanged || modeChanged) { populateSets(pack); renderCategories(pack); }
  updateCategorySelection();
  updateWordList();
  const host = byId.get(pack.cover) || byId.get('p76-02') || byId.get('p74-06') || items[0];
  $('host-art').replaceChildren(...(host ? [callerPicture(host)] : []));
  $('history').open = false;
  $('announcement').textContent = packTitle(pack) + '. ' + (items.length ? (items.length - called.length) + ' words left to call.' : 'Choose one or more categories.');
  drawWheel(); updateCard(); updateHistory(); updateButtons();
  rooms?.refreshChoices();
}
function rememberSelection() {
  try {
    localStorage.setItem(preferenceKey, activePack.id);
    if (activePack.categories) {
      localStorage.setItem('aroha.local-bingo-v2.additional.' + activePack.id, includeAdditional ? '1' : '0');
      localStorage.setItem('aroha.local-bingo-v2.categories.' + activePack.id, JSON.stringify(activeCategoryIds));
      localStorage.setItem('aroha.local-bingo-v2.categories-v2.' + activePack.id, '1');
    }
  } catch { /* Selection also works when storage is unavailable. */ }
  if (activePack.categories) extraPreferences.set(activePack.id, includeAdditional);
  const url = new URL(location.href);
  if (activePack.categories) url.searchParams.set('additional', includeAdditional ? '1' : '0');
  else url.searchParams.delete('additional');
  url.searchParams.set('pack', activePack.id);
  if (activePack.categories && activeCategoryIds.join(',') !== selectedCategories(activePack.categories).join(',')) url.searchParams.set('categories', activeCategoryIds.join(','));
  else url.searchParams.delete('categories');
  history.replaceState(null, '', url);
}
function readRound() {
  try {
    const stored = JSON.parse(localStorage.getItem(storageKey) || 'null');
    const alphabetCase = activePack.id === 'g3-u6' ? 'upper' : activePack.id === 'g4-u6' ? 'lower' : undefined;
    // Retain valid calls when a vocabulary bank expands or its order changes.
    return restoreRound(stored, items, alphabetCase);
  } catch { return { called: [], selectedId: null }; }
}
function saveRound() {
  if (rooms?.host) return;
  try { localStorage.setItem(storageKey, JSON.stringify({ deck: JSON.stringify(allIds), called, selectedId })); }
  catch { /* A round also works with storage disabled. */ }
}
function el(tag, attrs, value) {
  const node = document.createElementNS(NS, tag);
  for (const [name, v] of Object.entries(attrs)) node.setAttribute(name, v);
  if (value !== undefined) node.textContent = value;
  return node;
}
const mod = value => (value % 360 + 360) % 360;
function point(radius, angle) {
  const rad = (angle - 90) * Math.PI / 180;
  return [CENTER + radius * Math.cos(rad), CENTER + radius * Math.sin(rad)];
}
function splitLabel(label) {
  if (label.length < 14 || !label.includes(' ')) return [label];
  const words = label.split(' ');
  let best = 1;
  for (let i = 1; i < words.length; i++) {
    const distance = n => Math.abs(words.slice(0, n).join(' ').length - words.slice(n).join(' ').length);
    if (distance(i) < distance(best)) best = i;
  }
  return [words.slice(0, best).join(' '), words.slice(best).join(' ')];
}
function rotateTo(angle) {
  rotation = angle;
  $('rotor').setAttribute('transform', 'rotate(' + angle + ' ' + CENTER + ' ' + CENTER + ')');
}
function wheelMarker(item) {
  const numeral = /^(\d+)(st|nd|rd|th)?$/.exec(item.symbol);
  // Month pictures also use digits, but their meaning is a month, not a numeral.
  if (numeral && item.meaning?.split(' / ').includes(numeral[2] ? numeral[1] + '日' : numeral[1])) {
    return item.symbol;
  }
  return '#' + wordNumbers.get(item.id);
}
function drawWheel() {
  const count = remaining.length;
  const compact = count > FULL_LABEL_LIMIT;
  const showSliceLabels = count <= 120;
  const segments = document.createDocumentFragment();
  if (!count) {
    segments.append(el('circle', { cx:CENTER, cy:CENTER, r:RADIUS, fill:'#e5ece0' }));
    segments.append(el('circle', { cx:CENTER, cy:CENTER, r:RADIUS-3, fill:'url(#wheel-hatch)' }));
  }
  const step = 360 / Math.max(count,1);
  const iconSize = Math.min(96, 2 * 181 * Math.sin(Math.PI / Math.max(2,count)) * .88);
  remaining.forEach((item,i) => {
    const angle = i * step, start = point(RADIUS, angle-step/2), end = point(RADIUS,angle+step/2);
    const color = palette[i % palette.length];
    const marker = wheelMarker(item);
    const group = el('g', { 'data-item': item.id, class: item.id === selectedId ? 'winner' : '' });
    group.append(el('title', {}, marker + ': ' + item.label));
    if (count === 1) group.append(el('circle', { cx:CENTER, cy:CENTER, r:RADIUS, fill:color }));
    else group.append(el('path', {
      d:'M260 260 L'+start.join(' ')+' A225 225 0 '+(step>180?1:0)+' 1 '+end.join(' ')+' Z',
      fill:color, stroke:'#fffcf0', 'stroke-width':1.65, 'stroke-linejoin':'round'
    }));
    if (!compact) {
      const [ix,iy] = point(count < 8 ? (item.page ? 172 : 167) : 182,angle);
      const icon = item.image ? el('image',{href:item.image}) : wordPicture(item,activePack.id);
      icon.removeAttribute('class');
      for (const [attr,value] of Object.entries({x:ix-iconSize/2,y:iy-iconSize/2,width:iconSize,height:iconSize,transform:'rotate('+(-rotation)+' '+ix+' '+iy+')'})) icon.setAttribute(attr,value);
      group.append(icon);
    }
    const [tx,ty] = point(compact ? 180 : count < 8 ? 90 : 117,angle);
    const labelAngle = angle-90;
    const onPage = mod(labelAngle+rotation);
    const labelOrientation = labelAngle + (onPage>90 && onPage<270 ? 180 : 0);
    const lines = compact ? [marker] : count > 30 ? [item.label] : splitLabel(item.label);
    const fontSize = compact ? (count > 80 ? 9 : 12) : count > 30 ? 9.7 : count < 8 ? 12 : 10.6;
    const text = el('text', {
      'text-anchor':'middle', fill:'#29483b', 'font-size':fontSize, 'font-weight':680,
      transform:'translate('+tx+' '+ty+') rotate('+labelOrientation+')'
    });
    lines.forEach((part,j) => {
      const y=(j-(lines.length-1)/2)*fontSize*1.05+fontSize*.32;
      text.append(el('tspan', {x:0, y}, part));
    });
    if (showSliceLabels || item.id === selectedId) group.append(text);
    segments.append(group);
  });
  $('rotor').replaceChildren(segments);
  rotateTo(rotation);
  $('left-number').textContent = items.length - called.length;
  $('wheel').setAttribute('aria-label', 'Bingo wheel with ' + (items.length - called.length) + ' words left to call');
  $('wheel-guide').hidden = !compact || !remaining.some(item => wheelMarker(item).startsWith('#'));
  $('wheel-guide').textContent = 'Numbers with # refer to “Words in this set”.';
}
function addRimLights() {
  const lights = document.createDocumentFragment();
  for (let i=0; i<48; i++) {
    const [cx,cy] = point(232, i*360/48);
    lights.append(el('circle', {cx, cy:cy+0.8, r:2.9, fill:'#a74835'}));
    lights.append(el('circle', {cx, cy, r:2.5, fill: i%2 ? '#fff5c5' : '#ffc974'}));
  }
  $('rim-lights').append(lights);
}
function callerPicture(word) {
  if (!word.image) return wordPicture(word,activePack.id);
  const img=document.createElement('img');
  img.alt='';img.src=word.image;return img;
}
function updateCard(animate = false) {
  const total = called.length, item = byId.get(called[total-1]);
  const two = n => String(n).padStart(2,'0');
  $('counter').textContent = two(total)+' / '+two(items.length);
  $('counter').setAttribute('aria-label', total+' of '+items.length+' words called');
  $('host-art').hidden = Boolean(item) || !items.length;
  $('card-caption').textContent = item?.page ? 'p. ' + item.page + ' · No. ' + item.number
    : item && remaining.length > FULL_LABEL_LIMIT ? wheelMarker(item) : 'Calling card';
  $('called-art').hidden = !item;
  $('call-card').classList.toggle('called',Boolean(item));
  if (item) {
    $('called-art').replaceChildren(callerPicture(item));
    $('call-title').textContent = item.label;
    $('call-note').lang = item.meaning ? 'ja' : 'en';
    $('call-note').textContent = item.meaning || (total === items.length ? 'All words called. Round complete!' : 'Find it on your bingo card.');
  } else {
    $('called-art').replaceChildren();
    $('call-title').textContent = items.length ? 'Ready to spin?' : 'Choose a category';
    $('call-note').lang = 'en';
    $('call-note').textContent = items.length ? 'Spin the wheel to call the first word.' : 'Select one or more topics to build your wheel.';
  }
  $('call-card').classList.remove('reveal');
  if (animate && !reducedMotion.matches) {
    void $('call-card').offsetWidth;
    $('call-card').classList.add('reveal');
  }
}
function updateHistory() {
  $('history-total').textContent = called.length;
  $('history-empty').hidden = called.length>0;
  const rows=called.slice().reverse().map((id,i) => {
    const li=document.createElement('li'), num=document.createElement('span'), word=document.createElement('span');
    num.textContent=String(called.length-i).padStart(2,'0');
    const item = byId.get(id);
    word.textContent = item.label;
    if (item.page) {
      const ref = document.createElement('small');
      ref.textContent = 'p. ' + item.page + ' · No. ' + item.number;
      word.append(ref);
    }
    li.append(num,word); return li;
  });
  $('called-list').replaceChildren(...rows);
}
function updateButtons() {
  $('pack-select').disabled = spinning;
  $('grade-select').disabled = spinning;
  $('category-fieldset').disabled = spinning;
  const shown = Array.from($('category-options').querySelectorAll('label:not([hidden]) input'));
  $('categories-all').disabled = spinning || shown.every(input => input.checked);
  $('categories-clear').disabled = spinning || !shown.some(input => input.checked);
  $('reset').disabled = spinning || !called.length;
  $('spin').disabled = spinning || !items.length;
  if (rooms?.host) {
    $('pack-select').disabled = $('grade-select').disabled = $('category-fieldset').disabled = $('reset').disabled = true;
    $('spin').disabled ||= rooms.locked || !remaining.length;
  }
  const wheel = $('wheel-hit');
  wheel.disabled = rooms?.locked || (spinning && !drag) || !remaining.length;
  wheel.setAttribute('aria-label', selectedId ? 'Remove the winning wedge / 出たマスを消す' : 'Spin the bingo wheel');
  wheel.title = selectedId ? 'Tap or drag to remove the winning wedge. / タップかドラッグで、出たマスを消せます。'
    : 'Drag and flick to spin. A faster flick spins longer.';

  let labels = called.length ? ['Spin again', 'まわす'] : ['Spin the wheel', 'まわす'];
  if (!items.length) labels = ['Choose a category', 'トピックを選ぶ'];
  else if (selectedId) labels = spinning ? ['Removing…', '消しています'] : ['Remove wedge', '出たマスを消す'];
  else if (spinning) labels = ['Spinning…', '回転中'];
  else if (!remaining.length) labels = ['Start a new round', 'もう一度'];
  const [english, japanese] = labels;
  $('spin-label').textContent = english;
  $('spin-jp').textContent = japanese;
  document.body.classList.toggle('busy', spinning && !selectedId);
  if (rooms?.host && !remaining.length) $('spin-label').textContent = 'All words called';
  rooms?.controls();
}
function randomIndex(length) {
  if (!globalThis.crypto?.getRandomValues) return Math.floor(Math.random()*length);
  const max=2**32, limit=max-max%length, one=new Uint32Array(1);
  do { globalThis.crypto.getRandomValues(one); } while (one[0]>=limit);
  return one[0]%length;
}
function wordAt(angle) {
  const step = 360 / remaining.length;
  return remaining[Math.round(mod(-angle) / step) % remaining.length];
}
async function publishRoomCall(landing) {
  if (await rooms.call(wordAt(landing).id,called.length)) return true;
  spinning = false;
  rooms.resync();
  updateButtons();
  return false;
}
function finishSpin() {
  const winner = wordAt(rotation);
  document.body.classList.remove('listening');
  selectedId = winner.id;
  called.push(winner.id);
  saveRound();
  // Repaint at the landing angle so each building is upright when it is called.
  drawWheel();
  updateCard(true);
  updateHistory();
  $('announcement').textContent = 'Called ' + winner.label + '. ' + (items.length - called.length) + ' words remaining.';
  spinning = false;
  updateButtons();
  if (rooms?.host) rooms.resync();
  landingSound();
  speakWord(winner.spoken || winner.label, { delay: 290 });
}
function spinWithVoice(landing, speed, normalDuration) {
  const winner = wordAt(landing);
  const spoken = speakWord(winner.spoken || winner.label, { repetitions: 2 });
  if (!spoken) return false;

  const began = performance.now();
  const start = rotation;
  const direction = Math.sign(speed);
  const brakeTime = 900;
  let stopsAt = Infinity;
  let braking;
  document.body.classList.add('listening');
  $('host-art').hidden = true;
  $('called-art').hidden = true;
  $('call-card').classList.remove('called', 'reveal');
  $('card-caption').textContent = 'Calling card';
  $('call-title').textContent = 'Listen first!';
  $('call-note').lang = 'en';
  $('call-note').textContent = 'What does the word mean? / どんな意味かな？';

  spoken.then(heard => {
    // Keep the answer covered for a short thinking pause after both calls.
    const delay = heard ? THINK_TIME : brakeTime;
    stopsAt = Math.max(began + Math.min(normalDuration, 4200), performance.now() + delay);
    if (!heard) {
      document.body.classList.remove('listening');
      updateCard();
    }
  });

  function frame(now) {
    if (now >= stopsAt) {
      activeFrame = 0;
      rotateTo(mod(landing));
      finishSpin();
      return;
    }
    if (!reducedMotion.matches) {
      if (!braking) {
        rotateTo(start + speed * (now - began) / 1000);
        const timeLeft = stopsAt - now;
        if (timeLeft <= brakeTime) {
          const distance = mod(direction * (landing - rotation));
          const projected = Math.abs(speed) * timeLeft / 2000;
          const turns = Math.max(distance < 25 ? 1 : 0, Math.round((projected - distance) / 360));
          braking = { began: now, start: rotation, travel: direction * (distance + turns * 360) };
        }
      } else {
        const t = (now - braking.began) / (stopsAt - braking.began);
        rotateTo(braking.start + braking.travel * (2 * t - t * t));
      }
    }
    activeFrame = requestAnimationFrame(frame);
  }
  activeFrame = requestAnimationFrame(frame);
  return true;
}
async function removeSelection() {
  spinning = true;
  updateButtons();
  const slice = [...$('rotor').children].find(node => node.dataset.item === selectedId);
  removeSound();
  if (slice && !reducedMotion.matches && typeof slice.animate === 'function') {
    const animation = slice.animate(
      [{ opacity: 1, transform: 'scale(1)' }, { opacity: 0, transform: 'scale(.15)' }],
      { duration: 580, easing: 'cubic-bezier(.4,0,.8,.5)', fill: 'forwards' }
    );
    await animation.finished.catch(() => {});
  }
  remaining = remaining.filter(item => item.id !== selectedId);
  selectedId = null;
  saveRound();
  drawWheel();
  $('announcement').textContent = remaining.length ? 'Wedge removed. Spin again.' : 'Final wedge removed. Round complete.';
  spinning = false;
  updateButtons();
}
function activateWheel() {
  if (rooms?.locked || spinning || drag || !items.length) return;
  if (!remaining.length) {
    if (rooms?.host) return;
    requestReset();
    return;
  }
  enableAudio();
  if (selectedId) removeSelection();
  else spin();
}
async function spin() {
  spinning = true;
  updateButtons();
  const index = randomIndex(remaining.length), start = mod(rotation);
  const landing = mod(-index * 360 / remaining.length);
  if (rooms?.host && !await publishRoomCall(landing)) return;
  const duration = 3350;
  if (spinWithVoice(landing, 540, duration)) return;
  if (reducedMotion.matches) {
    rotateTo(landing);
    finishSpin();
    return;
  }
  const travel = 360 * 4 + mod(landing - start), began = performance.now();
  const accelerate = .115, velocity = 1 / (accelerate / 2 + (1 - accelerate) / 3);
  let lastStep = Math.floor(start / (360 / remaining.length));
  let lastTick = -Infinity;
  function frame(now) {
    const t = Math.min(1, Math.max(0, (now - began) / duration));
    const fraction = t < accelerate ? velocity * t * t / (2 * accelerate)
      : velocity * (accelerate / 2 + (1 - accelerate) / 3 * (1 - (1 - (t - accelerate) / (1 - accelerate)) ** 3));
    const angle = start + travel * fraction;
    rotateTo(angle);
    const step = Math.floor(angle / (360 / remaining.length));
    if (step !== lastStep && now - lastTick > 45) {
      tick();
      lastTick = now;
    }
    lastStep = step;
    if (t < 1) activeFrame = requestAnimationFrame(frame);
    else { activeFrame = 0; rotateTo(landing); finishSpin(); }
  }
  activeFrame = requestAnimationFrame(frame);
}
// Pointer angles use the visible wheel centre, so this also works on small screens.
function pointerAngle(event) {
  const rect = $('wheel-hit').getBoundingClientRect();
  const x = event.clientX - rect.left - rect.width / 2;
  const y = event.clientY - rect.top - rect.height / 2;
  if (Math.hypot(x, y) < rect.width * .12) return null;
  return Math.atan2(y, x) * 180 / Math.PI;
}
function startDrag(event) {
  if (rooms?.locked || drag || spinning || !remaining.length || event.button !== 0 || event.isPrimary === false) return;
  suppressWheelClick = false;
  const angle = pointerAngle(event);
  if (angle === null) return;
  drag = { id: event.pointerId, angle, distance: 0, started: false,
    samples: [{ angle: rotation, time: performance.now() }] };
  $('wheel-hit').setPointerCapture(event.pointerId);
}
function moveDrag(event) {
  if (!drag || event.pointerId !== drag.id) return;
  const angle = pointerAngle(event);
  if (angle === null) { drag.angle = null; return; }
  if (drag.angle === null) { drag.angle = angle; return; }
  const delta = mod(angle - drag.angle + 180) - 180;
  drag.angle = angle;
  drag.distance += Math.abs(delta);
  if (!drag.started) {
    if (drag.distance < 4) return;
    drag.started = true;
    suppressWheelClick = true;
    if (selectedId) return;
    spinning = true;
    enableAudio();
    updateButtons();
    document.body.classList.add('dragging');
  }
  if (selectedId) return;
  const before = Math.floor(rotation / (360 / remaining.length));
  rotateTo(rotation + delta);
  const now = performance.now();
  if (before !== Math.floor(rotation / (360 / remaining.length)) && now - (drag.lastTick || 0) > 45) {
    tick(); drag.lastTick = now;
  }
  drag.samples.push({ angle: rotation, time: now });
  // Keep a short history, including one sample just before the measurement window.
  while (drag.samples.length > 2 && drag.samples[1].time < now - 120) drag.samples.shift();
}
async function coast(velocity) {
  const start = rotation;
  const speed = Math.min(1800, Math.abs(velocity));
  const direction = velocity < 0 ? -1 : 1;
  const duration = speed / 180 * 1000;
  const travel = direction * speed * duration / 2000;
  const slice = 360 / remaining.length;
  const projected = speed < 20 || reducedMotion.matches ? start : start + travel;
  const landing = Math.round(projected / slice) * slice;
  if (rooms?.host && !await publishRoomCall(landing)) return;
  const listenSpeed = direction * Math.max(180, Math.min(840, speed));
  if (spinWithVoice(landing, listenSpeed, duration + 180)) return;
  const began = performance.now();
  let lastTick = -Infinity, lastStep = Math.floor(start / (360 / remaining.length));
  function settle() {
    const step = 360 / remaining.length;
    const target = Math.round(rotation / step) * step;
    const from = rotation, began = performance.now();
    function frame(now) {
      const t = reducedMotion.matches ? 1 : Math.min(1, (now - began) / 180);
      rotateTo(from + (target - from) * (1 - (1 - t) ** 3));
      if (t < 1) activeFrame = requestAnimationFrame(frame);
      else {
        activeFrame = 0;
        rotateTo(mod(target));
        finishSpin();
      }
    }
    activeFrame = requestAnimationFrame(frame);
  }
  if (reducedMotion.matches || speed < 20) { settle(); return; }
  function frame(now) {
    const t = Math.min(1, Math.max(0, (now - began) / duration));
    rotateTo(start + travel * (2 * t - t * t));
    const step = Math.floor(rotation / (360 / remaining.length));
    if (step !== lastStep && now - lastTick > 45) { tick(); lastTick = now; }
    lastStep = step;
    if (t < 1) activeFrame = requestAnimationFrame(frame);
    else settle();
  }
  activeFrame = requestAnimationFrame(frame);
}
function endDrag(event, cancelled = false) {
  if (!drag || drag.id !== event.pointerId) return;
  const released = drag;
  drag = null;
  document.body.classList.remove('dragging');
  if ($('wheel-hit').hasPointerCapture(event.pointerId)) $('wheel-hit').releasePointerCapture(event.pointerId);
  if (!released.started) return;
  // Consume the entire flick when a wedge is waiting to be removed.
  if (selectedId) {
    if (!cancelled) activateWheel();
    return;
  }
  updateButtons();
  const first = released.samples[0], last = released.samples.at(-1);
  const elapsed = last.time - first.time;
  const velocity = performance.now() - last.time < 100 && elapsed > 8
    ? (last.angle - first.angle) / elapsed * 1000 : 0;
  if (cancelled) { spinning = false; updateButtons(); return; }
  coast(velocity);
}
$('wheel-hit').addEventListener('pointerdown', startDrag);
$('wheel-hit').addEventListener('pointermove', moveDrag);
$('wheel-hit').addEventListener('pointerup', event => endDrag(event));
$('wheel-hit').addEventListener('pointercancel', event => endDrag(event, true));
$('wheel-hit').addEventListener('lostpointercapture', event => endDrag(event, true));

function resetRound() {
  if (spinning) return;
  if (activeFrame) cancelAnimationFrame(activeFrame);
  stopVoice();
  called=[]; selectedId=null; remaining=[...items];
  rotation=remaining.length>1 ? -180/remaining.length : 0;
  saveRound(); drawWheel(); updateCard(); updateHistory(); updateButtons();
  $('history').open=false;
  $('announcement').textContent='New round. All '+items.length+' words are back on the wheel.';
  $('spin').focus({preventScroll:true});
}
function requestReset() {
  if (rooms?.host || spinning || drag || !called.length) return;
  if (called.length===items.length) { resetRound(); return; }
  const dialog=$('reset-dialog');
  if (typeof dialog.showModal==='function') { dialog.returnValue=''; dialog.showModal(); }
  else if (window.confirm('Start a new round and return all words to the wheel?')) resetRound();
}
$('reset-dialog').addEventListener('close',() => { if ($('reset-dialog').returnValue==='reset') resetRound(); });
$('reset').addEventListener('click',requestReset);
$('spin').addEventListener('click', activateWheel);
$('wheel-hit').addEventListener('click', event => {
  if (event.detail && suppressWheelClick) { suppressWheelClick = false; return; }
  activateWheel();
});
$('grade-select').addEventListener('change', event => {
  if (spinning || drag) return;
  const pack = event.target.value === 'other' ? townPack : elementaryPacks.find(unit => unit.grade === Number(event.target.value));
  if (!pack) return;
  activatePack(pack.id, rememberedCategories(pack));
  rememberSelection();
});
$('pack-select').addEventListener('change', event => {
  if (spinning || drag) return;
  const pack = packs.get(event.target.value) || defaultPack;
  activatePack(pack.id, rememberedCategories(pack));
  rememberSelection();
});
$('category-options').addEventListener('change', event => {
  if (spinning || drag || event.target.type !== 'checkbox') return;
  const ids = [...$('category-options').querySelectorAll('input:checked')].map(input => input.value);
  activatePack(activePack.id, ids);
  rememberSelection();
});
$('categories-all').addEventListener('click', () => {
  if (spinning || drag) return;
  activatePack(activePack.id, activePack.categories.map(category => category.id));
  rememberSelection();
});
$('categories-clear').addEventListener('click', () => {
  if (spinning || drag) return;
  activatePack(activePack.id, []);
  rememberSelection();
});
$('additional-toggle').addEventListener('change', event => {
  if (spinning || drag) return;
  const enabled = event.target.checked;
  extraPreferences.set(activePack.id, enabled);
  activatePack(activePack.id, activeCategoryIds, enabled);
  rememberSelection();
});
populateGrades();
addRimLights();
const initialPack = packs.get(initialPackId()) || defaultPack;
const initialParams = new URLSearchParams(location.search);
const initialExtra = initialParams.get('additional');
activatePack(initialPack.id, initialCategories(initialPack), ['0','1'].includes(initialExtra) ? initialExtra === '1' : undefined);
rememberSelection();

function updateVoiceButton() {
  const enabled = isVoiceEnabled();
  $('voice-toggle').textContent = enabled ? 'Voice on' : 'Voice off';
  $('voice-toggle').setAttribute('aria-pressed', String(enabled));
  $('voice-toggle').title = enabled ? 'Turn the voice off' : 'Turn the voice on';
}
$('voice-toggle').addEventListener('click', () => {
  setVoiceEnabled(!isVoiceEnabled());
  updateVoiceButton();
});
updateVoiceButton();

rooms = classroom(sharedAccount,{
  isMoving:() => spinning || !!drag,
  pool:() => ({pack:activePack.id,grade:activePack.grade,categories:activeCategoryIds,additional:includeAdditional,ids:allIds,words:items}),
  chooseGrade(grade) {
    const pack = elementaryPacks.find(p=>p.grade===grade);
    if (pack) {activatePack(pack.id,rememberedCategories(pack));rememberSelection();}
  },
  enter(setup) {
    previousSelection = [activePack.id,activeCategoryIds.slice(),includeAdditional];
    activatePack(setup.pack,setup.categories,setup.additional,setup.words);
  },
  leave() {if(previousSelection)activatePack(...previousSelection);},
  sync(ids) {
    if (spinning || drag || (ids.length===called.length && ids.every((id,i)=>id===called[i]))) return;
    called=ids.slice(); selectedId=called.at(-1) || null;
    remaining=items.filter(item=>!called.includes(item.id) || item.id===selectedId);
    rotation=selectedId ? -remaining.findIndex(item=>item.id===selectedId)*360/remaining.length : 0;
    drawWheel();updateCard();updateHistory();updateButtons();
  },
  buttons:updateButtons,
  replay(word) {if(word){enableAudio();speakWord(word.spoken || word.label);}}
});
await rooms.init();
