import {createServer} from 'node:http';
import {Readable} from 'node:stream';
import {readFile} from 'node:fs/promises';
import {bingoRooms,GuestBingoRooms} from './bingo/guest-rooms.mjs';
const HOST='127.0.0.1';
const port=Number(process.env.PORT||8000);
if(!Number.isInteger(port)||port<1024||port>65535) throw Error('PORT must be 1024 to 65535');
const origin=`http://${HOST}:${port}`;
const store=new GuestBingoRooms();
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'};
const paths=new Set(['index.html','bingo/index.html','bingo/game.js','bingo/audio.js','bingo/rooms.js','bingo/rooms.css','bingo/selection.js','bingo/style.css','bingo/word-pictures.js','bingo/packs/elementary.js','bingo/packs/town-places.js','restaurant/index.html','restaurant/restaurant.css','restaurant/restaurant.mjs',...Array.from({length:8},(_,i)=>`restaurant/images/food-${i}.svg`)]);
const baseHeaders={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Permissions-Policy':'camera=(), microphone=(), geolocation=()'};
function status(res,code,text){res.writeHead(code,{'Content-Type':'text/plain; charset=utf-8',...baseHeaders});res.end(text);}
const server=createServer(async (req,res)=>{
  try{
    if(req.headers.host!==`${HOST}:${port}`)return status(res,400,'Use the printed local address.');
    const url=new URL(req.url,origin);
    if(url.origin!==origin)return status(res,400,'Use the printed local address.');
    if(url.pathname.startsWith('/api/bingo-room/')){
      const body=['GET','HEAD'].includes(req.method)?undefined:Readable.toWeb(req);
      const response=await bingoRooms(new Request(url,{method:req.method,headers:req.headers,body,duplex:'half'}),url,{getByName:()=>store});
      res.writeHead(response.status,{...baseHeaders,...Object.fromEntries(response.headers)});
      return res.end(Buffer.from(await response.arrayBuffer()));
    }
    const path=url.pathname.slice(1)+(url.pathname.endsWith('/')?'index.html':'');
    if(!paths.has(path))return status(res,404,'Not part of the offline demo.');
    if(!['GET','HEAD'].includes(req.method))return status(res,405,'Method not allowed.');
    const bytes=await readFile(new URL(path,import.meta.url));
    res.writeHead(200,{'Content-Type':mime[path.slice(path.lastIndexOf('.'))],...baseHeaders});
    res.end(req.method==='GET'?bytes:undefined);
  }catch{
    if(!res.headersSent)status(res,500,'Local demo error.');
    else res.end();
  }
});
server.listen(port,HOST,()=>console.log(`Aroha guest source review: ${origin}/`));
