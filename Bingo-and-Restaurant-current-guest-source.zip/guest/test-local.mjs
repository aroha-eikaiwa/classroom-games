import assert from 'node:assert/strict';
import {pack} from './bingo/packs/town-places.js';
const port=Number(process.env.PORT||8000);
if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Invalid PORT');
const origin='http://127.0.0.1:'+port;
const host=crypto.randomUUID(), player=crypto.randomUUID(), outsider=crypto.randomUUID();
async function api(path,id,data,expected=200,o=origin){
  const r=await fetch(origin+'/api/bingo-room/'+path,{method:data?'POST':'GET',
     headers:{'X-Bingo-Guest':id,...(data?{'Content-Type':'application/json',Origin:o}:{})},body:data&&JSON.stringify(data),signal:AbortSignal.timeout(1500)});
  const raw=await r.text();assert.equal(r.status,expected,raw);return raw?JSON.parse(raw):null;
}
for(const f of ['/','/bingo/','/bingo/rooms.js','/restaurant/','/restaurant/images/food-0.svg']) assert.equal((await fetch(origin+f)).status,200,f);
for(const f of ['/server.mjs','/bingo/guest-rooms.mjs','/api/account/session','/api/bingo-room/classes','/teacher/','/api/openai']) assert.equal((await fetch(origin+f)).status,404,f);
const config={nonce:crypto.randomUUID(),pack:pack.id,categories:[],ids:pack.items.map(x=>x.id),size:5};
await api('create',host,config,403,'https://example.invalid');
const c=await api('create',host,config); assert.match(c.code,/^[A-HJ-NP-Z2-9]{6}$/);
assert.equal((await api('create',host,config)).code,c.code);
await api(c.code,outsider,undefined,404);
const j=await api(c.code+'/join',player,{});assert.equal(j.player.board.length,25);
await api(c.code+'/start',player,{},403);
await api(c.code+'/start',host,{});
const b=(await api(c.code,player)).player.board;assert.equal(new Set(b).size,25);
await api(c.code+'/mark',player,{word:b[0]},422);
for(const [index,word] of b.slice(0,5).entries()){
  const call=await api(c.code+'/call',host,{index,word}); assert.equal(call.called.at(-1),word);
  const marked=await api(c.code+'/mark',player,{word});
  if(index===4)assert.equal(typeof marked.player.win,'number');
}
const h=await api(c.code,host);assert.equal(h.players[0].username,'Player 1');
assert.equal(await api(c.code+'?since='+h.version,host,undefined,204),null);
await api(c.code+'/end',host,{});
await api(c.code+'/join',outsider,{},410);
console.log('PASS same-origin HTTP: hub/static assets, room 5x5, duplicate create idempotent, host isolation, outsider rejection, early mark rejection, five calls to Bingo, synthetic label, end, no production/classroom paths');
