import {createWorld,currentQuestion,step,HZ,CHASE,QUESTION_COUNT} from './runner-core.mjs';
import {attachView} from './scene.mjs';
import {recordedSounds} from './audio-index.mjs';
const $=id=>document.getElementById(id);
const scenes=attachView($('view'),$('compat'));
$('view-mode').textContent=scenes.kind;
let world,mode,reason='',cueKey='',sound=null,epoch=0,queue=[],message='',gesture=null;
const sampleSeed=10975;
const laneIndex=[-1,0,1];
const laneButtons=laneIndex.map(target=>{
 const b=document.createElement('button');b.type='button';
 b.addEventListener('click',()=>{if(mode!=='run')return;queue=queue.filter(x=>!['left','right'].includes(x));for(let i=world.lane;i!==target;i+=i<target?1:-1)queue.push(i<target?'right':'left');});
 $('lanes').append(b);return b;
});
function stopAudio(){
 epoch++;
 if(sound){sound.pause();sound=null;}
 if(globalThis.speechSynthesis) speechSynthesis.cancel();
}
function render(){
 const q=currentQuestion(world),open=!world.gateResolved&&world.caughtAt===null&&!world.completed;
 $('mode').textContent={ready:'Ready',run:'Running',pause:'Paused',listen:'Listen before you continue',caught:'The boulder caught the cart!',over:'Run over',done:'All twelve crystals collected!'}[mode];
 $('score').textContent=`${world.correct} / ${QUESTION_COUNT} crystals`;
 $('gap').value=Math.max(0,world.gap);$('gap').max=CHASE.maxGap;
 $('prompt').textContent=open?q.label:world.completed?'Course complete.':world.caughtAt!==null?'The boulder caught the cart.':world.distance>=q.obstacle?'Next sound gate soon.':q.obstacleType==='jump'?'Barrier ahead: jump.':'Beam ahead: duck.';
 laneButtons.forEach((b,i)=>{
   b.textContent=open?q.options[i]:'·';
   b.disabled=!open||mode!=='run';b.setAttribute('aria-pressed',String(world.lane===i-1));
 });
 $('start').textContent=mode==='over'?'Retry':mode==='done'?'New run':mode==='ready'?'Start':'Continue';
 $('start').disabled=mode==='run'||mode==='caught';
 $('pause').disabled=mode!=='run';
 $('replay').disabled=!open||!['run','listen','pause'].includes(mode);
 $('course').disabled=mode==='run'||mode==='caught';
 $('teacher').hidden=!open||mode!=='listen';
 $('cue').textContent=open&&mode==='listen'?q.spoken:'';
 $('feedback').textContent=mode==='listen'?reason:message;
 scenes.draw(world);
}
function reset(){
 stopAudio();queue=[];world=createWorld(sampleSeed,$('course').selectedIndex===1);cueKey='';mode='ready';message='';reason='';$('teacher').open=false;render();
}
function cue(){
 const q=currentQuestion(world);if(world.gateResolved||world.caughtAt!==null||world.completed)return;
 stopAudio();
 const key=epoch;
 const reader=(why)=>{
   if(key!==epoch)return;mode='listen';reason=why;queue=[];$('teacher').open=false;render();
 };
 if($('reader').checked)return reader('Reader: give the cue aloud, then choose Continue.');
 if(q.kind==='phoneme'&&recordedSounds.includes(q.answer)){
   sound=new Audio('./sounds/'+encodeURIComponent(q.answer)+'.mp3');
   sound.addEventListener('error',()=>reader('Recording unavailable. Use the reader cue, then continue.'),{once:true});
   Promise.resolve(sound.play()).catch(()=>reader('Recording unavailable. Use the reader cue, then continue.'));
   return;
 }
 const voice=globalThis.speechSynthesis?.getVoices().find(v=>v.localService&&/^en(?:[-_]|$)/i.test(v.lang));
 if(voice&&globalThis.SpeechSynthesisUtterance){
   const line=new SpeechSynthesisUtterance(q.spoken);line.voice=voice;line.lang=voice.lang;line.rate=.76;
   line.onerror=()=>reader('Local English voice was unavailable. Ask the reader for the cue, then continue.');
   speechSynthesis.speak(line);return;
 }
 reader('This device has no local English voice for this word. Ask the reader for the cue, then continue.');
}
function pause(){if(mode==='run'){stopAudio();mode='pause';queue=[];render();}}
function begin(){
 const before=mode;
 if(before==='over'||before==='done')reset();
 if(!['listen','ready','pause'].includes(mode))return;
 mode='run';$('teacher').open=false;queue=[];
 const q=currentQuestion(world);cueKey=q.segment+':'+world.runNumber;
 if(before!=='listen')cue();
 render();
}
function action(a){if(mode==='run'&&queue.length<8)queue.push(a);}
function tick(){
 if(mode!=='run'&&mode!=='caught')return;
 if(mode==='caught'){step(world);if(world.gameOver)mode='over';return;}
 const events=step(world,queue.length?{action:queue.shift()}:undefined);
 if(events.some(e=>e.type==='caught')){stopAudio();mode='caught';queue=[];message='The boulder caught the cart.';return;}
 if(world.completed){stopAudio();mode='done';queue=[];message='Course complete.';return;}
 if(world.feedback&&world.tick<world.feedbackUntil)message=world.feedback.text;
 else message='';
 const q=currentQuestion(world),key=q.segment+':'+world.runNumber;
 if(key!==cueKey&&world.tick>=world.stunUntil){cueKey=key;cue();}
}
$('start').onclick=begin;$('pause').onclick=pause;
$('replay').onclick=()=>{if(!world.gateResolved)cue();};
$('course').onchange=reset;
$('reader').onchange=()=>{if(mode==='run'&&!world.gateResolved)cue();};
for(const button of document.querySelectorAll('[data-move]'))button.onclick=()=>action(button.dataset.move);
window.addEventListener('keydown',e=>{
 if(e.key==='Escape'){pause();return;}
 if(e.target?.matches('input, select, textarea')||(e.key===' '&&e.target?.matches('button')))return;
 const a={ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right',ArrowUp:'jump',w:'jump',' ':'jump',ArrowDown:'duck',s:'duck'}[e.key];
 if(a&&mode==='run'){e.preventDefault();if(!e.repeat)action(a);}
});
for(const canvas of [$('view'),$('compat')]){
 canvas.addEventListener('pointerdown',e=>{gesture={id:e.pointerId,x:e.clientX,y:e.clientY};canvas.setPointerCapture?.(e.pointerId);});
 canvas.addEventListener('pointermove',e=>{if(gesture?.id!==e.pointerId)return;const dx=e.clientX-gesture.x,dy=e.clientY-gesture.y;
    if(Math.max(Math.abs(dx),Math.abs(dy))>25){action(Math.abs(dx)>Math.abs(dy)?dx<0?'left':'right':dy<0?'jump':'duck');gesture=null;}});
 for(const name of ['pointerup','pointercancel'])canvas.addEventListener(name,()=>{gesture=null;});
}
window.addEventListener('blur',pause);document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
let then=performance.now(),carry=0;
const interval=1000/HZ;
function loop(now){
 if(mode==='run'||mode==='caught'){carry+=Math.min(82,now-then);while(carry>=interval&&(mode==='run'||mode==='caught')){carry-=interval;tick();}}
 else carry=0;
 then=now;render();requestAnimationFrame(loop);
}
reset();requestAnimationFrame(loop);
