import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {course,createWorld,currentQuestion,step,CHASE,BOULDER} from './runner-core.mjs';
import {buildStage,trackPoint} from './scene.mjs';
import {recordedSounds} from './audio-index.mjs';
const stage=buildStage();
assert.equal(stage.boulder.scale.x,BOULDER.halfWidth);
assert.ok(BOULDER.halfWidth>Math.abs(trackPoint(100,1).x-trackPoint(100,0).x));
assert.notEqual(trackPoint(200,0).x,trackPoint(400,0).x);
assert.notEqual(trackPoint(200,0).y,trackPoint(400,0).y);
let tested=0;
for(const advanced of [false,true])for(const seed of [17,10975,777,554]){
 const w=createWorld(seed,advanced);
 for(const q of course(seed,advanced).questions){
  if(q.kind==='phoneme')assert.ok(recordedSounds.includes(q.answer));
  assert.notEqual(q.prompt,q.answer);assert.equal(new Set(q.options).size,3);
 }
 let v;
 while(!w.completed&&!w.gameOver&&w.tick<16000){
   const q=currentQuestion(w);let action;
   if(w.lane!==q.lane)action=w.lane<q.lane?'right':'left';
   else if(q.obstacle-w.distance>0&&q.obstacle-w.distance<5&&w.tick>=w.jumpEnds&&w.tick>=w.duckEnds)action=q.obstacleType;
   step(w,action?{action}:undefined);
   if(w.tick%211===0){
     stage.update(w);
     for(const o of [stage.camera,stage.cart,stage.boulder,...stage.markers,...stage.segments])assert.ok(o.position.toArray().every(Number.isFinite));
     if(v)assert.notEqual(v[2],stage.cart.position.z);
     v=stage.cart.position.toArray();
   }
 }
 assert.ok(w.completed);assert.equal(w.correct,12);assert.deepEqual(w.rescuedIds,['owl','rabbit']);tested++;
}
for(const file of recordedSounds){
 const b=await readFile(new URL('./sounds/'+file+'.mp3',import.meta.url));
 assert.ok(b.length>500&&((b[0]===0xff&&b[1]>=0xe0)||b.subarray(0,3).toString()==='ID3'),file);
}
// Exercise the real app entry point using the DOM/audio/time boundary, no WebGL assumed.
const html=await readFile(new URL('index.html',import.meta.url),'utf8');
class El{
 constructor(){this.children=[];this.attrs={};this.events={};}
 setAttribute(k,v){this.attrs[k]=v;} append(x){this.children.push(x);}
 addEventListener(k,v){this.events[k]=v;} getContext(){return null;}
}
const els=Object.fromEntries([...html.matchAll(/id="([\w-]+)"/g)].map(([,id])=>[id,new El()]));
const globals={};
globalThis.window={addEventListener(k,fn){globals[k]=fn;}};
globalThis.document={getElementById:k=>els[k],createElement:()=>new El(),querySelectorAll:()=>[],addEventListener(k,fn){globals[k]=fn;}};
let now=0,frame;
Object.defineProperty(globalThis,'performance',{value:{now:()=>now}});
globalThis.requestAnimationFrame=fn=>{frame=fn;};
globalThis.fetch=()=>{throw Error('Unexpected request');};
let calls=[];globalThis.Audio=class {constructor(src){calls.push(src);}addEventListener(){}play(){return Promise.resolve();}pause(){}};
await import('./app.mjs');
assert.equal(els.mode.textContent,'Ready');
assert.ok(els.teacher.hidden);
els.start.onclick();
assert.equal(els.mode.textContent,'Running');
assert.match(calls[0],/^\.\/sounds\/\w+\.mp3$/);
assert.ok(els.teacher.hidden);
els.pause.onclick();assert.equal(els.mode.textContent,'Paused');
els.reader.checked=true;
els.start.onclick();assert.match(els.mode.textContent,/Listen/);
assert.ok(!els.teacher.hidden);
assert.equal(els.cue.textContent,currentQuestion(createWorld(10975)).spoken);
els.start.onclick();assert.ok(els.teacher.hidden);
const q=currentQuestion(createWorld(10975));
const wrong=q.lane===-1?2:0;
els.lanes.children[wrong].events.click();
for(let i=0;i<320&&els.mode.textContent!=='Run over';i++){now+=50;frame(now);}
assert.equal(els.mode.textContent,'Run over');
assert.equal(els.gap.value,0);
els.start.onclick();assert.match(els.mode.textContent,/Listen/);
assert.equal(els.score.textContent,'0 / 12 crystals');
console.log('PASS '+tested+' complete continuous sound courses, actual 3D scene transforms, procedural full-width boulder/curved rails, '+recordedSounds.length+' local MP3s, UI start/autocue/pause/reader/wrong+caught/retry. WebGL rendering not exercised.');
