import * as T from './vendor/three.module.js';
import {pose,currentQuestion,boulderBehind,catchProgress,BOULDER,LENGTH} from './runner-core.mjs';

// Track center and altitude from the current Crystal Mine Cart renderer.
export function trackPoint(distance,lane,seed=0){
 const d=Math.max(0,Math.min(LENGTH,distance)),phase=(seed%97)*.017;
 return {x:Math.sin(d/105+phase)*12+Math.sin(d/245)*15+lane*4.6,y:Math.sin(d/115)*2.2+Math.sin(d/300)*3+Math.abs(lane)*Math.sin(d/70)*.6,z:-d};
}
const point=(distance,lane,seed)=>{const {x,y,z}=trackPoint(distance,lane,seed);return new T.Vector3(x,y,z);};
const mat=(color,emissive=0)=>new T.MeshStandardMaterial({color,emissive,roughness:.87});
const cube=new T.BoxGeometry(1,1,1);
const crystal=new T.OctahedronGeometry(1,0);
const rockGeo=new T.IcosahedronGeometry(1,1);
const fit=(o,x,y,z)=>{o.scale.set(x,y,z);return o;};
export function buildStage(){
 const scene=new T.Scene();scene.background=new T.Color(0x0b1623);scene.fog=new T.Fog(0x111e2b,40,124);
 const camera=new T.PerspectiveCamera(64,1,.1,155);
 scene.add(new T.HemisphereLight(0xa5dbef,0x544156,1.6));
 const lantern=new T.PointLight(0xffd987,53,42,2);scene.add(lantern);
 const floor=mat(0x26323b), metal=mat(0xc2cad8), wood=mat(0x91664d), walls=mat(0x324050), gems=mat(0x49d2c9,0x146661), gold=mat(0xffac46,0x683514), iron=mat(0x485468), red=mat(0xed7754,0x6e2718), blue=mat(0x536ab2), skin=mat(0xd39360), dark=mat(0x49352a);
 const mesh=(geometry,material)=>new T.Mesh(geometry,material);
 function box(parent,m,x,y,z){const o=fit(mesh(cube,m),x,y,z);parent.add(o);return o;}
 const segments=[];
 for(let i=0;i<47;i++){
   const g=new T.Group();scene.add(g);
   box(g,floor,27,.45,3.35).position.y=-.33;
   for(let lane=-1;lane<=1;lane++){
      for(const off of [-.91,.91]){const rail=box(g,metal,.17,.14,3.35);rail.position.x=4.6*lane+off;rail.position.y=.12;}
      for(const z of [-1.15,0,1.15]){const tie=box(g,wood,2.45,.16,.25);tie.position.set(lane*4.6,0,z);}
   }
   for(const side of [-1,1]){
      const wall=fit(mesh(rockGeo,walls),5,7,3.2);wall.position.set(side*(14.8+i%3*.15),4,0);wall.rotation.z=side*.22;g.add(wall);
      if(i%4===0){const gem=fit(mesh(crystal,gems),.58,2.4,.8);gem.position.set(side*11.5,1.7,-.3);gem.rotation.z=side*.26;g.add(gem);}
   }
   if(i%4===0){
      for(const x of [-10.4,10.4]){const o=box(g,wood,.43,7.5,.55);o.position.set(x,3.65,0);}
      const beam=box(g,wood,21.4,.46,.55);beam.position.y=7.25;
   }
   segments.push(g);
 }
 const cart=new T.Group();scene.add(cart);
 box(cart,iron,2,1.03,2.55).position.y=.8;
 box(cart,gold,2.14,.23,2.62).position.y=1.28;
 for(const x of [-1.07,1.07])for(const z of [-.76,.76]){
   const o=mesh(new T.CylinderGeometry(.36,.36,.16,12),dark);o.rotation.z=Math.PI/2;o.position.set(x,.38,z);cart.add(o);
 }
 const rider=new T.Group();cart.add(rider);
 box(rider,blue,.69,.85,.42).position.y=1.56;
 const head=mesh(new T.SphereGeometry(.39,16,10),skin);head.position.y=2.10;rider.add(head);
 const cap=mesh(new T.SphereGeometry(.4,16,8,0,Math.PI*2,0,Math.PI*.58),dark);cap.position.set(0,2.18,.065);rider.add(cap);
 const boulder=fit(mesh(rockGeo,walls),BOULDER.halfWidth,BOULDER.height,BOULDER.depth);scene.add(boulder);
 const markers=[-1,0,1].map(()=>{
   const g=new T.Group();const base=box(g,gems,3.5,.38,.33);base.position.y=.35;scene.add(g);
   if(typeof document!=='undefined'){
     const sign=document.createElement('canvas');sign.width=128;sign.height=128;const ctx=sign.getContext('2d');
     if(ctx){
       const texture=new T.CanvasTexture(sign);texture.colorSpace=T.SRGBColorSpace;
       const panel=new T.Mesh(new T.PlaneGeometry(2.6,2.6),new T.MeshBasicMaterial({map:texture,side:T.DoubleSide}));
       panel.position.y=2.0;g.add(panel);
       g.userData.label=word=>{if(g.userData.word===word)return;g.userData.word=word;ctx.fillStyle='#172f39';ctx.fillRect(0,0,128,128);ctx.strokeStyle='#bde8dc';ctx.lineWidth=7;ctx.strokeRect(5,5,118,118);ctx.fillStyle='#fff7d8';ctx.font='bold 69px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(word,64,67);texture.needsUpdate=true;};
     }
   }
   return g;
 });
 const obstacle=new T.Group();scene.add(obstacle);const beam=box(obstacle,red,14,.32,.56);
 const uprights=[-6.7,6.7].map(x=>{const o=box(obstacle,wood,.26,2.8,.31);o.position.set(x,1.4,0);return o;});
 function angle(d,seed){const v=point(d+1,0,seed).sub(point(d-1,0,seed));return Math.atan2(-v.x,-v.z);}
 function update(w){
   const {seed,distance}=w,chunk=Math.floor(distance/3.3)-6;
   segments.forEach((g,i)=>{const d=(chunk+i)*3.3;g.visible=d>=0;g.position.copy(point(d,0,seed));g.rotation.y=angle(d,seed);});
   const a=pose(w),at=point(distance,a.lane,seed);cart.position.copy(at);cart.position.y+=a.jumpY;
   cart.rotation.y=angle(distance,seed);rider.position.y=a.duck?-.49:0;rider.rotation.x=a.duck?-.42:a.jumpY*.075;
   const back=boulderBehind(w);boulder.position.copy(point(distance,0,seed));boulder.position.z+=back;boulder.position.y+=BOULDER.height;
   boulder.rotation.x=distance*.065+catchProgress(w)*6;
   const q=currentQuestion(w);
   markers.forEach((g,i)=>{g.visible=!w.gateResolved&&w.caughtAt===null;g.position.copy(point(q.gate,i-1,seed));g.rotation.y=angle(q.gate,seed);g.userData.label?.(q.options[i]);});
   obstacle.visible=w.caughtAt===null;obstacle.position.copy(point(q.obstacle,0,seed));obstacle.rotation.y=angle(q.obstacle,seed);
   beam.position.y=q.obstacleType==='jump'?.58:2.74;uprights.forEach(p=>{p.visible=q.obstacleType==='duck';});
   lantern.position.copy(at);lantern.position.y+=4;lantern.position.z-=7;
   camera.position.set(at.x+6,at.y+12,at.z+20);const target=point(distance+25,0,seed);target.y+=2;camera.lookAt(target);
 }
 return {scene,camera,cart,boulder,markers,obstacle,segments,update};
}
function fallback(canvas){
 const ctx=canvas.getContext('2d');
 if(!ctx) return {kind:'Text controls only',draw(){}};
 return {kind:'Compatibility view (2D)',draw(w){
   const width=canvas.clientWidth||640,height=canvas.clientHeight||410;
   if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;}
   ctx.fillStyle='#121f2b';ctx.fillRect(0,0,width,height);
   ctx.strokeStyle='#91a7ab';ctx.lineWidth=3;
   for(let i=-2;i<=2;i++)if(i!==0){ctx.beginPath();ctx.moveTo(width/2+i*width*.036,height*.23);ctx.lineTo(width/2+i*width*.17,height);ctx.stroke();}
   const q=currentQuestion(w),a=pose(w);
   if(!w.gateResolved){ctx.fillStyle='#47a49a';const y=height*(.26+Math.max(0,1-(q.gate-w.distance)/82)*.38);
      for(let i=-1;i<=1;i++)ctx.fillRect(width/2+i*width*.19-15,y,30,14);
   }
   ctx.fillStyle='#eaaa4e';ctx.fillRect(width/2+a.lane*width*.19-22,height*.75-a.jumpY*11,44,a.duck?14:25);
   ctx.fillStyle='#63758a';ctx.beginPath();ctx.ellipse(width/2,height*(.96-catchProgress(w)*.21),width*.32,height*.09,0,0,Math.PI*2);ctx.fill();
 }};
}
export function attachView(canvas,compat){
 try{
   const stage=buildStage();
   const renderer=new T.WebGLRenderer({canvas,antialias:true});renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.7));
   let lastW=0,lastH=0;
   return {kind:'3D WebGL',draw(w){
     const width=canvas.clientWidth||640,height=canvas.clientHeight||410;
     if(width!==lastW||height!==lastH){renderer.setSize(width,height,false);stage.camera.aspect=width/height;stage.camera.updateProjectionMatrix();lastW=width;lastH=height;}
     stage.update(w);renderer.render(stage.scene,stage.camera);
   }};
 }catch{
   canvas.hidden=true;compat.hidden=false;return fallback(compat);
 }
}
