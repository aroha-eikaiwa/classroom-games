// @ts-nocheck
// Intentionally plain JavaScript: this exact module runs in Deno and the browser.
export const RUNNER_VERSION=3, HZ=60, SECTION=180, QUESTION_COUNT=12, LENGTH=SECTION*QUESTION_COUNT*2;
export const ACTIONS=['left','right','jump','duck','restart'];
export const CHASE={maxGap:28,hitLoss:14,recoverDelay:12*HZ,recoverPerSecond:1.8,catchTicks:96};
export const BOULDER={halfWidth:6.7,height:2.6,depth:3.3};
export function runSpeed(w){return Math.min(27,18+Math.max(0,w.tick-w.runStarted)/HZ*.065);}
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const words=['sat','mat','pin','tap','map','sit','pan','nap'];
const later=['dog','bed','gum','hen','fox','box','quit','quiz'];
function random(seed){let s=seed>>>0;return()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};}
function shuffled(items,rng){const a=[...items];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
const cache=new Map();
export function course(seed,advanced=false){
 const key=(seed>>>0)+':'+advanced;if(cache.has(key))return cache.get(key);
 const rng=random(seed^0x573ac19),letters=advanced?'bdgchrlvwyzjeou':'satpinmf';
 const pool=shuffled(advanced?later:words,rng);
 const questions=Array.from({length:QUESTION_COUNT},(_,i)=>{
  let answer,prompt,label,spoken,kind;
  if(i%3===0){answer=letters[(Math.floor(rng()*letters.length)+i)%letters.length];prompt='🔊';label='きこえた音は？ / Listen to the sound';spoken=answer;kind='phoneme';}
  else {const word=pool[Math.floor(i/3)*2+(i%3-1)];const at=i%3===1?0:word.length-1;answer=at===0&&word.startsWith('qu')?'qu':word[at];prompt='🔊';label=i%3===1?'はじめの音は？ / First sound':'おわりの音は？ / Last sound';spoken=word;kind='sound';}
  const distractors=shuffled([...new Set(letters+'satpinmf')].filter(x=>x!==answer),rng).slice(0,2);
  const options=shuffled([answer,...distractors],rng);
  return Object.freeze({index:i,kind,prompt,label,spoken,answer,options:Object.freeze(options),lane:options.indexOf(answer)-1,gate:i*SECTION+82,obstacle:i*SECTION+145,obstacleType:i%2===0?'jump':'duck'});
 });
 const result=Object.freeze({questions:Object.freeze(questions),length:LENGTH});if(cache.size>=64)cache.delete(cache.keys().next().value);cache.set(key,result);return result;
}
export function createWorld(seed,advanced=false,save){
 const initial={runnerVersion:RUNNER_VERSION,seed:seed>>>0,advanced,tick:0,runStarted:0,runNumber:1,distance:0,lane:0,fromLane:0,laneStarted:0,jumpStarted:-60,jumpEnds:0,duckEnds:0,stunUntil:0,gap:CHASE.maxGap,lastHit:-CHASE.recoverDelay,correct:0,questionIndex:0,section:0,gateResolved:false,gatePassed:false,mistakes:0,catches:0,falls:0,rescuedIds:[],completed:false,caughtAt:null,gameOver:false,feedback:null,feedbackUntil:0};
 if(save?.runnerVersion===RUNNER_VERSION)return {...initial,...save,seed:initial.seed,advanced,rescuedIds:[...(save.rescuedIds||[])]};
 return {...initial,rescuedIds:[...(save?.rescuedIds||[])],migrated:!!save};
}
export function pose(w){
 const t=clamp((w.tick-w.laneStarted)/10,0,1),smooth=t*t*(3-2*t);
 return {lane:w.fromLane+(w.lane-w.fromLane)*smooth,jumpY:w.tick<w.jumpEnds?Math.sin((w.tick-w.jumpStarted)/48*Math.PI)*2.6:0,duck:w.tick<w.duckEnds};
}
export function catchProgress(w){return w.caughtAt===null?0:clamp((w.tick-w.caughtAt)/CHASE.catchTicks,0,1);}
export function boulderBehind(w){return BOULDER.depth+1.9+w.gap*.28-catchProgress(w)*12;}
export function currentQuestion(w){
 const q=course(w.seed,w.advanced).questions[Math.min(QUESTION_COUNT-1,w.questionIndex)];
 return {...q,segment:w.section,gate:w.section*SECTION+82,obstacle:w.section*SECTION+145,obstacleType:w.section%2===0?'jump':'duck'};
}
function feedback(w,type,text){w.feedback={type,text};w.feedbackUntil=w.tick+140;}
function catchCart(w,events){
 if(w.caughtAt!==null)return;w.catches++;w.gap=0;w.caughtAt=w.tick;w.jumpEnds=0;w.duckEnds=0;
 feedback(w,'caught','岩に つかまった！ / Caught by the boulder!');events.push({type:'caught'});
}
function stumble(w,events,type,text){
 w.falls++;w.gap=Math.max(0,w.gap-CHASE.hitLoss);w.lastHit=w.tick;w.stunUntil=w.tick+36;
 feedback(w,type,text);events.push({type});if(w.gap<=0)catchCart(w,events);
}
export function step(w,input){
 const events=[],action=input?.action;
 if(w.completed)return events;
 if(w.gameOver){
  if(action!=='restart')return events;
  const tick=w.tick,runNumber=w.runNumber+1,catches=w.catches,rescuedIds=[...w.rescuedIds];
  Object.assign(w,createWorld(w.seed,w.advanced),{tick,runStarted:tick,runNumber,catches,rescuedIds});events.push({type:'restart'});
 }
 w.tick++;
 if(w.caughtAt!==null){if(w.tick-w.caughtAt>=CHASE.catchTicks){w.gameOver=true;events.push({type:'gameover'});}return events;}
 if(w.tick>=w.stunUntil&&action){
  if(action==='left'||action==='right'){w.fromLane=pose(w).lane;w.lane=clamp(w.lane+(action==='left'?-1:1),-1,1);w.laneStarted=w.tick;}
  if(action==='jump'&&w.tick>=w.jumpEnds){w.jumpStarted=w.tick;w.jumpEnds=w.tick+48;w.duckEnds=0;}
  if(action==='duck'&&w.tick>=w.jumpEnds&&w.tick>=w.duckEnds)w.duckEnds=w.tick+55;
 }
 const q=currentQuestion(w),before=w.distance,speed=runSpeed(w)*(w.tick<w.stunUntil?.5:1);w.distance=before+speed/HZ;
 if(w.tick-w.lastHit>CHASE.recoverDelay)w.gap=Math.min(CHASE.maxGap,w.gap+CHASE.recoverPerSecond/HZ);
 if(!w.gateResolved&&before<q.gate&&w.distance>=q.gate){
  w.gateResolved=true;w.gatePassed=Math.abs(pose(w).lane-q.lane)<.42;
  if(!w.gatePassed){w.mistakes++;stumble(w,events,'wrong',q.kind==='phoneme'?'音 → '+q.answer+'。つぎで もういちど！':q.spoken+' → '+q.answer+'。つぎで もういちど！');}
  else {w.correct++;feedback(w,'correct',q.kind==='phoneme'?'音 → '+q.answer+' ✓':q.spoken+' → '+q.answer+' ✓');events.push({type:'correct'});
   const friend=w.correct===4?'owl':w.correct===10?'rabbit':null;if(friend&&!w.rescuedIds.includes(friend)){w.rescuedIds.push(friend);events.push({type:'rescue',id:friend});feedback(w,'rescue',friend==='owl'?'フクロウが なかまに！ / Owl rescued!':'ウサギが なかまに！ / Rabbit rescued!');}
  }
 }
 if(w.caughtAt===null&&before<q.obstacle&&w.distance>=q.obstacle){
  const safe=q.obstacleType==='jump'?pose(w).jumpY>.55:pose(w).duck;
  if(!safe)stumble(w,events,'bump',q.obstacleType==='jump'?'↑ ジャンプ！ / Jump over the barrier':'↓ しゃがもう！ / Duck under the beam');
 }
 if(w.caughtAt===null&&w.distance>=(w.section+1)*SECTION){
  if(w.correct>=QUESTION_COUNT){w.completed=true;w.distance=(w.section+1)*SECTION;events.push({type:'finish'});}
  else {w.section++;w.questionIndex=w.correct;w.gateResolved=false;w.gatePassed=false;}
 }
 return events;
}
export function savedWorld(w,startedAt,now){const {seed,advanced,...state}=w;return {...state,rescuedIds:[...w.rescuedIds],startedAt,updatedAt:now};}
export function journeyWithWorld(journey,w,now,startedAt=now){
 const rescuedIds=[...new Set([...journey.rescuedIds,...w.rescuedIds])];
 return {...journey,steps:journey.steps+1,minecart:savedWorld(w,startedAt,now),rescuedIds,encounteredIds:[...new Set([...(journey.encounteredIds||[]),...rescuedIds])],lives:Math.min(2,journey.lives+rescuedIds.length-journey.rescuedIds.length),letterIndex:w.completed?26:Math.min(25,Math.floor(w.correct/QUESTION_COUNT*26)),nodeId:w.completed?'boss':'minecart-'+w.section,status:w.completed?'ready':'exploring'};
}
