import test from 'node:test';
import assert from 'node:assert/strict';
import {makeServer} from './server.mjs';
import {randomUUID} from 'node:crypto';
import {Script} from 'node:vm';
import {request} from 'node:http';

test('private listener accepts no wildcard, tunnel hostname, or public address',()=>{
 for(const ip of ['0.0.0.0','8.8.8.8','demo.example','172.32.0.1']) assert.throws(()=>makeServer(ip));
});
test('browser files, local identities, host/turn protection, acknowledgements and arcade',async t=>{
 const server=makeServer();
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 t.after(()=>new Promise(resolve=>server.close(resolve)));
 const base='http://127.0.0.1:'+server.address().port;
 async function post(route,body,status=200,token,extra){
  const res=await fetch(base+'/api/'+route,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...extra},body:JSON.stringify(body)});
  const data=(res.headers.get('content-type')||'').includes('json')?await res.json():await res.text();
  assert.equal(res.status,status,route+' '+JSON.stringify(data));return data;
 }
 for(const url of ['/','/boards.html','/star/','/haunted/','/room-host.js','/network-oct23.js','/lan-compat.js']) {
  const res=await fetch(base+url);assert.equal(res.status,200,url);
  assert.match(res.headers.get('permissions-policy'),/microphone=\(\)/);
  const body=await res.text();assert.doesNotMatch(body,/aroha-eikaiwa\.com|openai\.com/);
  if(url.endsWith('/')){
   for(const [,source,inline] of body.matchAll(/<script\b(?:[^>]*?src="([^"]+)")?[^>]*>(.*?)<\/script>/gs)){
    if(source){
     const js=await fetch(new URL(source,base+url));assert.equal(js.status,200,source);
     new Script(await js.text(),{filename:source});
    }else if(inline.trim())new Script(inline,{filename:url});
   }
  }
 }
 assert.equal((await fetch(base+'/server.mjs')).status,404);
 assert.equal((await fetch(base+'/schema.sql')).status,404);
 const wrongHost=await new Promise((ok,reject)=>request(base,{headers:{Host:'example.com'}},r=>{r.resume();ok(r.statusCode);}).on('error',reject).end());
 assert.equal(wrongHost,403);
 await post('rooms',{},403,null,{Origin:'https://example.com'});
 await post('voice-session',{},404);await post('arcade-speech',{},404);await post('speech-failures',{},404);
 for(const theme of ['star','haunted']){
  const avatars=theme==='star'?['star-leo','star-mia']:['ghost','bat'];
  const state={version:1,actions:[],theme,phase:'lobby',mode:'own',roster:[]};
  const {code,hostToken}=await post('rooms',{state},201);
  const hostBody={code,hostToken};
  const join=()=>post('join',{code});
  const a=await join(),b=await join();
  await post('start',{...hostBody,hostToken:'wrong'},403);
  await post('start',hostBody,409);
  await post('register',{code,name:'Synthetic A',avatar:avatars[0]},200,a.controllerToken);
  await post('register',{code,name:'Synthetic B',avatar:avatars[1]},200,b.controllerToken);
  const {players}=await post('start',hostBody);
  assert.deepEqual(players.map(p=>p.name),['Synthetic A','Synthetic B']);
  const [first,second]=players;
  Object.assign(state,{phase:'turn',actions:['roll'],version:2,roster:players,activePlayerId:first.id});
  await post('host',{...hostBody,state});
  await post('state',{code},401);
  assert.deepEqual((await post('state',{code},200,b.controllerToken)).state.actions,[]);
  assert.deepEqual((await post('state',{code},200,a.controllerToken)).state.actions,['roll']);
  const input={code,action:'roll',version:2,requestId:randomUUID(),diceSync:true};
  await post('action',input,409,b.controllerToken);
  await post('action',{...input,version:1},409,a.controllerToken);
  const q=await post('action',input,202,a.controllerToken);
  assert.equal((await post('action',input,200,a.controllerToken)).id,q.id);
  assert.equal((await post('host',{...hostBody,state})).commands[0].id,q.id);
  await post('host',{...hostBody,state:{...state,actions:[],version:3},acks:[{id:q.id,result:'applied'}]});
  assert.equal((await post('state',{code,pendingId:q.id},200,a.controllerToken)).result,'applied');
  await post('leave',{code},200,a.controllerToken);
  const again=await post('join',{code,reconnectToken:a.controllerToken});
  assert.equal(again.state.you.id,first.id);
  await post('leave',{code},200,a.controllerToken);
  assert.equal((await post('state',{code},200,again.controllerToken)).state.you.id,first.id);
  const c=await join();
  await post('register',{code,name:'Synthetic A',avatar:avatars[0]},409,c.controllerToken);
  await post('leave',{code},200,again.controllerToken);
  assert.equal((await post('register',{code,name:'Synthetic A',avatar:avatars[0]},200,c.controllerToken)).state.you.id,first.id);
  const key='synthetic-round';
  const arcadeState={...state,phase:'arcadeIntro',actions:[],version:4,arcade:{key,startRequested:true,miniGames:['rps'],voice:true}};
  const setup=await post('host',{...hostBody,state:arcadeState});
  assert.equal(setup.arcade.kind,'rps');
  await post('arcade',{code,key:'unrelated',stage:0,requestId:randomUUID(),type:'choice',choice:'rock'},409,c.controllerToken);
  await new Promise(resolve=>setTimeout(resolve,Math.max(0,setup.arcade.startAt-Date.now()+40)));
  const command={code,key,stage:0,requestId:randomUUID(),type:'choice',choice:'rock'};
  const choice=await post('arcade',command,200,c.controllerToken);
  assert.equal(choice.arcade.you.chosen,true);
  assert.equal((await post('arcade',command,200,c.controllerToken)).arcade.you.choice,'rock');
  await post('arcade',{...command,requestId:randomUUID(),choice:'paper'},409,c.controllerToken);
  const arc=await post('arcade-skip',{...hostBody,key});
  assert.equal(arc.arcade.status,'results');
  await post('close',hostBody);await post('state',{code},404,c.controllerToken);
 }
});
