PRAGMA foreign_keys = ON;
CREATE TABLE rooms (code TEXT PRIMARY KEY,host_hash TEXT NOT NULL,state TEXT NOT NULL,version INTEGER NOT NULL,created INTEGER NOT NULL,touched INTEGER NOT NULL);
CREATE TABLE players (id TEXT PRIMARY KEY,code TEXT NOT NULL REFERENCES rooms(code) ON DELETE CASCADE,slot INTEGER NOT NULL,name TEXT NOT NULL,avatar TEXT NOT NULL,joined_at INTEGER NOT NULL,UNIQUE(code,slot));
CREATE TABLE sessions (hash TEXT PRIMARY KEY,code TEXT NOT NULL REFERENCES rooms(code) ON DELETE CASCADE,created INTEGER NOT NULL,last_seen INTEGER NOT NULL,player_id TEXT,active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE commands (id INTEGER PRIMARY KEY,code TEXT NOT NULL REFERENCES rooms(code) ON DELETE CASCADE,request_id TEXT NOT NULL,version INTEGER NOT NULL,action TEXT NOT NULL,created INTEGER NOT NULL,payload TEXT,actor TEXT NOT NULL,mini_key TEXT,result TEXT,UNIQUE(code,request_id));
CREATE UNIQUE INDEX command_turn ON commands(code,version,actor) WHERE action NOT IN ('miniSubmit','diceSettled') AND action NOT LIKE 'shared%';
CREATE UNIQUE INDEX command_mini ON commands(code,actor,mini_key) WHERE mini_key IS NOT NULL;
CREATE TABLE mini_games (code TEXT PRIMARY KEY REFERENCES rooms(code) ON DELETE CASCADE, game_key TEXT NOT NULL,state TEXT NOT NULL,version INTEGER NOT NULL);
CREATE TABLE limits (key TEXT PRIMARY KEY,start INTEGER NOT NULL,hits INTEGER NOT NULL);
