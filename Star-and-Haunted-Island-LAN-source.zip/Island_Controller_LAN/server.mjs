import {createServer} from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {readFile,stat} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {resolve,extname} from 'node:path';
import {api} from './room-api.js';

const policy="default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'none'; media-src 'none'; frame-src 'none'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'; form-action 'none'";
const web=fileURLToPath(new URL('./web/',import.meta.url));
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'};
export function makeServer(host='127.0.0.1'){
  // No wildcard, DNS hostname, public IP or public proxy. Scope this plain-HTTP
  // demo to loopback or one explicitly chosen RFC1918 interface.
  const privateIP=/^(?:10\.\d{1,3}|192\.168|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}$/;
  if(host!=='127.0.0.1'&&(!privateIP.test(host)||host.split('.').some(o=>+o>255))) throw Error('Use 127.0.0.1 or an explicit private IPv4 address.');
  const sql=new DatabaseSync(':memory:');
  sql.exec(readFileSync(new URL('./schema.sql',import.meta.url),'utf8'));
  const DB={
    prepare(query){return {bind(...args){
      const s=sql.prepare(query);
      return {first:()=>s.get(...args),all:()=>({results:s.all(...args)}),run:()=>{const r=s.run(...args);return {meta:{changes:r.changes,last_row_id:r.lastInsertRowid}};}};
    }};},
    batch(xs){
      sql.exec('BEGIN');
      try{const result=xs.map(x=>x.queryOnly?x.all():x.run());sql.exec('COMMIT');return result;}
      catch(e){sql.exec('ROLLBACK');throw e;}
    }
  };
  const base=DB.prepare;
  DB.prepare=query=>({bind(...args){return {...base(query).bind(...args),queryOnly:/^\s*select\b/i.test(query)};}});
  const server=createServer(async (req,res)=>{
    const headers={'Content-Security-Policy':policy,'Permissions-Policy':'microphone=(), camera=(), geolocation=()','X-Content-Type-Options':'nosniff','Cache-Control':'no-store','Referrer-Policy':'no-referrer'};
    for(const [k,v] of Object.entries(headers))res.setHeader(k,v);
    const reply=(status,body,type='text/plain; charset=utf-8')=>{res.writeHead(status,{'Content-Type':type});res.end(body);};
    try{
      const port=server.address()?.port;
      const localHost=host==='127.0.0.1'?'localhost:'+port:host+':'+port;
      if(req.headers.host!==host+':'+port&&req.headers.host!==localHost)return reply(403,'Unexpected host.');
      const origin='http://'+req.headers.host;
      if(req.headers.origin&&req.headers.origin!==origin)return reply(403,'Unexpected origin.');
      if(!req.url?.startsWith('/')||req.url.startsWith('//'))return reply(400,'Bad URL.');
      const url=new URL(req.url,origin);
      if(url.pathname.startsWith('/api/')){
        if(req.method==='POST'&&(!req.headers['content-type']?.toLowerCase().startsWith('application/json')))return reply(415,'Expected JSON.');
        const chunks=[];let total=0;
        for await(const chunk of req){total+=chunk.length;if(total>100000){reply(413,'Request too large.');return;}chunks.push(chunk);}
        const h=new Headers();for(const [k,v] of Object.entries(req.headers))if(typeof v==='string')h.set(k,v);
        h.set('X-Local-Client',req.socket.remoteAddress||'local');
        const answer=await api(new Request(url,{method:req.method,headers:h,...(req.method==='POST'?{body:Buffer.concat(chunks)}:{})}),{DB});
        res.writeHead(answer.status,Object.fromEntries(answer.headers));res.end(await answer.text());return;
      }
      if(req.method!=='GET'&&req.method!=='HEAD')return reply(405,'Use GET.');
      let path=url.pathname.endsWith('/')?url.pathname+'index.html':url.pathname;
      const aliases={'/star':'/star/index.html','/haunted':'/haunted/index.html'};
      if(aliases[path]){res.writeHead(302,{Location:path+'/'});return res.end();}
      if(!/^[/a-zA-Z0-9._-]+$/.test(path)||path.split('/').some(x=>x.startsWith('.')))return reply(404,'Not found.');
      const file=resolve(web,'.'+path);
      if(!file.startsWith(web)||!MIME[extname(file)])return reply(404,'Not found.');
      if(!(await stat(file)).isFile())return reply(404,'Not found.');
      reply(200,req.method==='HEAD'?undefined:await readFile(file),MIME[extname(file)]);
    }catch(e){if(res.headersSent)return res.end();return reply(e.code==='ENOENT'?404:500,e.code==='ENOENT'?'Not found.':'Local service error.');}
  });
  server.on('close',()=>sql.close());
  return server;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const host=process.argv[2]||'127.0.0.1',port=Number(process.argv[3]||8787);
  if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Provide a port between 1024 and 65535.');
  makeServer(host).listen(port,host,()=>console.log('Local demo: http://'+host+':'+port));
}
