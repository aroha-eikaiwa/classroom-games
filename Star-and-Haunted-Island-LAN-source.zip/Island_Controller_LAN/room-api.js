import {syncArcade,getArcade,arcadeAction,skipArcade} from './arcade/service.js';
const OPEN_FOR = 12 * 60 * 60 * 1000;
const INACTIVE = 2 * 60 * 60 * 1000;
const PRESENCE_FOR = 60000;
// Allow a slow database request to finish before declaring a healthy board gone.
const BOARD_ONLINE_FOR = 60000;
export const token = () => crypto.randomUUID().replaceAll('-','') + crypto.randomUUID().replaceAll('-','');
const hash = async value => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(x=>x.toString(16).padStart(2,'0')).join('');
function db(env) { if(!env.DB) throw new Error('Room service is unavailable.'); return env.DB; }
const statement=(env,sql,...args)=>db(env).prepare(sql).bind(...args);
const fail=(message,status=400)=>Object.assign(new Error(message),{status});
function response(data,status=200,origin) {
  const headers={'Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin'};
  if(origin) Object.assign(headers,{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Max-Age':'600'});
  if(data.retryAfterMs)headers['Retry-After']=String(Math.ceil(data.retryAfterMs/1000));
  const body=JSON.stringify(data);
  return new Response(body,{status,headers});
}
function validState(s) {
  if(!s||!Number.isSafeInteger(s.version)||!Array.isArray(s.actions)||s.actions.some(a=>typeof a!=='string'||a.length>40)||JSON.stringify(s).length>80000) throw fail('Invalid board state.');
  if(s.arcade) {
    s.arcade.voice=false;
    const supported=['scramble','maze','missing','rps'];
    const picked=Array.isArray(s.arcade.miniGames)?s.arcade.miniGames.filter(g=>supported.includes(g)):[];
    s.arcade.miniGames=picked.length?picked:supported;
  }
  if(s.theme!==undefined&&!['star','haunted'].includes(s.theme))throw fail('Invalid island theme.');
  return s;
}
async function rate(env,request,scope,max=30,period=60000) {
  const key=scope+':'+await hash(request.headers.get('X-Local-Client')||'local');
  const now=Date.now();
  const row=await statement(env,`INSERT INTO limits (key,start,hits) VALUES (?, ?, 1) ON CONFLICT(key) DO UPDATE SET hits=CASE WHEN start < ? THEN 1 ELSE hits+1 END, start=CASE WHEN start < ? THEN excluded.start ELSE start END RETURNING hits`,key,now,now-period,now-period).first();
  if(row.hits>max) throw fail('Too many attempts. Please wait a moment.',429);
}
async function room(env,code,sessionHash) {
  if(!/^\d{6}$/.test(code||'')) throw fail('Enter the six-digit code on the board.');
  // State polling authenticates the controller and reads the room in one trip.
  const r=sessionHash===undefined
    ?await statement(env,'SELECT * FROM rooms WHERE code = ?',code).first()
    :await statement(env,`SELECT rooms.*, sessions.hash AS controller_hash,
      sessions.player_id AS controller_player_id, sessions.last_seen AS controller_last_seen,
      sessions.active AS controller_active FROM rooms LEFT JOIN sessions
      ON sessions.code = rooms.code AND sessions.hash = ? WHERE rooms.code = ?`,sessionHash,code).first();
  if(!r||Date.now()-r.created>OPEN_FOR||Date.now()-r.touched>INACTIVE) throw fail('That room has closed. Check the code on the board.',404);
  return r;
}
async function host(env,r,secret) {if(!secret||await hash(secret)!==r.host_hash) throw fail('This board cannot manage that room.',403);}
async function controller(env,r,request) {
  const secret=request.headers.get('Authorization')?.replace(/^Bearer /,'');
  const session=Object.hasOwn(r,'controller_hash')
    ?r.controller_hash?{hash:r.controller_hash,code:r.code,player_id:r.controller_player_id,last_seen:r.controller_last_seen,active:r.controller_active}:null
    :secret?.length===64?await statement(env,'SELECT * FROM sessions WHERE hash = ? AND code = ?',await hash(secret),r.code).first():null;
  if(!session) throw fail('Enter the room code to reconnect.',401);
  return session;
}
const AVATARS=["vampire", "witch", "mummy", "zombie", "werewolf", "skeleton", "ghost", "bat", "cat", "candy", "pumpkin", "spider", "devil", "cyclops", "dragon", "owl"];
const STAR_AVATARS=["star-leo", "star-mia", "star-luna", "star-finn", "star-emi", "star-haru", "star-noah", "star-nina", "star-theo", "star-ava", "star-ari", "star-ivy", "star-max", "star-sora"];
const COLORS=['#ef8354','#579fe5','#9b77db','#4db893','#e577a9','#cfad3a'];
async function roster(env,code,onlineOnly=false){const sql='SELECT id,slot,name,avatar FROM players WHERE code = ?'+(onlineOnly?' AND EXISTS (SELECT 1 FROM sessions WHERE sessions.code = players.code AND sessions.player_id = players.id AND active = 1 AND CASE WHEN last_seen = 0 THEN created ELSE last_seen END > ?)':'')+' ORDER BY joined_at,slot';return (await statement(env,sql,...(onlineOnly?[code,Date.now()-PRESENCE_FOR]:[code])).all()).results.map((p,i)=>({...p,slot:i,color:COLORS[p.slot%COLORS.length]}));}
async function pruneLobby(env,code,now=Date.now()){
  await db(env).batch([
    statement(env,`DELETE FROM players WHERE code = ? AND NOT EXISTS (SELECT 1 FROM sessions WHERE sessions.code = players.code AND sessions.player_id = players.id AND active = 1 AND CASE WHEN last_seen = 0 THEN created ELSE last_seen END > ?)`,code,now-PRESENCE_FOR),
    statement(env,'UPDATE sessions SET player_id = NULL WHERE code = ? AND player_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM players WHERE players.id = sessions.player_id)',code),
  ]);
}
async function heartbeat(env,session,state,now=Date.now()){
  if(!session.active)throw fail('Enter the room code to reconnect.',401);
  // Shared controllers have no lobby seat to maintain.
  if(state.mode==='own'&&now-session.last_seen>10000)await statement(env,'UPDATE sessions SET last_seen = ? WHERE hash = ?',now,session.hash).run();
}
function permitted(state,session){
  if(state.mode!=='own')return true;
  if(!session.player_id)return false;
  if(state.phase==='miniTurn'&&state.mini?.simultaneous)return !state.mini.submitted.includes(session.player_id);
  return state.activePlayerId===session.player_id;
}
function personal(state,session){
  if(state.mode!=='own')return state;
  const me=state.roster?.find(p=>p.id===session.player_id);
  const active=permitted(state,session);
  return {...state,you:me||null,active,actions:active?state.actions:[],canUseItems:active&&state.canUseItems,speech:active?state.speech:null,hearWord:active?state.hearWord:null,items:active?state.items:[],mini:state.mini?{...state.mini,submittedByYou:state.mini.submitted?.includes(session.player_id)}:null};
}
export async function api(request,env) {
  const url=new URL(request.url),origin=request.headers.get('Origin');
  const allowed=origin===url.origin;
  if(origin&&!allowed) return response({error:'This site cannot connect to the game.'},403);
  if(request.method==='OPTIONS') return response({},200,allowed?origin:null);
  if(request.method!=='POST') return response({error:'Use POST.'},405,allowed?origin:null);
  try {
    if(!['/api/rooms','/api/join','/api/start','/api/host','/api/arcade-skip','/api/close','/api/leave','/api/arcade','/api/register','/api/state','/api/action','/api/result'].includes(url.pathname))throw fail('Not found.',404);
    if(Number(request.headers.get('Content-Length')||0)>100000) throw fail('Request too large.',413);
    const raw=await request.text();if(raw.length>100000) throw fail('Request too large.',413);
    let b;try{b=JSON.parse(raw);}catch{throw fail('Invalid request.');}
    if(!b||typeof b!=='object'||Array.isArray(b)) throw fail('Invalid request.');
    if(url.pathname==='/api/rooms') {
      await rate(env,request,'create',10);
      const state=validState(b.state),now=Date.now(),secret=token(),hostHash=await hash(secret);
      await db(env).batch([
        statement(env,'DELETE FROM rooms WHERE created < ? OR touched < ?',now-OPEN_FOR,now-INACTIVE),
        statement(env,'DELETE FROM limits WHERE start < ?',now-3600000),
      ]);
      for(let i=0;i<20;i++) {
        const n=crypto.getRandomValues(new Uint32Array(1))[0];
        if(n>=4294000000) continue; // Reject the biased tail.
        const code=String(n%1000000).padStart(6,'0');
        const result=await statement(env,'INSERT OR IGNORE INTO rooms (code,host_hash,state,version,created,touched) VALUES (?,?,?,?,?,?)',code,hostHash,JSON.stringify(state),state.version,now,now).run();
        if(result.meta.changes) return response({code,hostToken:secret},201,origin);
      }
      throw fail('Could not create a room. Please try again.',503);
    }
    if(url.pathname==='/api/join') {
      await rate(env,request,'join',30);
      const r=await room(env,b.code);
      if(Date.now()-r.touched>=BOARD_ONLINE_FOR) throw fail('The board is offline. Ask your teacher to reopen it.',409);
      const joinedState=JSON.parse(r.state);
      let session=null,secret;
      if(typeof b.reconnectToken==='string'&&b.reconnectToken.length===64){session=await statement(env,'SELECT * FROM sessions WHERE hash = ? AND code = ?',await hash(b.reconnectToken),r.code).first();if(session)secret=b.reconnectToken;}
      if(!session){secret=token();session={hash:await hash(secret),player_id:null};await statement(env,'INSERT INTO sessions (hash,code,created,last_seen) VALUES (?,?,?,?)',session.hash,r.code,Date.now(),Date.now()).run();}
      else{
        // A new page gets a new token, so a delayed departure from the old page cannot disconnect it.
        const oldHash=session.hash;secret=token();session={...session,hash:await hash(secret)};
        await db(env).batch([statement(env,'UPDATE sessions SET active = 0 WHERE hash = ?',oldHash),statement(env,'INSERT INTO sessions (hash,code,created,last_seen,player_id) VALUES (?,?,?,?,?)',session.hash,r.code,Date.now(),Date.now(),session.player_id)]);
      }
      if(joinedState.mode==='own')joinedState.roster=await roster(env,r.code);
      return response({code:r.code,controllerToken:secret,state:personal(joinedState,session)},200,origin);
    }
    const isHost=['/api/start','/api/host','/api/arcade-skip','/api/close'].includes(url.pathname);
    const secret=request.headers.get('Authorization')?.replace(/^Bearer /,'');
    const r=await room(env,b.code,isHost?undefined:secret?.length===64?await hash(secret):'');
    if(url.pathname==='/api/start') {
      await host(env,r,b.hostToken);
      if(JSON.parse(r.state).phase!=='lobby')throw fail('The lobby has already closed.',409);
      await pruneLobby(env,r.code);const players=await roster(env,r.code);
      if(players.length<2)throw fail('Wait for at least two players.',409);
      const state=JSON.parse(r.state);state.phase='lobbyStarting';state.actions=[];state.roster=players;
      await statement(env,'UPDATE rooms SET state = ?, touched = ? WHERE code = ?',JSON.stringify(state),Date.now(),r.code).run();
      return response({players},200,origin);
    }
    if(url.pathname==='/api/host') {
      await host(env,r,b.hostToken);const state=validState(b.state);if((state.theme||'haunted')!==(JSON.parse(r.state).theme||'haunted'))throw fail('Start a new room to switch islands.',409);
      if(state.phase==='miniTurn'&&state.mini?.deadline&&Number.isFinite(b.clientNow)){
        const previous=JSON.parse(r.state).mini,deadline=state.mini.deadline;
        state.mini={...state.mini,boardDeadline:deadline,deadline:previous?.id===state.mini.id&&previous.boardDeadline===deadline?previous.deadline:Date.now()+deadline-b.clientNow};
      }
      const now=Date.now(),json=JSON.stringify(state),updates=[];
      if(state.mode==='own'&&state.phase!=='lobby'){
        const keep=new Set((state.roster||[]).map(p=>p.id)),removed=(JSON.parse(r.state).roster||[]).filter(p=>!keep.has(p.id));
        for(const p of removed){updates.push(statement(env,'UPDATE sessions SET active = 0, player_id = NULL WHERE code = ? AND player_id = ?',r.code,p.id));updates.push(statement(env,'DELETE FROM players WHERE code = ? AND id = ?',r.code,p.id));updates.push(statement(env,"UPDATE commands SET result = 'stale' WHERE code = ? AND actor = ? AND result IS NULL",r.code,p.id));}
      }
      if(json!==r.state)updates.push(statement(env,'UPDATE rooms SET state = ?, version = ?, touched = ? WHERE code = ?',json,state.version,now,r.code));
      else if(now-r.touched>10000)updates.push(statement(env,'UPDATE rooms SET touched = ? WHERE code = ?',now,r.code));
      for(const ack of (b.acks||[]).slice(0,50)) {
        if(Number.isSafeInteger(ack.id)&&['applied','stale'].includes(ack.result)) updates.push(statement(env,'UPDATE commands SET result = ? WHERE id = ? AND code = ?',ack.result,ack.id,r.code));
      }
      // Commit acknowledgements and fetch the remaining queue in the same trip.
      const results=await db(env).batch([...updates,statement(env,'SELECT id,action,version,created,payload,actor,mini_key FROM commands WHERE code = ? AND result IS NULL ORDER BY id LIMIT 40',r.code)]);
      const pending=results.at(-1),players=state.mode==='own'&&state.phase==='lobby'?await roster(env,r.code,true):(state.roster||[]);
      const arcade=await syncArcade(env,{...r,state:json},players,now);
      return response({commands:pending.results,players,arcade,serverNow:Date.now()},200,origin);
    }
    if(url.pathname==='/api/arcade-skip') {await host(env,r,b.hostToken);return response({arcade:await skipArcade(env,r,b.key,Date.now())},200,origin);}
    if(url.pathname==='/api/close') {
      await host(env,r,b.hostToken);await statement(env,'DELETE FROM rooms WHERE code = ?',r.code).run();
      return response({closed:true},200,origin);
    }
    const session=await controller(env,r,request);
    if(url.pathname==='/api/leave'){
      await statement(env,'UPDATE sessions SET active = 0 WHERE hash = ?',session.hash).run();
      if(JSON.parse(r.state).phase==='lobby')await pruneLobby(env,r.code);
      return response({left:true},200,origin);
    }
    await heartbeat(env,session,JSON.parse(r.state));
    if(url.pathname==='/api/arcade') {
      if(Date.now()-r.touched>=BOARD_ONLINE_FOR)throw fail('The board is offline. Keep it open.',409);
      await rate(env,request,'arcade:'+session.hash,100,10000);
      return response(await arcadeAction(env,r,session.player_id,b,Date.now()),200,origin);
    }
    if(url.pathname==='/api/register') {
      const state=JSON.parse(r.state);
      if(session.player_id)return response({state:personal({...state,roster:await roster(env,r.code)},session)},200,origin);
      if(state.mode!=='own')throw fail('This room uses a shared controller.',409);
      if(typeof b.name!=='string'||!b.name.trim()||b.name.trim().length>24||!(state.theme==='star'?STAR_AVATARS:AVATARS).includes(b.avatar))throw fail('Enter your name and choose an avatar.');
      if(state.phase!=='lobby'){
        const candidates=(await statement(env,'SELECT id FROM players WHERE code = ? AND lower(name) = lower(?) AND avatar = ?',r.code,b.name.trim(),b.avatar).all()).results;
        if(candidates.length!==1)throw fail('To return, use the same name and avatar you started with.',409);
        const id=candidates[0].id,online=await statement(env,'SELECT hash FROM sessions WHERE code = ? AND player_id = ? AND active = 1 AND last_seen > ?',r.code,id,Date.now()-PRESENCE_FOR).first();
        if(online)throw fail('That player is still connected on another controller. Close it and try again.',409);
        await db(env).batch([statement(env,'UPDATE sessions SET player_id = NULL, active = 0 WHERE code = ? AND player_id = ?',r.code,id),statement(env,'UPDATE sessions SET player_id = ?, active = 1, last_seen = ? WHERE hash = ?',id,Date.now(),session.hash)]);
        session.player_id=id;return response({state:personal({...state,roster:await roster(env,r.code)},session)},200,origin);
      }
      await pruneLobby(env,r.code);
      const id=session.hash.slice(0,32);
      const previous=await statement(env,'SELECT id FROM players WHERE id = ? AND code = ?',id,r.code).first();
      if(previous){await statement(env,'UPDATE sessions SET player_id = ? WHERE hash = ?',id,session.hash).run();session.player_id=id;return response({state:personal({...state,roster:await roster(env,r.code)},session)},200,origin);}
      const result=await statement(env,`INSERT OR IGNORE INTO players (id,code,slot,name,avatar,joined_at) SELECT ?, ?, (SELECT min(value) FROM json_each('[0,1,2,3,4,5]') WHERE value NOT IN (SELECT slot FROM players WHERE code = ?)), ?, ?, ? WHERE (SELECT COUNT(*) FROM players WHERE code = ?) < 6 AND (SELECT json_extract(state,'$.phase') FROM rooms WHERE code = ?) = 'lobby'`,id,r.code,r.code,b.name.trim(),b.avatar,Date.now(),r.code,r.code).run();
      if(!result.meta.changes)throw fail('This room is full or the game has started.',409);
      await statement(env,'UPDATE sessions SET player_id = ? WHERE hash = ?',id,session.hash).run();session.player_id=id;
      const next={...state,roster:await roster(env,r.code)};
      return response({state:personal(next,session)},200,origin);
    }
    if(url.pathname==='/api/state') {
      const state=JSON.parse(r.state),online=Date.now()-r.touched<BOARD_ONLINE_FOR;
      if(state.mode==='own'&&state.phase==='lobby')state.roster=await roster(env,r.code,true);
      if(!online) {state.actions=[];state.canUseItems=false;}
      const mine=personal(state,session);mine.arcade=await getArcade(env,r,session.player_id,Date.now());
      const command=Number.isSafeInteger(b.pendingId)?await statement(env,'SELECT result FROM commands WHERE id = ? AND code = ?',b.pendingId,r.code).first():null;
      return response({state:mine,online,result:command?.result||null,serverNow:Date.now()},200,origin);
    }
    if(url.pathname==='/api/action') {
      await rate(env,request,'action:'+session.hash,60,10000);
      const state=JSON.parse(r.state);
      if(typeof b.requestId!=='string'||!/^[-a-zA-Z0-9]{20,80}$/.test(b.requestId)) throw fail('Invalid action.');
      const existing=await statement(env,'SELECT * FROM commands WHERE request_id = ? AND code = ?',b.requestId,r.code).first();
      if(existing&&existing.actor!==(state.mode==='own'?session.player_id:''))throw fail('That request belongs to another player.',409);
      if(existing) return response({queued:true,id:existing.id},200,origin);
      if(Date.now()-r.touched>=BOARD_ONLINE_FOR) throw fail('The board is offline. Keep it open.',409);
      const simultaneous=b.action==='miniSubmit'&&state.mode==='own'&&state.phase==='miniTurn'&&state.mini?.simultaneous;
      const speech=b.action==='speech',shared=b.action?.startsWith('shared'),diceSettled=b.action==='diceSettled';
      if(!permitted(state,session)||(diceSettled?(!state.rollSync?.ready||b.rollKey!==state.rollSync.key):shared?state.mode!=='shared'||b.sharedKey!==state.shared?.key:speech?b.key!==state.speech?.key:simultaneous?b.miniKey!==state.mini.id:b.version!==r.version)||!state.actions.includes(b.action)) throw fail('That turn has changed. Wait for the next button.',409);
      let payload=null;
      if(['roll','rollSteal'].includes(b.action)&&b.diceSync===true)payload=JSON.stringify({diceSyncKey:b.requestId});
      if(diceSettled)payload=JSON.stringify({rollKey:b.rollKey});
      if(b.action==='miniSubmit') {
        if(state.mini?.deadline&&Date.now()>=state.mini.deadline)throw fail('Time is up. Look at the board.',409);
        if(typeof b.answer!=='string'||!b.answer.trim()||b.answer.length>100) throw fail('Type your answer first.');
        payload=JSON.stringify({answer:b.answer.trim(),...(simultaneous?{playerId:session.player_id,miniKey:b.miniKey}:{})});
      }
      if(b.action==='sharedAttempt') throw fail('Microphone mode is unavailable.',403);
      if(shared){
        if(!['sharedNext','sharedChoice','sharedListenReady','sharedListenAnswer','sharedListenRetry','sharedTypingReady','sharedTypingAnswer','sharedTypingRetry'].includes(b.action)||typeof b.sharedKey!=='string')throw fail('Invalid shared-controller action.');
        const data={sharedKey:b.sharedKey};if(b.action==='sharedChoice'){if(typeof b.choice!=='string'||b.choice.length>60)throw fail('Choose an answer.');data.choice=b.choice;}
        if(b.action==='sharedListenAnswer'){if(typeof b.choice!=='string'||b.choice.length>60||!Number.isInteger(b.elapsedMs)||b.elapsedMs<0||b.elapsedMs>20000)throw fail('Invalid timed listening answer.');data.choice=b.choice;data.elapsedMs=b.elapsedMs;}
        if(b.action==='sharedTypingAnswer'){if(typeof b.answer!=='string'||b.answer.length>100||!Number.isInteger(b.elapsedMs)||b.elapsedMs<0||b.elapsedMs>20000||!b.answer.trim()&&b.elapsedMs<20000)throw fail('Invalid timed typing answer.');data.answer=b.answer;data.elapsedMs=b.elapsedMs;}
        payload=JSON.stringify(data);
      }
      if(b.action==='speech') throw fail('Microphone mode is unavailable.',403);
      const result=await statement(env,'INSERT OR IGNORE INTO commands (code,request_id,version,action,created,payload,actor,mini_key) VALUES (?,?,?,?,?,?,?,?)',r.code,b.requestId,b.version,b.action,Date.now(),payload,state.mode==='own'?session.player_id:'',simultaneous?b.miniKey:null).run();
      if(!result.meta.changes) throw fail('Another player already tapped. Watch the board.',409);
      return response({queued:true,id:result.meta.last_row_id},202,origin);
    }
    if(url.pathname==='/api/result') {
      const command=await statement(env,'SELECT result FROM commands WHERE id = ? AND code = ?',b.id,r.code).first();
      return response({result:command?.result||null},200,origin);
    }
    throw fail('Not found.',404);
  } catch(e) {
    if(!e.status) console.error('room service',url.pathname,e.message);
    const busy=!e.status&&/overloaded|queued for too long|D1.*timeout/i.test(e.message);
    return response({error:busy?'The game server is busy. Reconnecting automatically…':e.status?e.message:'The room service is unavailable. Reconnecting automatically…',...(busy?{code:'SERVER_BUSY',retryAfterMs:4000}:{})},e.status||503,allowed?origin:null);
  }
}

