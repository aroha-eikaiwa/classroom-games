let PLAYER_AVATARS=window.PlayerAvatars;
let chosenAvatar='ghost';
function faceElement(id){const a=PLAYER_AVATARS.find(a=>a.id===id);if(!a)return null;const el=document.createElement('img');el.className='monster-face';el.src=a.src;el.alt=a.name;el.draggable=false;return el;}
function paintAvatarChoices(){$('avatarChoices').replaceChildren();for(const a of PLAYER_AVATARS){const b=document.createElement('button');b.type='button';b.className='avatar-choice';b.dataset.avatar=a.id;b.setAttribute('aria-pressed',String(chosenAvatar===a.id));b.append(faceElement(a.id),document.createTextNode(a.name));b.onclick=()=>{chosenAvatar=a.id;for(const button of $('avatarChoices').children)button.setAttribute('aria-pressed',String(button.dataset.avatar===chosenAvatar));};$('avatarChoices').append(b);}}
function paintSelf(s){const me=s?.mode==='own'?s.you:null;$('selfAvatar').hidden=!me;if(me){$('selfAvatar').style.setProperty('--player',me.color);if($('selfAvatar').dataset.avatar!==me.avatar){$('selfAvatar').dataset.avatar=me.avatar;$('selfAvatar').replaceChildren(faceElement(me.avatar));}}}
function setProfileTheme(theme){PLAYER_AVATARS=window.AvatarCatalogs[theme]||window.AvatarCatalogs.haunted;if(!PLAYER_AVATARS.some(a=>a.id===chosenAvatar))chosenAvatar=PLAYER_AVATARS[0].id;paintAvatarChoices();}
paintAvatarChoices();
