document.addEventListener('error',e=>{
 const img=e.target;
 if(!(img instanceof HTMLImageElement)||img.dataset.fallback)return;
 img.dataset.fallback='1';
 const key=img.src.match(/avatar-([a-z-]+)/)?.[1]?.replace(/^star-/,'');
 const glyph={vampire:'🧛',witch:'🧙',ghost:'👻',bat:'🦇',cat:'🐈',candy:'🍬',pumpkin:'🎃',dragon:'🐉',owl:'🦉',spider:'🕷'}[key]||key?.slice(0,2).toUpperCase()||'✦';
 const svg='<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><circle cx="48" cy="48" r="47" fill="#51468f"/><text fill="white" x="48" y="62" font-size="40" text-anchor="middle">'+glyph+'</text></svg>';
 img.src='data:image/svg+xml,'+encodeURIComponent(svg);
},true);
