(() => {
  const theme=document.documentElement?.dataset?.theme==='star'?'star':'haunted';
  const storageKey=theme==='star'?'star-host-room':'haunted-host-room';
  const CONTROLLER=location.origin;
  const codeElement=document.getElementById('roomCode'),status=document.getElementById('roomStatus');
  const joinUrl=code=>CONTROLLER+'/?'+new URLSearchParams({...(code?{code}:{}),theme});
  function showJoinLink(code){
    for(const id of ['joinLink','lobbyJoinLink']){
      const link=document.getElementById(id);
      if(link){link.href=joinUrl(code);link.textContent=link.href;}
    }
  }
  let room=null,inFlight=false,starting=false,creating=false,acks=[],lastApplied=new Set(),timer=null,closed=false,generation=0,resync=false;
  
  // Retain the host room across refreshes so student identities can reconnect.
  try{const saved=JSON.parse(sessionStorage.getItem(storageKey));if(/^\d{6}$/.test(saved?.code)&&saved?.hostToken?.length===64)room=saved;}catch{}
  function remember(){try{if(room)sessionStorage.setItem(storageKey,JSON.stringify(room));else sessionStorage.removeItem(storageKey);}catch{}}
  const snapshot=()=>{
    const s=window.StarIslandTabController.read();
    const art=value=>typeof value==='string'&&value&&!value.startsWith('/')&&!value.startsWith('data:')?new URL(value,location.href).pathname:value;
    return {...s,diceArt:art(s.diceArt),deckArt:Object.fromEntries(Object.entries(s.deckArt).map(([k,v])=>[k,art(v)])),items:s.items.map(item=>({...item,image:art(item.image)}))};
  };
  async function request(path,body){
    const r=await fetch(CONTROLLER+'/api/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(35000)});
    const data=await r.json();if(!r.ok)throw Object.assign(new Error(data.error||'Controllers could not connect.'),{status:r.status,retryAfterMs:data.retryAfterMs||0});return data;
  }
  async function create(){
    if(creating||closed)return;creating=true;const gen=generation;codeElement.textContent='••••••';status.textContent='Creating room…';
    try{const next=await request('rooms',{state:snapshot()});if(gen!==generation)return;room=next;regularFailures=0;remember();codeElement.textContent=room.code;showJoinLink(room.code);status.textContent='Enter this code to join';lastApplied=new Set();acks=[];window.StarIslandTabController.lobbyPlayers?.([],room.code);}
    catch(e){regularFailures++;status.textContent='Connection unavailable · retrying';console.warn('Controller room:',e.message);}
    finally{creating=false;}
  }
  let lastRegularSync=0,regularFailures=0,retryAfter=0;
  function regularDelay(){
    if(document.hidden)return 5000;
    if(regularFailures)return Math.min(8000,1000*2**Math.min(regularFailures,3));
    const s=window.StarIslandTabController.read();
    if(!s||s.phase==='finished')return 5000;
    if(s.phase==='lobby')return 1500;
    return s.phase?.startsWith('arcade')||s.phase==='speakCard'||s.shared&&s.phase==='miniTurn'?500:1000;
  }
  function regularSync(){if(inFlight||starting||creating||closed||Date.now()<retryAfter||Date.now()-lastRegularSync<regularDelay())return;lastRegularSync=Date.now();void sync();}
  async function sync(){
    if(closed||starting||Date.now()<retryAfter)return;if(inFlight){resync=true;return;}if(!room){await create();return;}
    inFlight=true;lastRegularSync=Date.now();const activeRoom=room,gen=generation;
    try{
      const sentAcks=acks.slice(),data=await request('host',{...activeRoom,state:snapshot(),clientNow:Date.now(),acks:sentAcks});
      if(gen!==generation||room!==activeRoom)return;
      codeElement.textContent=room.code;showJoinLink(room.code);
      acks=acks.filter(a=>!sentAcks.some(b=>a.id===b.id));
      window.StarIslandTabController.lobbyPlayers?.(data.players,room.code);
      window.StarIslandTabController.arcadeUpdate?.(data.arcade);
      for(const command of data.commands){
        if(lastApplied.has(command.id))continue;
        let payload=null;try{payload=command.payload?JSON.parse(command.payload):null;}catch{}
        const applied=(data.serverNow||Date.now())-command.created<60000&&window.StarIslandTabController.send(command.action,command.version,payload,command.actor);
        lastApplied.add(command.id);acks.push({id:command.id,result:applied?'applied':'stale'});
      }
      regularFailures=0;retryAfter=0;status.textContent='Enter this code to join';if(data.commands.length)resync=true;
    }catch(e){regularFailures++;retryAfter=Date.now()+(e.retryAfterMs||0);resync=false;status.textContent=e.retryAfterMs?'Game server busy · reconnecting…':'Reconnecting controllers…';if(e.status===404&&gen===generation){room=null;await create();}}
    finally{inFlight=false;if(resync&&!closed&&!starting){resync=false;queueMicrotask(sync);}}
  }
  async function reset(){
    const old=room;generation++;room=null;remember();acks=[];lastApplied=new Set();
    if(old)request('close',old).catch(()=>{});
    await create();
  }
  window.RoomHost={reset,sync,logSpeechFailure(){},async skipArcade(key){if(!room)throw Error('Reconnect the room first.');const data=await request('arcade-skip',{...room,key});window.StarIslandTabController.arcadeUpdate?.(data.arcade);},async start(){
    if(!room)throw Error('Wait for the room code, then try again.');
    if(starting)throw Error('The game is already starting.');
    const activeRoom=room,gen=generation;starting=true;resync=false;
    try{
      // Stop new heartbeats first, then drain the one already in flight.
      while(inFlight)await new Promise(resolve=>setTimeout(resolve,30));
      if(gen!==generation||room!==activeRoom||closed)throw Error('The room changed. Please try again.');
      inFlight=true;return (await request('start',activeRoom)).players;
    }finally{inFlight=false;starting=false;}

  }};
  document.getElementById('controllerBtn').textContent='Open controller';
  document.getElementById('controllerBtn').onclick=()=>window.open(joinUrl(room?.code),'_blank','noopener');
  document.getElementById('joinLink').href=joinUrl(room?.code);
  document.getElementById('joinLink').textContent=joinUrl(room?.code);
  document.getElementById('roomRetry').onclick=()=>sync();
  window.addEventListener('pagehide',()=>{closed=true;clearInterval(timer);});
  window.addEventListener('pageshow',e=>{if(e.persisted){closed=false;sync();timer=setInterval(regularSync,150);}});
  window.addEventListener('online',()=>{retryAfter=0;lastRegularSync=0;sync();});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){lastRegularSync=Date.now();sync();}});
  if(room)sync();else create();timer=setInterval(regularSync,150);
})();
