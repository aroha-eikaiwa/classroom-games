(() => {
 let active=null;
 const requested=new URLSearchParams(location.search).get('theme')==='star'?'star':'haunted';
 window.isStarIsland=()=>document.documentElement.dataset.theme==='star';
 window.applyIslandTheme=theme=>{
  theme=theme==='star'?'star':'haunted';if(active===theme)return;active=theme;
  document.documentElement.dataset.theme=theme;const star=theme==='star';
  document.title='Aroha Eikaiwa | Join a game';
  $('joinTitle').textContent='Aroha Eikaiwa';

  labels.coast=star?['Coast path','うみべのみち','🌊']:['Pumpkin path','かぼちゃのみち','🌊'];
  labels.trail=star?['Adventure trail','ぼうけんのみち','🌳']:['Monster trail','モンスターのみち','🌳'];
  labels.next[2]=star?'⭐':'🍬';
  setProfileTheme(theme);
 };
 window.applyIslandTheme(requested);
})();
