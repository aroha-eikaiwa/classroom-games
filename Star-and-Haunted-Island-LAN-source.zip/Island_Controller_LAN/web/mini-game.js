let miniTurnKey=null;
function renderMiniController(s,sending){
  const active=Boolean(s?.mini&&s.phase.startsWith('mini'));
  document.body.classList.toggle('mini-game',active);
  $('miniGame').hidden=!active;if(!active){miniTurnKey=null;return;}
  const turn=s.phase==='miniTurn';$('miniForm').hidden=!turn||(s.mode==='own'&&s.mini.submittedByYou);$('miniPicture').hidden=!turn;
  $('miniTitle').textContent=s.phase==='miniIntro'?'MINI GAME':s.phase==='miniResults'?'Mini game complete!':'Type the word';
  $('miniHelp').textContent=s.phase==='miniIntro'?'Get ready!':s.phase==='miniResults'?'Answer: '+(s.mini.answer||'')+' · Look at the board for your rewards.':s.mini.simultaneous?(s.mini.submittedByYou?'Answer sent! Waiting for everyone.':'Everyone, type the word!'):`Player ${s.mini.index+1} / ${s.mini.count} · ${s.player}’s turn`;
  if(turn&&miniTurnKey!==s.mini.id){
    miniTurnKey=s.mini.id;$('miniAnswer').value='';
    const picture=s.mini.picture;$('miniPicture').replaceChildren();
    if(picture.kind==='colour'){
      const swatch=document.createElement('div');swatch.className='mini-swatch';swatch.style.backgroundColor=picture.colour;swatch.setAttribute('role','img');swatch.setAttribute('aria-label','A colour to name in English');$('miniPicture').append(swatch);
    }else{
      const img=document.createElement('img');img.alt='Name this picture in English';img.src=picture.src;$('miniPicture').append(img);
      if(picture.kind==='month'){const number=document.createElement('span');number.className='mini-month';number.textContent=picture.number;$('miniPicture').append(number);}
    }
  }
  const enabled=turn&&s.connected&&!sending&&s.actions.includes('miniSubmit')&&(!s.mini.deadline||Date.now()+(typeof serverClock==='number'?serverClock:0)<s.mini.deadline);
  $('miniAnswer').disabled=!enabled;$('miniSubmit').disabled=!enabled;
  $('miniSubmit').textContent=sending?'Sending…':'Submit answer';
}
setInterval(()=>{const s=state,label=$('miniClock');if(!label)return;label.hidden=s?.phase!=='miniTurn'||!s.mini?.deadline;if(!label.hidden){const left=Math.max(0,s.mini.deadline-Date.now()-(typeof serverClock==='number'?serverClock:0));label.textContent=Math.ceil(left/1000)+'s';if(!left){$('miniAnswer').disabled=true;$('miniSubmit').disabled=true;}}},100);
