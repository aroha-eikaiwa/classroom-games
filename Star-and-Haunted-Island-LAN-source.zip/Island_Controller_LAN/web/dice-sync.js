/* Original rounded mesh; the existing six-face artwork supplies its texture. */
(() => {
  const faces=[
    {value:1,n:[0,0,1],u:[1,0,0],v:[0,1,0]},
    {value:6,n:[0,0,-1],u:[-1,0,0],v:[0,1,0]},
    {value:3,n:[1,0,0],u:[0,0,-1],v:[0,1,0]},
    {value:4,n:[-1,0,0],u:[0,0,1],v:[0,1,0]},
    {value:2,n:[0,1,0],u:[1,0,0],v:[0,0,-1]},
    {value:5,n:[0,-1,0],u:[1,0,0],v:[0,0,1]}
  ];
  const orientation=value=>{
    const base=[-.35,.4];
    if(value===6)base[1]+=Math.PI;
    if(value===3)base[1]-=Math.PI/2;
    if(value===4)base[1]+=Math.PI/2;
    if(value===2)base[0]+=Math.PI/2;
    if(value===5)base[0]-=Math.PI/2;
    return base;
  };
  function mesh(steps=16){
    const vertices=[];
    const vertex=(f,u,v)=>{
      const p=f.n.map((n,i)=>n+f.u[i]*u+f.v[i]*v),core=p.map(x=>Math.max(-.86,Math.min(.86,x))),d=p.map((x,i)=>x-core[i]),length=Math.hypot(...d),normal=d.map(x=>x/length);
      const pos=core.map((x,i)=>x+normal[i]*.14),index=f.value-1;
      // Skip the white margins of the original 3 by 2 sprite sheet.
      const uv=[(index%3+.13+(u+1)/2*.74)/3,(Math.floor(index/3)+.105+(1-v)/2*.77)/2];
      return [...pos,...normal,...uv];
    };
    for(const f of faces)for(let y=0;y<steps;y++)for(let x=0;x<steps;x++){
      const u=x/steps*2-1,v=y/steps*2-1,u2=(x+1)/steps*2-1,v2=(y+1)/steps*2-1;
      const a=vertex(f,u,v),b=vertex(f,u2,v),c=vertex(f,u2,v2),d=vertex(f,u,v2);
      vertices.push(...a,...b,...c,...a,...c,...d);
    }
    return new Float32Array(vertices);
  }
  function create(button,{onRoll=()=>{},draggable=true}={}){
    const canvas=document.createElement('canvas');canvas.className='dice-model';canvas.setAttribute('aria-hidden','true');
    const gl=canvas.getContext('webgl',{alpha:true,antialias:true,premultipliedAlpha:false});if(!gl)return null;
    const compile=(type,source)=>{const shader=gl.createShader(type);gl.shaderSource(shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error('Dice shader unavailable');return shader;};
    let program;
    try{
      program=gl.createProgram();
      gl.attachShader(program,compile(gl.VERTEX_SHADER,`attribute vec3 position;attribute vec3 normal;attribute vec2 uv;uniform vec2 angle;varying vec2 tex;varying vec3 lightNormal;
      vec3 rotate(vec3 p){float cx=cos(angle.x),sx=sin(angle.x),cy=cos(angle.y),sy=sin(angle.y);p=vec3(p.x,p.y*cx-p.z*sx,p.y*sx+p.z*cx);return vec3(p.x*cy+p.z*sy,p.y,-p.x*sy+p.z*cy);}
      void main(){vec3 p=rotate(position);float depth=4.2-p.z;gl_Position=vec4(p.x*2.7,p.y*2.7,depth*1.01-.202,depth);tex=uv;lightNormal=rotate(normal);}`));
      gl.attachShader(program,compile(gl.FRAGMENT_SHADER,`precision mediump float;uniform sampler2D art;varying vec2 tex;varying vec3 lightNormal;
      void main(){vec4 colour=texture2D(art,tex);float light=.70+.30*max(0.,dot(normalize(lightNormal),normalize(vec3(.3,.8,1.))));gl_FragColor=vec4(colour.rgb*light,colour.a);}`));
      gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))return null;
    }catch{return null;}
    gl.useProgram(program);const geometry=mesh(),buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,geometry,gl.STATIC_DRAW);
    for(const [name,size,offset] of [['position',3,0],['normal',3,12],['uv',2,24]]){const loc=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,32,offset);}
    const angle=gl.getUniformLocation(program,'angle'),texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([245,223,168,255]));
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.uniform1i(gl.getUniformLocation(program,'art'),0);gl.enable(gl.DEPTH_TEST);gl.clearColor(0,0,0,0);
    button.replaceChildren(canvas);button.classList.add('has-model');
    let x=-.35,y=.4,vx=0,vy=0,rollStarted=0,settleStarted=0,settleFrom=null,awaitingResult=false,awaitVersion=null,rollSerial=0,drag=null,suppressClickUntil=0,frame=0,lastTime=0,rolling=false,result=null,src='',target=null,ready=false,lost=false,pendingRoll=false;
    const reduced=()=>window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    function resize(){const size=Math.max(64,Math.round((canvas.clientWidth||256)*Math.min(window.devicePixelRatio||1,2)));if(canvas.width!==size||canvas.height!==size){canvas.width=canvas.height=size;}gl.viewport(0,0,size,size);}
    function land(value){
      const to=orientation(value),near=(a,b)=>a+Math.atan2(Math.sin(b-a),Math.cos(b-a));
      target=[near(x,to[0]),near(y,to[1])];settleFrom=[x,y];settleStarted=performance.now();awaitingResult=false;vx=vy=0;
    }
    function draw(time){
      frame=0;if(lost||document.hidden)return;
      const dt=Math.min(32,lastTime?time-lastTime:16);lastTime=time;
      const tumbling=rolling||pendingRoll||awaitingResult;
      let lift=0,tilt=0;
      if(tumbling&&!reduced()){
        const elapsed=Math.max(0,time-rollStarted),decay=Math.exp(-elapsed/1600);
        x+=dt*Math.sign(vx||1)*(.004+Math.abs(vx||.012)*decay);y+=dt*Math.sign(vy||1)*(.006+Math.abs(vy||.017)*decay);
        // Diminishing hops and angular momentum while awaiting the authoritative face.
        lift=-Math.abs(Math.sin(elapsed/125))*Math.max(2,15*Math.exp(-elapsed/950));tilt=Math.sin(elapsed/160)*5*Math.exp(-elapsed/1800);
      }
      else if(target&&!drag){const t=reduced()?1:Math.min(1,(time-settleStarted)/650),ease=1-Math.pow(1-t,3);x=settleFrom[0]+(target[0]-settleFrom[0])*ease;y=settleFrom[1]+(target[1]-settleFrom[1])*ease;lift=-Math.abs(Math.sin(t*Math.PI*3))*9*(1-t);if(t===1){[x,y]=target;target=null;}}
      else if(!drag&&!reduced()){x+=vx*dt;y+=vy*dt;const decay=Math.exp(-dt/170);vx*=decay;vy*=decay;}
      canvas.style.transform=`translateY(${lift}px) rotate(${tilt}deg)`;
      resize();gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.uniform2f(angle,x,y);gl.drawArrays(gl.TRIANGLES,0,geometry.length/8);
      if((rolling||pendingRoll||awaitingResult)&&!reduced()||target||Math.abs(vx)+Math.abs(vy)>.00008)schedule();
    }
    function schedule(){if(!frame&&!lost&&!document.hidden)frame=requestAnimationFrame(draw);}
    const cancelDrag=()=>{drag=null;vx=vy=0;};
    function roll(){
      if(button.disabled||rolling||pendingRoll||awaitingResult)return;
      const serial=++rollSerial;pendingRoll=true;awaitingResult=true;awaitVersion=lastVersion;rollStarted=performance.now();target=null;schedule();
      let response;try{response=onRoll();}catch{response=false;}
      return Promise.resolve(response).then(accepted=>{
        if(serial!==rollSerial)return;
        // Queue acceptance is not a dice result. Never settle on a guessed face.
        if(accepted===false){awaitingResult=false;land(result||1);}
      },()=>{if(serial===rollSerial){awaitingResult=false;land(result||1);}}).finally(()=>{if(serial===rollSerial){pendingRoll=false;if(awaitingResult&&!rolling&&lastVersion!==awaitVersion&&lastState?.phase==='ready'&&lastState?.actions?.includes('roll'))land(result||1);schedule();}});
    }
    let lastVersion=null,lastState=null;
    button.addEventListener('pointerdown',e=>{
      if(!draggable||button.disabled||rolling||pendingRoll||awaitingResult||!ready||e.isPrimary===false||e.button!==0)return;
      target=null;vx=vy=0;drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,x:e.clientX,y:e.clientY,time:e.timeStamp,moved:false,speed:0};button.setPointerCapture(e.pointerId);
    });
    button.addEventListener('pointermove',e=>{
      if(!drag||drag.id!==e.pointerId)return;if(button.disabled){cancelDrag();return;}
      if(Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)>6)drag.moved=true;
      if(!drag.moved)return;e.preventDefault();
      const dx=e.clientX-drag.x,dy=e.clientY-drag.y,dt=Math.max(8,e.timeStamp-drag.time),scale=.016;
      x+=dy*scale;y+=dx*scale;vx=Math.max(-.04,Math.min(.04,dy*scale/dt));vy=Math.max(-.04,Math.min(.04,dx*scale/dt));
      drag.speed=.35*Math.hypot(dx,dy)/dt+.65*drag.speed;
      Object.assign(drag,{x:e.clientX,y:e.clientY,time:e.timeStamp});schedule();
    });
    button.addEventListener('pointerup',e=>{
      if(drag?.id!==e.pointerId)return;
      const flick=drag.moved&&!button.disabled&&!rolling&&drag.speed>.35&&Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)>18&&e.timeStamp-drag.time<100;
      if(drag.moved)suppressClickUntil=performance.now()+600;
      if(e.timeStamp-drag.time>80||reduced())vx=vy=0;
      drag=null;if(button.hasPointerCapture(e.pointerId))button.releasePointerCapture(e.pointerId);
      if(flick)roll();
      schedule();
    });
    button.addEventListener('pointercancel',()=>{suppressClickUntil=performance.now()+600;cancelDrag();});
    button.addEventListener('lostpointercapture',()=>{if(drag){suppressClickUntil=performance.now()+600;cancelDrag();}});
    button.addEventListener('click',e=>{if(e.detail!==0&&performance.now()<suppressClickUntil){e.preventDefault();e.stopImmediatePropagation();}},true);
    const onVisibility=()=>{if(document.hidden){cancelDrag();cancelAnimationFrame(frame);frame=0;}else{lastTime=0;schedule();}};
    document.addEventListener('visibilitychange',onVisibility);
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;cancelDrag();cancelAnimationFrame(frame);button.classList.remove('has-model');});
    const observer=typeof ResizeObserver==='function'?new ResizeObserver(schedule):null;observer?.observe(button);
    return {
      roll,
      isSettled(value){return lost?true:!rolling&&!pendingRoll&&!awaitingResult&&!target&&result===value;},
      destroy(){lost=true;cancelAnimationFrame(frame);observer?.disconnect();document.removeEventListener('visibilitychange',onVisibility);gl.deleteBuffer(buffer);gl.deleteTexture(texture);gl.deleteProgram(program);gl.getExtension('WEBGL_lose_context')?.loseContext();},
      update(state){
        lastState=state;
        if(!state){rollSerial++;pendingRoll=awaitingResult=rolling=false;awaitVersion=null;lastVersion=null;result=null;target=null;cancelDrag();schedule();return !lost;}
        const nextRolling=Boolean(state?.rolling),nextResult=state?.dice||null;
        if(state?.diceArt&&src!==state.diceArt){src=state.diceArt;ready=false;const image=new Image();image.onload=()=>{if(image.src!==new URL(src,location.href).href)return;gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);ready=true;schedule();};image.src=src;}
        if(button.disabled&&drag)cancelDrag();
        const fresh=state?.version===undefined||state.version!==awaitVersion;
        if(nextRolling&&!rolling){rollStarted=performance.now();target=null;}
        // An item choice cancels the pending throw. The actual roll starts after choosing its target.
        if(awaitingResult&&fresh&&['itemTarget','setup','lobby','finished'].includes(state?.phase)){awaitingResult=false;pendingRoll=false;rollSerial++;land(nextResult||result||1);}
        if(!nextRolling&&nextResult&&((awaitingResult&&fresh&&state?.phase!=='ready')||rolling||(!awaitingResult&&nextResult!==result)))land(nextResult);
        // A fresh ready snapshot with actions restored means the attempted roll was rejected.
        if(awaitingResult&&fresh&&state?.phase==='ready'&&state?.actions?.includes('roll')&&!pendingRoll){awaitingResult=false;land(nextResult||1);}
        rolling=nextRolling;result=nextResult;lastVersion=state?.version??null;schedule();
        return !lost;
      }
    };
  }
  window.Dice3D={create,mesh,orientation};
})();
