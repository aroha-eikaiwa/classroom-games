const joinQuery=new URLSearchParams(location.search),queryCode=joinQuery.get('code');
const connectionStorageKey=joinQuery.get('theme')==='star'?'star-controller':'haunted-controller';
let roomCode=null,controllerToken=null,polling=false,pendingCommand=null,connectionGeneration=0,lastPaint='',serverClock=0,profileCode=null,pollFailures=0,retryAfter=0;
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function savedConnection(code){try{const record=JSON.parse(sessionStorage.getItem(connectionStorageKey+(code?':'+code:''))||sessionStorage.getItem(connectionStorageKey));return record&&(!code||record.code===code)&&/^\d{6}$/.test(record.code)&&record.token?.length===64?record:null;}catch{return null;}}
function paintConnection(){renderSpeechController(state,sending);const signature=JSON.stringify([state,sending]);if(signature!==lastPaint){lastPaint=signature;paint();}}
async function sendSpeech(payload){const gen=connectionGeneration,body={code:roomCode,version:state.version,action:'speech',...payload};try{await request('action',body);}catch(e){if(e.status||e.name==='TimeoutError')throw e;await wait(200);if(gen!==connectionGeneration)return;await request('action',body);}if(gen===connectionGeneration)poll();}
async function request(path,body,timeout=35000) {
  const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json',...(controllerToken?{'Authorization':'Bearer '+controllerToken}:{})},body:JSON.stringify(body),signal:AbortSignal.timeout(timeout)});
  const data=await r.json();if(!r.ok)throw Object.assign(new Error(data.error||'Could not connect.'),{status:r.status,retryAfterMs:data.retryAfterMs||0});return data;
}
function notifyLeave(){if(roomCode&&controllerToken)fetch('/api/leave',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+controllerToken},body:JSON.stringify({code:roomCode}),keepalive:true}).catch(()=>{});}
function leave(notify=true) {
  if(notify)notifyLeave();if(roomCode)saveConnection(false);connectionGeneration++;profileCode=null;
  stopControllerSpeech();window.ArcadeController?.stop();window.SharedChallengeController?.stop();diceModel?.update(null);roomCode=null;controllerToken=null;pendingCommand=null;state=null;sending=false;lastPaint='';renderMiniController(null,false);
  $('profilePanel').hidden=true;$('controller').hidden=true;$('joinPanel').hidden=false;$('joinError').textContent='';$('roomInput').focus();
}
async function poll() {
  if(!roomCode||polling)return;
  polling=true;
  const gen=connectionGeneration;
  try {
    const code=roomCode,pendingId=pendingCommand,started=Date.now(),data=await request('state',{code,pendingId});if(code!==roomCode||gen!==connectionGeneration)return;
    if(data.serverNow)serverClock=data.serverNow-(started+Date.now())/2;
    pollFailures=0;retryAfter=0;state={...data.state,connected:data.online};
    showConnectedPanel();
    if(pendingCommand===pendingId&&data.result) {
      if(data.result==='stale')$('error').textContent='Look at the board for the current turn.';pendingCommand=null;sending=false;
    }
    if(data.online&&hadConnectionError){$('error').textContent='';hadConnectionError=false;}
    if(!data.online){hadConnectionError=true;$('error').textContent='Reconnecting to the board automatically…';}
  } catch(e) {
    if(gen!==connectionGeneration)return;
    pollFailures++;retryAfter=Date.now()+(e.retryAfterMs||0);state={...state,connected:false,actions:[]};hadConnectionError=true;
    if(e.status===404||e.status===401){leave(false);$('joinError').textContent=e.message;}
    else $('error').textContent=e.message||'Connection lost. Reconnecting…';
  } finally {polling=false;if(roomCode&&state)paintConnection();}
}
async function send(action,payload={}) {
  if(sending||!state?.connected||!state.actions.includes(action))return false;
  const gen=connectionGeneration;sending=true;paintConnection();$('error').textContent='';
  const body={code:roomCode,action,version:state.version,requestId:crypto.randomUUID(),...(['roll','rollSteal'].includes(action)?{diceSync:true}:{}),...(action==='miniSubmit'&&state.mini?.simultaneous?{miniKey:state.mini.id}:{}),...payload};
  try {
    let result;
    try{result=await request('action',body);}catch(e){if(e.status||e.name==='TimeoutError')throw e;await wait(300);if(gen!==connectionGeneration)return false;result=await request('action',body);}
    if(gen===connectionGeneration)pendingCommand=result.id;
  }catch(e){if(gen===connectionGeneration){$('error').textContent=e.message;sending=false;paintConnection();}return false;}
  await poll();return true;
}
// Acknowledge the visible result, never the server's roll-start acknowledgement.
let diceCompletion=null;
async function completeVisibleDice(){
 const roll=state?.rollSync;
 if(!roll?.ready||state.rolling||!state.dice||!state.connected||!state.actions?.includes('diceSettled')||document.hidden){diceCompletion=null;return;}
 const identity=connectionGeneration+':'+roomCode+':'+roll.key;
 if(diceCompletion?.identity!==identity)diceCompletion={identity,key:roll.key,gen:connectionGeneration,code:roomCode,since:performance.now(),painted:false,pending:false,done:false,retryAt:0};
 const item=diceCompletion;
 if(item.done||item.pending||Date.now()<item.retryAt)return;
 if(diceModel?.isSettled){if(!diceModel.isSettled(state.dice))return;}
 else if(!item.painted){
  if(performance.now()-item.since<150)return;
  requestAnimationFrame(()=>requestAnimationFrame(()=>{if(diceCompletion===item)item.painted=true;}));return;
 }
 item.pending=true;
 try{await request('action',{code:item.code,action:'diceSettled',version:state.version,rollKey:item.key,requestId:item.key+'-settled'});item.done=true;}
 catch(e){item.retryAt=Date.now()+Math.max(1000,e.retryAfterMs||0);}
 finally{item.pending=false;}
}
setInterval(completeVisibleDice,100);
async function joinRoom(code){
  if(!/^\d{6}$/.test(code)){$('joinError').textContent='Enter all six digits.';return;}
  const gen=++connectionGeneration;profileCode=null;$('joinBtn').disabled=true;$('joinError').textContent='';
  try{
    const saved=savedConnection(code),data=await request('join',{code,...(saved?{reconnectToken:saved.token}:{})});if(gen!==connectionGeneration)return;roomCode=data.code;controllerToken=data.controllerToken;pollFailures=0;pendingCommand=null;sending=false;
    state={...data.state,connected:true};saveConnection();showConnectedPanel();$('error').textContent='';paintConnection();
  }catch(e){if(gen===connectionGeneration)$('joinError').textContent=e.message;}finally{if(gen===connectionGeneration)$('joinBtn').disabled=false;}
}
$('joinForm').onsubmit=event=>{event.preventDefault();joinRoom($('roomInput').value.trim());};
function saveConnection(autoReconnect=true){try{const saved=savedConnection(roomCode),record=JSON.stringify({code:roomCode,token:controllerToken,autoReconnect,profile:state?.you?{name:state.you.name,avatar:state.you.avatar}:saved?.profile});sessionStorage.setItem(connectionStorageKey,record);sessionStorage.setItem(connectionStorageKey,record);sessionStorage.setItem(connectionStorageKey+':'+roomCode,record);}catch{}}
function showConnectedPanel(){
 window.applyIslandTheme?.(state?.theme||'haunted');
 const needsProfile=state?.mode==='own'&&!state.you;
 $('roomLabel').textContent='Room '+roomCode;$('joinPanel').hidden=true;$('profilePanel').hidden=!needsProfile;$('controller').hidden=needsProfile;
 if(needsProfile){if(profileCode!==roomCode){profileCode=roomCode;const saved=savedConnection(roomCode);if(saved?.profile){$('studentName').value=saved.profile.name;chosenAvatar=saved.profile.avatar;paintAvatarChoices();}}$('profileHelp').textContent=state.phase==='lobby'?'Choose your name and avatar.':'Returning to the game? Use your original name and avatar.';}
}
$('profileForm').onsubmit=async event=>{
 event.preventDefault();const gen=connectionGeneration;$('goBtn').disabled=true;$('profileError').textContent='';
 try{const data=await request('register',{code:roomCode,name:$('studentName').value.trim(),avatar:chosenAvatar});if(gen!==connectionGeneration)return;state={...data.state,connected:true};saveConnection();showConnectedPanel();paintConnection();}
 catch(e){if(gen===connectionGeneration)$('profileError').textContent=e.message;}finally{$('goBtn').disabled=false;}
};
if(queryCode&&/^\d{6}$/.test(queryCode))$('roomInput').value=queryCode;
const initialConnection=savedConnection(queryCode);if(initialConnection&&(queryCode||initialConnection.autoReconnect!==false))joinRoom(initialConnection.code);
$('roomInput').oninput=()=>{$('roomInput').value=$('roomInput').value.replace(/\D/g,'').slice(0,6);};
$('leaveBtn').onclick=()=>leave();$('profileLeave').onclick=()=>leave();
$('miniForm').onsubmit=event=>{event.preventDefault();const answer=$('miniAnswer').value.trim();if(answer)send('miniSubmit',{answer});};
$('speakCardBtn').onclick=()=>send('speak');$('mysteryCardBtn').onclick=()=>send('mystery');$('die').onclick=()=>diceModel?diceModel.roll():send(state?.actions?.includes('rollSteal')?'rollSteal':'roll');
setInterval(()=>{const delay=document.hidden?10000:pollFailures?Math.min(8000,1000*2**Math.min(pollFailures,3)):state?.phase==='finished'?5000:state?.phase?.startsWith('arcade')||state?.phase==='speakCard'||state?.shared&&state.phase==='miniTurn'||sending||pendingCommand?500:1500;if(Date.now()>=retryAfter&&Date.now()-(window.lastRegularPoll||0)>=delay){window.lastRegularPoll=Date.now();poll();}},150);
window.addEventListener('online',()=>{retryAfter=0;window.lastRegularPoll=0;poll();});
document.addEventListener('visibilitychange',()=>{if(!document.hidden){window.lastRegularPoll=Date.now();poll();}});
window.addEventListener('pagehide',notifyLeave);window.addEventListener('pageshow',e=>{if(e.persisted&&roomCode)joinRoom(roomCode);});
