let wordAudio=null,hearMessage='';
function stopWordAudio(){const previous=wordAudio;wordAudio=null;if(previous)window.speechSynthesis?.cancel();hearMessage='';}
const microphoneAvailable=Boolean(window.BrowserSpeech?.available);
let speechKey=null,voiceSession=null,voiceQueue=[],voiceMessage='',voiceChecking=null,voiceSending=false,voiceRetry=false,voiceRetryBlocked=false,lastMeterSent=0;
function stopControllerSpeech(){stopWordAudio();const previous=voiceSession;voiceSession=null;previous?.handle?.abort();voiceQueue=[];speechKey=null;voiceMessage='';voiceChecking=null;voiceRetry=false;voiceRetryBlocked=false;}
function queueVoice(payload){if(speechKey){if(payload.kind==='level'){if(voiceChecking||!voiceSession)return;voiceQueue=voiceQueue.filter(p=>p.kind!=='level');}else if(['result','end'].includes(payload.kind))voiceQueue=voiceQueue.filter(p=>p.kind!=='level');voiceQueue.push({key:speechKey,requestId:crypto.randomUUID(),...payload});}flushVoice();}
async function flushVoice(){
 if(voiceSending||!voiceQueue.length||!state?.connected)return;
 const next=voiceQueue[0];if(next.key!==speechKey||state.speech?.key!==speechKey){voiceQueue.shift();return;}
 voiceSending=true;
 try{await sendSpeech(next);if(voiceQueue[0]===next)voiceQueue.shift();}
 catch(e){if(next.key===speechKey){if(e.status===409){voiceQueue.shift();voiceChecking=null;voiceRetryBlocked=true;voiceMessage='Look at the board for the current card.';}else if(next.kind==='level')voiceQueue.shift();else voiceMessage='Reconnecting… Your answer will be sent.';}}
 finally{if(next.key===speechKey)renderSpeechController(state,sending);voiceSending=false;if(voiceQueue.length)setTimeout(flushVoice,200);}
}
function renderSpeechController(s,busy){
 const speech=s?.speech||{verified:false},card=s?.speech||s?.hearWord;
 const active=s?.connected&&s.phase==='speakCard'&&card;$('speechPanel').hidden=!active;document.body.classList.toggle('speak-turn',Boolean(active));
 if(!active){stopWordAudio();if(s?.connected&&speechKey)stopControllerSpeech();else if(!s?.connected&&voiceSession){voiceSession.handle?.abort();voiceSession=null;}return;}
 if(speechKey!==card.key){stopControllerSpeech();speechKey=card.key;voiceMessage=!s.speech?'':microphoneAvailable?'Tap the microphone, then say the word.':'Browser speech recognition is unavailable. Ask your teacher to use Answered or Pass.';if(s.speech)queueVoice({kind:'support',available:microphoneAvailable});}
 if(voiceChecking&&speech.lastAttemptId===voiceChecking){voiceChecking=null;voiceRetry=!speech.verified&&speech.available!==false;voiceMessage=voiceRetry?'Nice try! Tap the microphone to try again. / マイクを もういちど おしてね。':speech.message;}
 const phase=voiceSession?.phase,label=phase==='starting'?'Preparing…':phase==='stopping'||voiceChecking?'Checking…':voiceSession?'Listening…':speech.verified?'Correct!':'Say the word';
 $('sayWord').hidden=!s.speech;
 $('sayWord').disabled=Boolean(!s.speech||wordAudio||!microphoneAvailable||speech.verified||voiceChecking||phase==='starting'||phase==='stopping');
 if(window.SpeechVisuals){$('sayWord').innerHTML=window.SpeechVisuals.button(label);$('sayWord').classList?.toggle('recording',phase==='listening');}else $('sayWord').textContent=label;
 $('sayWord').setAttribute('aria-label',voiceSession?'Finish answer':label);$('sayWord').setAttribute('aria-pressed',String(!!voiceSession));
 const retry=$('voiceRetry'),meter=$('voiceMeter');if(retry)retry.hidden=!voiceRetry||speech.verified;if(meter){meter.hidden=phase!=='listening';if(!meter.innerHTML&&window.SpeechVisuals)meter.innerHTML=window.SpeechVisuals.bars();}
 const hear=$('hearWord');if(hear){hear.disabled=Boolean(!window.speechSynthesis||!window.SpeechSynthesisUtterance||!s.hearWord?.text||voiceSession||voiceChecking||wordAudio||speech.listening);hear.setAttribute('aria-busy',String(!!wordAudio));}const hearStatus=$('hearWordStatus');if(hearStatus)hearStatus.textContent=hearMessage;
 $('speechStatus').textContent=speech.verified?'Correct! Look at the board for your reward.':voiceMessage||speech.message||'';flushVoice();
}
function startControllerSpeech(){
 if(wordAudio||!state?.speech||voiceSession||!speechKey||voiceChecking||!state?.connected||!microphoneAvailable||state.speech?.verified||document.hidden)return;
 voiceRetryBlocked=false;
 const session={key:speechKey,attemptId:crypto.randomUUID(),handle:null,phase:'starting'};voiceSession=session;
 const current=()=>voiceSession===session&&speechKey===session.key;
 const finish=payload=>{if(!current())return;voiceSession=null;voiceChecking=session.attemptId;if(payload.unavailable){voiceRetryBlocked=true;voiceRetry=false;}voiceMessage=payload.kind==='result'?'Checking your word…':payload.message;queueVoice({...payload,...(payload.diagnostic?{error:payload.diagnostic}:{}),attemptId:session.attemptId});renderSpeechController(state,sending);};
 voiceMessage='Preparing microphone… Allow access if your browser asks.';renderSpeechController(state,sending);
 const handle=window.BrowserSpeech.start({onstart(){if(!current())return;session.phase='listening';voiceMessage='Listening… Say the word now. / はなしてね！';queueVoice({kind:'start',attemptId:session.attemptId});renderSpeechController(state,sending);},onheard(){if(current()){session.phase='stopping';voiceMessage='Checking your word…';renderSpeechController(state,sending);}},onlevel(level){if(!current()||session.phase!=='listening')return;window.SpeechVisuals?.draw($('voiceMeter'),level);if(Date.now()-lastMeterSent>=500){lastMeterSent=Date.now();queueVoice({kind:'level',level:Math.round(level*100)/100,sessionId:session.attemptId});}},onresult(alternatives){finish({kind:'result',transcripts:alternatives.map(a=>a.transcript),alternatives});},onerror(error){finish({kind:'end',...error});}});
 session.handle=handle;if(!current())handle?.abort();
}
$('sayWord').onclick=()=>{if(voiceSession){if(voiceSession.phase==='listening'){voiceSession.phase='stopping';voiceMessage='Finishing your answer…';voiceSession.handle?.stop();renderSpeechController(state,sending);}return;}startControllerSpeech();};
window.addEventListener('pagehide',stopControllerSpeech);
document.addEventListener?.('visibilitychange',()=>{if(document.hidden){stopWordAudio();if(voiceSession){voiceSession.handle?.abort();voiceSession=null;voiceRetryBlocked=true;voiceMessage='Tap the microphone to try again.';}}});

if($('hearWord'))$('hearWord').onclick=()=>{
 const card=state?.hearWord,synth=window.speechSynthesis;
 if(!state?.connected||state.phase!=='speakCard'||!card?.text||card.key!==speechKey||voiceSession||voiceChecking||state.speech?.listening||wordAudio||document.hidden||!synth||!window.SpeechSynthesisUtterance)return;
 const utterance=new window.SpeechSynthesisUtterance(card.text),voices=synth.getVoices().filter(v=>v.localService && /^en(?:[-_]|$)/i.test(v.lang));
 const voice=voices.find(v=>/^en[-_]NZ$/i.test(v.lang))||voices.find(v=>/^en[-_]GB$/i.test(v.lang))||voices.find(v=>v.default)||voices[0];
 if(voice)utterance.voice=voice;utterance.lang=voice?.lang||'en-GB';utterance.rate=.85;utterance.pitch=1;utterance.volume=1;
 wordAudio=utterance;hearMessage='Playing… / さいせいちゅう';renderSpeechController(state,sending);
 const finish=message=>{if(wordAudio!==utterance)return;wordAudio=null;hearMessage=message;renderSpeechController(state,sending);};
 utterance.onend=()=>finish('');utterance.onerror=()=>finish('Could not play. Tap to try again. / もういちど おしてね。');
 try{synth.speak(utterance);}catch{finish('Could not play. Tap to try again. / もういちど おしてね。');}
};
