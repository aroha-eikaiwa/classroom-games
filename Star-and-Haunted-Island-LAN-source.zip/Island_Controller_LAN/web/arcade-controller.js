(() => {
 const art=''+'/assets/';
 const scenes={scramble:'spooky-road',maze:'maze-graveyard',dash:'dash-carnival',listening:'listening-room',pronunciation:'pronunciation-stage',missing:'haunted-tower',spelling:'spelling-library',potato:'pumpkin-patch',rps:'rps-arena'};
 const isStar=s=>s?.theme==='star';
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let sessionEpoch=0,panel=null,view=null,clock=0,signature='',gameKey='',order=[],editSequence=0,swipeUntil=0,pending=0,draftTimer=null,latestNow=0,online=false,feedback='',mic=null,micBusy=false,micRetry=false,drag=null;
 const now=()=>Date.now()+clock;
 const enabled=()=>online&&view?.active&&!pending&&!micBusy;
 function stopMic(cancel=false){if(cancel){micRetry=false;mic?.abort();mic=null;micBusy=false;}else mic?.stop();}
 function setFeedback(text,shake=false){feedback=text;const label=document.getElementById('arcFeedback');if(label)label.textContent=text;if(shake){const row=document.getElementById('arcAnswerRow');if(row){row.classList.remove('wrong');void row.offsetWidth;row.classList.add('wrong');}}}
 function accept(next){if(!next||next.key!==view?.key||next.serverNow<latestNow)return;if(next.kind==='spelling'&&next.wordRound!==view.wordRound){order=[];gameKey=next.key+':'+next.stage+':'+next.wordRound;editSequence=next.you?.editSequence||0;}latestNow=next.serverNow;view=next;clock=next.serverNow-Date.now();if(state)state.arcade=next;renderContent();}
 async function command(type,payload={}){
  if(!view||!online)return;const epoch=sessionEpoch,currentKey=view.key,currentStage=view.stage;const current=()=>epoch===sessionEpoch&&view?.key===currentKey&&view?.stage===currentStage;
  const body={code:roomCode,key:currentKey,stage:currentStage,requestId:crypto.randomUUID(),type,...(view.kind==='spelling'?{wordRound:view.wordRound}:{}),...(['draft','submit'].includes(type)?{sequence:++editSequence}:{}),...payload};
  if(type!=='draft'){pending++;renderContent();}try{let data;try{data=await request('arcade',body);}catch(e){if(e.status)throw e;if(!current())return;data=await request('arcade',body);}if(!current())return;accept(data.arcade);setFeedback(view?.you?.feedback||'',view?.you?.feedback==='TRY AGAIN');if(data.replay&&window.speechSynthesis){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(data.replay);u.lang='en-US';u.voice=speechSynthesis.getVoices().find(v=>v.lang==='en-US')||speechSynthesis.getVoices().find(v=>v.lang.startsWith('en'))||null;u.rate=.8;speechSynthesis.speak(u);}}
  catch(e){if(current()&&!view.you?.completed&&(view.kind!=='spelling'||body.wordRound===view.wordRound))setFeedback(e.message);}
  finally{if(current()){if(type!=='draft')pending=Math.max(0,pending-1);renderContent();}}
 }
 function tileChanged(){setFeedback('');renderContent();clearTimeout(draftTimer);draftTimer=setTimeout(()=>command('draft',{order:order.slice()}),180);}
 const arrow=direction=>`<svg viewBox="0 0 64 64" aria-hidden="true" focusable="false" style="transform:rotate(${{up:0,right:90,down:180,left:270}[direction]}deg)"><path d="M32 7 9 30h14v27h18V30h14Z" fill="currentColor"/></svg>`;
 function showdown(s){if(!s.monsterChoice||!s.you?.choice)return '';return `<div class="arc-showdown"><div><strong>${isStar(s)?'CAPTAIN JACK':'VAMPIRE'}</strong><img class="arc-duel-avatar" src="${art}avatar-${esc(isStar(s)?'star-kai':'vampire')}.webp" alt="Opponent"><img src="${art}${isStar(s)?'star-':''}hand-${s.monsterChoice}.webp" alt="${isStar(s)?'Captain':'Monster'}: ${s.monsterChoice}"><span>${s.monsterChoice.toUpperCase()}</span></div><b>VS</b><div><strong>YOU</strong><img class="arc-duel-avatar" src="${art}avatar-${esc(state.you?.avatar||(isStar(s)?'star-leo':'ghost'))}.webp" alt="Your avatar"><img src="${art}${isStar(s)?'star-':''}hand-${s.you.choice}.webp" alt="You: ${s.you.choice}"><span>${s.you.choice.toUpperCase()}</span></div></div>`;}
 function finishDrag(cancel=false){if(!drag)return;const old=drag;drag=null;old.ghost.remove();old.button.classList.remove('dragging');if(cancel)order=old.before;signature='';renderContent();if(!cancel)tileChanged();}
 function bindWordDrag(){
  panel.querySelectorAll('[data-word]').forEach(button=>{
   button.onpointerdown=e=>{if(!enabled()||e.button!==0)return;e.preventDefault();const ghost=button.cloneNode(true);ghost.removeAttribute('id');ghost.className='arc-drag-ghost';ghost.style.width=button.offsetWidth+'px';document.body.append(ghost);drag={id:Number(button.dataset.word),pointer:e.pointerId,button,ghost,before:order.slice(),key:view.key,stage:view.stage};button.classList.add('dragging');button.setPointerCapture(e.pointerId);move(e);};
   function move(e){if(!drag||e.pointerId!==drag.pointer)return;drag.ghost.style.left=e.clientX+'px';drag.ghost.style.top=e.clientY+'px';const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-word]');if(target&&target!==drag.button){const from=order.indexOf(drag.id),to=order.indexOf(Number(target.dataset.word));order.splice(from,1);order.splice(to,0,drag.id);const row=drag.button.parentElement;row.insertBefore(drag.button,from<to?target.nextSibling:target);drag.button.setPointerCapture(e.pointerId);}}
   button.onpointermove=move;button.onpointerup=e=>{if(drag&&e.pointerId===drag.pointer)finishDrag();};button.onpointercancel=()=>finishDrag(true);button.onlostpointercapture=()=>{if(drag)finishDrag(true);};
   button.onkeydown=e=>{if(!enabled()||!['ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();const id=Number(button.dataset.word),from=order.indexOf(id),to=Math.max(0,Math.min(order.length-1,from+(e.key==='ArrowLeft'?-1:1)));order.splice(from,1);order.splice(to,0,id);tileChanged();panel.querySelector(`[data-word="${id}"]`)?.focus();};
  });
 }
 function microphone(){
  if(mic){mic.stop();return;}if(!enabled())return;
  if(!window.BrowserSpeech?.available){setFeedback('このブラウザーでは 音声認識が つかえません。せんせいに つたえてね。');return;}
  const epoch=sessionEpoch,key=view.key,stage=view.stage,requestId=crypto.randomUUID();micBusy=true;setFeedback('マイクを じゅんび…');renderContent();
  const current=()=>epoch===sessionEpoch&&view?.key===key&&view.stage===stage&&view.status==='playing'&&online&&state?.connected;
  async function finish(alternatives,error='',unavailable=false){
   mic=null;if(!current()){micBusy=false;renderContent();return;}setFeedback(error?'もういちど チャレンジ！':'Checking…');renderContent();
   try{const body={code:roomCode,key,stage,requestId,alternatives,error};let data;try{data=await request('arcade-speech',body);}catch(e){if(e.status)throw e;if(!current())return;data=await request('arcade-speech',body);}if(current()){accept(data.arcade);micRetry=!unavailable&&!data.arcade.you?.completed&&data.arcade.status==='playing';setFeedback(micRetry?'Nice try! Tap the microphone to try again. / マイクを もういちど おしてね。':data.arcade.you?.feedback||'');}}
   catch(e){if(current())setFeedback(e.message);}finally{if(epoch===sessionEpoch){micBusy=false;renderContent();}}
  }
  const session={phase:'starting',handle:null,stop(){this.handle?.stop();},abort(){this.handle?.abort();}};mic=session;session.handle=window.BrowserSpeech.start({onstart(){if(current()){session.phase='listening';setFeedback('Listening… はなしてね！');renderContent();}},onheard(){if(current()){session.phase='checking';renderContent();}},onlevel(level){if(current()&&session.phase==='listening')window.SpeechVisuals?.draw(panel,level);},onresult:alternatives=>finish(alternatives),onerror:e=>finish([],e.diagnostic||e.error,e.unavailable)});renderContent();
 }
 function markup(s){
  const header=`<div class="arc-controller-head"><small>MINI GAME${s.stageCount>1?' · '+(s.stage+1)+' / '+s.stageCount:''}</small><h1>${esc(s.name)}</h1><strong id="arcDeviceClock"></strong></div>`;
  if(s.status==='intro')return header+`<div class="arc-device-intro"><div>${s.icon}</div><h2>${esc(s.instructions)}</h2><p lang="ja">${esc(s.ja)}</p><strong id="arcDeviceCount"></strong></div>`;
  if(s.status==='results'){const award=s.awards.find(a=>a.id===state.you?.id);return header+showdown(s)+`<div class="arc-device-result"><div>${award?.candy?'🎉':isStar(s)?'⭐':'🎃'}</div><h2>${s.skipped?'Next game!':award?.candy?'Nice job!':'Thanks for playing!'}</h2>${s.answer?`<p>Answer: ${esc(s.answer)}</p>`:''}${s.kind==='spelling'?'<p class="arc-word-score">'+(award?.score||0)+' words / ことば</p>':''}<strong>+${award?.candy||0} ${isStar(s)?'⭐':'🍬'}</strong><p lang="ja">ボードを みてね。</p></div>`;}
  let body=`<p class="arc-device-help" lang="ja">${esc(s.ja)}</p>`;if(s.kind==='potato'&&s.holder===state.you?.id&&s.image)body+=`<img class="arc-held-object" src="${esc(s.heldObject)}" alt="${isStar(s)?'Hot coconut':'Cursed pumpkin'}"><img class="arc-held-picture" src="${esc(s.image)}" alt="Name this picture">`;
  if(s.you?.completed)return header+body+'<div class="arc-device-result"><div>✓</div><h2>NICE!</h2><p lang="ja">みんなを おうえんしよう！</p></div>';
  if(s.revealing)return header+body+showdown(s)+`<div class="arc-device-result"><h2>${s.kind==='rps'?'SHOOT!':'Watch the board!'}</h2><p>${esc(s.you?.feedback||'')}</p></div>`;
  const disabled=!enabled()?'disabled':'';
  if(['scramble','spelling'].includes(s.kind)){
   body+=`${s.kind==='spelling'?'<p class="arc-word-score">Words made / できた ことば: '+(s.completedWords||0)+'</p>':''}<div id="arcAnswerRow" class="arc-answer-row arc-word-rack" aria-label="Drag words into sentence order">${order.map((id,i)=>`<button type="button" data-word="${id}" aria-label="${esc(s.tiles.find(t=>t.id===id)?.word)}, position ${i+1}. Drag to move, or use left and right arrow keys." ${disabled}><span class="arc-grip" aria-hidden="true">⠿</span>${esc(s.tiles.find(t=>t.id===id)?.word)}</button>`).join('')}</div><p class="arc-drag-help" lang="ja">ドラッグして じゅんばんを かえよう。</p><button id="arcGo" ${!enabled()||order.length!==s.tiles?.length?'disabled':''}>GO</button>`;
  }else if(s.kind==='maze')body+=`<div class="arc-dpad" aria-label="Move through the word maze">${['up','left','down','right'].map(dir=>`<button data-dir="${dir}" aria-label="${dir}" ${disabled}>${arrow(dir)}</button>`).join('')}</div><p>Swipe or tap / スワイプか タップ</p>`;
  else if(s.kind==='pronunciation')body+=`<button id="arcMic" class="arc-mic ${mic?'recording':''}" ${(!enabled()&&!mic)?'disabled':''}>${window.SpeechVisuals?.button(mic?.phase==='listening'?'Listening…':mic?'Checking…':'Say the word')||'Say the word'}</button>${micRetry?'<p class="voice-retry">Nice try, try again<small lang="ja">おしい！ もういちど いってみよう</small></p>':''}${mic?.phase==='listening'?window.SpeechVisuals?.bars()||'':''}`;
  else if(s.kind==='potato'&&s.holder!==state.you?.id)body+=`<div class="arc-safe"><h2>Safe for now</h2><p lang="ja">いまは あんしん！</p></div>`;
  else if(s.you?.chosen)body+='<div class="arc-device-result"><div>🔒</div><h2>Locked in!</h2><p lang="ja">つぎの もんだいを まってね。</p></div>';
  else body+=`<div class="arc-options ${s.kind==='rps'?'hands':''}">${(s.options||[]).map(o=>`<button type="button" data-option="${esc(o.id)}" ${disabled}>${o.image?`<img src="${esc(o.image)}" alt="${s.kind==='rps'?esc(o.text):'Choose this picture'}">${o.text?`<span>${esc(o.text)}</span>`:''}`:esc(o.text)}</button>`).join('')}</div>${s.kind==='listening'?`<button id="arcReplay" class="arc-replay" ${disabled}>🔊 Replay <small>+1 second / 1びょう プラス</small></button>`:''}`;
  return header+body+'<p id="arcFeedback" role="status" aria-live="polite"></p>';
 }
 function renderContent(){
  if(!panel||!view||!panel.isConnected||drag)return;
  if(['scramble','spelling'].includes(view.kind)&&view.tiles&&!order.length)order=(view.you?.order?.length===view.tiles.length?view.you.order:view.tiles.map(t=>t.id)).slice();
  const next=JSON.stringify([view.key,view.kind,view.status,view.stage,view.revealing,view.go,view.holder,view.you,view.tiles,view.options,view.awards,view.wordRound,view.monsterChoice,view.active,pending,micBusy,mic?.phase,micRetry,order,online]);
  if(next!==signature){signature=next;panel.innerHTML=markup(view);
   panel.querySelectorAll('[data-tile]').forEach(b=>b.onclick=()=>{order.push(Number(b.dataset.tile));tileChanged();});
   panel.querySelectorAll('[data-undo]').forEach(b=>b.onclick=()=>{order.splice(Number(b.dataset.undo),1);tileChanged();});
   if(['scramble','spelling'].includes(view.kind))bindWordDrag();
   const go=document.getElementById('arcGo');if(go)go.onclick=()=>{clearTimeout(draftTimer);command('submit',{order:order.slice()});};
   const controlKey=view.key,controlStage=view.stage;const currentControl=()=>view?.key===controlKey&&view?.stage===controlStage;panel.querySelectorAll('[data-option]').forEach(b=>b.onclick=()=>{if(currentControl())command('choice',{choice:b.dataset.option});});
   panel.querySelectorAll('[data-dir]').forEach(b=>b.onclick=()=>{if(Date.now()>swipeUntil)command('move',{direction:b.dataset.dir});});

   const replay=document.getElementById('arcReplay');if(replay)replay.onclick=()=>command('replay');
   const button=document.getElementById('arcMic');if(button)button.onclick=microphone;
  }
  if(feedback)setFeedback(feedback);else if(view.you?.feedback)setFeedback(view.you.feedback);
  updateClock();
 }
 function updateClock(){if(!view||!panel||panel.hidden)return;const n=now(),label=document.getElementById('arcDeviceClock'),count=document.getElementById('arcDeviceCount');if(count)count.textContent=Math.max(1,Math.ceil((view.startAt-n)/1000));if(label)label.textContent=!online?'Reconnecting…':view.status!=='playing'?'':view.you?.lockUntil>n?'Wait '+Math.ceil((view.you.lockUntil-n)/1000)+'s':n<view.stageStart?'Ready…':view.revealing?'':view.deadline?Math.max(0,Math.ceil((view.deadline-n)/1000))+'s':'';}
 window.ArcadeController={render(s){
  const show=s?.mode==='own'&&s.phase?.startsWith('arcade');document.body.classList.toggle('arcade-mode',!!show);
  if(!show){finishDrag(true);if(panel)panel.hidden=true;if(view){stopMic(true);window.speechSynthesis?.cancel();}view=null;gameKey='';signature='';latestNow=0;return false;}
  if(!panel){panel=document.createElement('section');panel.id='arcadeController';document.getElementById('controller').append(panel);let touch=null;panel.addEventListener('touchstart',e=>{if(view?.kind==='maze'&&enabled()&&e.target.closest('.arc-dpad'))touch={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});panel.addEventListener('touchend',e=>{if(!touch||view?.kind!=='maze'||!enabled())return;const dx=e.changedTouches[0].clientX-touch.x,dy=e.changedTouches[0].clientY-touch.y;touch=null;if(Math.max(Math.abs(dx),Math.abs(dy))<35)return;swipeUntil=Date.now()+450;command('move',{direction:Math.abs(dx)>Math.abs(dy)?dx>0?'right':'left':dy>0?'down':'up'});},{passive:true});}
  panel.hidden=false;online=!!s.connected;if(s.arcade?.kind)document.body.style.setProperty('--device-scene',`url(${art}${isStar(s)?'star-'+(s.arcade.kind==='retired'?'scramble':s.arcade.kind):(scenes[s.arcade.kind]||scenes.scramble)}.webp)`);
  if(!s.arcade){panel.innerHTML='<h1>MINI GAME</h1><p>Getting ready…</p>';return true;}
  const nextKey=s.arcade.key+':'+s.arcade.stage+':'+(s.arcade.wordRound??'');if(drag&&(drag.key!==s.arcade.key||drag.stage!==s.arcade.stage||s.arcade.status!=='playing'||!online))finishDrag(true);if(gameKey!==nextKey){stopMic(true);clearTimeout(draftTimer);gameKey=nextKey;order=[];editSequence=0;feedback='';signature='';latestNow=0;pending=0;}
  if(s.arcade.serverNow>=latestNow){view=s.arcade;editSequence=Math.max(editSequence,view.you?.editSequence||0);latestNow=view.serverNow;clock=view.serverNow-Date.now();}
  if(view.status==='results'||view.you?.completed||!online)stopMic(true);renderContent();return true;
 },stop(){sessionEpoch++;clearTimeout(draftTimer);finishDrag(true);stopMic(true);view=null;online=false;gameKey='';signature='';latestNow=0;pending=0;order=[];feedback='';window.speechSynthesis?.cancel();}};
 document.addEventListener?.('keydown',e=>{const dir={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right'}[e.key];if(!dir||view?.kind!=='maze'||!enabled()||e.repeat||/^(INPUT|TEXTAREA|SELECT)$/.test(e.target?.tagName)||e.target?.isContentEditable)return;e.preventDefault();command('move',{direction:dir});});
 setInterval(updateClock,100);window.addEventListener('pagehide',()=>stopMic(true));
})();
