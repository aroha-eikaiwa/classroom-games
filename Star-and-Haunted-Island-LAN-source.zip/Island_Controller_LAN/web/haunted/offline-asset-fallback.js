(() => {
 const placeholders = /^(?:\/)?assets\//;
 window.addEventListener('error', e => {
   const img=e.target;
   if(img?.tagName!=='IMG' || !placeholders.test(img.getAttribute('src')||'') || img.dataset.fallback) return;
   img.dataset.fallback='true';
   img.src='symbol.svg';
 }, true);
})();
