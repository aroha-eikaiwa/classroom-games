(() => {
 const weights=[.25,.42,.65,.85,1,.85,.65,.42,.25];
 const bars=()=>'<div class="voice-bars" aria-hidden="true">'+weights.map(()=>'<i></i>').join('')+'</div>';
 function draw(root,level){if(!root)return;root.querySelectorAll('.voice-bars i').forEach((bar,i)=>{bar.style.height=(5+Math.max(0,Math.min(1,level||0))*48*weights[i])+'px';});}
 function meter(onlevel){
  let cancelled=false,stream=null,context=null,source=null,frame=null;
  const stop=()=>{cancelled=true;if(frame!==null)window.cancelAnimationFrame?.(frame);source?.disconnect();stream?.getTracks().forEach(t=>t.stop());context?.close().catch(()=>{});onlevel?.(0);};
  (async()=>{try{
   if(!navigator.mediaDevices?.getUserMedia)return;
   stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
   if(cancelled){stream.getTracks().forEach(t=>t.stop());return;}
   const C=window.AudioContext||window.webkitAudioContext;if(!C){stop();return;}context=new C();await context.resume();if(cancelled){context.close().catch(()=>{});return;}
   source=context.createMediaStreamSource(stream);const analyser=context.createAnalyser();analyser.fftSize=256;source.connect(analyser);const samples=new Uint8Array(analyser.fftSize);let smooth=0;
   const tick=()=>{if(cancelled)return;analyser.getByteTimeDomainData(samples);let sum=0;for(const v of samples)sum+=((v-128)/128)**2;const level=Math.min(1,Math.sqrt(sum/samples.length)*7);smooth=level>smooth?level:smooth*.72;onlevel?.(smooth);frame=window.requestAnimationFrame(tick);};tick();
  }catch{stop();}})();return {stop};
 }
 window.SpeechVisuals={bars,draw,meter,button(label='Say the word'){return '<img class="voice-mic-art" src="/assets/speak-microphone-v1.webp" alt=""><span class="voice-mic-label">'+label+'<small lang="ja">'+({'Say the word':'ことばを いおう','Listening…':'はなしてね！','Preparing…':'マイクを じゅんび','Checking…':'かくにんちゅう','Correct!':'せいかい！'}[label]||'')+'</small></span>';}};
})();
