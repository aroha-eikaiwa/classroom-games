(() => {
  let key=null,roundKey=null,active=false,timer=null,element=null,generation=0;
  const hide=()=>{active=false;if(element)element.hidden=true;};
  window.TurnAnnouncement={
    get active(){return active;},
    update(state,epoch,onDone){
      if(!state){this.cancel();return;}
      if(state.phase!=='ready'){clearTimeout(timer);generation++;hide();return;}
      const next=epoch+':'+state.round+':'+state.turn;
      if(next===key)return;key=next;clearTimeout(timer);const token=++generation;active=true;
      if(!element){element=document.createElement('div');element.className='turn-announcement';element.setAttribute('role','status');element.setAttribute('aria-live','polite');document.body.append(element);}
      const round=epoch+':'+state.round,slides=[];
      if(round!==roundKey){roundKey=round;slides.push(state.round===state.maxRounds?'Final Round':'Round '+state.round);}
      slides.push(state.players[state.turn].name+"’s turn");
      const show=()=>{
        if(token!==generation)return;
        element.textContent=slides.shift();element.style.setProperty('--turn-colour',state.players[state.turn].color);
        element.hidden=false;element.classList.remove('show');void element.offsetWidth;element.classList.add('show');
        timer=setTimeout(()=>{if(token!==generation)return;if(slides.length)show();else{hide();onDone();}},2000);
      };
      show();
    },
    cancel(){clearTimeout(timer);generation++;key=null;roundKey=null;hide();}
  };
})();
