(() => {
// Exact templates retain names, counts and room identifiers as app data.
const patterns = {
  island: [
    [/^Player (\d+) name$/, ([, count]) => `プレイヤー${count}の名前`],
    [/^Choose avatar for player (\d+)$/, ([, count]) => `プレイヤー${count}のアバターを選択`],
    [/^(\d+) Speak cards \+ (\d+) Mystery cards\. (.+)$/, ([, speak, mystery, hint]) => `スピークカード ${speak}枚＋ミステリーカード ${mystery}枚。${hint.startsWith('Choose') ? 'テーマとカードの種類を組み合わせてください。' : '色の絵カードは色のテーマを使います。'}`],
    [/^(\d+) \/ 6 joined · Waiting for at least 2 players$/, ([, count]) => `参加：${count}／6人・2人以上で開始できます`],
    [/^(\d+) \/ 6 joined · Ready when everyone is here$/, ([, count]) => `参加：${count}／6人・全員がそろったら開始できます`],
  ],
};


const contentSelector = 'script,style,textarea,svg,canvas,[contenteditable=true]';
const fields = ['aria-label', 'title', 'placeholder', 'label', 'alt'];
const roots = {
  island: '.setup,.lobby-modal,.room-strip,nav:has(#soundBtn),.modal:has(#confirmYes,.rules-grid),.control-panel,#toast,#mysteryDrawPrompt',
};

function targets(game) {return roots[game];}

function install(game, copy) {
  const terms = new Map(copy);
  const rules = patterns[game] ?? [];
  const setupSelector = '.setup,.lobby-modal';
  const languageKey = 'aroha-island-settings-language';
  let settingsLanguage = 'en';
  try { settingsLanguage = localStorage.getItem(languageKey) === 'ja' ? 'ja' : 'en'; } catch {}
  const extraTerms = [
    ['Close dialog','閉じる'], ['Choose a matching theme and mode.','組み合わせられるテーマとカードの種類を選んでください。'],
    ['Colour pictures use Colours.','「絵と色」には「色」のテーマを使います。'],
    ['Avatar','アバター'], ['Choose avatar','アバターを選ぶ'], ['Choose an adventurer','キャラクターを選ぶ'],
    ['Little devil','小悪魔'],['Spider','クモ'],['Candy','キャンディー'],['Pumpkin','カボチャ'],['Ghost','おばけ'],['Bat','コウモリ']
  ];
  for (const pair of extraTerms) terms.set(...pair);
  const reverseTerms = new Map([...terms].map(([en,ja])=>[ja,en]));
  function settingsText(value) {
    const text = value.trim().replace(/\s+/g,' ');
    const en = reverseTerms.get(text) || text;
    const cards = en.match(/^(\d+) Speak cards \+ (\d+) Mystery cards\. (.*)$/);
    let output = settingsLanguage === 'ja' ? terms.get(en) || text : en;
    if(cards) output = settingsLanguage === 'ja'
      ? `スピークカード ${cards[1]}枚 ＋ ミステリーカード ${cards[2]}枚。${terms.get(cards[3])||cards[3]}` : en;
    return value.replace(/\S(?:[\s\S]*\S)?/,()=>output);
  }
  function setupControls() {
    if (!document.getElementById('settings-language-style')) {
      const style=document.createElement('style'); style.id='settings-language-style';
      style.textContent=`.settings-language{display:flex;justify-content:flex-end;margin:0 0 12px;gap:3px}.settings-language button{font:inherit;font-size:16px;font-weight:bold;padding:7px 12px;border-radius:9px;border:1px solid #b9ced7;background:white;color:#164a60;line-height:1.3;min-height:36px}.settings-language button[aria-pressed=true]{background:#0b5a7b;color:white;border-color:#0b5a7b}.settings-language button:focus-visible{outline:3px solid #edaa30;outline-offset:3px}.setup [lang=ja]:not(.settings-language button){display:none!important}`;
      document.head.append(style);
    }
    for (const root of document.querySelectorAll(setupSelector)) {
      let control=root.querySelector('.settings-language');
      if(!control){
        control=document.createElement('div');control.className='settings-language';control.role='group';
        control.innerHTML='<button type="button" data-settings-language="en" lang="en">English</button><button type="button" data-settings-language="ja" lang="ja">日本語</button>';
        control.addEventListener('click',event=>{
          const button=event.target.closest('[data-settings-language]');if(!button)return;
          settingsLanguage=button.dataset.settingsLanguage;
          try{localStorage.setItem(languageKey,settingsLanguage);}catch{}
          document.dispatchEvent(new Event('island-settings-language'));
        });
        root.prepend(control);
      }
      root.lang=settingsLanguage;
      control.setAttribute('aria-label',settingsLanguage==='ja'?'設定画面の言語':'Settings language');
      for(const button of control.querySelectorAll('button'))button.setAttribute('aria-pressed',String(button.dataset.settingsLanguage===settingsLanguage));
    }
  }
  const localizedText = new WeakMap();
  const localizedAttributes = new WeakMap();

  function translate(value, separator = ' / ') {
    const original = value.trim().replace(/\s+/g, ' ');
    if (!original) return value;
    let counterpart = terms.get(original);
    if (!counterpart) {
      for (const [pattern, render] of rules) {
        const match = original.match(pattern);
        if (!match) continue;
        counterpart = render(match, terms);
        break;
      }
    }
    if (!counterpart || original === counterpart) return value;
    return value.replace(/\S(?:[\s\S]*\S)?/, label => label + separator + counterpart);
  }

  function localize(node) {
    if(node.closest('.settings-language')) return;
    const inSettings=!!node.closest(setupSelector);
    const ignored = node.closest(contentSelector);
    if (ignored && (node !== ignored || node.tagName !== 'svg')) return;
    const attributes = localizedAttributes.get(node) ?? new Map();
    localizedAttributes.set(node, attributes);
    for (const field of fields) {
      const label = node.getAttribute(field);
      if (!label) continue;
      const previous=attributes.get(field);
      const original=previous?.rendered===label?previous.original:label;
      const translated=inSettings?settingsText(original):translate(original);
      attributes.set(field,{original,rendered:translated});
      if(translated!==label)node.setAttribute(field,translated);
    }
    if (ignored) return;
    for (const child of node.childNodes) {
      if (child.nodeType === 1) {
        localize(child);
        continue;
      }
      if (child.nodeType !== 3) continue;
      const current=child.nodeValue,previous=localizedText.get(child);
      const original=previous?.rendered===current?previous.original:current;
      const translated=inSettings?settingsText(original):translate(original);
      localizedText.set(child,{original,rendered:translated});
      if (translated === current) continue;
      // Keep form values and player input independent from displayed labels.
      if (node.tagName === 'OPTION' && !node.hasAttribute('value')) node.setAttribute('value', node.value);
      child.nodeValue = translated;
    }
  }

  let selector;
  function refresh() {
    setupControls();
    selector = targets(game);
    const selected = document.querySelectorAll(selector);
    for (const root of selected) {
      if (!root.parentElement?.closest(selector)) localize(root);
    }
  }

  if (game === 'animals') {
    // Translate the prompt but keep the exact value the teacher must enter.
    for (const method of ['confirm', 'prompt']) {
      const nativeDialog = window[method].bind(window);
      window[method] = (message, ...args) => nativeDialog(translate(String(message), '\n\n'), ...args);
    }
  }

  function start() {
    let observer;
    function update(records) {
      const next = targets(game);
      if (next !== selector || !records) {
        observer.disconnect();
        refresh();
        observe();
        return;
      }
      observer.disconnect();
      refresh();
      observe();
    }
    function observe() {
      observer.observe(document.documentElement, {
        subtree: true, childList: true, characterData: true,
        attributes: true, attributeFilter: [...fields, 'class', 'open', 'hidden', 'inputmode'],
      });
    }
    document.addEventListener('island-settings-language',()=>update());
    observer = new MutationObserver(update);
    update();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
  else start();
}

install("island", [["Teacher sign in","先生用ログイン"],["Teacher controls","先生用設定"],["Teacher menu","先生用メニュー"],["Teacher password","先生用パスワード"],["Teacher dashboard","先生用ダッシュボード"],["Sign in","ログイン"],["Sign out","ログアウト"],["Password","パスワード"],["New password","新しいパスワード"],["Confirm password","パスワードの確認"],["Confirm new password","新しいパスワードの確認"],["Change password","パスワードを変更"],["Show password","パスワードを表示"],["Signing in…","ログイン中…"],["Refresh","更新"],["Reload","再読み込み"],["Loading…","読み込み中…"],["Saving…","保存中…"],["Save","保存"],["Settings saved.","設定を保存しました。"],["School","学校"],["Class","クラス"],["School and class","学校・クラス"],["Student","児童"],["Students","児童"],["Attendance number","出席番号"],["Name","名前"],["Status","状況"],["Back","戻る"],["Back to list","一覧に戻る"],["Cancel","キャンセル"],["Close","閉じる"],["Open","開く"],["Open / edit","開く・編集する"],["Open →","開く →"],["Select class","クラスを選択"],["Choose a class","クラスを選択"],["Demo","デモ"],["New demo","新しいデモ"],["Save demo","デモを保存"],["Teacher demonstration","先生用デモ"],["Viewing as teacher","先生として表示中"],["Back to dashboard","ダッシュボードに戻る"],["No game prepared","ゲームが準備されていません"],["Online","オンライン"],["Offline","オフライン"],["Shopkeeper","お店の人"],["Customer","買い物客"],["Shopping","買い物"],["Paused","一時停止中"],["Locked","ロック中"],["Unlocked","利用可能"],["Invalid password","パスワードが正しくありません"],["Invalid password.","パスワードが正しくありません。"],["Incorrect password","パスワードが正しくありません"],["Incorrect password.","パスワードが正しくありません。"],["The passwords do not match.","パスワードが一致しません。"],["The request could not be completed. Check your password and try again.","操作を完了できませんでした。パスワードを確認して、もう一度お試しください。"],["Choose game","ゲームを選択"],["Game controls","ゲーム操作"],["SFX on","効果音オン"],["SFX off","効果音オフ"],["Music on","音楽オン"],["Music off","音楽オフ"],["Controller tab","コントローラーを開く"],["Recognition logs","音声認識ログ"],["Room code","ルームコード"],["Reconnect","再接続"],["Retry controller connection","コントローラーに再接続"],["Creating room…","ルームを作成中…"],["Join with a controller","コントローラーで参加"],["QR code for the student controller","児童用コントローラーのQRコード"],["WELCOME TO STAR ISLAND","スターアイランドへようこそ"],["WELCOME TO HAUNTED ISLAND","ホーンテッドアイランドへようこそ"],["An island full of adventure.","冒険がいっぱいの島"],["A night full of spooky surprises.","びっくりする仕掛けがいっぱいの夜"],["Choose your players and cards. Speak English and collect stars!","プレイヤーとカードを選び、英語を話して星を集めよう！"],["Choose your players and cards. Speak English and collect candy!","プレイヤーとカードを選び、英語を話してキャンディーを集めよう！"],["Controller mode","コントローラーの使い方"],["Shared controller","コントローラーを共有"],["Own devices","各自の端末で参加"],["Players","プレイヤー数"],["Player names","プレイヤー名"],["Rounds","ラウンド数"],["Voice recognition","音声認識"],["Off: the teacher checks answers using Answered or Pass. Pronunciation mini-games are excluded.","オフの場合は、先生が「答えた」または「パス」で解答を判定します。発音のミニゲームは出題されません。"],["One controller, taking turns. The teacher confirms answers and duel results.","1台のコントローラーを交代で使います。解答と対戦結果は先生が確認します。"],["Vocabulary themes","単語のテーマ"],["Card modes","カードの種類"],["Read English","英語を読む"],["Pictures → English","絵を見て英語で言う"],["Colour pictures","絵と色"],["Mini-games","ミニゲーム"],["Choose the games that can appear after each round. Uncheck all to turn mini-games off.","各ラウンドの後に出題するミニゲームを選びます。すべてのチェックを外すと、ミニゲームを行いません。"],["Picture Spelling","絵を見てスペルを入力"],["Sentence Speaker","英語の文を言う"],["Hot Coconut","ココナッツを渡そう"],["Listen & Pick","聞いて選ぶ"],["Picture → Word","絵を見て単語を選ぶ"],["Word → Picture","単語を見て絵を選ぶ"],["Sentence Scramble","文を並べ替える"],["Garden Maze","ことばの迷路"],["Word Dash","単語クイズ"],["Listening Race","リスニングレース"],["Star Speaker","単語を発音する"],["Missing Word","空欄に入る単語"],["Treehouse Spelling","文字を並べて単語を作る"],["Captain Jack’s Battle","キャプテン・ジャックとじゃんけん"],["Cursed Pumpkin","カボチャを渡そう"],["Pronunciation Challenge","発音チャレンジ"],["Spelling Sprint","スペル早打ち"],["Word Path","ことばの迷路"],["Monster RPS Battle","モンスターとじゃんけん"],["Start the adventure","冒険を始める"],["Resume saved game","保存したゲームを再開"],["Back to game","ゲームに戻る"],["Choose an avatar","アバターを選択"],["Choose an avatar for each player.","各プレイヤーのアバターを選んでください。"],["Choose a matching theme and card mode.","組み合わせられるテーマとカードの種類を選んでください。"],["The saved game could not be loaded. Please start a new adventure.","保存したゲームを読み込めませんでした。新しい冒険を始めてください。"],["ANIMALS","動物"],["BUILDINGS","建物"],["SCHOOL","学校"],["SPORTS","スポーツ"],["FOOD","食べ物"],["FRUIT","果物"],["FRUITS","果物"],["VEGETABLES","野菜"],["CLOTHES","服"],["COLOURS","色"],["COLORS","色"],["HALLOWEEN","ハロウィン"],["NATURE","自然"],["TRANSPORT","乗り物"],["WEATHER","天気"],["THINGS","物"],["SCHOOL SUPPLIES","文房具"],["DAILY LIFE","日常生活"],["CLASSROOM","教室"],["JOBS","職業"],["ACTIONS","動作"],["FEELINGS","気持ち"],["NUMBERS","数字"],["PLACES","場所"],["Animations on","アニメーションオン"],["Animations off","アニメーションオフ"],["Switch between animated and instant movement","移動アニメーションのオン・オフを切り替え"],["OWN DEVICES","各自の端末で参加"],["Waiting for players","プレイヤーの参加を待っています"],["Join at","参加先"],["Choose a name and adventurer, then press GO.","名前とキャラクターを選び、「GO」を押してください。"],["First to join plays first. 2–6 players.","参加順にプレイします。2〜6人で遊べます。"],["Back to options","設定に戻る"],["Start game","ゲームを始める"],["Fullscreen","全画面"],["Full screen","全画面"],["Exit fullscreen","全画面を終了"],["Students join with their names and avatars. First to join plays first. Random island mini-games run at the end of each round.","児童は名前とアバターを選んで参加します。参加した順にプレイし、各ラウンドの最後にミニゲームがランダムに出題されます。"],["Students join with their names and avatars. First to join plays first. Random Halloween mini-games run at the end of each round.","児童は名前とアバターを選んで参加します。参加した順にプレイし、各ラウンドの最後にハロウィンのミニゲームがランダムに出題されます。"],["Enter this code to join","このコードを入力して参加"],["Connection unavailable · retrying","接続できません・再試行中"],["Game server busy · reconnecting…","ゲームサーバーが混雑しています・再接続中…"],["Reconnecting controllers…","コントローラーに再接続中…"],["Starting game…","ゲームを開始しています…"],["MONTHS","月"],["FOOD & DRINK","食べ物・飲み物"],["FAMILY","家族"],["New game","新しいゲーム"],["TEACHER CONTROLS","先生用操作"],["Undo turn","前のターンに戻る"],["Start a new adventure?","新しい冒険を始めますか？"],["This will replace the saved game.","保存済みのゲームは上書きされます。"],["Replay the previous turn?","前のターンをやり直しますか？"],["Restore positions, stars, cards and items to before the latest movement roll.","位置、スター、カード、アイテムを直前のサイコロを振る前の状態に戻します。"],["Restore positions, candy, cards and items to before the latest movement roll.","位置、キャンディー、カード、アイテムを直前のサイコロを振る前の状態に戻します。"],["Continue","続ける"],["Current turn","現在のターン"],["Player scores","各プレイヤーの得点"],["Tap to roll the dice","押してサイコロを振る"],["Something paused the game. Refresh to resume.","ゲームが中断されました。画面を更新すると再開できます。"],["Use your browser’s full screen option (F11).","ブラウザーの全画面表示（F11）を使ってください。"],["ミステリーカードを引く","Draw a Mystery card"],["No players yet.","まだ誰も参加していません。"],["Choose a name and monster, then press GO.","名前とモンスターを選び、「GO」を押してください。"],["A TEACHER-LED ENGLISH ADVENTURE","先生が進める英語の冒険"],["Collect stars, try English, and explore together.","英語を使い、スターを集めながらみんなで冒険しよう。"],["Collect candy, try English, and explore together.","英語を使い、キャンディーを集めながらみんなで冒険しよう。"],["1. Choose, roll, move","1. アイテムを選び、サイコロを振って進む"],["2. Stop and click a deck","2. 止まったらカードを引く"],["Mini games","ミニゲーム"],["Floating special stars","空に浮かぶ特別なスター"],["Floating special candies","空に浮かぶ特別なキャンディー"],["3. Try some English","3. 英語で答える"],["4. Duel with your teacher","4. 先生とじゃんけん"],["5. Mystery surprises","5. ミステリーカード"],["6. Save your items","6. アイテムをためる"],["7. Take a different path","7. 道を選ぶ"],["Same-space janken","同じマスでじゃんけん"],["8. Finish with a cheer","8. 結果を確認する"]]);
})();