(() => {
  let current=null,controls=null,levelTimer=null;
  const normalize=text=>String(text).normalize('NFKC').toLowerCase().replace(/[^a-z0-9]/g,'');
  // These are transcription alternatives, not fuzzy spelling matches.
  // Keep aliases directional: "read" may transcribe "red", but "reed" is not red.
  const homophones={
    witch:['which'],witchs:['whichs','witches','whichis'],blue:['blew'],red:['read'],white:['wight'],grey:['gray'],
    bear:['bare'],bread:['bred'],carrot:['carat','karat','caret'],see:['sea'],buy:['by','bye'],
    wear:['where','ware'],read:['reed'],aunt:['ant'],father:['farther'],
    werewolf:['wearwolf','wherewolf'],or:['ore','oar'],
  };
  const words=text=>String(text).normalize('NFKC').toLowerCase().replace(/[’']/g,'').match(/[a-z0-9]+/g)||[];
  function matches(text,answer){
    const heard=normalize(text),expected=normalize(answer);if(!heard)return false;if(heard===expected)return true;
    const target=words(answer);if(!target.length)return false;
    // Match the whole utterance, including phrases such as "light blue" or "witch’s hat".
    let variants=[''];
    for(const word of target)variants=variants.flatMap(prefix=>[word,...(homophones[word]||[])].map(alias=>prefix+alias));
    return variants.includes(heard);
  }
  function state(card){return card.speech||(card.speech={available:null,verified:false,override:false,listening:false,message:'コントローラーで ことばを いってね。',revision:0});}
  const allowed=card=>{const s=state(card);return s.disabled||s.verified||s.override||s.available===false;};
  function refresh(){
    if(!current||!controls)return;
    const s=state(current);controls.answered.disabled=!allowed(current);
    controls.hear.disabled=s.listening||controls.voiceUnavailable;
    controls.status.textContent=s.retry?'':s.message;
    const bars=controls.status.parentElement?.querySelector('.voice-bars');if(bars)bars.hidden=!s.listening;
    const retry=controls.status.parentElement?.querySelector('.voice-retry');if(retry)retry.hidden=!s.retry||s.verified;

  }
  function apply(card,payload,answer){
    const s=state(card);if(payload.kind==='level'){if(current===card&&s.listening&&payload.sessionId===s.activeAttemptId){window.SpeechVisuals?.draw(controls?.status?.parentElement,payload.level);clearTimeout(levelTimer);levelTimer=setTimeout(()=>window.SpeechVisuals?.draw(controls?.status?.parentElement,0),1200);}return true;}if(payload.attemptId&&s.lastAttemptId===payload.attemptId)return true;s.revision++;
    if(payload.kind==='support'){s.available=payload.available;s.message=payload.available?'コントローラーで ことばを いってね。':'Voice unavailable on the controller. Teacher can use Answered or Pass.';}
    if(payload.kind==='start'){s.available=true;s.listening=true;s.activeAttemptId=payload.attemptId;s.message='Listening… / はなしてね！';window.AnswerVoice?.stop();const revision=s.revision;card.listeningId=revision;setTimeout(()=>{if(current===card&&s.listening&&card.listeningId===revision){s.listening=false;s.revision++;s.message='Try again on the controller, or pass.';refresh();controls?.resume?.();}},25000);}
    if(payload.kind==='end'){s.listening=false;s.retry=!payload.unavailable;s.message=payload.message||'Try again on the controller, or pass.';if(payload.unavailable){s.available=false;s.message+=' Teacher can use Answered or Pass.';}}
    if(payload.kind==='result'){
      s.listening=false;
      if(payload.transcripts.some(t=>matches(t,answer))){s.verified=true;s.retry=false;s.message='Correct! Teacher can press Answered.';}
      else{s.retry=true;s.message='Nice try! Tap the microphone to try again. / マイクを もういちど おしてね。';}
    }
    if(['result','end'].includes(payload.kind)&&payload.attemptId)s.lastAttemptId=payload.attemptId;
    refresh();return true;
  }
  function attach({card,enabled=true,answered,hear,status,icon,resume}){
    const speech=state(card);speech.disabled=!enabled;if(!enabled){speech.listening=false;speech.message='';}
    current=card;controls={answered,hear,status,resume,voiceUnavailable:hear.disabled};
    const parent=status.parentElement;if(parent&&window.SpeechVisuals&&!parent.querySelector('.voice-bars'))parent.insertAdjacentHTML('beforeend','<p class="voice-retry" role="status" aria-live="polite" hidden>Nice try! Tap the microphone to try again.<small lang="ja">マイクを もういちど おしてね。</small></p>'+window.SpeechVisuals.bars());
let clicks=[];
    icon.style.cursor='pointer';icon.onclick=()=>{
      const now=Date.now();clicks=clicks.filter(t=>now-t<900);clicks.push(now);
      if(clicks.length===3){const s=state(card);s.override=true;s.revision++;s.message='Teacher override: Answered is available.';clicks=[];refresh();}
    };refresh();
  }
  window.AnswerRecognition={state,allowed,apply,attach,refresh,matches,stop(){clearTimeout(levelTimer);current=null;controls=null;},get listening(){return Boolean(current&&state(current).listening);}};
})();
