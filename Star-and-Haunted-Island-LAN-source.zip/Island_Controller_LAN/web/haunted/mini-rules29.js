(() => {
 const rules={
 listenTurn:['きいて えらぼう',['「はじめる」を おして、えいごを きこう。','4つの えから、あう えを おそう。','きこえなかったら「もういちど きく」を おしてね。','20びょうで こたえよう。はやく せいかいすると、おかしが たくさん！']],
 pictureWord:['えをみて ことばを えらぼう',['「はじめる」を おして、えを みよう。','4つの えいごから、えに あう ことばを おそう。','20びょうで こたえよう。はやく せいかいすると、おかしが たくさん！']],
 wordPicture:['ことばをみて えを えらぼう',['「はじめる」を おして、えいごを よもう。','4つの えから、ことばに あう えを おそう。','20びょうで こたえよう。はやく せいかいすると、おかしが たくさん！']],
 typeTurn:['えいごを うとう',['えを みて、えいごを キーボードで うとう。','20びょうで こたえを おくろう。','はやく せいかいすると、おかしが たくさん！']],
 speaking:['えいごの ぶんを いおう',['がめんの えいごを よもう。','マイクの ボタンを おして、ぶんを いおう。','せいかいすると、おかしが もらえるよ。']],
 scramble:['ことばを ならべよう',['ことばを ドラッグして、えいごの ぶんを つくろう。','できたら「GO」を おそう。','まちがえても、もういちど できるよ。']],
 maze:['ことばの めいろ',['やじるしの ボタンで すすもう。','えいごの ぶんの じゅんばんに、ことばを たどろう。','まちがえると、1びょう おやすみ。']],
 dash:['えいごの クイズ',['もんだいを みて、あう こたえを おそう。','もんだいは 5もん あるよ。','はやく せいかいして、おかしを あつめよう。']],
 listening:['きいて えを えらぼう',['えいごを きいて、あう えを おそう。','きこえなかったら「Replay」で もういちど きこう。','もういちど きくと、タイムに 1びょう たされるよ。','もんだいは 5もん あるよ。']],
 pronunciation:['えいごを いおう',['えを みて、えいごを かんがえよう。','マイクの ボタンを おして、ことばを いおう。','じかんが ある あいだは、なんどでも できるよ。']],
 missing:['ぬけている ことば',['えいごの ぶんを よもう。','あいている ところに あう ことばを おそう。','5もん こたえて、うえまで のぼろう！']],
 spelling:['もじを ならべよう',['えを みて、えいごを かんがえよう。','もじを ならべて、ことばを つくろう。','じかんが なくなるまで、たくさん つくろう！']],
 potato:['かぼちゃを わたそう',['かぼちゃを もっている ひとが、もんだいに こたえるよ。','せいかいしたら、つぎの ひとへ わたそう。','かぼちゃが はじける まえに、わたしてね！']],
 rps:['モンスターと じゃんけん',['グー・チョキ・パーから、1つ おそう。','かつと すすむよ。まけると もどるよ。','あいこは そのまま。3かい しょうぶしよう！']]
 };
 function markup(kind,shared=false){const [title,steps]=rules[kind]||['ミニゲームの あそびかた',['がめんを みて、こたえよう。']];const lines=steps.slice();if(shared){if(['listenTurn','pictureWord','wordPicture','typeTurn'].includes(kind))lines.push('まちがい・じかんぎれは、おかし 0こ。');lines.push('おわったら、つぎの ひとに コントローラーを わたそう。');}return '<section class="kids-mini-rules" lang="ja" aria-label="ミニゲームの あそびかた"><p class="kids-rules-label">あそびかた</p><h3>'+title+'</h3><ol>'+lines.map(t=>'<li>'+t+'</li>').join('')+'</ol><p class="kids-rules-ready">みんな わかったら「ミニゲームを はじめる」を おしてね。</p></section>';}
 const style=document.createElement('style');style.textContent='.kids-mini-rules{text-align:left;background:#fff5df;color:#302139;border:2px solid #d4a95c;border-radius:16px;padding:14px 18px;margin:8px 0 16px;line-height:1.65;font-size:clamp(17px,2.4vw,24px)}.kids-mini-rules .kids-rules-label{font-size:16px;font-weight:bold;margin:0}.kids-mini-rules h3{font-size:clamp(23px,3vw,32px);color:#5d2d7b!important;text-shadow:none!important;margin:4px 0 10px}.kids-mini-rules ol{padding-left:1.5em;margin:4px 0}.kids-mini-rules li{margin:5px 0}.kids-mini-rules .kids-rules-ready{font-size:17px;font-weight:bold;margin:10px 0 0}.arcade-modal .kids-mini-rules{max-width:850px;margin:8px auto}';document.head.append(style);
 window.MiniGameRules={markup};
})();
