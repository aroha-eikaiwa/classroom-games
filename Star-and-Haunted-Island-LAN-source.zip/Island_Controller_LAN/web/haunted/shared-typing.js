(() => {
 const C=window.SharedChallenges,old={...C};
 const normalize=s=>String(s).normalize('NFKC').toLowerCase().replace(/[^a-z0-9]/g,'');
 C.choose=(s,r)=>{const kind=old.choose(s,r);return kind==='spelling'?'typeTurn':kind;};
 C.create=(kind,players,random,now,cards)=>{const m=old.create(kind,players,random,now,cards);if(kind==='typeTurn'){m.typingCard=cards[0];if(!m.typingCard?.picture)throw Error('No typing picture available.');m.ready=false;m.limitMs=20000;}return m;};
 function ready(m){if(m.kind!=='typeTurn'||m.ready||m.passPending||m.done)return false;m.ready=true;m.sequence++;return true;}
 function record(m,answer,elapsedMs,teacher=false){if(m.kind!=='typeTurn'||m.done||m.passPending||!teacher&&!m.ready||typeof answer!=='string'||answer.length>100||!teacher&&(!Number.isInteger(elapsedMs)||elapsedMs<0||elapsedMs>m.limitMs)||!teacher&&!answer.trim()&&elapsedMs<m.limitMs)return false;
  const timedOut=!teacher&&elapsedMs>=m.limitMs,correct=!teacher&&!timedOut&&normalize(answer)===normalize(m.typingCard.en);
  m.entries.push({playerId:m.roster[m.index].id,answer:answer.trim(),sentence:m.typingCard.en,ja:m.typingCard.ja||'',elapsedMs:teacher?null:elapsedMs,correct,timedOut,skipped:teacher});m.ready=false;m.passPending=true;m.sequence++;if(m.entries.length===m.roster.length)m.done=true;return true;
 }
 function retry(m){if(m.kind!=='typeTurn'||!m.ready||m.passPending||m.done)return false;m.ready=false;m.sequence++;return true;}
 const awards=m=>C.listenAwards(m);
 C.next=m=>{if(m.kind!=='typeTurn')return old.next(m);if(!m.passPending||m.done)return false;m.index++;m.passPending=false;m.ready=false;m.sequence++;return true;};
 C.remove=(m,id)=>{if(m.kind!=='typeTurn')return old.remove(m,id);const i=m.roster.findIndex(p=>p.id===id);if(i<0)return;m.roster.splice(i,1);m.entries=m.entries.filter(e=>e.playerId!==id);if(i<m.index)m.index--;else if(i===m.index){m.ready=false;m.passPending=false;m.index=Math.min(m.index,m.roster.length-1);}m.done=m.entries.length>=m.roster.length;m.sequence++;};
 C.view=(m,key,theme)=>m.kind!=='typeTurn'?old.view(m,key,theme):{key,kind:'typeTurn',theme,player:m.roster[m.index],nextPlayer:m.roster[m.index+1],index:m.index,count:m.roster.length,recorded:m.entries.length,ready:m.ready,passPending:m.passPending,done:!!m.done,limitMs:m.limitMs,picture:!m.passPending&&!m.done?m.typingCard.picture:undefined};
 function renderBoard({game,openModal,title,button,avatarFace,esc,act}){const s=game.s,m=s.mini,star=document.documentElement.dataset.theme==='star',name=star?'Island Typing Race':'Haunted Typing Race',reward=star?'stars':'candy';let html;
  if(s.phase==='miniIntro')html=title('SHARED CONTROLLER',name,'ひとりずつ、えをみて、えいごをはやくうとう！')+'<p>Press “I’m ready” on the controller. Type the correct English word within 20 seconds. Faster correct answers earn more '+reward+'.</p>';
  else if(s.phase==='miniResults'){html=title('TYPING RACE RESULTS',m.skipped?'Mini-game skipped':'Typing times revealed!','せいかいとタイムをみよう！')+'<div style="overflow-x:auto"><table style="width:100%;text-align:left;border-spacing:10px"><thead><tr><th>Rank</th><th>Player</th><th>Answer</th><th>Time</th><th>'+reward+'</th></tr></thead><tbody>'+(m.skipped?[]:awards(m)).map(e=>{const p=m.roster.find(p=>p.id===e.playerId);return '<tr><td>'+(e.rank||'−')+'</td><td>'+avatarFace(p)+' '+esc(p.name)+'</td><td>'+esc(e.answer||'—')+'<br><small>'+(e.skipped?'Skipped':e.timedOut?'Time up':e.correct?'Correct':'Incorrect')+'</small></td><td>'+(e.elapsedMs===null?'—':(e.elapsedMs/1000).toFixed(3)+' s')+'</td><td><strong>+'+e.reward+'</strong></td></tr>';}).join('')+'</tbody></table></div><p>Correct word: <strong>'+esc(m.typingCard.en)+'</strong></p>'+button('typingFinish',s.round===s.maxRounds?'See the winners':'Next Player','つぎへ');}
  else{const p=m.roster[m.passPending?m.index+1:m.index];html=title(name,esc(p?.name||''),m.passPending?'コントローラーをわたそう。':'コントローラーの「はじめる」をおしてね。')+'<p>'+(m.passPending?'Answer recorded. Pass the controller.':m.ready?'Typing in progress…':'Ready when you are!')+'</p><p>'+m.entries.length+' / '+m.roster.length+' recorded</p>'+(!m.passPending?button('typingSkipPlayer','Skip this student','このひとをスキップ','secondary'):'')+button('typingSkip','Skip mini-game','ミニゲームをスキップ','secondary');}
  openModal(html,'card-modal mini-modal');const bind=(id,fn)=>{const e=document.getElementById(id);if(e)e.onclick=()=>act(fn);};bind('typingFinish',()=>game.finishMini());bind('typingSkip',()=>game.skipSharedMini());bind('typingSkipPlayer',()=>game.sharedTypingSkip());
 }
 window.SharedTyping={ready,record,retry,awards,renderBoard};
})();
