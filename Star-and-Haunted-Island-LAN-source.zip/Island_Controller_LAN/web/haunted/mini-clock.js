(() => {
 const tick=()=>{const deadline=window.StarIslandTabController?.miniTick(Date.now());const label=document.getElementById('miniCountdown');if(label&&deadline)label.textContent=Math.max(0,Math.ceil((deadline-Date.now())/1000))+'s';};
 setInterval(tick,100);document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick();});
})();
