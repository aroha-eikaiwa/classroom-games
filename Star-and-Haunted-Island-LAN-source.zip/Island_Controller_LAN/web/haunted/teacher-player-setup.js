(() => {
 const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 window.SharedPlayerSetup={create(container,options){
  const catalog=window.PlayerAvatars,names=options.names.slice(),avatars=options.avatars.slice();
  const capture=()=>{for(const input of container.querySelectorAll('[data-player-name]'))names[Number(input.dataset.playerName)]=input.value;};
  const face=a=>`<img src="${esc(a.src)}" alt="" draggable="false"><span>${esc(a.name)}</span>`;
  function render(count){capture();
   for(let i=0;i<count;i++)if(!catalog.some(a=>a.id===avatars[i])){
    const available=catalog.filter(a=>!avatars.includes(a.id)),pool=available.length?available:catalog;
    avatars[i]=pool[Math.floor(Math.random()*pool.length)].id;
   }
   container.innerHTML=Array.from({length:count},(_,i)=>{
   const selected=catalog.find(a=>a.id===avatars[i]);
   return `<div class="setup-player-row"><label class="name-input"><span class="avatar" style="--player:${esc(options.colors[i])}">${i+1}</span><input type="text" data-player-name="${i}" id="name${i}" aria-label="Player ${i+1} name" maxlength="24" value="${esc(names[i]??options.defaultNames[i]??'')}"></label><details class="setup-avatar-picker"><summary aria-label="Choose avatar for player ${i+1}">${selected?face(selected):'<span>Choose avatar</span>'}</summary><div class="setup-avatar-menu">${catalog.map(a=>`<button type="button" data-avatar-player="${i}" data-avatar-id="${esc(a.id)}" aria-pressed="${avatars[i]===a.id}">${face(a)}</button>`).join('')}</div></details></div>`;
  }).join('');
   for(const button of container.querySelectorAll('[data-avatar-id]'))button.onclick=()=>{const i=Number(button.dataset.avatarPlayer),id=button.dataset.avatarId;avatars[i]=id;const picker=button.closest('details');picker.querySelector('summary').innerHTML=face(catalog.find(a=>a.id===id));for(const b of picker.querySelectorAll('button'))b.setAttribute('aria-pressed',String(b.dataset.avatarId===id));picker.open=false;};
   for(const picker of container.querySelectorAll('details'))picker.addEventListener('toggle',()=>{if(picker.open)for(const other of container.querySelectorAll('details'))if(other!==picker)other.open=false;});
  }
  return {render,read(){capture();const count=container.querySelectorAll('[data-player-name]').length;return {names:names.slice(0,count),avatars:Array.from({length:count},(_,i)=>avatars[i]||null)};}};
 }};
})();
