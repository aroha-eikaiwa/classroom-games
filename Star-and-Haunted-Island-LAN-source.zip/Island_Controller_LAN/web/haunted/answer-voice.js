(() => {
  const synthesis=window.speechSynthesis;
  let active=null;
  function stop(){
    const previous=active;active=null;
    if(previous){
      previous.music.volume=previous.volume;
      previous.button.removeAttribute('aria-busy');
      previous.status.textContent='';
      synthesis.cancel();
    }
  }
  function attach(button,answer){
    const status=document.getElementById('answerVoiceStatus');
    if(!synthesis||!window.SpeechSynthesisUtterance){
      button.disabled=true;status.textContent='Voice unavailable in this browser.';return;
    }
    button.onclick=()=>{
      stop();
      const utterance=new SpeechSynthesisUtterance(answer);
      const english=synthesis.getVoices().filter(voice=>voice.localService && /^en(?:[-_]|$)/i.test(voice.lang));
      const voice=english.find(v=>/^en[-_]NZ$/i.test(v.lang))||english.find(v=>/^en[-_]GB$/i.test(v.lang))||english.find(v=>v.default)||english[0];
      if(!voice){status.textContent='No local English voice is installed.';return;}utterance.voice=voice;
      utterance.lang=voice?.lang||'en-GB';utterance.rate=.85;utterance.pitch=1;utterance.volume=1;
      const music=document.getElementById('bgm'),volume=music.volume;
      active={utterance,music,volume,button,status};
      music.volume=Math.min(volume,.06);button.setAttribute('aria-busy','true');status.textContent='Playing…';
      const finish=message=>{
        if(active?.utterance!==utterance)return;
        music.volume=volume;button.removeAttribute('aria-busy');status.textContent=message;active=null;
      };
      utterance.onend=()=>finish('');
      utterance.onerror=event=>finish(['canceled','interrupted'].includes(event.error)?'':'Could not play the voice. Please try again.');
      try{synthesis.speak(utterance);}catch{finish('Could not play the voice. Please try again.');}
    };
  }
  window.AnswerVoice={attach,stop};
  window.addEventListener('pagehide',stop);
})();
