// Firefox and Chromium do not expose randomUUID on plain private-network HTTP.
// getRandomValues is available there and still provides cryptographic randomness.
if(!crypto.randomUUID)crypto.randomUUID=function(){
 const a=crypto.getRandomValues(new Uint8Array(16));
 a[6]=(a[6]&15)|64;a[8]=(a[8]&63)|128;
 const hex=Array.from(a,b=>b.toString(16).padStart(2,'0')).join('');
 return [hex.slice(0,8),hex.slice(8,12),hex.slice(12,16),hex.slice(16,20),hex.slice(20)].join('-');
};
// Allow installed device voices only, never browser cloud speech.
if(window.speechSynthesis){
 const synth=window.speechSynthesis;
 const original=synth.speak.bind(synth);
 synth.speak=utterance=>{
  const voices=synth.getVoices().filter(voice=>voice.localService);
  const current=utterance.voice;
  const preferred=voices.find(voice=>voice.voiceURI===current?.voiceURI)
   ||voices.find(voice=>voice.lang.toLowerCase()===utterance.lang.toLowerCase())
   ||voices.find(voice=>voice.lang.split('-')[0]===utterance.lang.split('-')[0]);
  if(preferred){utterance.voice=preferred;return original(utterance);}
  queueMicrotask(()=>utterance.dispatchEvent(new Event('error')));
 };
}
