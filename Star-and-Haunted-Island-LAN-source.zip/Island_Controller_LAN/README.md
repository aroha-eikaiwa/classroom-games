# Star Island & Haunted Island: private-network controller edition

This is a standalone source adaptation of the November 24, 2026 game and controller builds. It pairs the actual updated board engines and bilingual settings with the controller’s room protocol, clients and supported arcade engine. It does not connect to the original service or to classroom accounts.

## Start a room

Install Node.js 24 or newer. From this directory, run `node server.mjs`; no package install or account is needed. Open **http://127.0.0.1:8787/boards.html** and choose an island. In **Own devices** mode, start a lobby and have 2–6 controllers open the join address shown on the board and choose a fictional nickname and avatar. Select **Start game** after the players join. The **Shared controller** mode also uses the board's join address. To test on one computer, use separate browser profiles for separate controllers.

For a trusted local Wi-Fi network, run `node server.mjs <host-private-IPv4> 8787`, replacing the placeholder with the server computer's private LAN address, and open that address from the host and phones. The server defaults to loopback and refuses wildcard, public IP, and domain-name bindings. The demo is **plain HTTP only; a person on the network could read or tamper with traffic**. Do not expose it to the internet, tunnel, reverse proxy, or run it on public/guest Wi-Fi. Use fictional names, never real student data. Cross-device access also depends on your firewall and Wi-Fi permitting local device-to-device traffic.

Room state is kept **in memory** and is lost when the server stops. Boards and controllers retain per-tab state only until closed, except that browsers may restore tab sessions; old room credentials stop working whenever the server stops. A join code is an invitation for the trusted LAN, not an internet authentication system. Use the room code or local link; no QR asset is included. There are no external URLs, paid services, account integrations, teacher logs, or microphone recognition. The avatars and other images use locally generated fallback graphics where original art could not be cleared. The supported own-device arcade games are Sentence Scramble, Maze, Missing Word and Rock–Paper–Scissors. Shared artwork/speech mini-games, picture cards, network-dependent features, music, and original visual assets are not included. Voice prompts, where present, require a matching installed local OS voice.

## Verify locally

Run `node --test`. The tests exercise the HTTP API over loopback, parse the served browser scripts, and check room authentication, active-turn gating, request replay/acknowledgement, player reconnect and replacement, both island rosters, arcade RPS input and duplicate rejection, room closure, and blocking production-only routes and foreign origins. Physical phone/Wi-Fi interaction and visual browser behavior are not covered by those tests.

Source and fallback artwork are provided for owner review; no public license is presumed.
