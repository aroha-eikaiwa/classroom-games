import {starContent} from './star-content.js';
// Content is independent of the games. Answers stay on the server.
const art = file => '/assets/'+file;
export const vocabulary = [
 ['vampire','Vampire','きゅうけつき','16cd9dae6a2f9b9a9eb8.webp'],
 ['witch','Witch','まじょ','74c6bf3afd165581e63a.webp'],
 ['ghost','Ghost','おばけ','ee39dd2f754ca758b54c.webp'],
 ['skeleton','Skeleton','ガイコツ','4436b18b777954ba1e73.webp'],
 ['mummy','Mummy','ミイラ','57ff56c53682ac364a18.webp'],
 ['zombie','Zombie','ゾンビ','26b23b69fa850d85dbe4.webp'],
 ['werewolf','Werewolf','おおかみおとこ','086481365b8965fc8768.webp'],
 ['monster','Monster','モンスター','2d67837999a1bcea143c.webp'],
 ['bat','Bat','こうもり','a1c90b638d98e9a2a89f.webp'],
 ['cat','Black cat','くろねこ','ac322d92db75fad712bd.webp'],
 ['spider','Spider','くも','dea18ac9300126a66bbe.webp'],
 ['pumpkin','Jack-o’-lantern','ジャック・オー・ランタン','c845edd112f6df402617.webp'],
 ['cauldron','Cauldron','まじょの なべ','ae5ea01b086d3fb76136.webp'],
 ['candy','Candy','おかし','2622b7f9ea884ecff148.webp'],
 ['house','Haunted house','おばけやしき','a844ade0ecba3ec81ae9.webp'],
 ['broom','Broomstick','ほうき','e0274ff37d6df2b9285a.webp'],
 ['hat','Witch’s hat','まじょの ぼうし','9d02c169892ca7f5b814.webp'],
 ['moon','Full moon','まんげつ','7c6713e7318148a20929.webp'],
].map(([id,answer,ja,image])=>({id,type:'vocabulary',answer,ja,image:art(image)}));

export const sentences = [
 ['s1','I can see a ghost','おばけが みえるよ。'],
 ['s2','The witch has a hat','まじょは ぼうしを もっているよ。'],
 ['s3','The black cat is cute','くろねこは かわいいね。'],
 ['s4','I like Halloween candy','ハロウィーンの おかしが すき。'],
 ['s5','The bat can fly','こうもりは とべるよ。'],
 ['s6','This is a haunted house','これは おばけやしきです。'],
 ['s7','The ghost is white','おばけは しろいよ。'],
 ['s8','I have a broomstick','ぼくは ほうきを もっているよ。'],
 ['s9','The spider has eight legs','くもは あしが 8ぽん。'],
 ['s10','The monster likes candy','モンスターは おかしが すき。'],
 ['s11','The mummy is in the house','ミイラは いえの なかに いるよ。'],
 ['s12','I saw a witch yesterday','きのう まじょを みたよ。',['Yesterday I saw a witch']],
 ['s13','The vampire has two teeth','きゅうけつきには はが 2ほん。'],
 ['s14','The moon is very bright','つきが とても あかるいね。'],
].map(([id,answer,prompt,alternates=[]])=>({id,type:'sentence_order',answer,prompt,words:answer.split(' '),alternates}));

export const gaps = [
 ['g1','The bat ___ fly.',['can','is','has','are'],'can'],
 ['g2','The ghost ___ white.',['is','are','am','has'],'is'],
 ['g3','I ___ Halloween candy.',['like','likes','liking','is'],'like'],
 ['g4','The witch ___ a hat.',['has','have','is','are'],'has'],
 ['g5','There ___ two bats.',['are','is','am','has'],'are'],
 ['g6','The spider has eight ___.',['legs','leg','hat','moon'],'legs'],
 ['g7','I saw a witch ___.',['yesterday','tomorrow','next week','every day'],'yesterday'],
 ['g8','This ___ a haunted house.',['is','are','am','can'],'is'],
 ['g9','The monster ___ candy.',['likes','like','liking','are'],'likes'],
 ['g10','I ___ a broomstick.',['have','has','am','are'],'have'],
 ['g11','The black cat is ___.',['cute','fly','swim','eat'],'cute'],
 ['g12','The mummy is ___ the house.',['in','can','has','are'],'in'],
].map(([id,prompt,options,answer])=>({id,type:'missing_word',prompt,options,answer}));

export const games = [
 {id:'scramble',name:'Sentence Scramble',icon:'🏚️',instructions:'Drag the words into order. GO checks your whole sentence.',ja:'ことばを ドラッグして ならべよう。GOで こたえよう。',content:'sentence_order'},
 {id:'maze',name:'Word Path',icon:'🕸️',instructions:'Follow the sentence through the word maze. Wrong steps pause you!',ja:'ぶんの じゅんばんに すすもう。まちがえると 1びょう おやすみ。',content:'sentence_order'},
 {id:'dash',name:'Word Dash',icon:'⚡',instructions:'Five Halloween questions. Choose the answer quickly!',ja:'ハロウィーンの もんだい 5もん。はやく えらぼう！',content:'vocabulary'},
 {id:'listening',name:'Listening Race',icon:'🔊',instructions:'Listen, then tap the picture. Replay costs one second.',ja:'きいて えを タップ。もういちど きくと 1びょう プラス。',content:'vocabulary'},
 {id:'pronunciation',name:'Pronunciation Challenge',icon:'🎤',instructions:'Say the word. Keep trying! Everyone who succeeds earns 3 candies.',ja:'ことばを いおう。なんどでも チャレンジ！せいかいで おかし 3こ。',content:'vocabulary'},
 {id:'missing',name:'Missing Word',icon:'🏰',instructions:'Choose the missing word. Five questions to climb the tower!',ja:'あいている ところの ことばを えらぼう。5もん チャレンジ！',content:'missing_word'},
 {id:'spelling',name:'Spelling Sprint',icon:'🪜',instructions:'Put the letters in the correct order to make as many words as you can before time runs out!',ja:'じかんないに もじを ならべて、たくさんの ことばを つくろう！',content:'vocabulary'},
 {id:'potato',name:'Cursed Pumpkin',icon:'🎃',instructions:'Holding the pumpkin? Answer to pass it. Do not hold it when it pops!',ja:'かぼちゃを もったら こたえて わたそう。いつ はじけるかな？',content:'vocabulary'},
 {id:'rps',name:'Monster RPS Battle',icon:'✊',instructions:'Play the monster! Win: move forward. Loss: move backward. Draw: stay still. Three battles!',ja:'モンスターと じゃんけん！かちで すすむ、まけで もどる、あいこは そのまま。3かい しょうぶ！',content:'rps'},
];

export function contentFor(theme,topics=[]){return theme==='star'?starContent(topics):{vocabulary,sentences,gaps,games,reactionTarget:vocabulary.find(v=>v.id==='ghost')};}
