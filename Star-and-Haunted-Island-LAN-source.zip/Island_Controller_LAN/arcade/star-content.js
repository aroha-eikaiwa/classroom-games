import {starVocabulary} from './star-vocabulary.js';
const art=file=>'/assets/'+file;
export const starGames=[
 ['scramble','Rainbow Sentence Rally','🌈','Drag the words into order. Race to the island castle!','ことばを ドラッグして ならべよう。おしろまで レース！','sentence_order'],
 ['maze','Garden Word Maze','🌿','Follow the sentence through the garden rooms. Wrong steps pause you!','ぶんの じゅんばんに すすもう。まちがえると 1びょう おやすみ。','sentence_order'],
 ['dash','Island Word Dash','⚡','Five picture questions. Choose the answer quickly!','えと ことばの もんだい 5もん。はやく えらぼう！','vocabulary'],
 ['listening','Seashell Listening Race','🐚','Listen, then tap the picture. Replay costs one second.','きいて えを タップ。もういちど きくと 1びょう プラス。','vocabulary'],
 ['pronunciation','Star Speaker Challenge','🎤','Say the word. Keep trying! Everyone who succeeds earns 3 stars.','ことばを いおう。なんどでも チャレンジ！せいかいで スター 3こ。','vocabulary'],
 ['missing','Castle Climb','🏰','Choose the missing word. Five questions to climb the castle!','あいている ところの ことばを えらぼう。おしろを のぼろう！','missing_word'],
 ['spelling','Treehouse Spelling Sprint','📚','Put the letters in the correct order to make as many words as you can before time runs out!','じかんないに もじを ならべて、たくさんの ことばを つくろう！','vocabulary'],
 ['potato','Hot Coconut','🥥','Holding the coconut? Answer to pass it. Do not hold it when it pops!','ココナッツを もったら こたえて わたそう。いつ はじけるかな？','vocabulary'],
 ['rps','Captain Jack Janken','✊','Challenge Captain Jack! Win: move forward. Loss: move backward. Draw: stay still. Three battles!','キャプテンと じゃんけん！かちで すすむ、まけで もどる、あいこは そのまま。3かい しょうぶ！','rps'],
].map(([id,name,icon,instructions,ja,content])=>({id,name,icon,instructions,ja,content}));
const sentences=[
 ['I can see a bird','とりが みえるよ。'],['The cat is cute','ねこは かわいいね。'],['I like apples','りんごが すき。'],
 ['The dog can run','いぬは はしれるよ。'],['This is a castle','これは おしろです。'],['I have a book','ぼくは ほんを もっているよ。'],
 ['The fish can swim','さかなは およげるよ。'],['I can play soccer','サッカーが できるよ。'],['The rabbit has long ears','うさぎには ながい みみが あるよ。'],
 ['I go to the park','こうえんに いくよ。'],['The school is big','がっこうは おおきいね。'],
 ['I played soccer yesterday','きのう サッカーを したよ。',['Yesterday I played soccer']],
 ['My mother can cook','おかあさんは りょうりが できるよ。'],['The lion is strong','ライオンは つよいね。'],
].map(([answer,prompt,alternates=[]],i)=>({id:'star-s'+i,type:'sentence_order',answer,prompt,words:answer.split(' '),alternates}));
const gaps=[
 ['The bird ___ fly.',['can','is','has','are'],'can'],['The rabbit ___ white.',['is','are','am','has'],'is'],
 ['I ___ apples.',['like','likes','liking','is'],'like'],['The cat ___ a tail.',['has','have','is','are'],'has'],
 ['There ___ two dogs.',['are','is','am','has'],'are'],['The dog has four ___.',['legs','leg','book','apple'],'legs'],
 ['I played soccer ___.',['yesterday','tomorrow','next week','now'],'yesterday'],['This ___ a castle.',['is','are','am','can'],'is'],
 ['My sister ___ bananas.',['likes','like','liking','are'],'likes'],['I ___ a book.',['have','has','am','are'],'have'],
 ['The fish can ___.',['swim','fly','run','jump'],'swim'],['The book is ___ the bag.',['in','can','has','are'],'in'],
].map(([prompt,options,answer],i)=>({id:'star-g'+i,type:'missing_word',prompt,options,answer}));
export function starContent(topics=[]){
 let vocabulary=starVocabulary.filter(v=>topics.includes(v.topic));
 if(vocabulary.length<4)vocabulary=starVocabulary.filter(v=>v.topic==='ANIMALS');
 return {vocabulary,sentences,gaps,games:starGames,reactionTarget:{id:'star',answer:'STAR',image:art('star-original/9f96ff4810f4a44dff7f1778.png')}};
}
