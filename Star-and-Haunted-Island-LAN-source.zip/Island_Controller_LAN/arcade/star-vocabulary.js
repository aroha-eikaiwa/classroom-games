// Existing picture decks shared with Star Island mini-games.
export const starVocabulary = [
  {
    "id": "S073",
    "type": "vocabulary",
    "answer": "cat",
    "ja": "ねこ",
    "topic": "ANIMALS",
    "image": "/assets/f9c8f867b073b6a5b09f.webp"
  },
  {
    "id": "S074",
    "type": "vocabulary",
    "answer": "dog",
    "ja": "いぬ",
    "topic": "ANIMALS",
    "image": "/assets/9e0349b0d247b6aa2b5b.webp"
  },
  {
    "id": "S075",
    "type": "vocabulary",
    "answer": "rabbit",
    "ja": "うさぎ",
    "topic": "ANIMALS",
    "image": "/assets/5c568db1de02970f1dd8.webp"
  },
  {
    "id": "S076",
    "type": "vocabulary",
    "answer": "bird",
    "ja": "とり",
    "topic": "ANIMALS",
    "image": "/assets/fe64f58533967aea3f9b.webp"
  },
  {
    "id": "S077",
    "type": "vocabulary",
    "answer": "fish",
    "ja": "さかな",
    "topic": "ANIMALS",
    "image": "/assets/f7975c984f64b349b4f4.webp"
  },
  {
    "id": "S078",
    "type": "vocabulary",
    "answer": "lion",
    "ja": "ライオン",
    "topic": "ANIMALS",
    "image": "/assets/c0741d949e50e3ac6809.webp"
  },
  {
    "id": "S079",
    "type": "vocabulary",
    "answer": "tiger",
    "ja": "とら",
    "topic": "ANIMALS",
    "image": "/assets/27c735144a2ba28ed1d3.webp"
  },
  {
    "id": "S080",
    "type": "vocabulary",
    "answer": "giraffe",
    "ja": "きりん",
    "topic": "ANIMALS",
    "image": "/assets/72c01c3f6bf989804f30.webp"
  },
  {
    "id": "S081",
    "type": "vocabulary",
    "answer": "elephant",
    "ja": "ぞう",
    "topic": "ANIMALS",
    "image": "/assets/26c984ef43abbd7981db.webp"
  },
  {
    "id": "S082",
    "type": "vocabulary",
    "answer": "monkey",
    "ja": "さる",
    "topic": "ANIMALS",
    "image": "/assets/152d05060a117adf503c.webp"
  },
  {
    "id": "S083",
    "type": "vocabulary",
    "answer": "bear",
    "ja": "くま",
    "topic": "ANIMALS",
    "image": "/assets/ab02c2ae483c313d49d7.webp"
  },
  {
    "id": "S084",
    "type": "vocabulary",
    "answer": "penguin",
    "ja": "ペンギン",
    "topic": "ANIMALS",
    "image": "/assets/aeb3db3511d4b453b358.webp"
  },
  {
    "id": "S097",
    "type": "vocabulary",
    "answer": "apple",
    "ja": "りんご",
    "topic": "FOOD & DRINK",
    "image": "/assets/10d51d5310632b87636f.webp"
  },
  {
    "id": "S098",
    "type": "vocabulary",
    "answer": "banana",
    "ja": "バナナ",
    "topic": "FOOD & DRINK",
    "image": "/assets/8782159af34e9c4e96da.webp"
  },
  {
    "id": "S099",
    "type": "vocabulary",
    "answer": "orange",
    "ja": "オレンジ",
    "topic": "FOOD & DRINK",
    "image": "/assets/985e9df4916ef8d3f81c.webp"
  },
  {
    "id": "S100",
    "type": "vocabulary",
    "answer": "grapes",
    "ja": "ぶどう",
    "topic": "FOOD & DRINK",
    "image": "/assets/357e23c053b354b6795c.webp"
  },
  {
    "id": "S101",
    "type": "vocabulary",
    "answer": "strawberry",
    "ja": "いちご",
    "topic": "FOOD & DRINK",
    "image": "/assets/a6d2bd7fc8e0b42351d3.webp"
  },
  {
    "id": "S102",
    "type": "vocabulary",
    "answer": "carrot",
    "ja": "にんじん",
    "topic": "FOOD & DRINK",
    "image": "/assets/50d8c7b1862372aa094b.webp"
  },
  {
    "id": "S103",
    "type": "vocabulary",
    "answer": "potato",
    "ja": "じゃがいも",
    "topic": "FOOD & DRINK",
    "image": "/assets/33a5ae799663d8f1630b.webp"
  },
  {
    "id": "S104",
    "type": "vocabulary",
    "answer": "bread",
    "ja": "パン",
    "topic": "FOOD & DRINK",
    "image": "/assets/a704dc8f2ab466cc5e9f.webp"
  },
  {
    "id": "S105",
    "type": "vocabulary",
    "answer": "rice",
    "ja": "ごはん",
    "topic": "FOOD & DRINK",
    "image": "/assets/a5817499cd4e070135bd.webp"
  },
  {
    "id": "S106",
    "type": "vocabulary",
    "answer": "egg",
    "ja": "たまご",
    "topic": "FOOD & DRINK",
    "image": "/assets/e804d95c75482c1ff12a.webp"
  },
  {
    "id": "S107",
    "type": "vocabulary",
    "answer": "pizza",
    "ja": "ピザ",
    "topic": "FOOD & DRINK",
    "image": "/assets/265420d3ea7698cc2927.webp"
  },
  {
    "id": "S108",
    "type": "vocabulary",
    "answer": "milk",
    "ja": "ぎゅうにゅう",
    "topic": "FOOD & DRINK",
    "image": "/assets/fd17503a3d1cebe3236c.webp"
  },
  {
    "id": "S121",
    "type": "vocabulary",
    "answer": "soccer",
    "ja": "サッカー",
    "topic": "SPORTS",
    "image": "/assets/7ea478dd278412f491d2.webp"
  },
  {
    "id": "S122",
    "type": "vocabulary",
    "answer": "baseball",
    "ja": "やきゅう",
    "topic": "SPORTS",
    "image": "/assets/a4ca0b33a89627e16afd.webp"
  },
  {
    "id": "S123",
    "type": "vocabulary",
    "answer": "basketball",
    "ja": "バスケットボール",
    "topic": "SPORTS",
    "image": "/assets/5aa0d734abccbd9cafd8.webp"
  },
  {
    "id": "S124",
    "type": "vocabulary",
    "answer": "tennis",
    "ja": "テニス",
    "topic": "SPORTS",
    "image": "/assets/758989023283d7ebc89f.webp"
  },
  {
    "id": "S125",
    "type": "vocabulary",
    "answer": "volleyball",
    "ja": "バレーボール",
    "topic": "SPORTS",
    "image": "/assets/50b706a9f7ff4ba10572.webp"
  },
  {
    "id": "S126",
    "type": "vocabulary",
    "answer": "badminton",
    "ja": "バドミントン",
    "topic": "SPORTS",
    "image": "/assets/05236e891bfadf303e35.webp"
  },
  {
    "id": "S127",
    "type": "vocabulary",
    "answer": "swimming",
    "ja": "すいえい",
    "topic": "SPORTS",
    "image": "/assets/7206adc6bb7e3843d773.webp"
  },
  {
    "id": "S128",
    "type": "vocabulary",
    "answer": "running",
    "ja": "ランニング",
    "topic": "SPORTS",
    "image": "/assets/b551a90d056e450a2c19.webp"
  },
  {
    "id": "S129",
    "type": "vocabulary",
    "answer": "cycling",
    "ja": "サイクリング",
    "topic": "SPORTS",
    "image": "/assets/53de312e4ec731190d9d.webp"
  },
  {
    "id": "S130",
    "type": "vocabulary",
    "answer": "table tennis",
    "ja": "たっきゅう",
    "topic": "SPORTS",
    "image": "/assets/35f6581a58794caabf17.webp"
  },
  {
    "id": "S131",
    "type": "vocabulary",
    "answer": "golf",
    "ja": "ゴルフ",
    "topic": "SPORTS",
    "image": "/assets/b08a1922535089605409.webp"
  },
  {
    "id": "S132",
    "type": "vocabulary",
    "answer": "skiing",
    "ja": "スキー",
    "topic": "SPORTS",
    "image": "/assets/b4dabcbbf4e240ddfa66.webp"
  },
  {
    "id": "S145",
    "type": "vocabulary",
    "answer": "book",
    "ja": "ほん",
    "topic": "CLASSROOM",
    "image": "/assets/a90bd04441ac705450df.webp"
  },
  {
    "id": "S146",
    "type": "vocabulary",
    "answer": "pencil",
    "ja": "えんぴつ",
    "topic": "CLASSROOM",
    "image": "/assets/d797641625b5e8d08a45.webp"
  },
  {
    "id": "S147",
    "type": "vocabulary",
    "answer": "pen",
    "ja": "ペン",
    "topic": "CLASSROOM",
    "image": "/assets/85cadd4fc070ce5c4bef.webp"
  },
  {
    "id": "S148",
    "type": "vocabulary",
    "answer": "eraser",
    "ja": "けしゴム",
    "topic": "CLASSROOM",
    "image": "/assets/56a71553e99ceff12375.webp"
  },
  {
    "id": "S149",
    "type": "vocabulary",
    "answer": "ruler",
    "ja": "じょうぎ",
    "topic": "CLASSROOM",
    "image": "/assets/acdd8acce06c3fad5bbf.webp"
  },
  {
    "id": "S150",
    "type": "vocabulary",
    "answer": "bag",
    "ja": "かばん",
    "topic": "CLASSROOM",
    "image": "/assets/e6121d460ad3c8137295.webp"
  },
  {
    "id": "S151",
    "type": "vocabulary",
    "answer": "desk",
    "ja": "つくえ",
    "topic": "CLASSROOM",
    "image": "/assets/49d36670ad7baecd1729.webp"
  },
  {
    "id": "S152",
    "type": "vocabulary",
    "answer": "chair",
    "ja": "いす",
    "topic": "CLASSROOM",
    "image": "/assets/3c9f0b46647a49472be4.webp"
  },
  {
    "id": "S153",
    "type": "vocabulary",
    "answer": "notebook",
    "ja": "ノート",
    "topic": "CLASSROOM",
    "image": "/assets/8194240917aff75fdb44.webp"
  },
  {
    "id": "S154",
    "type": "vocabulary",
    "answer": "scissors",
    "ja": "はさみ",
    "topic": "CLASSROOM",
    "image": "/assets/759667dfd16d90468cef.webp"
  },
  {
    "id": "S155",
    "type": "vocabulary",
    "answer": "glue",
    "ja": "のり",
    "topic": "CLASSROOM",
    "image": "/assets/a9e2f05b8d0e877ee784.webp"
  },
  {
    "id": "S156",
    "type": "vocabulary",
    "answer": "clock",
    "ja": "とけい",
    "topic": "CLASSROOM",
    "image": "/assets/8e16a5e74c1ba42a28b4.webp"
  },
  {
    "id": "S199",
    "type": "vocabulary",
    "answer": "spell",
    "ja": "つづりを いう",
    "topic": "ACTIONS",
    "image": "/assets/02216d07e4cf877a24da.webp"
  },
  {
    "id": "S200",
    "type": "vocabulary",
    "answer": "like",
    "ja": "すき",
    "topic": "ACTIONS",
    "image": "/assets/bb4e0afa53445243b72c.webp"
  },
  {
    "id": "S201",
    "type": "vocabulary",
    "answer": "listen",
    "ja": "きく",
    "topic": "ACTIONS",
    "image": "/assets/6ece483d8a0c73087902.webp"
  },
  {
    "id": "S202",
    "type": "vocabulary",
    "answer": "want",
    "ja": "ほしい",
    "topic": "ACTIONS",
    "image": "/assets/3e24cb171f941773d4f8.webp"
  },
  {
    "id": "S203",
    "type": "vocabulary",
    "answer": "play",
    "ja": "あそぶ",
    "topic": "ACTIONS",
    "image": "/assets/b25a05f0510c86be4dda.webp"
  },
  {
    "id": "S204",
    "type": "vocabulary",
    "answer": "walk",
    "ja": "あるく",
    "topic": "ACTIONS",
    "image": "/assets/21730d1493ea54551ea3.webp"
  },
  {
    "id": "S205",
    "type": "vocabulary",
    "answer": "run",
    "ja": "はしる",
    "topic": "ACTIONS",
    "image": "/assets/54cd6caa9c6546cc1cb8.webp"
  },
  {
    "id": "S206",
    "type": "vocabulary",
    "answer": "dance",
    "ja": "おどる",
    "topic": "ACTIONS",
    "image": "/assets/4bd6abfd3f167c0d2a69.webp"
  },
  {
    "id": "S207",
    "type": "vocabulary",
    "answer": "jump",
    "ja": "とぶ",
    "topic": "ACTIONS",
    "image": "/assets/f0b806b7ec9f23afae82.webp"
  },
  {
    "id": "S208",
    "type": "vocabulary",
    "answer": "catch",
    "ja": "キャッチする",
    "topic": "ACTIONS",
    "image": "/assets/bcbc4b11f0e7e911efdb.webp"
  },
  {
    "id": "S209",
    "type": "vocabulary",
    "answer": "swim",
    "ja": "およぐ",
    "topic": "ACTIONS",
    "image": "/assets/9b03dc9c70686f0615e4.webp"
  },
  {
    "id": "S210",
    "type": "vocabulary",
    "answer": "fly",
    "ja": "そらを とぶ",
    "topic": "ACTIONS",
    "image": "/assets/fafd7e0cba8b9a425869.webp"
  },
  {
    "id": "S211",
    "type": "vocabulary",
    "answer": "sing",
    "ja": "うたう",
    "topic": "ACTIONS",
    "image": "/assets/325d087808a381d32d0b.webp"
  },
  {
    "id": "S212",
    "type": "vocabulary",
    "answer": "cook",
    "ja": "りょうりする",
    "topic": "ACTIONS",
    "image": "/assets/003feb25763ef1d59ced.webp"
  },
  {
    "id": "S213",
    "type": "vocabulary",
    "answer": "have",
    "ja": "もっている",
    "topic": "ACTIONS",
    "image": "/assets/f944a84203cce4567b79.webp"
  },
  {
    "id": "S214",
    "type": "vocabulary",
    "answer": "go",
    "ja": "いく",
    "topic": "ACTIONS",
    "image": "/assets/cd022f7a57f9ecc1b1f8.webp"
  },
  {
    "id": "S215",
    "type": "vocabulary",
    "answer": "turn",
    "ja": "むきを かえる",
    "topic": "ACTIONS",
    "image": "/assets/35aade56a12f7afa9af9.webp"
  },
  {
    "id": "S216",
    "type": "vocabulary",
    "answer": "see",
    "ja": "みえる",
    "topic": "ACTIONS",
    "image": "/assets/89bfd20c3b3d642acbc2.webp"
  },
  {
    "id": "S217",
    "type": "vocabulary",
    "answer": "look",
    "ja": "みる",
    "topic": "ACTIONS",
    "image": "/assets/c8664a9d855814e08ac8.webp"
  },
  {
    "id": "S218",
    "type": "vocabulary",
    "answer": "drink",
    "ja": "のむ",
    "topic": "ACTIONS",
    "image": "/assets/be0470148fd0123a9fe8.webp"
  },
  {
    "id": "S219",
    "type": "vocabulary",
    "answer": "eat",
    "ja": "たべる",
    "topic": "ACTIONS",
    "image": "/assets/fd4c8221d9f390252c94.webp"
  },
  {
    "id": "S220",
    "type": "vocabulary",
    "answer": "buy",
    "ja": "かう",
    "topic": "ACTIONS",
    "image": "/assets/7d88fbc8a93ec2767e77.webp"
  },
  {
    "id": "S221",
    "type": "vocabulary",
    "answer": "speak",
    "ja": "はなす",
    "topic": "ACTIONS",
    "image": "/assets/5015c7bb3cca321c1455.webp"
  },
  {
    "id": "S222",
    "type": "vocabulary",
    "answer": "live",
    "ja": "すむ",
    "topic": "ACTIONS",
    "image": "/assets/eea5f22e1b5a37a8be30.webp"
  },
  {
    "id": "S223",
    "type": "vocabulary",
    "answer": "make",
    "ja": "つくる",
    "topic": "ACTIONS",
    "image": "/assets/9ac032f5d6f09ae20818.webp"
  },
  {
    "id": "S224",
    "type": "vocabulary",
    "answer": "wear",
    "ja": "きる",
    "topic": "ACTIONS",
    "image": "/assets/b929297144af18421ec7.webp"
  },
  {
    "id": "S225",
    "type": "vocabulary",
    "answer": "talk",
    "ja": "はなす",
    "topic": "ACTIONS",
    "image": "/assets/ed830c1cda3e194996a8.webp"
  },
  {
    "id": "S226",
    "type": "vocabulary",
    "answer": "watch",
    "ja": "みる",
    "topic": "ACTIONS",
    "image": "/assets/8f9ec8a83da4211cb78c.webp"
  },
  {
    "id": "S227",
    "type": "vocabulary",
    "answer": "read",
    "ja": "よむ",
    "topic": "ACTIONS",
    "image": "/assets/ae49d9b4bd8ec7c8543d.webp"
  },
  {
    "id": "S228",
    "type": "vocabulary",
    "answer": "help",
    "ja": "てつだう",
    "topic": "ACTIONS",
    "image": "/assets/3d2bbaa3ddd65063a9e7.webp"
  },
  {
    "id": "S229",
    "type": "vocabulary",
    "answer": "practice",
    "ja": "れんしゅうする",
    "topic": "ACTIONS",
    "image": "/assets/a8e3c45e0e72504cba74.webp"
  },
  {
    "id": "S230",
    "type": "vocabulary",
    "answer": "clean",
    "ja": "そうじする",
    "topic": "ACTIONS",
    "image": "/assets/16011adde629104b0ae0.webp"
  },
  {
    "id": "S231",
    "type": "vocabulary",
    "answer": "enjoy",
    "ja": "たのしむ",
    "topic": "ACTIONS",
    "image": "/assets/4e844f9237f1b6e8c53d.webp"
  },
  {
    "id": "S232",
    "type": "vocabulary",
    "answer": "visit",
    "ja": "たずねる",
    "topic": "ACTIONS",
    "image": "/assets/436e3989ff24500df884.webp"
  },
  {
    "id": "S233",
    "type": "vocabulary",
    "answer": "ride",
    "ja": "のる",
    "topic": "ACTIONS",
    "image": "/assets/858a104908056404ce51.webp"
  },
  {
    "id": "S234",
    "type": "vocabulary",
    "answer": "come",
    "ja": "くる",
    "topic": "ACTIONS",
    "image": "/assets/48d821311a96535f37e0.webp"
  },
  {
    "id": "S235",
    "type": "vocabulary",
    "answer": "get",
    "ja": "もらう",
    "topic": "ACTIONS",
    "image": "/assets/6f5ab351ea6a1fe6c88c.webp"
  },
  {
    "id": "S236",
    "type": "vocabulary",
    "answer": "save",
    "ja": "たすける",
    "topic": "ACTIONS",
    "image": "/assets/e01e0a2225b1f5476dfe.webp"
  },
  {
    "id": "S237",
    "type": "vocabulary",
    "answer": "stop",
    "ja": "とまる",
    "topic": "ACTIONS",
    "image": "/assets/22a6f39049fbf5cf873b.webp"
  },
  {
    "id": "S238",
    "type": "vocabulary",
    "answer": "study",
    "ja": "べんきょうする",
    "topic": "ACTIONS",
    "image": "/assets/1967ad8d5bf24ee96539.webp"
  },
  {
    "id": "S239",
    "type": "vocabulary",
    "answer": "join",
    "ja": "さんかする",
    "topic": "ACTIONS",
    "image": "/assets/7c6f45e7d8b172070885.webp"
  },
  {
    "id": "S240",
    "type": "vocabulary",
    "answer": "work",
    "ja": "はたらく",
    "topic": "ACTIONS",
    "image": "/assets/c88df04950a1c342b6d4.webp"
  },
  {
    "id": "S250",
    "type": "vocabulary",
    "answer": "grandfather",
    "ja": "おじいさん",
    "topic": "FAMILY",
    "image": "/assets/8980902cb5d77cf35735.webp"
  },
  {
    "id": "S251",
    "type": "vocabulary",
    "answer": "grandmother",
    "ja": "おばあさん",
    "topic": "FAMILY",
    "image": "/assets/4c8a7eeb31a0c9f50566.webp"
  },
  {
    "id": "S252",
    "type": "vocabulary",
    "answer": "father",
    "ja": "おとうさん",
    "topic": "FAMILY",
    "image": "/assets/9d47af7c624d413fc5bb.webp"
  },
  {
    "id": "S253",
    "type": "vocabulary",
    "answer": "mother",
    "ja": "おかあさん",
    "topic": "FAMILY",
    "image": "/assets/7b8951510d6340b09f1e.webp"
  },
  {
    "id": "S254",
    "type": "vocabulary",
    "answer": "uncle",
    "ja": "おじ",
    "topic": "FAMILY",
    "image": "/assets/b035a9f5325e1d206d65.webp"
  },
  {
    "id": "S255",
    "type": "vocabulary",
    "answer": "aunt",
    "ja": "おば",
    "topic": "FAMILY",
    "image": "/assets/f33afda4b81fa29667f0.webp"
  },
  {
    "id": "S256",
    "type": "vocabulary",
    "answer": "brother",
    "ja": "あに・おとうと",
    "topic": "FAMILY",
    "image": "/assets/3ee310711bcd6aae4b26.webp"
  },
  {
    "id": "S257",
    "type": "vocabulary",
    "answer": "sister",
    "ja": "あね・いもうと",
    "topic": "FAMILY",
    "image": "/assets/32496c22d8a15c7ab774.webp"
  },
  {
    "id": "S258",
    "type": "vocabulary",
    "answer": "cousin",
    "ja": "いとこ",
    "topic": "FAMILY",
    "image": "/assets/67b9d8b75cc1b172ec7b.webp"
  },
  {
    "id": "BS01",
    "type": "vocabulary",
    "answer": "house",
    "ja": "家",
    "topic": "BUILDINGS",
    "image": "/assets/building-house.webp"
  },
  {
    "id": "BS02",
    "type": "vocabulary",
    "answer": "park",
    "ja": "公園",
    "topic": "BUILDINGS",
    "image": "/assets/building-park.webp"
  },
  {
    "id": "BS03",
    "type": "vocabulary",
    "answer": "library",
    "ja": "図書館",
    "topic": "BUILDINGS",
    "image": "/assets/building-library.webp"
  },
  {
    "id": "BS04",
    "type": "vocabulary",
    "answer": "museum",
    "ja": "博物館・美術館",
    "topic": "BUILDINGS",
    "image": "/assets/building-museum.webp"
  },
  {
    "id": "BS05",
    "type": "vocabulary",
    "answer": "hospital",
    "ja": "病院",
    "topic": "BUILDINGS",
    "image": "/assets/building-hospital.webp"
  },
  {
    "id": "BS06",
    "type": "vocabulary",
    "answer": "bus stop",
    "ja": "バス停",
    "topic": "BUILDINGS",
    "image": "/assets/building-bus-stop.webp"
  },
  {
    "id": "BS07",
    "type": "vocabulary",
    "answer": "station",
    "ja": "駅",
    "topic": "BUILDINGS",
    "image": "/assets/building-station.webp"
  },
  {
    "id": "BS08",
    "type": "vocabulary",
    "answer": "police station",
    "ja": "警察署",
    "topic": "BUILDINGS",
    "image": "/assets/building-police-station.webp"
  },
  {
    "id": "BS09",
    "type": "vocabulary",
    "answer": "fire station",
    "ja": "消防署",
    "topic": "BUILDINGS",
    "image": "/assets/building-fire-station.webp"
  },
  {
    "id": "BS10",
    "type": "vocabulary",
    "answer": "post office",
    "ja": "郵便局",
    "topic": "BUILDINGS",
    "image": "/assets/building-post-office.webp"
  },
  {
    "id": "BS11",
    "type": "vocabulary",
    "answer": "bookstore",
    "ja": "書店",
    "topic": "BUILDINGS",
    "image": "/assets/building-bookstore.webp"
  },
  {
    "id": "BS12",
    "type": "vocabulary",
    "answer": "restaurant",
    "ja": "レストラン",
    "topic": "BUILDINGS",
    "image": "/assets/building-restaurant.webp"
  },
  {
    "id": "BS13",
    "type": "vocabulary",
    "answer": "supermarket",
    "ja": "スーパーマーケット",
    "topic": "BUILDINGS",
    "image": "/assets/building-supermarket.webp"
  },
  {
    "id": "BS14",
    "type": "vocabulary",
    "answer": "castle",
    "ja": "城",
    "topic": "BUILDINGS",
    "image": "/assets/building-castle.webp"
  },
  {
    "id": "BS15",
    "type": "vocabulary",
    "answer": "shrine",
    "ja": "神社",
    "topic": "BUILDINGS",
    "image": "/assets/building-shrine.webp"
  },
  {
    "id": "BS16",
    "type": "vocabulary",
    "answer": "temple",
    "ja": "寺",
    "topic": "BUILDINGS",
    "image": "/assets/building-temple.webp"
  },
  {
    "id": "BS17",
    "type": "vocabulary",
    "answer": "church",
    "ja": "教会",
    "topic": "BUILDINGS",
    "image": "/assets/building-church.webp"
  },
  {
    "id": "BS18",
    "type": "vocabulary",
    "answer": "aquarium",
    "ja": "水族館",
    "topic": "BUILDINGS",
    "image": "/assets/building-aquarium.webp"
  },
  {
    "id": "BS19",
    "type": "vocabulary",
    "answer": "stadium",
    "ja": "スタジアム",
    "topic": "BUILDINGS",
    "image": "/assets/building-stadium.webp"
  },
  {
    "id": "BS20",
    "type": "vocabulary",
    "answer": "zoo",
    "ja": "動物園",
    "topic": "BUILDINGS",
    "image": "/assets/building-zoo.webp"
  },
  {
    "id": "BS21",
    "type": "vocabulary",
    "answer": "amusement park",
    "ja": "遊園地",
    "topic": "BUILDINGS",
    "image": "/assets/building-amusement-park.webp"
  },
  {
    "id": "BS22",
    "type": "vocabulary",
    "answer": "convenience store",
    "ja": "コンビニエンスストア",
    "topic": "BUILDINGS",
    "image": "/assets/building-convenience-store.webp"
  },
  {
    "id": "BS23",
    "type": "vocabulary",
    "answer": "elementary school",
    "ja": "小学校",
    "topic": "BUILDINGS",
    "image": "/assets/building-elementary-school.webp"
  },
  {
    "id": "BS24",
    "type": "vocabulary",
    "answer": "junior high school",
    "ja": "中学校",
    "topic": "BUILDINGS",
    "image": "/assets/building-junior-high-school.webp"
  }
];
