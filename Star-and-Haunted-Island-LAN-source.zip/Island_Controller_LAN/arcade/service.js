import {createGame,startGame,tick,retainPlayers,action,judge,abort,publicState,normalize} from './engine.js';
const fail=(message,status=409)=>Object.assign(Error(message),{status});
const stmt=(env,sql,...args)=>env.DB.prepare(sql).bind(...args);
const read=(env,code)=>stmt(env,'SELECT * FROM mini_games WHERE code = ?',code).first();
const active=(room,key)=>{const board=JSON.parse(room.state);if(board.mode!=='own'||!board.phase.startsWith('arcade')||board.arcade?.key!==key)throw fail('That mini-game has finished.');return board;};
async function update(env,code,key,mutate,firstRow=null){
 for(let n=0;n<10;n++){
  const row=n===0&&firstRow?firstRow:await read(env,code);if(!row||row.game_key!==key)throw fail('The mini-game is getting ready.');
  const s=JSON.parse(row.state);await mutate(s);const json=JSON.stringify(s);if(json===row.state)return s;
  const changed=await stmt(env,'UPDATE mini_games SET state = ?, version = version + 1 WHERE code = ? AND game_key = ? AND version = ?',json,code,key,row.version).run();
  if(changed.meta.changes)return s;
 }
 throw fail('Lots of players at once! Please try again.',503);
}
export async function syncArcade(env,room,players,now){
 const board=JSON.parse(room.state);if(board.mode!=='own'||!board.phase.startsWith('arcade')||!board.arcade?.key)return null;
 const key=board.arcade.key;let row=await read(env,room.code);
 if(row?.game_key!==key){const previous=row?JSON.parse(row.state):null,s=createGame(key,players,now,{waitForStart:board.theme!=='star',voice:board.arcade.voice!==false,theme:board.theme,topics:board.arcade.topics,miniGames:board.arcade.miniGames},previous);
  if(row)await stmt(env,'UPDATE mini_games SET game_key = ?, state = ?, version = version + 1 WHERE code = ? AND game_key = ?',key,JSON.stringify(s),room.code,row.game_key).run();
  else await stmt(env,'INSERT OR IGNORE INTO mini_games (code,game_key,state,version) VALUES (?,?,?,1)',room.code,key,JSON.stringify(s)).run();
 }
 const s=await update(env,room.code,key,s=>{if(board.arcade.startRequested)startGame(s,now);return retainPlayers(s,players.map(p=>p.id),now);},row?.game_key===key?row:null);return publicState(s,now,null,true);
}
export async function getArcade(env,room,id,now){
 const board=JSON.parse(room.state);if(board.mode!=='own'||!board.phase.startsWith('arcade')||!board.arcade?.key)return null;
 const row=await read(env,room.code);if(!row||row.game_key!==board.arcade.key)return null;
 const s=await update(env,room.code,row.game_key,s=>tick(s,now),row);return publicState(s,now,id);
}
export async function arcadeAction(env,room,id,b,now){
 active(room,b.key);if(!id)throw fail('Join the game first.',403);
 if(typeof b.requestId!=='string'||!/^[-a-zA-Z0-9]{20,80}$/.test(b.requestId)||!Number.isInteger(b.stage))throw fail('Invalid action.',400);
 let replay=null;const s=await update(env,room.code,b.key,s=>{action(s,id,b,now);if(b.type==='replay'&&s.kind==='listening'&&b.stage===s.stage&&!s.revealUntil)replay=s.questions[s.stage].say;});
 return {arcade:publicState(s,now,id),...(replay?{replay}:{} )};
}
export async function skipArcade(env,room,key,now){active(room,key);const s=await update(env,room.code,key,s=>abort(s,now));return publicState(s,now,null,true);}
