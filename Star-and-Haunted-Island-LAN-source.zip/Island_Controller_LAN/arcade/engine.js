function letterTiles(word,r){const tiles=shuffle(word.answer.toUpperCase().split('').map((word,id)=>({id,word})),r);if(tiles.length>1&&tiles.map(t=>t.word).join('')===word.answer.toUpperCase())tiles.push(tiles.shift());return tiles;}
import {contentFor} from './content.js';
export const normalize=s=>String(s).normalize('NFKC').toLowerCase().replace(/[^a-z0-9]/g,'');
const pick=(a,r)=>a[Math.floor(r()*a.length)];
export function shuffle(a,r=Math.random){a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
const actor=(s,id)=>s.players.find(p=>p.id===id);
const error=message=>{throw Object.assign(Error(message),{status:409});};
const revealMs=1800;
function mazeRoute(length,r){
 const walk=path=>{if(path.length===length+1)return path.slice(1);const cell=path.at(-1),neighbours=[cell-4,cell+4,...(cell%4?[cell-1]:[]),...(cell%4<3?[cell+1]:[])].filter(n=>n>=0&&n<16&&!path.includes(n));for(const n of shuffle(neighbours,r)){const route=walk([...path,n]);if(route)return route;}return null;};
 return walk([0]);
}
export function createGame(key,players,now,options={},previous=null,r=Math.random){
 const theme=options.theme==='star'?'star':'haunted',topics=Array.isArray(options.topics)?options.topics:[],pack=contentFor(theme,topics),{vocabulary,sentences,gaps,games}=pack,basic=vocabulary.filter(v=>!v.answer.includes(' ')&&v.id!=='pumpkin'),spellPool=basic.length?basic:contentFor(theme).vocabulary.filter(v=>!v.answer.includes(' '));
 const allowed=games.filter(g=>g.id!=='finger'&&(!Array.isArray(options.miniGames)||options.miniGames.includes(g.id))&&(g.id!=='pronunciation'||options.voice)).map(g=>g.id);
 if(!allowed.length&&!options.forceKind)throw Error('No mini-games selected.');
 if(options.forceKind==='finger')throw Error('This reaction game has been removed.');
 let bag=(previous?.bag||[]).filter(id=>allowed.includes(id));if(!bag.length){bag=shuffle(allowed,r);if(bag[0]===previous?.kind&&bag.length>1)[bag[0],bag[1]]=[bag[1],bag[0]];}
 const kind=options.forceKind||bag.shift(),s={key,kind,bag,theme,topics,reactionTarget:pack.reactionTarget,status:'intro',waitingForStart:!!options.waitForStart,created:now,startAt:now+5000,stage:0,stageStart:now+5000,deadline:0,revealUntil:0,players:players.map(p=>({...p,score:0,progress:0,doneAt:null,answer:null,lockUntil:0,feedback:'',seen:[],replays:0,pos:0,passed:0})),questions:[],awards:[],voice:!!options.voice};
 if(['scramble','maze'].includes(kind)){s.content=pick(sentences.filter(c=>kind!=='maze'||c.words.length<=6),r);s.tiles=shuffle(s.content.words.map((word,id)=>({id,word})),r);s.duration=60000;if(kind==='maze'){s.route=mazeRoute(s.content.words.length,r);s.grid=Array.from({length:16},()=>pick(theme==='star'?['a','the','is','has','can','bird','cat','book','are','in','like','apple']:['a','the','is','has','can','ghost','bat','witch','are','in','like','candy'],r));s.grid[0]='START';s.route.forEach((cell,i)=>s.grid[cell]=s.content.words[i]);}}
 if(kind==='spelling'){s.spellWords=shuffle(spellPool,r);s.duration=20000;for(const p of s.players){p.wordIndex=0;p.wordRound=0;p.wordsCompleted=[];p.wordTiles=letterTiles(s.spellWords[0],r);}}
 if(['dash','listening'].includes(kind)){s.questions=shuffle(vocabulary,r).slice(0,5).map((v,i)=>({type:'multiple_choice',prompt:kind==='listening'?'LISTEN!':i%2===0?'Which word means 「'+v.ja+'」?':'Name the picture.',image:kind==='dash'&&i%2?v.image:null,say:kind==='listening'?v.answer:null,answer:v.id,options:shuffle([v,...shuffle(vocabulary.filter(x=>x.id!==v.id),r).slice(0,3)],r).map(x=>({id:x.id,text:kind==='listening'?'':x.answer,image:kind==='listening'?x.image:null}))}));s.duration=10000;}
 if(kind==='missing'){s.questions=shuffle(gaps,r).slice(0,5).map(c=>({...c,options:shuffle(c.options,r).map((text,i)=>({id:String(i),text})),correctText:c.answer}));for(const q of s.questions)q.answer=q.options.find(o=>o.text===q.correctText).id;s.duration=12000;}
 if(kind==='pronunciation'){s.content=pick(vocabulary.filter(v=>v.id!=='pumpkin'),r);s.duration=20000;}
 if(kind==='potato'){s.questions=shuffle(vocabulary,r).map(v=>({prompt:'What’s this?',image:v.image,answer:v.id,options:shuffle([v,...shuffle(vocabulary.filter(x=>x.id!==v.id),r).slice(0,3)],r).map(x=>({id:x.id,text:x.answer}))}));s.holder=pick(players,r).id;s.duration=20000+Math.floor(r()*15001);}
 if(kind==='rps'){s.questions=Array.from({length:3},(_,i)=>({monster:pick(['rock','paper','scissors'],r),avatar:theme==='star'?'star-kai':'vampire'}));s.duration=10000;}
 s.deadline=s.startAt+s.duration;return s;
}
function end(s,now){
 s.status='results';s.ended=now;
 const ranked=[...s.players].sort((a,b)=>s.kind==='potato'?Number(a.id===s.holder)-Number(b.id===s.holder):['scramble','maze','pronunciation'].includes(s.kind)?(a.doneAt??Infinity)-(b.doneAt??Infinity):b.score-a.score);
 let prior=null,rank=0;s.awards=ranked.map((p,i)=>{const metric=['scramble','maze','pronunciation'].includes(s.kind)?p.doneAt??Infinity:p.score;if(metric!==prior){rank=i+1;prior=metric;}let candy=0;
 if(s.kind==='pronunciation')candy=p.doneAt?3:0;else if(s.kind==='potato')candy=p.id===s.holder?0:3;else if(['scramble','maze'].includes(s.kind))candy=p.doneAt?Math.max(0,4-rank):0;else candy=p.score>0?Math.max(0,4-rank):0;
 return {id:p.id,name:p.name,avatar:p.avatar,color:p.color,rank,candy,score:p.score,completed:!!p.doneAt,loser:s.kind==='potato'&&p.id===s.holder};});return s;
}
function scoreRps(s){const beats={rock:'scissors',scissors:'paper',paper:'rock'},monster=s.questions[s.stage].monster||'rock';for(const p of s.players){p.answer??=['rock','paper','scissors'][(s.stage+p.slot)%3];const win=beats[p.answer]===monster,draw=p.answer===monster;p.score+=win?1:draw?0:-1;p.progress+=win?1:draw?0:-1;p.movement=win?1:draw?0:-1;p.feedback=win?'YOU WIN!':draw?'DRAW!':s.theme==='star'?'CAPTAIN WINS!':'MONSTER WINS!';}}
export function retainPlayers(s,ids,now){
 const keep=new Set(ids),holderIndex=s.players.findIndex(p=>p.id===s.holder);
 const successor=[...s.players.slice(holderIndex+1),...s.players.slice(0,holderIndex+1)].find(p=>keep.has(p.id));
 s.players=s.players.filter(p=>keep.has(p.id));s.awards=s.awards.filter(p=>keep.has(p.id));
 if(s.kind==='potato'&&!keep.has(s.holder))s.holder=successor?.id;
 if(!s.players.length)return abort(s,now);return tick(s,now);
}
export function startGame(s,now){if(s.status!=='intro'||!s.waitingForStart)return s;s.waitingForStart=false;s.startAt=now+1500;s.stageStart=s.startAt;s.deadline=s.startAt+s.duration;return s;}
export function tick(s,now){
 if(s.kind==='finger')return abort(s,now);
 if(s.kind==='spelling'&&!s.spellWords){s.spellWords=s.content?[s.content]:contentFor(s.theme,s.topics).vocabulary.filter(v=>!v.answer.includes(' '));for(const p of s.players){p.score=p.doneAt?1:0;p.progress=p.score;p.doneAt=null;p.wordIndex=0;p.wordRound=0;p.wordsCompleted=[];p.wordTiles=letterTiles(s.spellWords[0],Math.random);p.order=[];}}
 if(s.status==='results')return s;
 if(s.status==='intro'){if(s.waitingForStart||now<s.startAt)return s;s.status='playing';}
 if(s.revealUntil){if(now<s.revealUntil)return s;if(s.stage>=s.questions.length-1)return end(s,now);s.stage++;s.stageStart=s.revealUntil+1500;s.deadline=s.stageStart+s.duration;s.revealUntil=0;for(const p of s.players){p.answer=null;p.feedback='';p.replays=0;p.lockUntil=0;}return tick(s,now);}
 if(now<s.stageStart)return s;
 if(['dash','listening','missing','rps'].includes(s.kind)){
  if(now>=s.deadline||(s.players.every(p=>p.answer!==null))){if(s.kind==='rps')scoreRps(s);s.revealUntil=Math.min(now,s.deadline)+(s.kind==='rps'?3500:revealMs);return tick(s,now);}
 }else if(now>=s.deadline||(!['potato','spelling'].includes(s.kind)&&s.players.every(p=>p.doneAt)))end(s,now);
 return s;
}
function complete(s,p,now){p.doneAt=now;p.progress=1;p.feedback='NICE!';if(['scramble','maze'].includes(s.kind))s.deadline=Math.min(s.deadline,now+8000);}
export function action(s,id,input,now,r=Math.random){
 tick(s,now);const p=actor(s,id);if(!p)error('Join the game first.');
 if(p.seen.includes(input.requestId))return s;
 if(input.stage!==s.stage)error('The question changed.');
 if(s.status!=='playing'||s.revealUntil||now<s.stageStart)error('Watch the countdown.');
 if(p.doneAt||now<p.lockUntil)error('Wait a moment, then try again.');
 p.seen.push(input.requestId);p.seen=p.seen.slice(-40);
 const q=s.questions[s.stage%s.questions.length];p.feedback='';
 if(s.kind==='spelling'){
  if(input.wordRound!==p.wordRound)error('A new word is ready.');
  const tiles=p.wordTiles;if(!['draft','submit'].includes(input.type)||!Array.isArray(input.order)||input.order.length>tiles.length||new Set(input.order).size!==input.order.length||input.order.some(i=>!Number.isInteger(i)||!tiles.some(t=>t.id===i)))error('Choose the letters again.');
  if(!Number.isSafeInteger(input.sequence)||input.sequence<1)error('Choose the letters again.');if(input.sequence<=(p.editSequence||0))return s;p.editSequence=input.sequence;p.order=input.order.slice();
  const answer=input.order.map(i=>tiles.find(t=>t.id===i).word).join(''),word=s.spellWords[p.wordIndex];
  if(input.order.length===tiles.length&&normalize(answer)===normalize(word.answer)){p.wordsCompleted.push(word.answer);p.score++;p.progress=p.score;p.wordIndex=(p.wordIndex+1)%s.spellWords.length;p.wordRound++;p.wordTiles=letterTiles(s.spellWords[p.wordIndex],r);p.order=[];p.feedback='NICE! Next word!';}else if(input.type==='submit')p.feedback='TRY AGAIN';
 }else if(s.kind==='scramble'){
  if(!['draft','submit'].includes(input.type)||!Array.isArray(input.order)||input.order.length>s.tiles.length||new Set(input.order).size!==input.order.length||input.order.some(i=>!Number.isInteger(i)||!s.tiles.some(t=>t.id===i)))error('Choose the tiles again.');
  if(!Number.isSafeInteger(input.sequence)||input.sequence<1)error('Choose the tiles again.');if(input.sequence<=(p.editSequence||0))return s;p.editSequence=input.sequence;
  p.order=input.order.slice();const words=input.order.map(i=>s.tiles.find(t=>t.id===i).word),targets=s.kind==='spelling'?[s.content.answer.toUpperCase().split('')]:[s.content.words,...s.content.alternates.map(a=>a.split(' '))];
  p.progress=Math.max(...targets.map(t=>{let n=0;while(n<words.length&&normalize(words[n])===normalize(t[n]??''))n++;return n/t.length;}));
  if(input.type==='submit'){const answer=words.join(s.kind==='spelling'?'':' ');if(input.order.length===s.tiles.length&&[s.content.answer,...(s.content.alternates||[])].some(a=>normalize(a)===normalize(answer)))complete(s,p,now);else p.feedback='TRY AGAIN';}
 }else if(s.kind==='maze'){
  if(input.type!=='move'||!['up','down','left','right'].includes(input.direction))error('Use the direction buttons.');
  const delta={up:-4,down:4,left:-1,right:1}[input.direction],next=p.pos+delta,valid=next>=0&&next<16&&(Math.abs(delta)!==1||Math.floor(next/4)===Math.floor(p.pos/4));
  const step=p.passed||0;if(valid&&next===s.route[step]){p.pos=next;p.passed++;p.progress=p.passed/s.route.length;if(p.passed===s.route.length)complete(s,p,now);}else{p.lockUntil=now+1000;p.feedback='Dead end!';}
 }else if(['dash','listening','missing'].includes(s.kind)){
  if(s.kind==='listening'&&input.type==='replay'){if(p.answer!==null)error('Wait for the next question.');p.replays++;p.feedback='Replay +1s';}
  else{if(input.type!=='choice'||p.answer!==null||!q.options.some(o=>o.id===input.choice))error('Choose one answer.');p.answer=input.choice;if(input.choice===q.answer){p.score+=1000+Math.max(0,500-Math.floor((now-s.stageStart+p.replays*1000)/20));p.responseMs=Math.max(0,now-s.stageStart+p.replays*1000);p.progress+=s.kind==='listening'?1+4*Math.exp(-p.responseMs/1800):1;p.feedback='NICE!';}else p.feedback='Next question!';}
 }else if(s.kind==='potato'){
  if(input.type!=='choice'||id!==s.holder||!q.options.some(o=>o.id===input.choice))error(s.theme==='star'?'Wait for the coconut.':'Wait for the pumpkin.');
  if(input.choice===q.answer){p.passed++;p.score++;s.holder=s.players[(s.players.findIndex(x=>x.id===id)+1)%s.players.length].id;actor(s,s.holder).feedback='';s.stage++;p.feedback='Passed!';}else{p.lockUntil=now+700;p.feedback='TRY AGAIN';}
 }else if(s.kind==='rps'){
  if(input.type!=='choice'||p.answer!==null||!['rock','paper','scissors'].includes(input.choice))error('Choose one hand.');p.answer=input.choice;p.feedback='Locked in!';
 }else error('Use the microphone.');
 tick(s,now);return s;
}
export function judge(s,id,accepted,stage,now){tick(s,now);const p=actor(s,id);if(s.kind!=='pronunciation'||s.status!=='playing'||s.stage!==stage||!p||p.doneAt)error('That challenge has finished.');p.feedback=accepted?'NICE!':'TRY AGAIN';if(accepted)complete(s,p,now);return tick(s,now);}
export function abort(s,now){if(s.status==='results')return s;s.status='results';s.ended=now;s.skipped=true;s.awards=s.players.map(p=>({id:p.id,name:p.name,avatar:p.avatar,color:p.color,rank:0,candy:0,score:0}));return s;}
export function publicState(s,now,id=null,host=false){
 const {vocabulary,games,reactionTarget}=contentFor(s.theme,s.topics);
 const p=actor(s,id),q=s.questions[s.stage%s.questions.length],info=games.find(g=>g.id===s.kind),revealing=!!s.revealUntil,live=s.status==='playing'&&!revealing&&now>=s.stageStart;
 const out={key:s.key,kind:s.kind==='finger'?'retired':s.kind,theme:s.theme||'haunted',name:info?.name||'Minigame retired',icon:info?.icon||'',instructions:info?.instructions||'',ja:info?.ja||'',status:s.status,waitingForStart:!!s.waitingForStart,stage:s.stage,stageCount:s.kind==='potato'?null:s.questions.length||1,serverNow:now,startAt:s.startAt,stageStart:s.stageStart,deadline:s.kind==='potato'?null:s.deadline,revealing,awards:s.awards,skipped:!!s.skipped,players:s.players.map(x=>({id:x.id,name:x.name,avatar:x.avatar,color:x.color,score:x.score,progress:x.progress,completed:!!x.doneAt,chosen:x.answer!==null,pos:x.pos,movement:x.movement||0,choice:s.kind==='rps'&&revealing?x.answer:undefined})),you:p?{id:p.id,editSequence:p.editSequence||0,progress:p.progress,completed:!!p.doneAt,chosen:p.answer!==null,choice:s.kind==='rps'?p.answer:undefined,feedback:p.feedback,lockUntil:p.lockUntil,pos:p.pos,score:p.score,wordRound:p.wordRound}:null,active:live&&!!p&&!p.doneAt&&p.answer===null&&now>=p.lockUntil};
 if(p)out.you.order=p.order;
 if(s.kind==='rps'){out.monsterAvatar=s.theme==='star'?'star-kai':'vampire';if(revealing||s.status==='results')out.monsterChoice=q.monster||'rock';}
 if(s.status==='results'&&['scramble','maze'].includes(s.kind)&&!s.skipped)out.answer=s.content.answer;
 if(s.status==='intro'||s.status==='results')return out;
 if(s.kind==='spelling'){out.prompt='Put the letters in the correct order to make as many words as you can before time runs out!';if(!host&&p){out.tiles=p.wordTiles;out.image=s.spellWords[p.wordIndex].image;out.wordRound=p.wordRound;out.completedWords=p.score;}out.you&&(out.you.words=p.score);}
 else if(['scramble','maze'].includes(s.kind)){
  out.prompt=s.kind==='spelling'?'Name the picture.':s.content.prompt;out.image=s.kind==='spelling'?s.content.image:null;
  if(!host&&p&&s.kind!=='maze')out.tiles=s.tiles;
  if(s.kind==='maze'){out.grid=s.grid;out.target=s.content.answer;out.finish=s.route.at(-1);const path=[0,...s.route.slice(0,Math.max(...s.players.map(p=>p.passed||0)))];out.openDoors=path.slice(1).map((cell,i)=>[path[i],cell].sort((a,b)=>a-b).join('-'));}
 }else if(['dash','missing','listening'].includes(s.kind)){
  out.prompt=q.prompt;out.image=q.image||null;if(!host&&p)out.options=q.options;
  if(s.kind==='listening'&&host)out.say=q.say;
  if(revealing&&s.kind!=='listening')out.correct=q.options.find(o=>o.id===q.answer)?.text;
 }else if(s.kind==='pronunciation'){out.prompt=s.content.answer;out.image=s.content.image;}
 else if(s.kind==='potato'){out.holder=s.holder;out.active=live&&id===s.holder&&now>=(p?.lockUntil||0);out.prompt=s.theme==='star'?'Pass the hot coconut!':'Pass the cursed pumpkin!';if(host||id===s.holder){out.image=q.image;if(!host){out.options=q.options;out.heldObject='/assets/'+(s.theme==='star'?'star-hot-coconut':'cursed-pumpkin')+'.webp';}}}
 else if(s.kind==='rps'){out.prompt=revealing?'ROCK • PAPER • SCISSORS • SHOOT!':s.theme==='star'?'Beat the captain! Choose your hand in secret.':'Beat the monster! Choose your hand in secret.';if(!host&&p)out.options=['rock','scissors','paper'].map(id=>({id,text:id.toUpperCase(),image:'/assets/'+(s.theme==='star'?'star-':'')+'hand-'+id+'.svg'}));}
 return out;
}
