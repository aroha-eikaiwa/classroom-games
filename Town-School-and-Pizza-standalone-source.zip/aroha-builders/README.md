# Aroha Eikaiwa standalone builders

Town Builder, School Builder and Pizza Builder are playable adaptations of the current 24 November 2026 game source. They run from a static web server without production accounts, class data, network services, or credentials.

Unpack this folder and run `python3 -m http.server --bind 127.0.0.1 8080` here. Open `http://127.0.0.1:8080/` and choose a game. Each game can also be run from its own directory. Browser storage is on the current device only. If this port is busy, choose another port.

These are the actual game interfaces and gameplay engines adapted for safe sharing, not exact production replicas. Connected classroom dashboards, paired remote control and QR purchase services do not ship. The release includes locally generated artwork and procedural fallbacks in place of assets without clear redistribution evidence. Open each game's README for precise coverage, dependency notices, and test limitations. No application-wide redistribution licence is supplied.
