import {M,P,shade} from './model-kit.mjs';

/** Architecturally distinct choices sharing the same road-facing centre entrance. */
export function buildVariant(type,k,w,d,variant){
 if(type==='house'&&variant===1){japaneseHouse(k);return true;}
 if(type==='house'&&variant===2){modernHouse(k);return true;}
 if(type==='castle'&&variant===1){japaneseCastle(k);return true;}
 return false;
}
function garden(k){
 k.grass();k.path(.44,.77,.12,.22);
 for(const x of [.16,.80]){k.rounded(x,.82,.02,.065,.06,.08,P.ivory,M.stone,.012);k.shrub(x+.032,.85,.11,.036);}
}
function japaneseHouse(k){
 garden(k);
 const timber='#77553d',plaster='#eee1c5',roof='#4c6067';
 k.softBox(.19,.22,.035,.62,.50,.72,plaster,M.stucco,.014);
 k.softBox(.18,.21,.04,.64,.52,.065,P.stone,M.stone,.010);
 k.hip(.14,.17,.80,.72,.60,.24,roof,M.ceramic,.19);
 k.beam([.34,.47,1.045],[.66,.47,1.045],.009,roof,M.ceramic,8);
 for(const x of [.20,.40,.60,.80])k.softBox(x-.008,.715,.105,.016,.024,.65,timber,M.wood,.003);
 for(const z of [.13,.40,.72])k.box(.19,.719,z,.62,.027,.025,timber,M.wood);
 for(const side of [0,1,2,3]){
  const face=(xx,yy,zz,a,h)=>k.wallWindow(side,xx,yy,zz,a,h,{arched:false,frame:timber,glass:'#b7c7be'});
  if(side===0||side===2){const y=side===0?.725:.215;for(const x of [.30,.70])for(const z of [.18,.47])face(x,y,z,.14,.18);}
  else for(const y of [.34,.61])for(const z of [.18,.47])face(side===1?.815:.185,y,z,.14,.18);
 }
 k.softBox(.32,.70,.035,.36,.13,.065,P.honey,M.wood,.008);
 k.door(.50,.744,.105,.18,.29,{arched:false,color:timber,glass:true,frame:timber});
 for(let j=0;j<5;j++)k.box(.423+j*.038,.803,.13,.004,.004,.24,P.honey,M.wood);
 k.hip(.28,.66,.425,.44,.20,.10,roof,M.ceramic,.07);
 for(const x of [.31,.69])k.cyl(x,.82,.04,.010,.010,.38,timber,M.wood,10);
 k.steps(.50,.837,.065,.24,2,.025,.025);k.path(.44,.89,.12,.10);
 for(const x of [.12,.86]){k.softBox(x,.25,.02,.022,.45,.16,P.ivory,M.stucco,.008);for(let i=0;i<7;i++)k.box(x+.003,.26+i*.061,.18,.016,.022,.10,timber,M.wood);}
 k.tree(.105,.68,.52);k.sphere(.86,.76,.065,.052,.04,.06,P.stone,M.stone,12,7);k.sphere(.87,.63,.045,.035,.027,.04,P.stone,M.stone,10,6);
 k.lamp(.36,.88,.53);
}
function modernHouse(k){
 garden(k);const plaster='#f3eee0',wood='#b48256',glass='#6d9fab';
 k.softBox(.16,.23,.035,.68,.49,.48,plaster,M.stucco,.018);
 k.softBox(.18,.25,.51,.40,.43,.38,plaster,M.stucco,.016);
 k.softBox(.14,.21,.495,.72,.53,.035,P.ivory,M.stone,.008);
 k.softBox(.16,.23,.88,.44,.47,.045,P.ivory,M.stone,.010);
 k.softBox(.20,.28,.925,.36,.37,.014,P.sand,M.paving,.003);
 k.softBox(.60,.25,.53,.22,.44,.015,P.sand,M.paving,.004);
 k.box(.18,.719,.10,.22,.014,.36,wood,M.siding);for(let i=0;i<9;i++)k.box(.185+i*.025,.736,.10,.006,.008,.36,shade(wood,.85),M.wood);
 k.door(.50,.726,.055,.16,.37,{arched:false,color:wood,glass:true,frame:P.ivory});
 for(const [x,a] of [[.275,.17],[.715,.18]])k.wallWindow(0,x,.728,.16,a,.26,{arched:false,glass,frame:P.ivory,mullions:false});
 k.wallWindow(0,.38,.685,.59,.30,.23,{arched:false,glass,frame:P.ivory,mullions:false});
 for(const side of [1,3]){for(const y of [.36,.60])k.wallWindow(side,side===1?.845:.155,y,.14,.13,.25,{arched:false,glass,frame:P.ivory});}
 k.wallWindow(2,.38,.244,.59,.27,.23,{arched:false,glass,frame:P.ivory,mullions:false});
 // Transparent terrace railing and a timber pergola give a low, asymmetric silhouette.
 for(const [a,b]of[[[.60,.72],[.83,.72]],[[.83,.72],[.83,.26]],[[.60,.26],[.83,.26]]]){
  k.beam([...a,.72],[...b,.72],.004,P.sand,M.metal,6);k.face([[...a,.56],[...b,.56],[...b,.71],[...a,.71]],'#add1cf',M.glass);
 }
 for(const [x,y]of[[.62,.29],[.80,.29],[.62,.67],[.80,.67]])k.softBox(x,y,.54,.013,.013,.29,wood,M.wood,.003);
 for(let i=0;i<6;i++)k.softBox(.60,.28+i*.075,.83,.23,.016,.018,wood,M.wood,.003);
 k.softBox(.36,.74,.43,.28,.13,.03,P.ivory,M.stone,.008);k.path(.44,.86,.12,.13);
 k.planter(.64,.78,.16,.07,P.ivory);k.shrub(.15,.75,.03,.05);k.lamp(.37,.87,.54);
}
function japaneseCastle(k){
 const white='#eee7d2',roof='#445461',stone='#a4a59b',dark='#48535b',gold='#c8a44e';
 k.grass();
 // Low surrounding moat is crossed only by the front approach bridge.
 k.rounded(.035,.045,.014,.93,.88,.025,stone,M.stone,.075);
 k.rounded(.06,.07,.041,.88,.82,.006,'#79afb0',M.glass,.065);
 k.rounded(.125,.13,.049,.75,.70,.032,P.stone,M.stone,.025);
 const base=(x,y,z,a,b,h,inset=.045)=>{
  const bot=[[x,y,z],[x+a,y,z],[x+a,y+b,z],[x,y+b,z]],top=[[x+inset,y+inset,z+h],[x+a-inset,y+inset,z+h],[x+a-inset,y+b-inset,z+h],[x+inset,y+b-inset,z+h]];
  for(let i=0;i<4;i++)k.face([bot[i],bot[(i+1)%4],top[(i+1)%4],top[i]],stone,M.stone);k.face(top,stone,M.stone);
  for(let row=0;row<4;row++){const t=(row+.2)/4,ix=inset*t,zz=z+h*t;for(let side=0;side<4;side++){
   if(side%2===0)k.box(x+ix,side===0?y+ix-.001:y+b-ix,zz,a-ix*2,.003,.009,'#858d89',M.stone);
   else k.box(side===1?x+a-ix:x+ix-.001,y+ix,zz,.003,b-ix*2,.009,'#858d89',M.stone);
  }}
 };
 base(.22,.20,.08,.56,.48,.37,.06);
 const tileRoof=(x,y,z,a,b,h)=>{
  k.pagodaRoof(x,y,z,a,b,h,roof,M.ceramic);
  for(let i=1;i<14;i++){const u=i/14;for(const yy of [y,y+b]){const s=yy===y?1:-1;k.tube([[x+a*u,yy,z+.047],[x+a*(.08+.84*u),yy+s*b*.08,z+.005],[x+a*(.18+.64*u),yy+s*b*.18,z+h*.42+.004],[x+a*(.31+.38*u),yy+s*b*.31,z+h+.004]],.002,shade(roof,1.24),M.ceramic,4);}}
  for(const yy of [y,y+b])k.beam([x,yy,z+.049],[x+a,yy,z+.049],.004,P.sand,M.ceramic,6);
 };
 const wing=(x,y,z,a,b,h,roofH)=>{
  k.softBox(x,y,z,a,b,h,white,M.stucco,.010);k.softBox(x-.007,y-.007,z+h-.06,a+.014,b+.014,.045,white,M.stucco,.008);
  for(const side of [0,1,2,3])for(let j=0;j<3;j++){
   const u=(j+1)/4,xx=side===0||side===2?x+a*u:side===1?x+a+.003:x-.003,yy=side===1||side===3?y+b*u:side===0?y+b+.003:y-.003;
   k.wallWindow(side,xx,yy,z+.08,(side%2?b:a)*.12,h*.43,{arched:false,frame:white,glass:dark,mullions:false});
  }
  tileRoof(x-.055,y-.05,z+h,a+.11,b+.10,roofH);
 };
 wing(.28,.26,.45,.44,.36,.40,.19);
 wing(.335,.30,1.01,.33,.29,.33,.17);
 wing(.385,.335,1.48,.23,.22,.29,.15);
 // Decorative irimoya gables on both principal elevations and the top ridge.
 for(const [x,y,z,a,h] of [[.5,.692,.84,.27,.20],[.5,.211,.84,.27,.20],[.5,.639,1.33,.21,.17],[.5,.285,1.33,.21,.17]]){
  k.xzShape([[x-a/2,z],[x+a/2,z],[x,z+h]],y,.015,white,M.stucco);
  k.tube([[x-a/2-.012,y+.019,z+.012],[x,y+.019,z+h+.015],[x+a/2+.012,y+.019,z+.012]],.008,roof,M.ceramic,8);
  k.wallWindow(0,x,y+.020,z+.04,a*.28,h*.42,{arched:false,frame:white,glass:dark,mullions:false});
 }
 k.roof(.365,.315,1.875,.27,.26,.14,roof,M.ceramic);
 k.beam([.5,.31,2.02],[.5,.58,2.02],.009,roof,M.ceramic,10);
 for(const y of [.32,.57]){
  k.tube([[.5,y,2.02],[.5,y+(y<.4?-.012:.012),2.07],[.5,y+(y<.4?-.024:.024),2.11]],.009,gold,M.metal,8);
  k.sphere(.5,y,2.055,.013,.014,.022,gold,M.metal,10,5);
 }
 // White perimeter wall and two corner watchtowers frame an open, centred gate.
 for(const x of [.145,.73]){k.softBox(x,.72,.08,.125,.055,.23,white,M.stucco,.008);tileRoof(x-.02,.705,.31,.165,.085,.075);}
 for(const x of [.145,.80]){base(x-.025,.205,.08,.105,.17,.18,.01);wing(x-.01,.225,.26,.075,.13,.18,.07);}
 for(const x of [.32,.65])k.softBox(x,.735,.08,.03,.06,.30,dark,M.wood,.004);
 k.softBox(.32,.735,.35,.36,.06,.055,white,M.stucco,.008);tileRoof(.28,.70,.405,.44,.14,.11);
 k.door(.5,.704,.09,.17,.26,{arched:false,color:dark,frame:dark});k.path(.43,.77,.14,.07);
 for(let i=0;i<8;i++)k.softBox(.425,.82+i*.021,.068,.15,.018,.018,P.honey,M.wood,.003);
 for(const x of [.414,.586]){k.beam([x,.81,.18],[x,.99,.18],.006,P.wood,M.wood,6);for(const y of [.82,.89,.97])k.cyl(x,y,.065,.005,.005,.13,P.wood,M.wood,8);}
 // Sakura stand on the island's front gardens, above the stone platform.
 k.at(0,0,.046,0,()=>{k.tree(.20,.80,.65,P.pink);k.tree(.80,.80,.65,P.pink);});
}
