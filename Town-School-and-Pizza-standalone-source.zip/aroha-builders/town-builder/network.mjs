// Straight, eight-direction road sections. Coordinates refer to grid-cell centers.
import {signalJunctions} from './traffic-signals.mjs';
import {WIDTH as W,HEIGHT as H} from './town-grid.mjs';
export {WIDTH as W,HEIGHT as H} from './town-grid.mjs';
const idx=(x,y)=>y*W+x,point=k=>({x:k%W,y:Math.floor(k/W)});
export const edgeKey=(a,b)=>a<b?a+':'+b:b+':'+a;
export const nodeKey=(x,y)=>x+','+y;
export function snapRoadEnd(a,b){const dx=b.x-a.x,dy=b.y-a.y,ax=Math.abs(dx),ay=Math.abs(dy);if(!ax&&!ay)return {...a};if(ay<ax*.414214)return{x:Math.max(0,Math.min(W-1,b.x)),y:a.y};if(ax<ay*.414214)return{x:a.x,y:Math.max(0,Math.min(H-1,b.y))};const n=Math.min(Math.max(ax,ay),dx>=0?W-1-a.x:a.x,dy>=0?H-1-a.y:a.y);return{x:a.x+Math.sign(dx)*n,y:a.y+Math.sign(dy)*n};}
export function straightRoad(a,b){const end=snapRoadEnd(a,b),n=Math.max(Math.abs(end.x-a.x),Math.abs(end.y-a.y)),dx=Math.sign(end.x-a.x),dy=Math.sign(end.y-a.y);return Array.from({length:n+1},(_,i)=>({x:a.x+dx*i,y:a.y+dy*i}));}
export function migrateRoadEdges(roads){const set=new Set(roads),edges=[];for(const k of roads){const{x,y}=point(k);if(x<W-1&&set.has(k+1))edges.push([k,k+1]);if(y<H-1&&set.has(k+W))edges.push([k,k+W]);}return edges;}
const cache=new WeakMap();
export function roadGraph(t){const roads=t.roads||[],edges=t.roadEdges??migrateRoadEdges(roads),old=cache.get(t);if(old&&old.roads===roads&&old.edges===edges&&old.n===roads.length&&old.e===edges.length)return old.graph;
 const roadSet=new Set(roads),validEdges=edges.filter(e=>e.every(k=>roadSet.has(k))),nodes=new Map(),links=[],raw=new Set(validEdges.map(e=>edgeKey(...e)));
 const ensure=(x,y)=>{const id=nodeKey(x,y);if(!nodes.has(id))nodes.set(id,{id,x,y,neighbors:new Set()});return nodes.get(id);};
 const connect=(a,b)=>{const p=ensure(a.x,a.y),q=ensure(b.x,b.y);p.neighbors.add(q.id);q.neighbors.add(p.id);links.push({a:p,b:q});};
 for(const k of roads){const p=point(k);ensure(p.x,p.y);}
 for(const [ka,kb]of validEdges){const a=point(ka),b=point(kb);if(Math.abs(a.x-b.x)===1&&Math.abs(a.y-b.y)===1&&raw.has(edgeKey(idx(a.x,b.y),idx(b.x,a.y)))){const mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};connect(a,mid);connect(mid,b);}else connect(a,b);}
 const intersections=[...nodes.values()].filter(n=>n.neighbors.size>=3);
 const graph={nodes,links,intersections};cache.set(t,{roads,edges,n:roads.length,e:edges.length,graph});return graph;
}
export function connectedNodes(t){const graph=roadGraph(t),seen=new Set();if(!t.start)return seen;const id=nodeKey(t.start.x,t.start.y);if(!graph.nodes.has(id))return seen;const q=[id];seen.add(id);for(let i=0;i<q.length;i++)for(const n of graph.nodes.get(q[i]).neighbors)if(!seen.has(n)){seen.add(n);q.push(n);}return seen;}
export function roadStep(t,pos,dx,dy){const g=roadGraph(t),n=g.nodes.get(nodeKey(pos.x,pos.y));if(!n)return null;const len=Math.hypot(dx,dy)||1;const choices=[...n.neighbors].map(id=>g.nodes.get(id)).map(q=>({x:q.x,y:q.y,score:((q.x-n.x)*dx+(q.y-n.y)*dy)/(Math.hypot(q.x-n.x,q.y-n.y)*len)})).filter(q=>q.score>.66).sort((a,b)=>b.score-a.score);return choices.length?{x:choices[0].x,y:choices[0].y}:null;}
export function addRoad(t,a,b,isBlocked=()=>false){const line=straightRoad(a,b);if(line.some(p=>p.x<0||p.y<0||p.x>=W||p.y>=H||isBlocked(p)))return false;t.roadEdges??=migrateRoadEdges(t.roads);const roads=new Set(t.roads),edges=new Map(t.roadEdges.map(e=>[edgeKey(...e),e]));line.forEach((p,i)=>{const k=idx(p.x,p.y);roads.add(k);if(i){const prev=line[i-1],j=idx(prev.x,prev.y);edges.set(edgeKey(k,j),k<j?[k,j]:[j,k]);}});t.roads=[...roads];t.roadEdges=[...edges.values()];return true;}
export function eraseRoad(t,k){if(!t.roads.includes(k))return false;t.roadEdges=(t.roadEdges??migrateRoadEdges(t.roads)).filter(e=>!e.includes(k));t.roads=t.roads.filter(x=>x!==k);if(t.start&&idx(t.start.x,t.start.y)===k)t.start=null;return true;}
export function segmentTouchesBox(a,b,r,pad=.41){const x0=r.x-pad,y0=r.y-pad,x1=r.x+r.w+pad,y1=r.y+r.d+pad;let lo=0,hi=1;const ax=a.x+.5,ay=a.y+.5,dx=b.x-a.x,dy=b.y-a.y;for(const[p,q]of [[-dx,ax-x0],[dx,x1-ax],[-dy,ay-y0],[dy,y1-ay]]){if(p===0){if(q<0)return false;}else{const v=q/p;if(p<0)lo=Math.max(lo,v);else hi=Math.min(hi,v);if(lo>hi)return false;}}return true;}

const placementCache=new WeakMap();
// Put the whole signal housing outside every road's .49-wide paved shoulder.
export function trafficLightPlacements(t){
 const g=roadGraph(t);if(placementCache.has(g))return placementCache.get(g);const out=[],tau=Math.PI*2,plans=new Map(signalJunctions(g).map(j=>[j.id,j]));
 const clear=(x,y)=>g.links.every(({a,b})=>{const dx=b.x-a.x,dy=b.y-a.y,u=Math.max(0,Math.min(1,((x-a.x-.5)*dx+(y-a.y-.5)*dy)/(dx*dx+dy*dy)));return Math.hypot(x-a.x-.5-u*dx,y-a.y-.5-u*dy)>=.64;});
 for(const n of g.intersections){
  const angles=[...n.neighbors].map(id=>{const b=g.nodes.get(id);return (Math.atan2(b.y-n.y,b.x-n.x)+tau)%tau;}).sort((a,b)=>a-b),candidates=[];
  for(let i=0;i<angles.length;i++){const gap=(angles[(i+1)%angles.length]-angles[i]+tau)%tau,angle=angles[i]+gap/2;
   for(let r=.66/Math.sin(Math.min(gap,Math.PI)/2);r<=2.2;r+=.12){const x=n.x+.5+Math.cos(angle)*r,y=n.y+.5+Math.sin(angle)*r;if(x<.15||y<.15||x>W-.15||y>H-.15)break;if(clear(x,y)){candidates.push({x,y,angle,gap});break;}}
  }
  candidates.sort((a,b)=>b.gap-a.gap);const chosen=[],heads=[],plan=plans.get(n.id);
  for(const c of candidates){if(out.some(p=>Math.hypot(p.x-c.x,p.y-c.y)<.6)||chosen.some(p=>Math.cos(p.angle-c.angle)>(plan.phaseCount>=4?.8:plan.phaseCount===3?.6:.1)))continue;const phase=chosen.length,approach=plan.approaches.filter(a=>a.phase===phase).sort((a,b)=>(b.dx*Math.cos(c.angle)+b.dy*Math.sin(c.angle))-(a.dx*Math.cos(c.angle)+a.dy*Math.sin(c.angle)))[0];if(!approach)continue;chosen.push(c);heads.push({x:c.x,y:c.y,rotation:Math.atan2(approach.dx,approach.dy),phase,phaseCount:plan.phaseCount,junction:n.id});if(chosen.length===plan.phaseCount)break;}
  if(heads.length===plan.phaseCount)out.push(...heads);
 }
 placementCache.set(g,out);return out;
}
