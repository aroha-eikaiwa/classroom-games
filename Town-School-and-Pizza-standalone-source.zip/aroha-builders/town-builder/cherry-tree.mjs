import * as THREE from './vendor/three.module.js';
let loaded=null,pending=null,revision=0;
export const cherryTreeRevision=()=>revision;
export function cherryGeometry(part){
 const data=new Float32Array(part.vertices),buffer=new THREE.InterleavedBuffer(data,8),g=new THREE.BufferGeometry();
 g.setAttribute('position',new THREE.InterleavedBufferAttribute(buffer,3,0));g.setAttribute('normal',new THREE.InterleavedBufferAttribute(buffer,3,3));g.setAttribute('uv',new THREE.InterleavedBufferAttribute(buffer,2,6));g.setIndex(part.indices);g.computeBoundingBox();g.computeBoundingSphere();return g;
}
export function loadCherryTree(){return Promise.resolve(false);}
export function createCherryTree(variant='normal'){
 if(!loaded)return null;const group=new THREE.Group();
 // A mature canopy: 2.86 tiles wide and about 2.45 tiles tall, rooted at y=0.
 group.scale.setScalar(2.2);
 for(const part of loaded){let material=part.material;if(variant.startsWith('ghost')){material=material.clone();material.userData.shared=false;material.transparent=true;material.opacity=.66;if(variant==='ghost-invalid')material.color.set('#ef7575');}
 const mesh=new THREE.Mesh(part.geometry,material);mesh.userData.sharedGeometry=true;group.add(mesh);}return group;
}
