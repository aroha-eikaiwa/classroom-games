import {M,P} from './model-kit.mjs';

/** Attached grounds stay within the stored lot, including older compact school plots. */
export function buildSchool(type,k,w,d){
 if(type!=='elementary-school'&&type!=='junior-high-school')return false;
 const junior=type==='junior-high-school',roof=junior?'#477f82':'#cb7049',wall=junior?'#e8d7b9':'#f0dfbc',glass='#90bac3';
 k.grass();k.path(.46,.42,.08,.57);k.path(.075,.49,.85,.045);k.path(.055,.545,.025,.39);k.path(.92,.545,.025,.39);
 // Broad rear school building leaves the foreground for usable-looking grounds.
 const z=.04,levels=junior?3:2,h=junior?.94:.70;
 k.softBox(.10,.11,z,.80,.29,h,wall,M.stucco,.014);
 k.softBox(.095,.105,z,.81,.30,.055,P.ivory,M.stone,.008);
 for(let floor=0;floor<levels;floor++){
  const zz=.16+floor*.275;
  k.softBox(.093,.103,zz-.055,.814,.304,.026,P.ivory,M.stone,.005);
  for(const x of [.165,.25,.335,.665,.75,.835])k.wallWindow(0,x,.402,zz,.063,.17,{arched:false,frame:P.ivory,glass});
  for(const x of [.18,.29,.4,.6,.71,.82])k.wallWindow(2,x,.108,zz,.07,.17,{arched:false,frame:P.ivory,glass});
  for(const side of [1,3])for(const y of [.19,.32])k.wallWindow(side,side===1?.904:.096,y,zz,.075,.17,{arched:false,frame:P.ivory,glass});
 }
 if(junior){
  k.softBox(.085,.095,h+.055,.83,.32,.05,roof,M.slate,.012);
  k.softBox(.115,.125,h+.106,.77,.26,.012,P.sand,M.paving,.005);
  for(const x of [.17,.68])k.hvac(x,.19,h+.12,.10);
 }else k.hip(.065,.075,h+.08,.87,.36,.22,roof,M.terracotta,.11);
 // Centre clock tower and covered doors remain exactly aligned to the front approach.
 k.softBox(.425,.21,.04,.15,.215,h+.22,P.ivory,M.stone,.012);
 k.softBox(.412,.198,h+.245,.176,.24,.028,roof,M.slate,.006);
 if(junior){k.softBox(.425,.21,h+.275,.15,.215,.012,P.sand,M.metal,.003);}else{k.hip(.402,.185,h+.28,.196,.265,.14,roof,M.terracotta,.065);k.sphere(.5,.31,h+.438,.011,.011,.02,P.gold,M.metal,10,5);}
 k.clock(.5,.43,h+.12,.088);
 k.door(.5,.430,.055,.115,.30,{arched:false,color:'#9b754a',glass:true,frame:P.ivory});
 k.softBox(.37,.414,.365,.26,.10,.035,roof,junior?M.slate:M.terracotta,.008);
 for(const x of [.385,.615])k.cyl(x,.495,.035,.008,.008,.33,P.ivory,M.stone,12);
 k.steps(.5,.491,.045,.22,2,.019,.015);
 for(const x of [.18,.69])k.planter(x,.447,.13,.037,P.ivory);
 buildSchoolGrounds(k,{junior,roof});
 return true;
}
export function buildSchoolGrounds(k,{junior=true,roof='#477f82'}={}){
 // The school field is a distinct attached part of the plot, not another building.
 const field={x:.095,y:.58,a:.32,b:.29};
 k.rounded(field.x-.015,field.y-.015,.017,field.a+.03,field.b+.03,.012,junior?'#b7775d':'#c7b28b',M.paving,.045);
 if(junior){
  k.grass(field.x,field.y,field.a,field.b);
  const line=(x,y,a,b)=>k.box(x,y,.032,a,b,.002,P.white);
  line(.105,.59,.30,.003);line(.105,.858,.30,.003);line(.105,.59,.003,.271);line(.402,.59,.003,.271);line(.105,.724,.30,.003);
  k.ring(.255,.725,.033,.043,.035,.002,.002,P.white,null,28);
  for(const y of [.59,.858]){
   k.beam([.215,y,.033],[.215,y,.12],.003,P.white,null,6);k.beam([.295,y,.033],[.295,y,.12],.003,P.white,null,6);k.beam([.215,y,.12],[.295,y,.12],.003,P.white,null,6);
   for(let i=0;i<7;i++)k.beam([.217+i*.0125,y,.034],[.217+i*.0125,y,.12],.0008,P.ivory,null,3);
  }
  // Blue multipurpose court and basketball hoops beside a shaded reading garden.
  k.rounded(.60,.58,.019,.29,.25,.012,'#769caa',M.paving,.018);
  for(const x of [.61,.87])k.box(x,.59,.034,.003,.23,.001,P.white);
  for(const y of [.59,.817])k.box(.61,y,.034,.263,.003,.001,P.white);
  k.box(.74,.59,.034,.003,.23,.001,P.white);k.ring(.74,.704,.035,.028,.030,.002,.001,P.white,null,24);
  for(const x of [.612,.88]){k.cyl(x,.704,.035,.004,.004,.28,P.dark,M.metal,8);k.box(x-.003,.685,.275,.006,.038,.06,P.white);k.at(x+(x<.7?.018:-.018),.704,.27,0,()=>k.ring(0,0,0,.013,.014,.002,.003,P.red,null,16));}
  k.rounded(.59,.86,.018,.31,.075,.012,P.ivory,M.paving,.016);k.bench(.64,.88,.16);k.tree(.87,.90,.42);
  // Covered bicycles sit by the front gate, clear of the centre entrance.
  k.hip(.08,.91,.24,.31,.055,.035,roof,M.slate,.025);for(const x of [.10,.36])k.cyl(x,.94,.025,.004,.004,.21,P.dark,M.metal,8);
  for(let i=0;i<5;i++){const x=.12+i*.047;for(const y of [.925,.96])k.at(x,y,.055,Math.PI/2,()=>k.disk(0,0,0,.012,.022,P.dark,null,12));k.beam([x,.925,.055],[x,.943,.10],.0015,P.red,null,4);k.beam([x,.943,.10],[x,.96,.055],.0015,P.red,null,4);}
 }else{
  // Pale running/play field with curved track lines and two small football goals.
  for(const r of [0,.014,.028])k.ring(.255,.725,.032,.143-r,.128-r,.0015,.001,P.white,null,36);
  k.box(.12,.723,.034,.27,.002,.001,P.white);
  for(const y of [.64,.81]){k.beam([.22,y,.033],[.22,y,.10],.003,P.white,null,6);k.beam([.29,y,.033],[.29,y,.10],.003,P.white,null,6);k.beam([.22,y,.10],[.29,y,.10],.003,P.white,null,6);}
  // A separate park/playground with a smooth slide, climbing tower and swings.
  k.rounded(.60,.58,.017,.29,.28,.012,'#dcc89f',M.paving,.025);
  for(const x of [.64,.75])for(const y of [.62,.72])k.cyl(x,y,.03,.006,.006,.26,P.teal,M.metal,8);
  k.softBox(.63,.61,.27,.135,.125,.022,P.honey,M.wood,.006);k.hip(.615,.598,.34,.165,.15,.085,P.blue,M.slate,.055);
  for(const x of [.64,.75])k.cyl(x,.62,.29,.005,.005,.065,P.red,M.metal,8);
  const slide=[];for(let i=0;i<=9;i++){const u=i/9;slide.push([.70+u*.16,.73,.29-.245*(u*u*(3-2*u))]);}
  for(let i=0;i<slide.length-1;i++)k.face([[slide[i][0],.71,slide[i][2]],[slide[i][0],.75,slide[i][2]],[slide[i+1][0],.75,slide[i+1][2]],[slide[i+1][0],.71,slide[i+1][2]]].reverse(),P.gold,M.metal,'school-slide');
  for(const y of [.708,.752])k.tube(slide.map(p=>[p[0],y,p[2]+.009]),.003,P.red,M.metal,6);
  for(let i=0;i<6;i++)k.beam([.635,.62,.06+i*.034],[.635,.72,.06+i*.034],.003,P.red,M.metal,6);
  for(const x of [.64,.84])for(const yy of [.80,.88])k.beam([x,yy,.03],[x,.84,.27],.005,P.teal,M.metal,8);
  k.beam([.63,.84,.27],[.85,.84,.27],.005,P.teal,M.metal,8);
  for(const x of [.70,.79]){for(const dx of [-.017,.017])k.beam([x+dx,.84,.26],[x+dx,.84,.10],.0017,P.dark,M.metal,5);k.softBox(x-.022,.824,.09,.044,.032,.012,P.red,null,.003);}
  k.tree(.64,.93,.46,P.pink);k.tree(.88,.55,.42,P.pink);k.bench(.75,.91,.13);k.planter(.14,.92,.19,.045,P.ivory);
 }
 // Continuous low boundary with a clear front gate and a front-centre flagpole.
 for(const x of [.045,.955])for(const y of [.57,.71,.85,.95])k.cyl(x,y,.02,.004,.004,.12,P.sand,M.metal,6);
 for(const x of [.045,.955])k.beam([x,.57,.13],[x,.95,.13],.0025,P.sand,M.metal,6);
 for(const [a,b]of[[.045,.435],[.565,.955]]){k.beam([a,.96,.12],[b,.96,.12],.0025,P.sand,M.metal,6);for(let i=0;i<9;i++)k.cyl(a+(b-a)*i/8,.96,.02,.003,.003,.10,P.sand,M.metal,6);}
 for(const x of [.435,.565])k.softBox(x-.012,.946,.018,.024,.036,.16,P.stone,M.stone,.004);
 k.cyl(.56,.52,.025,.004,.004,.40,P.sand,M.metal,10);k.face([[.565,.52,.41],[.64,.52,.397],[.64,.52,.34],[.565,.52,.35]],P.white);k.disk(.603,.522,.375,.015,.015,P.red,null,20);
}
