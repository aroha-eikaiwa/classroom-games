import * as THREE from './vendor/three.module.js';
// A single material draw covers all of a building's surfaces. The generated
// material atlas supplies fine surface detail; vertex colors preserve the menu art palette.
const uniforms={townTreeAtlas:{value:null},townTreesReady:{value:0},townExpansionAtlas:{value:null},townExpansionReady:{value:0},townAnimalAtlas:{value:null},townAnimalsReady:{value:0},townAtlas:{value:null},townGrass:{value:null},townTexturesReady:{value:0},townGrassReady:{value:0}};
const variants=new Map();let promise;
export const MATERIAL_SCALE=[1.4,.9,1.0,1.0,.95,.95,.85,1.1,1.1,1.4,1.2,.8,1.6,1.2,1.6,.9,8,.62,.42,.38,.38,1.0,.85,1.1,1.5,1.2,.6,1.3,.7,1.0,.65,.9];
export function loadBuildingMaterials(){return Promise.resolve(false);}
let animalPromise;
export function loadAnimalMaterials(){return Promise.resolve(false);}
let expansionPromise;
export function loadExpansionMaterials(){return Promise.resolve(false);}
let treePromise;
export function loadTreeMaterials(){return Promise.resolve(false);}
export function setBuildingGrass(texture){uniforms.townGrass.value=texture;uniforms.townGrassReady.value=1;}
export function buildingMaterial(variant='normal'){
 if(variants.has(variant))return variants.get(variant);
 const ghost=variant.startsWith('ghost'),red=variant==='blocked'||variant==='ghost-invalid';
 const m=new THREE.MeshStandardMaterial({color:'#ffffff',vertexColors:true,roughness:.84,side:THREE.DoubleSide,transparent:ghost,opacity:ghost?.66:1,depthWrite:!ghost,emissive:variant==='points'?'#31d995':variant==='destination'?'#ffd34d':red?'#f33326':'#000000',emissiveIntensity:variant==='points'?.72:variant==='destination'?.85:red?.32:0});
 m.shadowSide=THREE.DoubleSide;m.userData.shared=true;m.onBeforeCompile=shader=>{
  Object.assign(shader.uniforms,uniforms);
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nattribute float surface; varying float vTownSurface; varying vec2 vTownUv; varying vec2 vTownGrassUv; varying vec3 vAnimalPosition; varying vec3 vAnimalNormal;');
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvTownSurface=surface; vTownUv=uv; vAnimalPosition=position; vAnimalNormal=normal; vec4 townWorld=modelMatrix*vec4(position,1.0); vTownGrassUv=vec2(townWorld.x,-townWorld.z)/8.0;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform sampler2D townTreeAtlas; uniform float townTreesReady; uniform sampler2D townExpansionAtlas; uniform float townExpansionReady; uniform sampler2D townAnimalAtlas; uniform float townAnimalsReady; uniform sampler2D townAtlas; uniform sampler2D townGrass; uniform float townTexturesReady; uniform float townGrassReady; varying float vTownSurface; varying vec2 vTownUv; varying vec2 vTownGrassUv; varying vec3 vAnimalPosition; varying vec3 vAnimalNormal;\nvec3 townRelief(vec3 p,vec3 n,vec2 dh,float side){vec3 sx=dFdx(p),sy=dFdy(p),r1=cross(sy,n),r2=cross(n,sx);float det=dot(sx,r1)*side;vec3 gradient=sign(det)*(dh.x*r1+dh.y*r2);return normalize(abs(det)*n-gradient);}');
  shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`
  float townHeight=0.;
  if(vTownSurface>28.5){if(townTreesReady>.5){float tile=floor(vTownSurface-28.5);vec2 cell=vec2(mod(tile,2.),1.-floor(tile/2.));vec3 detail=texture2D(townTreeAtlas,(cell+(.012+fract(vTownUv)*.976))*.5).rgb;if(tile<.5||(tile>1.5&&tile<2.5))detail=mix(detail,vec3(.14,.32,.08),.28)*1.5;diffuseColor.rgb=detail;townHeight=dot(detail,vec3(.2126,.7152,.0722))*.006;}}
  else if(vTownSurface>21.5){
   if(townExpansionReady>.5){float tile=floor(vTownSurface-21.5);vec2 cell=vec2(mod(tile,4.),1.-floor(tile/4.));vec2 uv=(cell+(.012+fract(vTownUv)*.976))/vec2(4.,2.);vec3 detail=texture2D(townExpansionAtlas,uv).rgb;float grain=dot(detail,vec3(.2126,.7152,.0722));if(tile>4.5&&tile<6.5)diffuseColor.rgb=detail;else diffuseColor.rgb*=mix(.72,1.42,grain);townHeight=grain*.009;}
  }
  else if(vTownSurface>17.5){
   diffuseColor.rgb=vTownSurface<18.5?vec3(.64,.35,.12):vTownSurface<19.5?vec3(.35,.34,.31):vTownSurface<20.5?vec3(.65,.42,.18):vec3(.25,.12,.04);
   if(townAnimalsReady>.5){float animal=floor(vTownSurface-17.5);vec2 cell=vec2(mod(animal,2.),1.-floor(animal/2.));float scale=animal<.5?.62:animal<1.5?.42:.38;vec3 p=vAnimalPosition/scale;vec3 weights=pow(abs(normalize(vAnimalNormal)),vec3(6.));weights/=max(.001,weights.x+weights.y+weights.z);
    vec3 skin=texture2D(townAnimalAtlas,(cell+(.008+fract(p.zy)*.984))*.5).rgb*weights.x+texture2D(townAnimalAtlas,(cell+(.008+fract(p.xz)*.984))*.5).rgb*weights.y+texture2D(townAnimalAtlas,(cell+(.008+fract(p.xy)*.984))*.5).rgb*weights.z;
    diffuseColor.rgb=skin;
   }
  }
  else if(vTownSurface>16.5){ if(townGrassReady>.5)diffuseColor.rgb*=texture2D(townGrass,vTownGrassUv).rgb;else diffuseColor.rgb*=vec3(.42,.61,.29); }
  else if(vTownSurface>.5&&townTexturesReady>.5){float tile=floor(vTownSurface-.5);vec2 cell=vec2(mod(tile,4.),3.-floor(tile/4.));vec2 detailUv=(cell*256.+8.+fract(vTownUv)*240.)/1024.;float detail=texture2D(townAtlas,detailUv).r;townHeight=detail*(tile>3.5&&tile<6.5?.027:tile<3.5?.010:.006);diffuseColor.rgb*=mix(.64,1.36,detail);}
  `);
  shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>','#include <normal_fragment_maps>\nif(vTownSurface>.5&&vTownSurface<12.5&&townTexturesReady>.5)normal=townRelief(-vViewPosition,normal,vec2(dFdx(townHeight),dFdy(townHeight)),faceDirection);\nif(vTownSurface>21.5&&vTownSurface<28.5&&abs(vTownSurface-25.)>.25&&townExpansionReady>.5)normal=townRelief(-vViewPosition,normal,vec2(dFdx(townHeight),dFdy(townHeight)),faceDirection);');
  shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>','#include <roughnessmap_fragment>\nif(vTownSurface>24.5&&vTownSurface<25.5)roughnessFactor=.35;else if(vTownSurface>16.5)roughnessFactor=.87;else if(vTownSurface>12.5&&vTownSurface<13.5)roughnessFactor=.20;else if(vTownSurface>13.5&&vTownSurface<14.5)roughnessFactor=.38;else if(vTownSurface>14.5&&vTownSurface<15.5)roughnessFactor=.45;else if(vTownSurface>5.5&&vTownSurface<7.5)roughnessFactor=.58;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <metalnessmap_fragment>','#include <metalnessmap_fragment>\nif(vTownSurface>13.5&&vTownSurface<14.5)metalnessFactor=.28;');
 };m.customProgramCacheKey=()=> 'town-tree-atlas-v9';variants.set(variant,m);return m;
}
export function updateBuildingGlow(tick){const m=variants.get('blocked');if(m)m.emissiveIntensity=.28+Math.sin(tick*3)*.07;const target=variants.get('destination');if(target)target.emissiveIntensity=.85+Math.sin(tick*2.4)*.25;}
