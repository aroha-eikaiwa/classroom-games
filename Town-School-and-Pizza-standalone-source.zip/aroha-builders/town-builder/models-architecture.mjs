/** Detailed everyday buildings, modeled after the matching menu miniatures. */
import {M,P} from './model-kit.mjs';
export function buildArchitecture(type,k,w,d){
 const {face,at,box,rounded,cyl,cone,sphere,dome,roof,hip,beam,tube,disk,xzShape,arch,pane,door,steps,cornice,quoin,clock,shrub,tree,topiary,planter,lamp,openBook,awning,path,hvac,car}=k;
 const warmWindows=['house','library','station','post-office','bookstore','restaurant'].includes(type),glassColor=warmWindows?'#cd9a4f':P.glassDark;
 const window=(x,y,z,a,h,opts={})=>k.window(x,y,z,a,h,{glass:glassColor,...opts});
 const wallWindow=(side,x,y,z,a,h,opts={})=>k.wallWindow(side,x,y,z,a,h,{glass:glassColor,...opts});
 const frontRow=(y,z,xs,a=.09,h=.22,opts={})=>xs.forEach(x=>wallWindow(0,x,y,z,a,h,opts));
 const sideRow=(side,x,ys,z,a=.09,h=.22,opts={})=>ys.forEach(y=>wallWindow(side,x,y,z,a,h,opts));
 const body=(x,y,z,a,b,h,c=P.cream,m=M.stucco)=>{k.softBox(x,y,z,a,b,h,c,m,.012);cornice(x,y,z+h-.035,a,b);box(x-.008,y-.008,z,a+.016,b+.016,.055,P.sand,M.stone);for(const xx of [x,x+a-.02])for(const yy of [y,y+b-.02])quoin(xx,yy,z+.06,h-.08);};
 const finial=(x,y,z,s=1)=>{cyl(x,y,z,.023*s,.023*s,.025*s,P.gold,null,10);sphere(x,y,z+.055*s,.024*s,.024*s,.033*s,P.gold,null,10,5);cone(x,y,z+.08*s,.011*s,.011*s,.04*s,P.gold,null,8);};
 const cupola=(x,y,z,a=.15,h=.25,c=P.blue)=>{const b=a*.85;body(x-a/2,y-b/2,z,a,b,h,P.cream,M.stone);wallWindow(0,x,y+b/2,z+.035,a*.42,h*.63);wallWindow(1,x+a/2,y,z+.035,b*.42,h*.63);hip(x-a*.62,y-b*.64,z+h,a*1.24,b*1.28,.14,c,M.slate,.06);finial(x,y,z+h+.14,.7);};
 const pillar=(x,y,z,h=.55,r=.022,c=P.ivory)=>{cyl(x,y,z,r*1.45,r*1.45,.035,c,M.stone,10);k.frustum(x,y,z+.035,r,r,h-.075,r*.87,r*.87,c,M.stone,12);cyl(x,y,z+h-.04,r*1.3,r*1.3,.04,c,M.stone,10);box(x-r*1.5,y-r*1.5,z+h,r*3,r*3,.025,c,M.stone);};
 const entryPath=(from=.80)=>path(.43,from,.14,.99-from);
 const books=(x,y,z,a=.13,h=.12)=>{for(let i=0;i<6;i++){const colors=[P.red,P.gold,P.teal,P.blue,P.lilac,P.honey];box(x+i*a/6,y,z,a/7,.018,h*(.75+(i%3)*.10),colors[i]);box(x+i*a/6+.003,y+.019,z+h*.3,a/9,.002,.003,P.gold);}};
 const roundPot=(x,y,z=.025,s=.04,c=P.ivory)=>{k.frustum(x,y,z,s*.78,s*.78,.085,s,s,c,M.stone,10);shrub(x,y,z+.105,s*1.1);};
 const table=(x,y,r=.045)=>{cyl(x,y,.04,.008,.008,.12,P.dark,null,6);cyl(x,y,.16,r,r,.018,P.ivory,M.marble,12);for(const dx of [-r*1.5,r*1.5]){cyl(x+dx,y,.06,.022,.022,.02,P.red,null,8);box(x+dx-.018,y-.006,.08,.036,.012,.10,P.red);box(x+dx-.004,y-.004,.02,.008,.008,.06,P.dark);}sphere(x,y,.195,.012,.012,.02,P.leaf,M.leaf,6,3);};
 switch(type){
 case 'house':{
  body(.22,.23,.035,.56,.52,.93,P.cream,M.stucco);roof(.17,.19,.98,.66,.60,.42,P.terra,M.terracotta);
  box(.62,.28,1.22,.075,.09,.27,P.cream,M.stone);box(.61,.27,1.48,.095,.11,.025,P.ivory,M.stone);box(.635,.293,1.507,.045,.055,.005,P.dark);
  door(.50,.753,.055,.13,.38,{color:P.blue});wallWindow(0,.50,.754,.81,.13,.28,{shutters:true,flowers:true});
  sideRow(1,.783,[.36,.62],.16,.10,.23,{shutters:true,flowers:true});sideRow(1,.783,[.36,.62],.60,.10,.24,{shutters:true});sideRow(3,.217,[.39,.64],.20,.09,.22,{shutters:true});frontRow(.754,.11,[.30,.70],.075,.20,{flowers:true});
  for(const x of [.395,.60]){box(x-.01,.79,.25,.02,.025,.09,P.gold);hip(x-.017,.784,.34,.034,.04,.025,P.dark,null,.01);}entryPath(.79);break;
 }
 case 'library':{
  body(.16,.20,.09,.68,.55,.87,P.cream,M.stone);hip(.12,.16,.98,.76,.63,.34,P.blue,M.slate,.17);cupola(.52,.40,1.32,.15,.18,P.blue);
  for(const x of [.24,.76]){k.softBox(x-.045,.66,1.045,.09,.055,.14,P.ivory,M.stone,.005);arch(x-.044,.718,1.095,.088,.13,P.ivory,M.stone,.012);wallWindow(0,x,.734,1.085,.049,.101,{frame:P.gold,glass:'#d2aa60'});finial(x,.70,1.225,.45);}for(const x of [.16,.84])finial(x,.75,1.02,.6);
  box(.35,.72,.10,.30,.09,.70,P.ivory,M.stone);arch(.36,.817,.52,.28,.53,P.ivory,M.stone,.035);arch(.383,.855,.59,.234,.41,P.gold,null,.010);arch(.393,.867,.606,.214,.375,P.cream,M.stone,.005);openBook(.50,.884,.67,.24,.25);
  for(const x of [.39,.61])pillar(x,.832,.11,.37,.018);door(.50,.831,.11,.14,.39);steps(.5,.86,.075,.29,3,.025,.025);entryPath(.93);
  frontRow(.756,.20,[.245,.755],.13,.50);for(const x of [.20,.71])books(x,.779,.22,.10,.12);
  sideRow(1,.845,[.33,.57],.20,.12,.47);sideRow(3,.155,[.33,.57],.20,.12,.47);frontRow(.756,.76,[.24,.76],.10,.14);planter(.11,.80,.15,.07);planter(.74,.80,.15,.07);topiary(.30,.84,.7);topiary(.70,.84,.7);break;
 }
 case 'hospital':{
  rounded(.15,.18,.035,.70,.56,1.09,P.ivory,M.stucco,.035);
  for(let i=0;i<3;i++){const z=.09+i*.32;box(.14,.175,z,.72,.575,.045,P.mint);frontRow(.747,z+.075,[.23,.77],.105,.19,{arched:false});sideRow(1,.855,[.29,.47,.65],z+.075,.105,.19,{arched:false});sideRow(3,.145,[.29,.47,.65],z+.075,.105,.19,{arched:false});}
  cyl(.50,.66,.05,.15,.15,1.12,P.ivory,M.stucco,20);for(let level=0;level<3;level++){const z=.16+level*.30;for(let i=0;i<5;i++){const a=i/5*Math.PI+.05,b=(i+1)/5*Math.PI-.05;face([[.5+Math.cos(a)*.152,.66+Math.sin(a)*.152,z],[.5+Math.cos(b)*.152,.66+Math.sin(b)*.152,z],[.5+Math.cos(b)*.152,.66+Math.sin(b)*.152,z+.24],[.5+Math.cos(a)*.152,.66+Math.sin(a)*.152,z+.24]],P.glass,M.glass);}cyl(.50,.66,z+.245,.156,.156,.030,P.ivory,null,20);}
  rounded(.34,.74,.39,.32,.17,.05,P.ivory,null,.025);for(const x of [.37,.63])pillar(x,.86,.04,.34,.013);door(.50,.814,.035,.14,.34,{arched:false,glass:true});k.cross(.50,.828,.93,.15,P.red);entryPath(.89);
  box(.18,.21,1.13,.64,.45,.035,P.mint);hvac(.21,.25,1.17,.11);hvac(.38,.28,1.17,.10);box(.64,.24,1.17,.13,.12,.12,P.ivory,M.stucco);k.mark('parked-vehicle',[.81,.875,.025],{vehicle:'ambulance',length:Math.min(.9,d*.18)},()=>car(.75,.79,.025,.12,.17,P.ivory,'ambulance'));topiary(.18,.84,.75);break;
 }
 case 'bus-stop':{
  path(.17,.26,.67,.57);box(.20,.29,.03,.57,.012,.57,P.glass,M.glass);box(.20,.29,.03,.012,.35,.57,P.glass,M.glass);
  for(const x of [.20,.77])for(const y of [.29,.64]){cyl(x,y,.03,.011,.011,.62,P.dark,null,8);cyl(x,y,.025,.022,.022,.025,P.dark,null,10);}
  const x0=.15,x1=.82,y0=.23,y1=.71,n=12;for(let i=0;i<n;i++){const a=i/n*Math.PI,b=(i+1)/n*Math.PI,pa=[y0+(1-Math.cos(a))*(y1-y0)/2,.65+Math.sin(a)*.16],pb=[y0+(1-Math.cos(b))*(y1-y0)/2,.65+Math.sin(b)*.16];face([[x0,pa[0],pa[1]],[x1,pa[0],pa[1]],[x1,pb[0],pb[1]],[x0,pb[0],pb[1]]],P.glass,M.glass,'bus-canopy');}for(const x of [.15,.32,.49,.66,.82])tube(Array.from({length:13},(_,i)=>{const a=i/12*Math.PI;return[x,y0+(1-Math.cos(a))*(y1-y0)/2,.652+Math.sin(a)*.163];}),.007,P.dark,null,6);
  k.bench(.29,.37,.38);box(.69,.310,.25,.065,.007,.20,P.ivory);pane(.698,.319,.267,.049,.167,'#bdc3b3',null);for(let i=0;i<4;i++)box(.702,.327,.28+i*.035,.035,.003,.002,P.terra);
  cyl(.24,.77,.025,.008,.008,.48,P.dark,null,6);rounded(.19,.759,.39,.10,.018,.13,P.blue,null,.012);pane(.207,.781,.423,.066,.061,P.ivory,null);pane(.218,.784,.448,.044,.027,P.blue,null);disk(.222,.787,.425,.007,.007,P.blue);disk(.259,.787,.425,.007,.007,P.blue);
  cyl(.19,.68,.03,.029,.029,.12,P.honey,M.wood,12);dome(.19,.68,.15,.031,.031,.035,P.dark,null,12,4);shrub(.78,.34,.05,.055);shrub(.16,.58,.04,.05);entryPath(.84);break;
 }
 case 'station':{
  body(.18,.31,.045,.64,.44,.69,P.brick,M.brick);roof(.135,.28,.76,.73,.50,.32,P.teal,M.slate);
  body(.40,.48,.05,.20,.30,1.15,P.brick,M.brick);hip(.375,.455,1.22,.25,.35,.30,P.teal,M.slate,.10);finial(.50,.63,1.53,.7);clock(.50,.789,.96,.067);
  door(.50,.785,.055,.15,.40,{glass:true});arch(.37,.815,.32,.26,.23,P.teal,null,.03);pane(.39,.851,.35,.22,.06,P.glass);steps(.5,.84,.053,.27,2,.025,.025);entryPath(.89);
  frontRow(.756,.22,[.28,.72],.10,.29);sideRow(1,.825,[.42,.64],.22,.09,.29);sideRow(3,.175,[.42,.64],.22,.09,.29);frontRow(.757,.58,[.28,.72],.065,.13);topiary(.18,.83,.65);topiary(.82,.83,.65);
  path(.08,.17,.84,.10);for(const x of [.13,.37,.63,.87])pillar(x,.22,.03,.43,.008,P.teal);roof(.06,.17,.49,.88,.12,.08,P.teal,M.slate);
  for(const y of [.048,.104])box(.06,y,.018,.88,.012,.018,P.dark,M.metal);for(let i=0;i<14;i++)box(.07+i*.063,.025,.013,.018,.105,.01,P.wood,M.wood);
  // The commuter train is a live rail vehicle in scene.mjs, not a second baked model.
  break;
 }
 case 'police-station':{
  body(.17,.23,.05,.66,.53,.74,P.cream,M.stone);box(.16,.22,.57,.68,.55,.055,P.blue);hip(.13,.19,.82,.74,.61,.20,P.blue,M.slate,.14);
  cyl(.50,.44,1.015,.115,.10,.19,P.cream,M.stone,16);for(const x of [.46,.54])wallWindow(0,x,.533,1.04,.045,.11);dome(.5,.44,1.205,.13,.115,.16,P.blue,M.slate,16,5);finial(.50,.44,1.37,.7);
  arch(.34,.77,.51,.32,.43,P.ivory,M.stone,.035);arch(.36,.806,.56,.28,.36,P.blue,null,.02);xzShape([[.50,.60],[.41,.68],[.42,.82],[.50,.87],[.58,.82],[.59,.68]],.829,.018,P.gold);xzShape([[.50,.69],[.47,.75],[.43,.75],[.47,.79],[.46,.84],[.50,.81],[.54,.84],[.53,.79],[.57,.75],[.53,.75]],.850,.008,P.ivory);
  door(.5,.761,.06,.15,.37);frontRow(.765,.17,[.275,.725],.11,.30,{frame:P.blue});sideRow(1,.835,[.36,.61],.18,.10,.32,{frame:P.blue});sideRow(3,.165,[.36,.61],.18,.10,.32,{frame:P.blue});steps(.5,.81,.06,.26,2,.026,.025);entryPath(.88);
  hvac(.71,.29,1.02,.09);topiary(.18,.84,.68);topiary(.64,.88,.58);lamp(.33,.83,.65);break;
 }
 case 'fire-station':{
  // A real shell: the garage openings have no front wall or flat door behind them.
  box(.15,.15,.04,.67,.03,.76,P.red,M.brick);box(.15,.15,.04,.03,.62,.76,P.red,M.brick);box(.79,.15,.04,.03,.62,.76,P.red,M.brick);
  box(.18,.18,.017,.61,.59,.008,'#79766c',M.paving);box(.18,.18,.04,.61,.006,.70,'#8b8273',M.stucco);
  hip(.12,.12,.83,.72,.68,.16,P.dark,M.ceramic,.11);cornice(.15,.15,.765,.67,.62);
  for(const [left,right] of [[.15,.223],[.397,.483],[.657,.82]])box(left,.735,.04,right-left,.035,.725,P.red,M.brick);
  for(const x of [.31,.57]){
   const radius=.087,spring=.045+.44-.105;
   for(let i=0;i<12;i++){const a=Math.PI-i*Math.PI/12,b=Math.PI-(i+1)*Math.PI/12,xa=x+Math.cos(a)*radius,xb=x+Math.cos(b)*radius,za=spring+Math.sin(a)*radius,zb=spring+Math.sin(b)*radius;
    face([[xa,.77,za],[xb,.77,zb],[xb,.77,.765],[xa,.77,.765]],P.red,M.brick);face([[xb,.735,zb],[xa,.735,za],[xa,.735,.765],[xb,.735,.765]],P.red,M.brick);face([[xa,.735,za],[xb,.735,zb],[xb,.77,zb],[xa,.77,za]],P.sand,M.stone);
   }
  }
  for(const x of [.31,.57]){const length=Math.min(w*.46,d*.78),rear=.89-length/d;k.archFrame(x-.105,.77,.045,.21,.44,.018,P.ivory,M.stone,.035);k.mark('parked-vehicle',[x,.89-length/(2*d),.025],{vehicle:'fire-truck',length},()=>{car(x-.076,rear,.025,.152,length/d,P.red,'fire');for(let i=0;i<4;i++)box(x-.055,rear+.10+i*.06,.285,.11,.008,.01,P.sand,M.metal);});}
  cyl(.79,.59,.05,.095,.105,1.13,P.cream,M.stone,16);for(const z of [.29,.64,.98]){cyl(.79,.59,z,.101,.111,.045,P.red,null,16);wallWindow(0,.79,.698,z+.07,.053,.17);}
  cyl(.79,.59,1.18,.109,.119,.045,P.ivory,null,16);dome(.79,.59,1.225,.11,.12,.18,P.red,null,16,6);finial(.79,.59,1.405,.65);
  arch(.28,.783,.66,.33,.31,P.ivory,M.stone,.04);disk(.445,.827,.81,.10,.10,P.gold);disk(.445,.830,.81,.084,.084,P.red);xzShape([[.445,.74],[.405,.78],[.415,.82],[.443,.88],[.45,.81],[.473,.85],[.49,.79],[.47,.75]],.834,.008,P.gold);
  door(.73,.775,.04,.055,.30,{arched:false});entryPath(.96);sideRow(3,.145,[.39,.63],.21,.08,.26);hvac(.65,.28,1.00,.08);cyl(.88,.80,.02,.018,.018,.15,P.red,null,10);break;
 }
 case 'post-office':{
  body(.22,.24,.04,.56,.51,.73,P.cream,M.stone);roof(.17,.20,.81,.66,.59,.37,P.red,M.terracotta);
  box(.65,.29,1.02,.065,.08,.24,P.cream,M.stone);for(const x of [.665,.696])cyl(x,.327,1.26,.012,.012,.055,P.red,null,8);
  arch(.34,.764,.57,.32,.35,P.ivory,M.stone,.04);rounded(.375,.809,.63,.25,.035,.16,P.ivory,null,.015);tube([[.385,.850,.77],[.50,.851,.685],[.615,.850,.77]],.007,P.red,null,6);
  awning(.33,.776,.51,.34,.11,P.red,P.ivory,8);door(.50,.760,.05,.15,.40);frontRow(.756,.18,[.29,.71],.067,.22,{frame:P.red});sideRow(1,.785,[.37,.62],.20,.085,.29,{frame:P.red,flowers:true});sideRow(3,.215,[.38,.62],.20,.085,.29,{frame:P.red});
  cyl(.18,.83,.025,.038,.038,.22,P.red,null,12);dome(.18,.83,.245,.04,.04,.045,P.red,null,12,4);box(.152,.863,.205,.056,.006,.018,P.dark);pane(.16,.871,.12,.04,.045,P.ivory,null);steps(.50,.81,.06,.25,3,.025,.02);entryPath(.89);topiary(.76,.85,.65);planter(.25,.88,.12,.05);break;
 }
 case 'bookstore':{
  body(.20,.24,.035,.60,.52,.98,P.cream,M.stucco);box(.19,.23,.48,.62,.54,.045,P.lilac);roof(.15,.20,1.05,.70,.60,.36,P.terra,M.terracotta);
  box(.37,.61,1.09,.14,.13,.15,P.cream,M.stucco);roof(.35,.59,1.24,.18,.17,.13,P.terra,M.terracotta);wallWindow(0,.44,.742,1.105,.07,.12,{frame:P.lilac});box(.68,.28,1.25,.07,.09,.24,P.ivory,M.stone);
  for(const x of [.31,.69]){window(x-.09,.766,.09,.18,.31,{arched:false,frame:P.lilac});for(let i=0;i<2;i++)books(x-.075,.789,.105+i*.11,.15,.09);}door(.50,.766,.045,.115,.36,{glass:true,frame:P.lilac});awning(.20,.78,.46,.60,.13,P.lilac,P.ivory,10);openBook(.50,.817,.57,.19,.14);
  frontRow(.765,.66,[.31,.69],.10,.22,{frame:P.lilac,flowers:true,shutters:true});sideRow(1,.805,[.36,.63],.65,.09,.23,{frame:P.lilac,flowers:true});sideRow(1,.805,[.37,.62],.12,.13,.28,{frame:P.lilac,arched:false});at(.811,.38,0,-Math.PI/2,()=>awning(-.10,0,.46,.34,.08,P.lilac,P.ivory,6));
  for(const x of [.18,.82]){roundPot(x,.86,.02,.035,P.terra);shrub(x,.86,.20,.044);}books(.72,.885,.05,.12,.15);box(.71,.875,.035,.14,.055,.025,P.wood,M.wood);entryPath(.91);break;
 }
 case 'restaurant':{
  body(.22,.23,.035,.56,.53,.94,P.cream,M.stucco);roof(.17,.19,1.01,.66,.61,.34,P.terra,M.terracotta);box(.67,.29,1.16,.07,.08,.22,P.cream,M.stone);box(.66,.28,1.38,.09,.10,.03,P.terra);
  body(.38,.70,.04,.24,.09,.90,P.ivory,M.stone);arch(.37,.805,.72,.26,.35,P.ivory,M.stone,.035);disk(.50,.844,.89,.085,.102,P.red);disk(.50,.847,.89,.068,.085,P.ivory);beam([.39,.845,.81],[.39,.845,1.02],.006,P.gold,null,6);for(const x of [.382,.39,.398])beam([x,.845,.99],[x,.845,1.045],.003,P.gold,null,4);beam([.61,.845,.81],[.61,.845,1.04],.006,P.gold,null,6);
  door(.50,.80,.05,.135,.43);frontRow(.766,.16,[.29,.71],.09,.26,{frame:P.wood});frontRow(.766,.66,[.29,.71],.09,.22,{shutters:true,flowers:true});sideRow(1,.785,[.36,.64],.16,.11,.28,{frame:P.wood});sideRow(1,.785,[.36,.64],.65,.09,.23,{shutters:true,flowers:true});
  awning(.19,.78,.52,.18,.11,P.red,P.ivory,5);awning(.63,.78,.52,.18,.11,P.red,P.ivory,5);at(.79,.37,0,-Math.PI/2,()=>awning(-.10,0,.50,.36,.09,P.red,P.ivory,7));table(.20,.88,.045);table(.79,.88,.045);topiary(.13,.70,.75);topiary(.87,.70,.75);entryPath(.85);break;
 }
 case 'supermarket':{
  body(.12,.22,.03,.76,.53,.73,P.ivory,M.stucco);box(.10,.20,.79,.80,.57,.065,P.green);box(.15,.25,.80,.70,.47,.045,P.sand,M.metal);for(const [x,y]of[[.19,.30],[.69,.29]])hvac(x,y,.85,.10);
  for(let i=0;i<8;i++){const a=i/8*Math.PI,b=(i+1)/8*Math.PI;face([[.40,.36+Math.cos(a)*.105,.86+Math.sin(a)*.07],[.63,.36+Math.cos(a)*.105,.86+Math.sin(a)*.07],[.63,.36+Math.cos(b)*.105,.86+Math.sin(b)*.07],[.40,.36+Math.cos(b)*.105,.86+Math.sin(b)*.07]].reverse(),P.glass,M.glass);}arch(.33,.755,.65,.34,.39,P.green,null,.04);arch(.35,.798,.68,.30,.34,P.ivory,M.stucco,.01);
  k.frustum(.50,.829,.755,.105,.016,.065,.085,.014,P.honey,M.wood,10);sphere(.46,.847,.87,.035,.018,.042,P.red,null,10,5);sphere(.54,.846,.86,.035,.018,.04,P.gold,null,10,5);sphere(.51,.847,.92,.022,.015,.03,P.green,null,8,4);for(let i=0;i<5;i++)sphere(.575+(i%2)*.012,.85,.80+Math.floor(i/2)*.018,.012,.010,.014,P.lilac,null,6,4);
  for(const x of [.235,.765])window(x-.08,.757,.11,.16,.36,{arched:false,frame:P.green});door(.50,.758,.035,.22,.40,{arched:false,glass:true,frame:P.green});awning(.16,.78,.55,.68,.10,P.green,P.green,8);sideRow(1,.885,[.36,.60],.12,.15,.38,{arched:false,frame:P.green});
  for(let i=0;i<3;i++){box(.16+i*.075,.87,.03,.066,.06,.075,P.honey,M.wood);for(let j=0;j<4;j++)sphere(.175+i*.075+(j%2)*.025,.885+Math.floor(j/2)*.027,.12,.014,.014,.018,[P.red,P.gold,P.green][i],null,6,3);}
  for(let i=0;i<3;i++){const x=.74+i*.045;box(x,.86,.08,.038,.075,.04,P.sand,M.metal);beam([x,.86,.13],[x,.84,.17],.003,P.dark,null,4);for(const y of [.87,.92])sphere(x+.018,y,.065,.008,.008,.008,P.dark,null,6,3);}entryPath(.91);break;
 }
 case 'convenience-store':{
  rounded(.16,.25,.025,.68,.49,.57,P.ivory,M.stucco,.02);for(const [z,c]of[[.49,P.blue],[.55,P.gold],[.59,P.green]])box(.15,.24,z,.70,.51,.04,c);cornice(.15,.24,.63,.70,.51,P.ivory);box(.19,.28,.65,.62,.43,.015,P.sand,M.metal);hvac(.39,.35,.67,.16);hvac(.67,.32,.67,.075);
  frontRow(.744,.10,[.28,.72],.15,.34,{arched:false,frame:P.sand,mullions:false});door(.50,.744,.025,.19,.41,{arched:false,glass:true,frame:P.sand});sideRow(1,.845,[.37,.62],.11,.14,.33,{arched:false,frame:P.sand,mullions:false});box(.35,.75,.46,.30,.075,.024,P.blue);
  for(const x of [.23,.67])for(let i=0;i<3;i++){box(x,.766,.13+i*.075,.09,.005,.015,P.honey);for(let j=0;j<4;j++)box(x+.005+j*.021,.775,.147+i*.075,.012,.005,.035,[P.red,P.gold,P.green,P.blue][j]);}
  rounded(.075,.73,.025,.09,.09,.30,P.blue,null,.008);pane(.086,.823,.12,.066,.15,P.ivory,null);for(let i=0;i<3;i++)for(let j=0;j<3;j++)box(.093+i*.018,.828,.135+j*.041,.012,.005,.025,[P.red,P.gold,P.green][i]);box(.128,.83,.055,.026,.005,.018,P.dark);for(const x of [.79,.85]){box(x,.82,.025,.05,.06,.15,P.ivory);box(x+.008,.827,.17,.034,.042,.010,x===.79?P.green:P.blue);}entryPath(.82);break;
 }
 case 'elementary-school':case 'junior-high-school':{
  const junior=type==='junior-high-school',h=junior?1.14:.89,roofColor=junior?P.teal:P.terra;
  body(.12,.23,.035,.76,.48,h,P.cream,junior?M.stone:M.stucco);const levels=junior?3:2;for(let l=0;l<levels;l++){const z=.15+l*.31;box(.13,.22,z-.045,.74,.50,.025,P.ivory);frontRow(.714,z,[.21,.32,.68,.79],.085,.21,{arched:false});sideRow(1,.885,[.33,.48,.63],z,.078,.21,{arched:false});sideRow(3,.115,[.33,.48,.63],z,.078,.21,{arched:false});}
  if(junior){hip(.10,.21,h+.08,.80,.52,.15,roofColor,M.slate,.12);box(.22,.31,h+.23,.56,.30,.015,P.sand,M.metal);hvac(.66,.36,h+.25,.09);}else roof(.08,.19,h+.08,.84,.56,.31,roofColor,M.terracotta);
  body(.41,.54,.035,.18,.22,h+.32,P.ivory,M.stone);if(junior){cornice(.40,.53,h+.36,.20,.24,P.teal);box(.42,.55,h+.405,.16,.20,.01,P.sand,M.metal);}else{roof(.385,.515,h+.38,.23,.27,.18,P.terra,M.terracotta);finial(.5,.64,h+.56,.45);}clock(.50,.769,h+.18,.065);
  door(.50,.766,.04,.135,.37,{arched:false,glass:true});for(const x of [.38,.62])pillar(x,.85,.03,.34,.010);if(junior)box(.35,.75,.39,.30,.16,.04,roofColor);else roof(.35,.75,.39,.30,.16,.10,roofColor,M.terracotta);steps(.50,.87,.05,.29,3,.025,.016);entryPath(.95);
  if(junior){
   for(const x of [.73,.92])pillar(x,.84,.03,.23,.006,P.dark);roof(.70,.77,.28,.25,.15,.06,P.teal,M.slate);for(let i=0;i<5;i++){const x=.725+i*.042;for(const y of [.82,.90])at(x,y,.065,Math.PI/2,()=>disk(0,.002,0,.025,.032,P.dark,null,12));beam([x,.82,.065],[x,.86,.13],.002,P.red,null,4);beam([x,.90,.065],[x,.86,.13],.002,P.red,null,4);beam([x,.82,.065],[x,.90,.065],.002,P.dark,null,4);}
   tree(.11,.84,.68);planter(.22,.85,.12,.065);
  }else{
   tree(.13,.81,.70,P.pink);tree(.86,.80,.70,P.pink);
   for(const x of [.70,.84])for(const y of [.83,.93])box(x,y,.02,.009,.009,.27,P.blue);box(.70,.83,.27,.15,.11,.018,P.gold);cone(.775,.885,.30,.095,.075,.12,P.blue,null,4);face([[.83,.89,.28],[.87,.89,.28],[.94,.97,.04],[.90,.97,.04]],P.gold);for(let i=0;i<5;i++)beam([.69,.84,.06+i*.04],[.69,.92,.06+i*.04],.003,P.red,null,4);
   for(let i=0;i<4;i++){const x=.18+i*.06;at(x,.94,.025,0,()=>{for(let j=0;j<8;j++){const a=j/8*Math.PI,b=(j+1)/8*Math.PI;face([[Math.cos(a)*.026,0,Math.sin(a)*.05],[Math.cos(b)*.026,0,Math.sin(b)*.05],[Math.cos(b)*.017,0,Math.sin(b)*.034],[Math.cos(a)*.017,0,Math.sin(a)*.034]],[P.red,P.blue,P.gold,P.green][i]);}});}
  }break;
 }
 default:return false;
 }
 // Back elevations are modeled as carefully as the street-facing elevations;
 // children see these when driving around a rotated building.
 const rear={
  house:{y:.225,xs:[.34,.66],zs:[.19,.62],a:.10,h:.22,shutters:true},
  library:{y:.195,xs:[.29,.50,.71],zs:[.23],a:.12,h:.48},
  hospital:{y:.175,xs:[.26,.42,.58,.74],zs:[.16,.48,.80],a:.105,h:.19,rect:true},
  station:{y:.305,xs:[.29,.50,.71],zs:[.16],a:.10,h:.28},
  'police-station':{y:.225,xs:[.30,.50,.70],zs:[.18],a:.095,h:.30,frame:P.blue},
  'fire-station':{y:.235,xs:[.27,.46,.65],zs:[.20,.58],a:.075,h:.17},
  'post-office':{y:.235,xs:[.35,.65],zs:[.22],a:.09,h:.30,frame:P.red},
  bookstore:{y:.235,xs:[.32,.68],zs:[.16,.65],a:.10,h:.24,frame:P.lilac,shutters:true},
  restaurant:{y:.225,xs:[.34,.66],zs:[.16,.63],a:.09,h:.24,shutters:true},
  supermarket:{y:.215,xs:[.26,.50,.74],zs:[.46],a:.13,h:.12,rect:true},
  'convenience-store':{y:.245,xs:[.28,.70],zs:[.26],a:.10,h:.11,rect:true},
  'elementary-school':{y:.225,xs:[.22,.36,.50,.64,.78],zs:[.15,.46],a:.085,h:.21,rect:true},
  'junior-high-school':{y:.225,xs:[.22,.36,.50,.64,.78],zs:[.15,.46,.77],a:.085,h:.21,rect:true}
 }[type];
 if(rear)for(const z of rear.zs)for(const x of rear.xs)wallWindow(2,x,rear.y,z,rear.a,rear.h,{arched:!rear.rect,frame:rear.frame||P.ivory,shutters:!!rear.shutters});
 return true;
}
