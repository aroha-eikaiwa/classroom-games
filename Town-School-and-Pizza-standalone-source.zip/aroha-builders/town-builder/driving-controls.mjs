// Independent pointer ownership allows a thumb to steer while another holds a pedal.
export function installDrivingControls(stick,knob,pedals,enabled){
 let steering=null;const pointers=new Map();let steer=0;
 const resetStick=()=>{steering=null;steer=0;knob.style.transform='translate(0px,0px)';};
 const clear=()=>{resetStick();pointers.clear();for(const b of pedals)b.classList.remove('pressed');};
 const block=e=>{e.preventDefault();e.stopPropagation?.();};
 for(const el of [stick,...pedals])for(const event of ['contextmenu','selectstart','dragstart'])el.addEventListener(event,block);
 const move=e=>{if(steering!==e.pointerId)return;block(e);if(!enabled()){clear();return;}const r=stick.getBoundingClientRect(),radius=r.width*.28;let x=e.clientX-r.left-r.width/2,y=e.clientY-r.top-r.height/2;const distance=Math.hypot(x,y);if(distance>radius){x*=radius/distance;y*=radius/distance;}const amount=Math.min(1,Math.max(0,(Math.abs(x)/radius-.18)/.82));steer=Math.sign(x)*amount*amount;knob.style.transform=`translate(${x}px,${y}px)`;};
 stick.addEventListener('pointerdown',e=>{block(e);if(!enabled()||steering!==null)return;steering=e.pointerId;stick.setPointerCapture(e.pointerId);move(e);});
 stick.addEventListener('pointermove',move);
 for(const event of ['pointerup','pointercancel','lostpointercapture'])stick.addEventListener(event,e=>{if(steering===e.pointerId){block(e);resetStick();}});
 for(const b of pedals){
  b.addEventListener('pointerdown',e=>{block(e);if(!enabled())return;pointers.set(e.pointerId,b);b.setPointerCapture(e.pointerId);b.classList.add('pressed');});
  for(const event of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(event,e=>{block(e);pointers.delete(e.pointerId);if(![...pointers.values()].includes(b))b.classList.remove('pressed');});
 }
 window.addEventListener('blur',clear);document.addEventListener('visibilitychange',clear);
 return {clear,input(){if(!enabled()){clear();return {};}const active=[...pointers.values()];return {w:active.some(b=>b.dataset.pedal==='w'),s:active.some(b=>b.dataset.pedal==='s'),a:steer<0,d:steer>0,...(steering!==null?{steer}: {})};}};
}
