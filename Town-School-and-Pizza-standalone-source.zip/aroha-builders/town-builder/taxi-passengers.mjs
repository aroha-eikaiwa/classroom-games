import * as THREE from './vendor/three.module.js';
import {Pedestrians} from './pedestrians.mjs';
import {taxiDropoffMarker,taxiPassengerPose,TAXI_DROPOFF_RADIUS,TAXI_DANCER_MODEL} from './taxi-effects.mjs';
import {validateTransport,transportHeightAt} from './transport.mjs';

export class TaxiPassengers extends Pedestrians{
 constructor(scene){super(scene);this.smoothAnimation=true;this.root.name='Taxi passengers';this.root.visible=false;}
 syncChallenge(challenge,avatar){
  this.avatar=avatar;
  this.root.visible=!!challenge;if(!challenge)return;
  if(this.challenge===challenge)return;this.challenge=challenge;
  // Each original character retains its mesh, clothes and animation family.
  const plan=challenge.passengers.map(p=>({...p,passenger:p,seed:p.id,model:p.model||TAXI_DANCER_MODEL,mode:'stand',phase:p.index,base:0}));
  this.sync(challenge.town,{},challenge,plan);
  if(!this.markers){
   const shape=new THREE.Shape();shape.moveTo(-.055,.19);shape.lineTo(.055,.19);shape.lineTo(.055,.03);shape.lineTo(.14,.03);shape.lineTo(0,-.14);shape.lineTo(-.14,.03);shape.lineTo(-.055,.03);shape.closePath();
   const geometry=new THREE.ExtrudeGeometry(shape,{depth:.035,bevelEnabled:false});
   this.markers=new THREE.InstancedMesh(geometry,new THREE.MeshBasicMaterial({color:'#32ff65',side:THREE.DoubleSide}),6);this.markers.frustumCulled=false;this.markers.instanceMatrix.setUsage(THREE.DynamicDrawUsage);this.root.add(this.markers);
   this.rings=new THREE.InstancedMesh(new THREE.RingGeometry(.19,.24,20),new THREE.MeshBasicMaterial({color:'#44ff75',transparent:true,opacity:.7,side:THREE.DoubleSide,depthWrite:false}),6);this.rings.frustumCulled=false;this.root.add(this.rings);
   this.dropoff=new THREE.Group();this.dropoff.name='Taxi stop circle';this.dropoff.visible=false;
   const ring=new THREE.Mesh(new THREE.RingGeometry(TAXI_DROPOFF_RADIUS-.1,TAXI_DROPOFF_RADIUS,48),new THREE.MeshBasicMaterial({color:'#ffe14f',transparent:true,opacity:1,side:THREE.DoubleSide,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3}));
   const fill=new THREE.Mesh(new THREE.CircleGeometry(TAXI_DROPOFF_RADIUS-.1,48),new THREE.MeshBasicMaterial({color:'#25ffd5',transparent:true,opacity:.2,side:THREE.DoubleSide,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
   ring.rotation.x=fill.rotation.x=-Math.PI/2;ring.renderOrder=6;fill.renderOrder=5;this.dropoff.add(fill,ring);this.root.add(this.dropoff);
  }
 }
 pose(p){return taxiPassengerPose(this.challenge,p.passenger,p.phase);}
 tick(time,force=false){
  if(!this.root.visible||!this.challenge)return;
  super.tick(time,force);const c=this.challenge,t=c.clock,obj=this.object;
  if(!this.markers)return;
  const stop=taxiDropoffMarker(c,this.avatar);this.dropoff.visible=!!stop;
  if(stop){this.dropoff.position.set(stop.x,.055+transportHeightAt(validateTransport(c.town),stop.x,stop.z,'road'),stop.z);this.dropoff.children[0].material.opacity=.12+.2*stop.pulse;this.dropoff.children[1].material.opacity=.45+.55*stop.pulse;}
  c.passengers.forEach((p,i)=>{const visible=c.phase==='searching'&&p!==c.passenger&&p.availableAt<=t;obj.scale.setScalar(visible?1:0);obj.position.set(p.x,.89+Math.sin(t*4+i)*.065,p.z);obj.rotation.set(0,t*.6,0);obj.updateMatrix();this.markers.setMatrixAt(i,obj.matrix);obj.position.y=.045;obj.rotation.set(-Math.PI/2,0,0);obj.updateMatrix();this.rings.setMatrixAt(i,obj.matrix);});
  this.markers.count=c.passengers.length;this.rings.count=c.passengers.length;this.markers.instanceMatrix.needsUpdate=true;this.rings.instanceMatrix.needsUpdate=true;
 }
}
