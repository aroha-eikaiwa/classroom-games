// Keep per-renderer load state separate from shared GPU/model caches. A failed
// request must release its loading silhouette too, without retrying every frame.
export class ModelLoads{
 constructor({timeout=30000,warn=(key,error)=>console.warn('Asset unavailable:',key,error)}={}){this.records=new Map();this.revision=0;this.timeout=timeout;this.warn=warn;}
 request(key,load,ready=false){
  if(this.records.has(key))return this.records.get(key).promise;
  if(ready){this.records.set(key,{state:'ready',promise:Promise.resolve(true)});return this.records.get(key).promise;}
  const record={state:'loading',promise:null};this.records.set(key,record);this.revision++;
  let timer;const deadline=new Promise(resolve=>{timer=setTimeout(()=>resolve(false),this.timeout);timer?.unref?.();});
  // Call load immediately so existing loader in-flight deduplication still works.
  let task;try{task=Promise.resolve(load());}catch(error){task=Promise.reject(error);}
  record.promise=Promise.race([task,deadline]).then(ok=>{record.state=ok===false?'failed':'ready';return ok!==false;},error=>{record.state='failed';this.warn(key,error);return false;}).finally(()=>{clearTimeout(timer);this.revision++;});
  return record.promise;
 }
 loading(keys){return keys.some(key=>this.records.get(key)?.state==='loading');}
 get pending(){let count=0;for(const record of this.records.values())if(record.state==='loading')count++;return count;}
}
