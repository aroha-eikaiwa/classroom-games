import {roadGraph,connectedNodes} from './network.mjs';
import {destinationBuildings,entranceAccess,entranceTarget,footprint} from './core.mjs';

// Driving uses grid-cell coordinates (the world-space centre adds .5). Positive
// atan2(dx,dy) turns are LEFT, matching the driver's steering and camera.
const EPS=1e-7,TURN=Math.PI/8;
const distance=(a,b)=>Math.hypot(b.x-a.x,b.y-a.y);
const heading=(a,b)=>Math.atan2(b.x-a.x,b.y-a.y);
const delta=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
const ordinal=n=>['','first','second','third','fourth','fifth','sixth','seventh'][n]||`${n}th`;
const numberWord=n=>['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty'][n]||String(n);

function segmentProjection(point,a,b){
 const dx=b.x-a.x,dy=b.y-a.y,length=Math.hypot(dx,dy),u=length?Math.max(0,Math.min(1,((point.x-a.x)*dx+(point.y-a.y)*dy)/(length*length))):0;
 const x=a.x+u*dx,y=a.y+u*dy;return {x,y,u,length,distance:Math.hypot(point.x-x,point.y-y)};
}
function nearestRoad(graph,point,allowed,travelHeading){
 let best=null;
 for(const {a,b}of graph.links){
  if(allowed&&(!allowed.has(a.id)||!allowed.has(b.id)))continue;
  const p=segmentProjection(point,a,b),forward=Number.isFinite(travelHeading)?Math.max(...[a,b].map(n=>{const d=distance(p,n);return d>EPS?((n.x-p.x)*Math.sin(travelHeading)+(n.y-p.y)*Math.cos(travelHeading))/d:-1;})):0;
  if(!best||p.distance<best.distance-EPS||Math.abs(p.distance-best.distance)<EPS&&forward>best.forward+EPS)best={...p,a,b,forward};
 }
 if(best)return best;
 for(const n of graph.nodes.values())if(!allowed||allowed.has(n.id)){
  const d=distance(point,n);if(!best||d<best.distance)best={x:n.x,y:n.y,u:0,length:0,distance:d,a:n,b:n};
 }
 return best;
}

class Queue{
 constructor(){this.items=[];}
 push(item){let i=this.items.length;this.items.push(item);while(i){const p=(i-1)>>1;if(this.items[p].cost<=item.cost)break;this.items[i]=this.items[p];i=p;}this.items[i]=item;}
 pop(){const top=this.items[0],last=this.items.pop();if(this.items.length){let i=0;while(true){let c=i*2+1;if(c>=this.items.length)break;if(c+1<this.items.length&&this.items[c+1].cost<this.items[c].cost)c++;if(this.items[c].cost>=last.cost)break;this.items[i]=this.items[c];i=c;}this.items[i]=last;}return top;}
 get length(){return this.items.length;}
}

/** Describe the actual outgoing branch relative to the incoming travel vector.
 * Multiple left/right branches are numbered from the gentlest turn to the
 * sharpest turn; the incoming road and U-turn are never counted as exits. */
export function turnInstruction(graph,incoming,junction,outgoing){
 const a=typeof incoming==='string'?graph.nodes.get(incoming):incoming,n=typeof junction==='string'?graph.nodes.get(junction):junction,b=typeof outgoing==='string'?graph.nodes.get(outgoing):outgoing;
 if(!a||!n||!b)return 'Go straight.';
 const travel=heading(a,n),turn=delta(travel,heading(n,b));
 if(Math.abs(turn)<TURN)return 'Go straight.';
 if(Math.abs(turn)>Math.PI-TURN)return 'Turn around when it is safe.';
 const side=turn>0?'left':'right',choices=[...n.neighbors].map(id=>graph.nodes.get(id)).filter(Boolean).map(q=>({id:q.id,angle:delta(travel,heading(n,q))})).filter(q=>q.id!==a.id&&Math.abs(q.angle)>TURN&&Math.abs(q.angle)<Math.PI-TURN&&(q.angle>0)===(turn>0)).sort((p,q)=>Math.abs(p.angle)-Math.abs(q.angle)||p.id.localeCompare(q.id));
 if(choices.length<=1)return `Turn ${side}.`;
 let index=choices.findIndex(q=>q.id===b.id);if(index<0)index=choices.reduce((best,q,i)=>Math.abs(q.angle-turn)<Math.abs(choices[best].angle-turn)?i:best,0);return `Take the ${ordinal(index+1)} ${side}.`;
}

function compact(points){
 const out=[];for(const p of points){const point={x:p.x,y:p.y,...(p.id?{id:p.id}:{})};if(!out.length||distance(out.at(-1),p)>EPS)out.push(point);else if(p.id)out[out.length-1]=point;}return out;
}

/** A shortest road route from the current position to the destination's usable
 * road entrance. No turns or paths are exposed as rendering instructions. */
export function planGpsRoute(town,pose,destinationId,{forwardOnly=false}={}){
 if(!Number.isFinite(pose?.x)||!Number.isFinite(pose?.y))return null;
 const building=town.buildings.find(b=>b.id===(destinationId?.id??destinationId));if(!building||!destinationBuildings(town).some(b=>b.id===building.id))return null;
 const access=entranceAccess(town,building,{connected:true}),arrivalTarget=entranceTarget(town,building);if(!access||!arrivalTarget)return null;
 const graph=roadGraph(town),allowed=connectedNodes(town),start=nearestRoad(graph,pose,null,forwardOnly?pose.heading:undefined),goal=nearestRoad(graph,{x:access.x-.5,y:access.y-.5},allowed);if(!start||!goal||start.distance>.8||!allowed.has(start.a.id)||!allowed.has(start.b.id))return null;
 const sameEdge=(a,b)=>a.id===start.a.id&&b.id===start.b.id||b.id===start.a.id&&a.id===start.b.id;
 const travel={x:Math.sin(pose.heading||0),y:Math.cos(pose.heading||0)},ahead=n=>(n.x-start.x)*travel.x+(n.y-start.y)*travel.y;
 const costs=new Map(),previous=new Map(),queue=new Queue(),startPoint={x:start.x,y:start.y};
 for(const n of [start.a,start.b]){
  if(forwardOnly&&ahead(n)<EPS)continue;
  const len=distance(startPoint,n),angle=len>.04&&Number.isFinite(pose.heading)?Math.abs(delta(pose.heading,heading(startPoint,n))):0;
  // A small initial manoeuvre cost avoids a pointless U-turn around a loop.
  const cost=len+(angle>Math.PI*.65?1.5:0);
  if(cost>=(costs.get(n.id)??Infinity))continue;costs.set(n.id,cost);previous.set(n.id,null);queue.push({id:n.id,cost});
 }
 while(queue.length){
  const current=queue.pop();if(current.cost>costs.get(current.id)+EPS)continue;
  const n=graph.nodes.get(current.id);
  for(const id of [...n.neighbors].sort()){
   if(!allowed.has(id))continue;const q=graph.nodes.get(id),cost=current.cost+distance(n,q);
   // A route that immediately crosses back over the road just entered is a
   // turnaround, not an alternative route. Cut that edge for detour searches.
   if(forwardOnly&&sameEdge(n,q))continue;
   if(cost>=(costs.get(id)??Infinity)-EPS)continue;costs.set(id,cost);previous.set(id,n.id);queue.push({id,cost});
  }
 }
 const goalPoint={x:goal.x,y:goal.y},sameGoalEdge=sameEdge(goal.a,goal.b),goalAhead=(goalPoint.x-start.x)*travel.x+(goalPoint.y-start.y)*travel.y;
 const ends=[goal.a,goal.b].filter(n=>costs.has(n.id)&&!(forwardOnly&&sameGoalEdge&&goalAhead<0&&ahead(n)>0)).sort((a,b)=>(costs.get(a.id)+distance(a,goalPoint))-(costs.get(b.id)+distance(b,goalPoint))||a.id.localeCompare(b.id));
 if(!ends.length&&!(forwardOnly&&sameGoalEdge&&goalAhead>=0))return null;
 const ids=[];for(let id=ends[0]?.id;id!==null&&id!==undefined;id=previous.get(id)){ids.push(id);if(ids.length>graph.nodes.size)return null;}ids.reverse();
 let points=compact([startPoint,...ids.map(id=>graph.nodes.get(id)),goalPoint]);
 // Both projections can lie on the same road section. The direct segment must
 // remain an option instead of driving to an endpoint and immediately back.
 if(sameGoalEdge&&(!forwardOnly||goalAhead>=0)&&(!ends.length||distance(startPoint,goalPoint)<=points.slice(1).reduce((sum,p,i)=>sum+distance(points[i],p),0)+EPS))points=compact([startPoint,goalPoint]);
 const cumulative=[0];for(let i=1;i<points.length;i++)cumulative.push(cumulative[i-1]+distance(points[i-1],points[i]));
 const turns=[];
 for(let i=0;i<points.length-1;i++){
  const n=points[i],out=points[i+1],a=i?points[i-1]:{x:n.x-Math.sin(pose.heading||0),y:n.y-Math.cos(pose.heading||0),id:'@heading'},turn=delta(heading(a,n),heading(n,out));
  if(Math.abs(turn)<=TURN)continue;
  const junction=n.id&&graph.nodes.get(n.id),instruction=junction?turnInstruction(graph,a,junction,out):Math.abs(turn)>Math.PI-TURN?'Turn around when it is safe.':`Turn ${turn>0?'left':'right'}.`;
  turns.push({index:i,distance:cumulative[i],instruction});
 }
 const finalHeading=points.length>1?heading(points.at(-2),points.at(-1)):pose.heading||0,f=footprint(building),center={x:building.x+f.w/2-.5,y:building.y+f.d/2-.5},left=(center.x-goalPoint.x)*Math.cos(finalHeading)-(center.y-goalPoint.y)*Math.sin(finalHeading),side=Math.abs(left)<.25?'front':left>0?'left':'right';
 return {destination:building,graph,points,cumulative,length:cumulative.at(-1),turns,arrivalTarget,targetPoint:goalPoint,side,finalInstruction:side==='front'?'You can see it in front of you.':`You can see it on your ${side}.`};
}

function projectRoute(plan,pose,previousProgress=0){
 if(plan.points.length<2)return {distance:distance(pose,plan.points[0]),progress:0,index:0};
 let best=null;
 for(let i=1;i<plan.points.length;i++){
  const p=segmentProjection(pose,plan.points[i-1],plan.points[i]),progress=plan.cumulative[i-1]+p.u*p.length;
  if(!best||p.distance<best.distance-EPS||Math.abs(p.distance-best.distance)<EPS&&Math.abs(progress-previousProgress)<Math.abs(best.progress-previousProgress))best={...p,progress,index:i-1};
 }
 return best;
}

function promptAt(plan,progress){
 const next=plan.turns.find(t=>t.distance>=progress-.6),remaining=Math.max(0,plan.length-progress);
 const before=next?.distance??plan.length,intervening=plan.points.some((p,i)=>i>0&&p.id&&plan.graph.nodes.get(p.id)?.neighbors.size>=3&&plan.cumulative[i]>progress-.6&&plan.cumulative[i]<before-EPS);
 // Do not say "turn left" while the child is still passing an earlier left
 // exit. Close junctions retain the straight cue until that junction is clear.
 if(next&&next.distance-progress<=3.2&&!intervening)return {key:'turn:'+next.index,text:next.instruction};
 if(!next&&remaining<=3.8&&!intervening)return {key:'destination',text:plan.finalInstruction};
 const until=next?.distance??plan.length,junctions=plan.points.filter((p,i)=>i>0&&plan.cumulative[i]>progress+.6&&plan.cumulative[i]<=until+EPS&&p.id&&plan.graph.nodes.get(p.id)?.neighbors.size>=3).length;
 const text=junctions?`Go straight for ${numberWord(junctions)} ${junctions===1?'block':'blocks'}.`:remaining<=6?'Go straight for a little bit.':'Go straight.';
 return {key:`straight:${next?.index??'end'}:${junctions}`,text};
}

/** Stateful spoken navigation. .spoken is emitted only when a cue changes;
 * .repeat() returns the current English cue without moving the route forward. */
export class SpokenGps{
 constructor(town,{random=Math.random}={}){this.town=town;this.random=random;this.stop();}
 stop(){this.plan=null;this.instruction='';this.promptKey='';this.arrived=false;this.time=0;this.lastWarning=-Infinity;this.progress=0;this.furthest=0;this.lastPose=null;this.turnAround=false;this.nextRecovery=0;}
 start(pose,{destinationId,excludeId}={}){
  this.stop();let destination;
  if(destinationId!==undefined)destination=this.town.buildings.find(b=>b.id===(destinationId?.id??destinationId));
  else{
   let choices=destinationBuildings(this.town).filter(b=>entranceAccess(this.town,b,{connected:true}));
   const other=choices.filter(b=>b.id!==excludeId);if(other.length)choices=other;
   const farther=choices.filter(b=>{const p=entranceTarget(this.town,b);return p&&Math.hypot(p.x-.5-pose.x,p.y-.5-pose.y)>=3;});if(farther.length)choices=farther;
   if(!choices.length)return null;destination=choices[Math.min(choices.length-1,Math.max(0,Math.floor(this.random()*choices.length)))];
  }
  if(!destination)return null;this.plan=planGpsRoute(this.town,pose,destination.id);if(!this.plan)return null;
  this.lastPose={x:pose.x,y:pose.y};const prompt=promptAt(this.plan,0);this.promptKey=prompt.key;this.instruction=prompt.text;
  if(this.instruction==='Turn around when it is safe.'){this.turnAround=true;this.lastWarning=0;return this.result({warning:true});}
  return this.result({spoken:this.instruction});
 }
 repeat(){return this.turnAround?'':this.instruction;}
 result({spoken='',warning=false,rerouted=false}={}){return this.plan?{destination:this.plan.destination,instruction:this.instruction,spoken,warning,rerouted,turnAround:this.turnAround,arrived:this.arrived,route:this.plan.points}:null;}
 usePlan(plan){this.plan=plan;this.progress=0;this.furthest=0;this.turnAround=false;const prompt=promptAt(plan,0);this.instruction=prompt.text;this.promptKey=prompt.key;}
 update(pose,dt=0,{allowArrival=true}={}){
  if(!this.plan||!Number.isFinite(pose?.x)||!Number.isFinite(pose?.y))return null;
  this.time+=Number.isFinite(dt)?Math.max(0,dt):0;if(this.arrived)return this.result();
  const p=projectRoute(this.plan,pose,this.progress),moved=this.lastPose?distance(this.lastPose,pose):0,world={x:pose.x+.5,y:pose.y+.5},near=distance(world,this.plan.arrivalTarget)<.85;
  if(allowArrival&&near&&this.plan.length-p.progress<1.2&&p.distance<.8){this.arrived=true;this.turnAround=false;this.instruction=this.plan.finalInstruction;this.lastPose={x:pose.x,y:pose.y};return this.result({spoken:'You have arrived. Well done!'});}
  // Route-distance thresholds supply the deadband. A per-frame movement
  // minimum would silently disable warnings at high refresh rates/low speeds.
  const wrong=moved>EPS&&(p.distance>.8||p.progress<this.furthest-.85);
  if((wrong||this.turnAround)&&moved>EPS&&this.time>=this.nextRecovery){
   this.nextRecovery=this.time+.3;
   const travelPose={...pose,heading:heading(this.lastPose,pose)},revised=planGpsRoute(this.town,travelPose,this.plan.destination.id,{forwardOnly:true}),recovering=this.turnAround;
   this.lastPose={x:pose.x,y:pose.y};
   if(revised){this.usePlan(revised);return this.result({rerouted:!recovering,spoken:this.instruction});}
   this.turnAround=true;
   const warning=this.time-this.lastWarning>=4;if(warning)this.lastWarning=this.time;
   return this.result({warning});
  }
  if(this.turnAround){this.lastPose={x:pose.x,y:pose.y};return this.result();}
  this.progress=p.progress;this.furthest=Math.max(this.furthest,p.progress);this.lastPose={x:pose.x,y:pose.y};
  const prompt=promptAt(this.plan,this.progress);if(prompt.key!==this.promptKey){this.promptKey=prompt.key;this.instruction=prompt.text;return this.result({spoken:this.instruction});}
  return this.result();
 }
}
