import { M, P, shade } from './model-kit.mjs';

// All horizontal coordinates are fractions of the lot.  The public entrance
// faces +Y; every ornament, including the flags, stays inside that footprint.
const TEAL = '#356d69';
const ROOF_BLUE = '#355f9b';
const REDWOOD = '#b63e31';

function helpers(k) {
  const column = (x,y,z,h,r=.027) => {
    k.box(x-r*1.65,y-r*1.65,z,r*3.3,r*3.3,.035,P.ivory,M.marble);
    k.cyl(x,y,z+.035,r*1.45,r*1.45,.025,P.sand,M.marble,16);
    k.cyl(x,y,z+.06,r,r,h-.115,P.ivory,M.marble,16);
    for(let i=0;i<12;i++) {
      const t=i*Math.PI/6;
      k.beam([x+Math.cos(t)*r,y+Math.sin(t)*r,z+.08],
        [x+Math.cos(t)*r,y+Math.sin(t)*r,z+h-.07],.0025,P.sand,M.marble,4);
    }
    k.cyl(x,y,z+h-.055,r*1.35,r*1.35,.025,P.ivory,M.marble,16);
    k.box(x-r*1.65,y-r*1.65,z+h-.03,r*3.3,r*3.3,.03,P.ivory,M.marble);
  };
  const rail = (a,b,z,h=.13,color=P.wood,n=8) => {
    k.beam([a[0],a[1],z+h],[b[0],b[1],z+h],.008,color,M.wood,6);
    k.beam([a[0],a[1],z+.025],[b[0],b[1],z+.025],.005,color,M.wood,4);
    for(let i=0;i<=n;i++) {
      const t=i/n,x=a[0]+(b[0]-a[0])*t,y=a[1]+(b[1]-a[1])*t;
      k.box(x-.004,y-.004,z,.008,.008,h+.012,color,M.wood);
      if(i===0||i===n) k.sphere(x,y,z+h+.014,.011,.011,.014,P.gold,M.metal,6,3);
    }
  };
  const lantern = (x,y,s=1) => {
    k.box(x-.035*s,y-.035*s,.025,.07*s,.07*s,.035*s,P.stone,M.stone);
    k.box(x-.024*s,y-.024*s,.025+.035*s,.048*s,.048*s,.038*s,P.ivory,M.stone);
    k.cyl(x,y,.025+.07*s,.016*s,.016*s,.16*s,P.stone,M.stone,8);
    k.box(x-.036*s,y-.036*s,.025+.225*s,.072*s,.072*s,.025*s,P.stone,M.stone);
    k.box(x-.025*s,y-.025*s,.025+.25*s,.05*s,.05*s,.08*s,P.gold,M.glass);
    for(const dx of [-.029,.022]) for(const dy of [-.029,.022])
      k.box(x+dx*s,y+dy*s,.025+.25*s,.007*s,.007*s,.08*s,P.ivory,M.stone);
    k.hip(x-.046*s,y-.046*s,.025+.335*s,.092*s,.092*s,.045*s,P.stone,M.stone,.028*s);
    k.sphere(x,y,.025+.395*s,.014*s,.014*s,.024*s,P.stone,M.stone,8,4);
  };
  const tileRoof = (x,y,z,a,b,h,color=TEAL,ornate=true) => {
    k.pagodaRoof(x,y,z,a,b,h,color,M.ceramic);
    const rings=[[0,.045],[.08,0],[.18,h*.42],[.31,h]];
    // Raised tile seams run from the curled eaves to the roof's upper plateau.
    for(let side=0;side<4;side++) for(let j=1;j<14;j++) {
      const u=j/14;
      const pts=rings.map(([t,dz])=> {
        const xa=x+a*t,xb=x+a*(1-t),ya=y+b*t,yb=y+b*(1-t);
        return side===0?[xa+(xb-xa)*u,ya,z+dz+.004]:
          side===1?[xb,ya+(yb-ya)*u,z+dz+.004]:
          side===2?[xb-(xb-xa)*u,yb,z+dz+.004]:
          [xa,yb-(yb-ya)*u,z+dz+.004];
      });
      k.tube(pts,.0024,shade(color,1.15),M.ceramic,4);
    }
    for(let side=0;side<4;side++) {
      const c=ornate?P.gold:shade(color,.78);
      const corners=[[x,y],[x+a,y],[x+a,y+b],[x,y+b]],p=corners[side],q=corners[(side+1)%4];
      k.beam([p[0],p[1],z+.045],[q[0],q[1],z+.045],.005,c,ornate?M.metal:M.wood,6);
      if(ornate) {
        k.cyl(p[0],p[1],z-.035,.004,.004,.07,P.gold,M.metal,6);
        k.frustum(p[0],p[1],z-.075,.012,.012,.025,.006,.006,P.gold,M.metal,8);
      }
    }
  };
  const lattice = (x,y,z,a,h,color=P.honey) => {
    k.box(x,y,z,a,.018,h,P.wood,M.wood);
    k.pane(x+.009,y+.020,z+.015,a-.018,h-.03,'#d9b574',M.glass);
    for(let i=1;i<6;i++) k.box(x+a*i/6-.002,y+.024,z+.014,.004,.005,h-.028,color,M.wood);
    for(let i=1;i<5;i++) k.box(x+.008,y+.026,z+h*i/5,a-.016,.006,.005,color,M.wood);
    k.box(x-.008,y-.002,z-.01,a+.016,.035,.018,color,M.wood);
    k.box(x-.008,y-.002,z+h-.008,a+.016,.035,.02,color,M.wood);
  };
  const gothic = (x,y,z,a,h,glass=true) => {
    const pointed=(xx,zz,aa,hh)=>[[xx,zz],[xx+aa,zz],[xx+aa,zz+hh*.61],
      [xx+aa*.85,zz+hh*.81],[xx+aa*.5,zz+hh],[xx+aa*.15,zz+hh*.81],[xx,zz+hh*.61]];
    k.xzShape(pointed(x,z,a,h),y,.023,P.ivory,M.stone);
    k.xzShape(pointed(x+.013,z+.017,a-.026,h-.04),y+.026,.006,glass?P.blue:P.dark,glass?M.glass:M.wood);
    if(glass) {
      const cs=[P.red,P.gold,P.teal,P.blue];
      for(let i=0;i<4;i++) {
        const xx=x+.018+i*(a-.036)/4;
        k.pane(xx,y+.035,z+.025,(a-.04)/4,h*(i===1||i===2?.67:.53),cs[i],M.glass);
      }
      k.box(x+a/2-.003,y+.038,z+.023,.006,.006,h*.75,P.gold,M.metal);
      k.box(x+.015,y+.038,z+h*.40,a-.03,.006,.006,P.gold,M.metal);
      k.beam([x+a/2,y+.039,z+h*.65],[x+a*.25,y+.039,z+h*.78],.003,P.gold,M.metal,4);
      k.beam([x+a/2,y+.039,z+h*.65],[x+a*.75,y+.039,z+h*.78],.003,P.gold,M.metal,4);
    } else for(let j=0;j<5;j++)
      k.box(x+.021,y+.037,z+.036+j*h*.085,a-.042,.008,.009,P.honey,M.wood);
    k.box(x-.01,y-.006,z-.019,a+.02,.049,.028,P.ivory,M.stone);
  };
  return {column,rail,lantern,tileRoof,lattice,gothic};
}

function museum(k) {
  const {column}=helpers(k);
  k.grass();
  k.rounded(.08,.075,.016,.84,.83,.035,P.stone,M.paving,.018);
  k.box(.15,.12,.051,.70,.60,.70,P.cream,M.marble);
  k.box(.14,.11,.055,.72,.62,.07,P.ivory,M.stone);
  k.cornice(.15,.12,.71,.70,.60,P.ivory);
  k.hip(.13,.10,.785,.74,.64,.23,TEAL,M.ceramic,.16);
  for(const x of [.15,.85]) for(const y of [.12,.71]) {
    k.quoin(x,y,.14,.58);
    k.box(x-.024,y-.024,.82,.048,.048,.09,P.ivory,M.marble);
    k.cyl(x,y,.91,.023,.023,.04,P.ivory,M.marble,12);
    k.sphere(x,y,.965,.022,.022,.035,P.gold,M.metal,10,5);
  }
  // The drum, segmented teal dome and twelve fine gold meridian ribs.
  k.cyl(.5,.37,.94,.205,.175,.115,P.ivory,M.marble,24);
  for(let i=0;i<16;i++) {
    const a=i*Math.PI/8;
    k.at(.5,.37,0,a,()=>k.window(-.019,.174, .966,.038,.066,{arched:true,glass:P.glassDark,mullions:false}));
  }
  k.cyl(.5,.37,1.052,.214,.184,.028,P.gold,M.metal,32);
  k.dome(.5,.37,1.08,.205,.175,.345,TEAL,M.ceramic,32,10);
  for(let i=0;i<12;i++) {
    const a=i*Math.PI/6,pts=[];
    for(let j=0;j<=12;j++) {
      const t=j/12*Math.PI/2;
      pts.push([.5+Math.cos(a)*Math.cos(t)*.207,.37+Math.sin(a)*Math.cos(t)*.177,1.083+Math.sin(t)*.345]);
    }
    k.tube(pts,.0037,P.gold,M.metal,5);
  }
  k.cyl(.5,.37,1.42,.013,.013,.045,P.gold,M.metal,10);
  k.sphere(.5,.37,1.485,.019,.019,.027,P.gold,M.metal,12,6);
  // Four-column classical portico with a fully extruded triangular pediment.
  k.box(.19,.68,.065,.62,.16,.055,P.ivory,M.stone);
  for(const x of [.26,.42,.58,.74]) column(x,.785,.12,.665,.026);
  k.box(.17,.67,.785,.66,.17,.065,P.ivory,M.marble);
  for(let i=0;i<18;i++) k.box(.185+i*.036,.837,.775,.018,.025,.032,P.ivory,M.marble);
  k.xzShape([[.14,.85],[.86,.85],[.5,1.105]],.665,.195,P.ivory,M.marble);
  k.xzShape([[.20,.868],[.80,.868],[.5,1.065]],.863,.007,P.sand,M.marble);
  k.xzShape([[.235,.882],[.765,.882],[.5,1.037]],.872,.008,P.cream,M.marble);
  for(const y of [.66,.866]) {
    k.beam([.135,y,.851],[.5,y,1.112],.012,P.ivory,M.marble,6);
    k.beam([.5,y,1.112],[.865,y,.851],.012,P.ivory,M.marble,6);
    k.beam([.143,y,.853],[.857,y,.853],.012,P.ivory,M.marble,6);
  }
  k.disk(.5,.883,.938,.036,.036,P.ivory,M.marble,24);
  k.disk(.5,.886,.938,.023,.023,P.gold,M.metal,24);
  for(const x of [.36,.64]) k.sphere(x,.888,.917,.025,.008,.025,P.ivory,M.marble,10,6);
  k.door(.5,.722,.125,.12,.50,{arched:true,color:P.honey,frame:P.ivory,glass:true});
  for(const x of [.205,.72]) k.window(x,.724,.22,.075,.36,{glass:P.gold});
  for(const side of [1,3]) for(const y of [.22,.40,.58])
    k.wallWindow(side,side===1?.851:.149,y,.23,.083,.36,{glass:P.gold});
  for(const x of [.26,.42,.58,.74]) k.wallWindow(2,x,.118,.24,.08,.34,{glass:P.glassDark});
  k.steps(.5,.832,.095,.45,6,.024,.013);
  for(const x of [.19,.81]) {
    k.box(x-.033,.84,.042,.066,.067,.085,P.ivory,M.stone);
    k.topiary(x,.873,.75);
  }
  for(const x of [.105,.895]) for(const y of [.23,.47,.70]) k.shrub(x,y,.055,.028);
  // Slim classical statue on a plinth beside the entrance.
  k.box(.318,.884,.02,.054,.054,.07,P.ivory,M.marble);
  k.frustum(.345,.911,.09,.016,.016,.095,.011,.011,P.teal,M.metal,10);
  k.sphere(.345,.911,.204,.012,.012,.019,P.teal,M.metal,10,5);
  k.beam([.345,.911,.16],[.365,.914,.19],.006,P.teal,M.metal,6);
}

function castle(k) {
  k.grass();
  k.rounded(.075,.065,.016,.85,.83,.045,P.stone,M.stone,.04);
  const tower=(cx,cy,rear=false) => {
    const h=rear?1.14:1.02,z=.08,r=.106,top=z+h;
    k.cyl(cx,cy,z,.121,.121,.07,P.stone,M.stone,24);
    k.cyl(cx,cy,z+.07,.114,.114,.045,P.ivory,M.stone,24);
    k.cyl(cx,cy,z+.115,r,r,h-.115,P.cream,M.stone,24);
    for(let j=0;j<5;j++) k.cyl(cx,cy,.27+j*.145,r+.001,r+.001,.011,P.sand,M.stone,24);
    k.cyl(cx,cy,top-.075,.114,.114,.025,P.sand,M.stone,24);
    k.cyl(cx,cy,top-.05,.123,.123,.05,P.ivory,M.stone,24);
    for(let i=0;i<10;i++) {
      const a=i*Math.PI/5;
      k.at(cx,cy,top,a,()=>k.box(-.022,.088,0,.044,.04,.095,P.cream,M.stone));
      k.at(cx,cy,top-.13,a,()=>k.box(-.01,.105,0,.02,.018,.07,P.ivory,M.stone));
    }
    k.cone(cx,cy,top+.025,.087,.087,.38,ROOF_BLUE,M.slate,20);
    for(let j=1;j<6;j++) {
      const rr=.087*(1-j/6);
      k.cyl(cx,cy,top+.025+.38*j/6,rr+.001,rr+.001,.008,shade(ROOF_BLUE,1.15),M.slate,20);
    }
    k.sphere(cx,cy,top+.413,.010,.010,.018,P.gold,M.metal,8,4);
    k.flag(cx,cy,top+.425,.20,P.red);
    for(const a of [0,Math.PI/2,Math.PI,Math.PI*1.5])
      k.at(cx,cy,0,a,()=>k.window(-.023,r+.001,.51,.046,.23,{arched:true,glass:P.glassDark,mullions:false}));
    if(!rear) {
      k.xzShape([[cx-.024,.60],[cx+.024,.60],[cx+.024,.34],[cx,.30],[cx-.024,.34]],cy+r+.026,.008,P.red,M.redwood);
      k.cross(cx,cy+r+.038,.395,.065,P.gold);
    }
  };
  // Curtain walls and evenly spaced individual merlons make the silhouette.
  k.box(.21,.17,.10,.58,.075,.80,P.cream,M.stone);
  k.box(.17,.22,.10,.075,.54,.72,P.cream,M.stone);
  k.box(.755,.22,.10,.075,.54,.72,P.cream,M.stone);
  k.box(.22,.715,.10,.20,.075,.72,P.cream,M.stone);
  k.box(.58,.715,.10,.20,.075,.72,P.cream,M.stone);
  for(let j=0;j<4;j++) {
    k.box(.24,.166,.25+j*.14,.52,.007,.014,P.sand,M.stone);
    k.box(.166,.25,.23+j*.14,.007,.46,.014,P.sand,M.stone);
    k.box(.827,.25,.23+j*.14,.007,.46,.014,P.sand,M.stone);
  }
  for(let i=0;i<9;i++) {
    k.box(.23+i*.06,.165,.90,.033,.085,.09,P.ivory,M.stone);
    for(const x of [.165,.75]) k.box(x,.255+i*.051,.82,.085,.027,.085,P.ivory,M.stone);
  }
  for(const x of [.28,.34,.60,.66,.72]) k.box(x,.71,.82,.035,.085,.085,P.ivory,M.stone);
  // Central round keep rises above the four flanking towers.
  k.cyl(.5,.405,.11,.17,.155,1.70,P.cream,M.stone,28);
  for(const z of [.15,.50,.95,1.38,1.77]) k.cyl(.5,.405,z,.179,.164,.035,P.ivory,M.stone,28);
  for(let i=0;i<12;i++) k.at(.5,.405,1.805,i*Math.PI/6,()=>k.box(-.019,.132,0,.038,.034,.095,P.ivory,M.stone));
  k.cone(.5,.405,1.85,.159,.145,.48,ROOF_BLUE,M.slate,28);
  for(let j=1;j<8;j++) k.cyl(.5,.405,1.85+.48*j/8,.159*(1-j/8)+.001,.145*(1-j/8)+.001,.008,shade(ROOF_BLUE,1.15),M.slate,28);
  k.sphere(.5,.405,2.341,.012,.012,.022,P.gold,M.metal,10,5);
  k.flag(.5,.405,2.355,.22,P.red);
  for(const z of [.75,1.29]) for(const a of [0,Math.PI/2,Math.PI,Math.PI*1.5])
    k.at(.5,.405,0,a,()=>k.window(-.028,.157,z,.056,.27,{glass:P.glassDark,mullions:false}));
  k.xzShape([[.46,1.26],[.54,1.26],[.54,1.00],[.5,.955],[.46,1.00]],.574,.009,P.red,M.redwood);
  k.cross(.5,.587,1.05,.095,P.gold);
  for(const x of [.21,.79]) {tower(x,.21,true);tower(x,.755,false);}
  // Gatehouse, portcullis, and a sloped, plank-built drawbridge.
  k.box(.365,.70,.09,.27,.09,.69,P.cream,M.stone);
  k.arch(.385,.794,.09,.23,.58,P.ivory,M.stone,.018);
  k.arch(.408,.817,.09,.184,.535,'#503c2b',M.wood,.008);
  for(let i=0;i<7;i++) k.box(.423+i*.024,.83,.10,.008,.01,.36,P.dark,M.metal);
  for(const z of [.20,.33,.43]) k.box(.42,.834,z,.16,.01,.007,P.dark,M.metal);
  for(const x of [.36,.405,.45,.495,.54,.585,.63]) k.box(x,.70,.78,.027,.10,.08,P.ivory,M.stone);
  const front=.965,back=.831;
  for(let i=0;i<8;i++) {
    const ya=back+(front-back)*i/8,yb=back+(front-back)*(i+1)/8-.002;
    const za=.12-(ya-back)*.65,zb=.12-(yb-back)*.65;
    k.face([[.395,ya,za],[.605,ya,za],[.605,yb,zb],[.395,yb,zb]],i%2?P.honey:P.wood,M.wood);
  }
  for(const x of [.394,.606]) {
    k.beam([x,.831,.12],[x,.965,.033],.006,P.dark,M.metal,5);
    k.beam([x,.824,.38],[x,.96,.04],.003,P.dark,M.metal,5);
  }
  for(const x of [.17,.83])k.tree(x,.91,.42);
}

function shrine(k) {
  const {rail,lantern,tileRoof,lattice}=helpers(k);
  k.grass();
  k.path(.42,.65,.16,.33);
  k.box(.19,.08,.025,.62,.61,.075,P.stone,M.stone);
  for(const x of [.23,.77]) for(const y of [.14,.34,.60]) k.box(x-.025,y-.025,.10,.05,.05,.09,P.stone,M.stone);
  k.box(.18,.08,.16,.64,.61,.045,P.wood,M.wood);
  for(let i=0;i<18;i++) k.box(.186+i*.034,.085,.207,.027,.60,.008,P.honey,M.wood);
  k.box(.245,.135,.208,.51,.445,.47,REDWOOD,M.redwood);
  for(const x of [.26,.50,.74]) for(const y of [.15,.58]) {
    k.box(x-.014,y-.014,.20,.028,.028,.52,REDWOOD,M.redwood);
    k.box(x-.023,y-.023,.64,.046,.046,.035,P.gold,M.metal);
  }
  lattice(.37,.582,.24,.26,.35);
  lattice(.275,.582,.31,.068,.22);
  lattice(.657,.582,.31,.068,.22);
  for(const side of [1,3]) for(const y of [.25,.45]) k.at(side===1?.756:.244,y,0,side===1?-Math.PI/2:Math.PI/2,()=>lattice(-.055,0,.30,.11,.23));
  rail([.20,.10],[.20,.665],.215,.13,REDWOOD,11);
  rail([.80,.10],[.80,.665],.215,.13,REDWOOD,11);
  rail([.20,.66],[.39,.66],.215,.13,REDWOOD,4);
  rail([.61,.66],[.80,.66],.215,.13,REDWOOD,4);
  rail([.20,.10],[.80,.10],.215,.13,REDWOOD,12);
  for(let i=0;i<15;i++) {
    k.box(.235+i*.036,.105,.66,.015,.51,.022,P.honey,M.wood);
    k.box(.195,.15+i*.032,.66,.61,.015,.022,P.honey,M.wood);
  }
  tileRoof(.125,.055,.705,.75,.64,.30,TEAL,false);
  // Irimoya gable placed above the sweeping hip roof, unlike the pagoda.
  k.xzShape([[.315,.89],[.685,.89],[.5,1.20]],.17,.45,REDWOOD,M.redwood);
  k.face([[.285,.13,.91],[.5,.13,1.22],[.5,.645,1.22],[.285,.645,.91]],TEAL,M.ceramic);
  k.face([[.5,.13,1.22],[.715,.13,.91],[.715,.645,.91],[.5,.645,1.22]],shade(TEAL,.94),M.ceramic);
  for(let i=0;i<16;i++) {
    const yy=.14+i*.032;
    k.beam([.29,yy,.918],[.5,yy,1.226],.0035,shade(TEAL,1.16),M.ceramic,4);
    k.beam([.5,yy,1.226],[.71,yy,.918],.0035,shade(TEAL,1.16),M.ceramic,4);
  }
  k.beam([.5,.11,1.23],[.5,.66,1.23],.013,P.gold,M.metal,10);
  for(const y of [.11,.66]) k.sphere(.5,y,1.24,.021,.018,.028,P.gold,M.metal,10,5);
  k.beam([.315,.643,.90],[.5,.643,1.19],.008,P.gold,M.metal,6);
  k.beam([.5,.643,1.19],[.685,.643,.90],.008,P.gold,M.metal,6);
  k.cross(.5,.655,.99,.07,P.gold);
  k.steps(.5,.682,.176,.25,5,.024,.035);
  k.box(.418,.644,.24,.164,.07,.10,P.wood,M.wood);
  for(let i=0;i<7;i++) k.box(.422+i*.022,.645,.343,.013,.069,.008,P.honey,M.wood);
  // Freestanding vermilion torii leaves a clear entrance at the lot's front.
  for(const x of [.225,.775]) {
    k.cyl(x,.828,.025,.038,.038,.07,P.stone,M.stone,12);
    k.cyl(x,.828,.095,.026,.026,.13,P.dark,M.metal,12);
    k.cyl(x,.828,.225,.022,.022,.75,'#d83d2d',M.redwood,16);
    k.cyl(x,.828,.945,.027,.027,.027,P.gold,M.metal,12);
  }
  k.box(.165,.802,.795,.67,.052,.055,'#d83d2d',M.redwood);
  k.xzShape([[.12,.971],[.31,.94],[.69,.94],[.88,.971],[.88,1.025],[.69,.988],[.31,.988],[.12,1.025]],.793,.072,P.dark,M.wood);
  k.xzShape([[.14,.933],[.31,.909],[.69,.909],[.86,.933],[.86,.971],[.69,.947],[.31,.947],[.14,.971]],.80,.060,'#d83d2d',M.redwood);
  k.box(.471,.86,.835,.058,.015,.12,P.gold,M.metal);
  k.box(.48,.879,.849,.04,.006,.092,P.dark,M.wood);
  const rope=[];for(let i=0;i<=18;i++){const t=i/18;rope.push([.255+t*.49,.873,.777-.045*Math.sin(Math.PI*t)]);}
  k.tube(rope,.005,P.honey,M.wood,6);
  for(const x of [.32,.41,.59,.68]) {
    const z=.777-.045*Math.sin(Math.PI*(x-.255)/.49);
    k.xzShape([[x-.008,z],[x+.008,z-.013],[x,z-.029],[x+.012,z-.045],[x-.004,z-.061],[x-.014,z-.045],[x-.004,z-.028],[x-.014,z-.013]],.876,.003,P.white,M.stucco);
  }
  lantern(.092,.72,.95);lantern(.908,.72,.95);
  for(const x of [.096,.904]) {k.shrub(x,.21,.025,.045);k.shrub(x,.39,.025,.038);}
}

function temple(k) {
  const {rail,lantern,tileRoof,lattice}=helpers(k);
  k.grass();k.path(.42,.73,.16,.25);
  k.rounded(.17,.13,.02,.66,.66,.06,P.stone,M.stone,.015);
  const levels=[
    {x:.23,y:.20,a:.54,b:.48,z:.10,h:.42,rx:.095,ry:.09,ra:.81,rb:.72,rh:.19},
    {x:.30,y:.26,a:.40,b:.36,z:.69,h:.27,rx:.18,ry:.18,ra:.64,rb:.56,rh:.175},
    {x:.355,y:.31,a:.29,b:.26,z:1.105,h:.23,rx:.255,ry:.245,ra:.49,rb:.43,rh:.17}
  ];
  for(let n=0;n<levels.length;n++) {
    const l=levels[n],roofZ=l.z+l.h;
    k.box(l.x-.047,l.y-.035,l.z,l.a+.094,l.b+.07,.035,P.wood,M.wood);
    k.box(l.x,l.y,l.z+.035,l.a,l.b,l.h-.04,P.honey,M.wood);
    for(let i=0;i<8;i++) {
      k.box(l.x+l.a*i/8,l.y-.003,l.z+.04,.007,l.b+.006,l.h-.05,P.wood,M.wood);
      k.box(l.x-.003,l.y+l.b*i/8,l.z+.04,l.a+.006,.007,l.h-.05,P.wood,M.wood);
    }
    for(const xx of [l.x,l.x+l.a]) for(const yy of [l.y,l.y+l.b]) {
      k.box(xx-.013,yy-.013,l.z,.026,.026,l.h,P.wood,M.wood);
      k.box(xx-.022,yy-.022,roofZ-.065,.044,.044,.022,P.gold,M.metal);
    }
    const wa=n===0?.13:.10,wh=n===0?.27:.14;
    for(const x of [l.x+l.a*.25-wa/2,l.x+l.a*.75-wa/2]) lattice(x,l.y+l.b+.004,l.z+.065,wa,wh);
    for(const side of [1,3]) k.at(side===1?l.x+l.a+.004:l.x-.004,l.y+l.b/2,0,side===1?-Math.PI/2:Math.PI/2,()=>lattice(-wa/2,0,l.z+.065,wa,wh));
    const xa=l.x-.035,xb=l.x+l.a+.035,ya=l.y-.022,yb=l.y+l.b+.022;
    rail([xa,ya],[xb,ya],l.z+.035,.115,P.wood,9);
    rail([xa,ya],[xa,yb],l.z+.035,.115,P.wood,7);
    rail([xb,ya],[xb,yb],l.z+.035,.115,P.wood,7);
    if(n===0){rail([xa,yb],[.40,yb],l.z+.035,.115,P.wood,4);rail([.60,yb],[xb,yb],l.z+.035,.115,P.wood,4);}
    else rail([xa,yb],[xb,yb],l.z+.035,.115,P.wood,9);
    for(let i=0;i<13;i++) {
      const xx=l.rx+.035+i*(l.ra-.07)/12;
      k.box(xx-.005,l.ry+.045,roofZ-.031,.01,l.rb-.09,.019,P.honey,M.wood);
    }
    tileRoof(l.rx,l.ry,roofZ,l.ra,l.rb,l.rh,TEAL,true);
  }
  // The central sacred spire has individual diminishing gold discs.
  k.cyl(.5,.46,1.51,.009,.009,.285,P.gold,M.metal,12);
  for(let i=0;i<7;i++) k.frustum(.5,.46,1.53+i*.031,.034-i*.0035,.034-i*.0035,.012,.026-i*.0025,.026-i*.0025,P.gold,M.metal,16);
  k.sphere(.5,.46,1.82,.012,.012,.023,P.gold,M.metal,10,6);
  k.steps(.5,.714,.09,.25,4,.029,.02);
  for(const x of [.38,.62]) {
    k.beam([x,.70,.22],[x,.82,.09],.008,P.gold,M.metal,6);
    k.box(x-.005,.79,.03,.01,.01,.09,P.wood,M.wood);
  }
  lantern(.105,.83,.86);lantern(.895,.83,.86);
  for(const x of [.075,.925]) {k.shrub(x,.36,.025,.042);k.shrub(x,.55,.025,.035);}
  for(const x of [.27,.73]) k.shrub(x,.84,.025,.04);
}

function church(k) {
  const {gothic}=helpers(k);
  k.grass();
  k.rounded(.14,.11,.018,.73,.77,.035,P.stone,M.paving,.018);
  k.box(.35,.18,.055,.43,.59,.67,P.cream,M.stone);
  k.box(.33,.16,.055,.47,.63,.065,P.ivory,M.stone);
  k.cornice(.35,.18,.70,.43,.59,P.ivory);
  k.roof(.315,.14,.78,.50,.67,.345,ROOF_BLUE,M.slate);
  // The roof is broken into overlapping slate courses, with stone gable trim.
  for(let i=1;i<9;i++) {
    const t=i/9,z=.78+.345*t,x1=.315+.25*t,x2=.815-.25*t;
    k.beam([x1,.142,z+.003],[x1,.806,z+.003],.0035,shade(ROOF_BLUE,1.13),M.slate,4);
    k.beam([x2,.142,z+.003],[x2,.806,z+.003],.0035,shade(ROOF_BLUE,1.13),M.slate,4);
  }
  k.beam([.565,.13,1.13],[.565,.82,1.13],.009,P.ivory,M.stone,8);
  for(const y of [.137,.813]) {
    k.beam([.313,y,.775],[.565,y,1.133],.012,P.ivory,M.stone,6);
    k.beam([.565,y,1.133],[.817,y,.775],.012,P.ivory,M.stone,6);
  }
  // Front porch gable and inset timber double doors.
  k.box(.445,.77,.055,.24,.09,.43,P.ivory,M.stone);
  k.roof(.425,.752,.485,.28,.135,.20,ROOF_BLUE,M.slate);
  k.door(.565,.864,.075,.15,.35,{arched:true,color:P.honey,frame:P.ivory});
  for(const x of [.53,.60]) for(const z of [.16,.23,.30]) k.sphere(x,.931,z,.0035,.003,.0035,P.gold,M.metal,6,3);
  k.steps(.565,.875,.06,.29,3,.027,.018);
  // Circular rose window: colored radial glass surrounded by stone tracery.
  k.disk(.565,.803,.845,.077,.096,P.ivory,M.stone,32);
  k.disk(.565,.807,.845,.061,.079,P.gold,M.metal,32);
  for(let i=0;i<10;i++) {
    const a=i/10*Math.PI*2,b=(i+1)/10*Math.PI*2,c=[P.red,P.teal,P.blue,P.gold,P.lilac][i%5];
    k.face([[.565,.81,.845],[.565+Math.cos(a)*.054,.81,.845+Math.sin(a)*.071],[.565+Math.cos(b)*.054,.81,.845+Math.sin(b)*.071]],c,M.glass);
    k.beam([.565,.813,.845],[.565+Math.cos(a)*.057,.813,.845+Math.sin(a)*.074],.0025,P.ivory,M.stone,4);
  }
  k.disk(.565,.817,.845,.015,.019,P.gold,M.metal,16);
  for(const y of [.29,.48,.67]) k.at(.782,y,0,-Math.PI/2,()=>gothic(-.041,0,.20,.082,.40));
  for(const y of [.28,.45]) k.at(.348,y,0,Math.PI/2,()=>gothic(-.041,0,.20,.082,.40));
  for(const x of [.45,.66]) k.at(x,.178,0,Math.PI,()=>gothic(-.041,0,.23,.082,.39));
  // Stepped buttresses and masonry corner quoins around the nave.
  for(const y of [.19,.385,.58,.77]) {
    k.box(.78,y-.019,.055,.047,.038,.51,P.ivory,M.stone);
    k.box(.78,y-.025,.055,.067,.05,.08,P.stone,M.stone);
    k.face([[.78,y-.02,.63],[.827,y-.02,.565],[.827,y+.02,.565],[.78,y+.02,.63]],P.ivory,M.stone);
    k.cone(.798,y,.65,.016,.016,.08,P.ivory,M.stone,4);
  }
  for(const x of [.35,.78]) for(const y of [.18,.77]) k.quoin(x,y,.13,.57);
  // Offset bell tower with open Gothic belfry and a slender blue steeple.
  k.box(.17,.535,.055,.23,.25,1.16,P.cream,M.stone);
  for(const z of [.07,.45,.83,1.185]) k.box(.156,.521,z,.258,.278,.035,P.ivory,M.stone);
  for(const x of [.17,.40]) for(const y of [.535,.785]) k.quoin(x,y,.13,1.02);
  gothic(.237,.787,.91,.096,.235,false);
  k.at(.403,.66,0,-Math.PI/2,()=>gothic(-.048,0,.91,.096,.235,false));
  k.at(.167,.66,0,Math.PI/2,()=>gothic(-.048,0,.91,.096,.235,false));
  k.at(.285,.532,0,Math.PI,()=>gothic(-.048,0,.91,.096,.235,false));
  gothic(.242,.787,.55,.086,.22,true);
  const cx=.285,cy=.66,z=1.225,apex=1.68;
  const corners=[[.143,.507],[.427,.507],[.427,.813],[.143,.813]];
  for(let i=0;i<4;i++) {
    const p=corners[i],q=corners[(i+1)%4];
    k.face([[p[0],p[1],z],[q[0],q[1],z],[cx,cy,apex]],shade(ROOF_BLUE,1+i*.025),M.slate);
    k.beam([p[0],p[1],z],[cx,cy,apex],.006,P.gold,M.metal,6);
    for(let j=1;j<8;j++) {
      const t=j/8;
      k.beam([p[0]+(cx-p[0])*t,p[1]+(cy-p[1])*t,z+(apex-z)*t],
        [q[0]+(cx-q[0])*t,q[1]+(cy-q[1])*t,z+(apex-z)*t],.0025,shade(ROOF_BLUE,1.2),M.slate,4);
    }
  }
  k.sphere(cx,cy,1.694,.014,.014,.022,P.gold,M.metal,12,6);
  k.cross(cx,cy-.014,1.706,.18,P.gold);
  for(const [x,y] of corners) {
    k.cyl(x,y,1.19,.011,.011,.07,P.ivory,M.stone,8);
    k.cone(x,y,1.26,.014,.014,.065,P.ivory,M.stone,8);
  }
  for(const x of [.12,.82]) for(const y of [.30,.50,.73]) k.topiary(x,y,.68);
  for(const x of [.19,.78]) {
    k.shrub(x,.875,.035,.043);
    for(let i=0;i<6;i++) {const a=i*Math.PI/3;k.sphere(x+Math.cos(a)*.029,.875+Math.sin(a)*.029,.11,.008,.008,.009,P.white,M.leaf,6,3);}
  }
}

/** Add one fully modelled landmark. Return false for another vocabulary type. */
export function buildLandmarks(type,k,w,d) {
  const build={museum,castle,shrine,temple,church}[type];
  if(!build) return false;
  const start=k.faces.length;
  build(k);
  // A few shared architectural helpers intentionally leave trim material open.
  // Landmark trim is carved stone, so every exported polygon has an explicit ID.
  for(let i=start;i<k.faces.length;i++) if(k.faces[i].material==null) k.faces[i].material=M.stone;
  return true;
}
