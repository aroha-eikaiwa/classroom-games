import {WIDTH,HEIGHT,xy} from './core.mjs';
import * as THREE from './vendor/three.module.js';
const geometry=new THREE.PlaneGeometry(1,1).rotateX(-Math.PI/2),material=new THREE.MeshStandardMaterial({color:'#b7b6ad',roughness:.95,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});
let pending;
export function loadPavementTexture(){return Promise.resolve(false);}
export function createPavementSurface(){
 const mesh=new THREE.InstancedMesh(geometry,material,WIDTH*HEIGHT),matrix=new THREE.Matrix4();mesh.count=0;mesh.receiveShadow=true;mesh.frustumCulled=false;let signature='';
 return {mesh,update(t){const keys=t.pavement||[],next=keys.join(',');if(next===signature)return;signature=next;mesh.count=keys.length;keys.forEach((k,i)=>{const p=xy(k);matrix.makeTranslation(p.x+.5,.038,p.y+.5);mesh.setMatrixAt(i,matrix);});mesh.instanceMatrix.needsUpdate=true;}};
}
