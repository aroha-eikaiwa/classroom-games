// One reusable audio graph per screen; no oscillators or DOM nodes per frame.
export function createPoliceFeedback({document,getContext,isMuted,isEnglish=()=>false}){
 const element=document.createElement('div');element.className='police-feedback';element.hidden=true;element.setAttribute('role','status');element.setAttribute('aria-live','polite');document.body.append(element);
 let audio=null,key='';
 function update(police={},enabled=false,time=0,town){
  const chasing=enabled&&police.phase==='chasing',caught=enabled&&police.hold>0,english=isEnglish(),type=town?.buildings.find(b=>b.id===police.restartBuilding)?.type;
  const next=[chasing,caught,english,police.offence,type].join(':');
  if(next!==key){key=next;element.hidden=!chasing&&!caught;element.dataset.phase=caught?'caught':'chasing';element.lang=english?'en':'ja';
   const reason=police.offence==='red-light'?(english?'A police car saw you run a red light.':'信号無視を見られた！'):police.offence==='railway-crossing'?(english?'A police car saw you cross a closed railway crossing.':'踏切に入ったところを見られた！'):(english?'A police car saw the collision.':'ぶつかったところを見られた！');
   element.textContent=caught?(english?'Caught! Restart from the '+(type==='prison'?'prison':type==='police-station'?'police station':'start')+'.':'つかまった！'+(type==='prison'?'刑務所':type==='police-station'?'警察署':'スタート地点')+'からもう一度出発しよう。'):reason+(english?' Police pursuit! Pull over safely.':'警察が追いかけてきたよ。安全に止まろう。');
  }
  try{
   const context=getContext();if(chasing&&!isMuted()&&context&&!audio){const oscillator=context.createOscillator(),gain=context.createGain();oscillator.type='triangle';gain.gain.value=0;oscillator.connect(gain);gain.connect(context.destination);oscillator.start();audio={oscillator,gain,context};}
   if(audio){const now=audio.context.currentTime;audio.gain.gain.setTargetAtTime(chasing&&!isMuted()&&audio.context.state==='running'?.025:0,now,.05);if(chasing)audio.oscillator.frequency.setTargetAtTime(700+350*Math.sin(time*6),now,.035);}
  }catch{}
 }
 return {element,update};
}
