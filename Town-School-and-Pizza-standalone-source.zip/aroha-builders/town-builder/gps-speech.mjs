// A single replaceable English instruction prevents queued GPS directions from
// being read after the car has already reached another junction.
export function createGpsSpeech({scope=globalThis,isMuted=()=>false,onState=()=>{}}={}){
 const synthesis=()=>scope.speechSynthesis||scope.window?.speechSynthesis;
 const Utterance=()=>scope.SpeechSynthesisUtterance||scope.window?.SpeechSynthesisUtterance;
 let generation=0;
 function cancel(){generation++;try{synthesis()?.cancel();}catch{}}
 function available(){return !!synthesis()&&typeof Utterance()==='function';}
 function speak(text){
  cancel();if(!text)return false;
  if(isMuted()){onState('muted');return false;}
  if(!available()){onState('unavailable');return false;}
  try{
   const synth=synthesis(),u=new (Utterance())(text),voices=synth.getVoices?.()||[],id=generation;
   u.voice=voices.find(v=>/^en-(NZ|GB|AU)/i.test(v.lang))||voices.find(v=>/^en(?:-|$)/i.test(v.lang))||null;
   u.lang=u.voice?.lang||'en-GB';u.rate=.83;u.pitch=1;u.volume=.95;
   u.onstart=()=>{if(id===generation)onState('speaking');};
   u.onend=()=>{if(id===generation)onState('ready');};
   u.onerror=()=>{if(id===generation)onState('error');};
   synth.speak(u);onState('speaking');return true;
  }catch{onState('error');return false;}
 }
 return {speak,cancel,available};
}
