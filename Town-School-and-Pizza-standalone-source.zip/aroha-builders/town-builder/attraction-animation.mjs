import {createMallParkedCar} from './mall-parking.mjs';
import {createLandscapeTree} from './landscape-trees.mjs';
import {createFountain} from './fountain-model.mjs';
import {createGiraffe} from './giraffe-model.mjs';
import {createEmergencyVehicle} from './emergency-models.mjs';
import {createElephant} from './elephant-model.mjs';
import * as THREE from './vendor/three.module.js';
export function attachAttractionAnimation(group,b,parts,baseMaterial,variant='normal'){
 const animated=[];
 for(const part of parts){
  const {animation:a,geometry,origin,w,d,height}=part,glowing=['fountain','stadium-light','arcade-light'].includes(a.kind);
  const imported=a.kind==='parked-passenger'?createMallParkedCar(a,variant):a.kind==='landscape-tree'?createLandscapeTree(b,part,variant):a.kind==='fountain'?createFountain(.34*a.scale*w,variant):a.kind==='parked-vehicle'?createEmergencyVehicle(a.vehicle,a.length,variant):a.species==='giraffe'?createGiraffe(a.scale,variant):a.species==='elephant'?createElephant(a.scale,variant):null;
  const mat=imported?null:glowing?new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.DoubleSide,transparent:a.kind==='fountain',opacity:a.kind==='fountain'?.8:1}):baseMaterial;
  const mesh=imported?new THREE.Group():new THREE.Mesh(geometry,mat);if(imported){mesh.add(imported);if(a.kind==='parked-passenger')mesh.userData.parkedPassenger=true;else if(a.kind==='landscape-tree')mesh.userData.importedLandscapeTree=true;else if(a.kind==='parked-vehicle'){mesh.userData.importedVehicle=true;imported.rotation.y=Math.PI;}else if(a.kind==='fountain')mesh.userData.importedFountain=true;else mesh.userData.importedAnimal=true;mesh.userData.animate=t=>imported.userData.animate?.(t+(a.phase||0));}mesh.position.fromArray(origin);mesh.userData.sharedGeometry=true;mesh.userData.shadowCaster=false;mesh.userData.animated=true;group.add(mesh);animated.push({mesh,a,origin,w,d,height});
  if(a.kind==='fountain'&&!imported){
   const drops=new THREE.InstancedMesh(new THREE.SphereGeometry(.009,6,4),new THREE.MeshBasicMaterial({color:'#c8f8ff',transparent:true,opacity:.85}),24);
   drops.position.fromArray(origin);drops.userData.shadowCaster=false;group.add(drops);animated.push({drops,a,w,d,height});
  }
  if(a.kind==='stadium-light'){
   const target=new THREE.Vector3(0,.05,0),start=new THREE.Vector3(...origin),delta=start.clone().sub(target),beam=new THREE.Mesh(new THREE.ConeGeometry(.45,delta.length(),16,1,true),new THREE.MeshBasicMaterial({color:'#fff5bc',transparent:true,opacity:.055,depthWrite:false,side:THREE.DoubleSide}));
   beam.position.copy(start).add(target).multiplyScalar(.5);beam.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());beam.userData.shadowCaster=false;group.add(beam);
   const pool=new THREE.Mesh(new THREE.CircleGeometry(.7,24),new THREE.MeshBasicMaterial({color:'#ffffbe',transparent:true,opacity:.13,depthWrite:false}));pool.rotation.x=-Math.PI/2;pool.position.set(origin[0]*.25,.07,origin[2]*.25);pool.userData.shadowCaster=false;group.add(pool);
  }
 }
 if(parts.some(p=>p.animation.kind==='stadium-light')){const flood=new THREE.PointLight('#fff1c2',5,5,2);flood.position.set(0,1.65,0);group.add(flood);}
 const matrix=new THREE.Matrix4(),forward=new THREE.Vector3(),up=new THREE.Vector3(),side=new THREE.Vector3(),worldUp=new THREE.Vector3(0,1,0);
 group.userData.animate=t=>{
  for(const p of animated){const {mesh,a,origin,drops}=p;
   if(drops){for(let i=0;i<24;i++){const u=(t*.72+i/24)%1,angle=i%6*Math.PI/3,r=(.04+.065*u)*a.scale;matrix.makeTranslation(Math.cos(angle)*r*p.w,(.31*a.scale+.06+.09*a.scale*Math.sin(u*Math.PI)-.22*a.scale*u-.075)*p.height,Math.sin(angle)*r*p.d);drops.setMatrixAt(i,matrix);}drops.instanceMatrix.needsUpdate=true;continue;}
   if(a.kind==='coaster'){
    const angle=a.angle+t*.6,c=Math.cos(angle),s=Math.sin(angle);
    mesh.position.set((.745+.17*c-.5)*p.w,(.31+.16*Math.sin(2*angle)+.08*c)*p.height,(.32+.205*s-.5)*p.d);
    forward.set(-.17*s*p.w,(.32*Math.cos(2*angle)-.08*s)*p.height,.205*c*p.d).normalize();
    side.crossVectors(forward,worldUp).normalize();up.crossVectors(side,forward).normalize();
    matrix.makeBasis(forward,up,side);mesh.quaternion.setFromRotationMatrix(matrix);
   }
   if(a.kind==='wheel')mesh.rotation.z=t*.22;
   if(a.kind==='gondola'){const angle=a.angle+t*.22;mesh.position.set(origin[0]+a.radius*(Math.cos(angle)-Math.cos(a.angle)),origin[1]+a.radius*(Math.sin(angle)-Math.sin(a.angle)),origin[2]);}
   if(a.kind==='carousel')mesh.rotation.y=t*.42;
   mesh.userData.animate?.(t);
   if(a.kind==='animal'){const phase=t*(a.speed||1)+a.phase;mesh.rotation.y=Math.sin(phase)*.12;mesh.rotation.z=Math.sin(phase*1.5)*.018;mesh.position.y=origin[1]+Math.sin(phase*2)*.006;}
   if(a.kind==='fountain'&&!mesh.userData.importedFountain){mesh.scale.y=1+Math.sin(t*2.5)*.035;mesh.material.opacity=.68+Math.sin(t*3)*.12;}
   // Alternating marquee chase: distinct lit and dim phases.
   if(a.kind==='arcade-light'){const brightness=Math.sin(t*Math.PI*2+a.phase)>0?1:.12;mesh.material.color.setRGB(brightness,brightness,brightness);}
  }
 };
 group.userData.animationParts=animated;
}
export function createDestinationArrow(){
 const arrow=new THREE.Group(),mat=new THREE.MeshBasicMaterial({color:'#ffcd32',depthTest:false,depthWrite:false}),head=new THREE.Mesh(new THREE.ConeGeometry(.24,.43,5),mat),shaft=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.52,12),mat);head.rotation.z=Math.PI;head.position.y=-.22;shaft.position.y=.22;arrow.add(head,shaft);arrow.traverse(o=>o.renderOrder=30);arrow.visible=false;return arrow;
}
