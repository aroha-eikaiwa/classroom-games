// Feedback stays separate from English instruction speech. Never read the
// Japanese warning or an English wrong-way/U-turn phrase to the class.
export const TURN_AROUND_JA='安全を確認してから、引き返してね。';
export const RECALCULATING_JA='ルートを再計算中…';
export function createGpsFeedback({element,speech,buzz,setTimer=setTimeout,clearTimer=clearTimeout}){
 let voiceTimer=null,hideTimer=null,pending='',warning=false;
 const clearTimers=()=>{if(voiceTimer!==null)clearTimer(voiceTimer);if(hideTimer!==null)clearTimer(hideTimer);voiceTimer=hideTimer=null;pending='';};
 function show(kind,text){element.hidden=false;element.dataset.kind=kind;element.querySelector('p').textContent=text;element.querySelector('img').hidden=kind!=='blocked';}
 function reset(){clearTimers();warning=false;element.hidden=true;}
 function apply(state){
  if(!state)return;
  if(state.turnAround){clearTimers();if(!warning||state.warning)speech.cancel();warning=true;show('blocked',TURN_AROUND_JA);if(state.warning)buzz();return;}
  if(warning){warning=false;element.hidden=true;}
  if(state.rerouted){
   clearTimers();speech.cancel();show('rerouting',RECALCULATING_JA);pending=state.spoken;
   voiceTimer=setTimer(()=>{voiceTimer=null;const text=pending;pending='';speech.speak(text);},650);
   hideTimer=setTimer(()=>{hideTimer=null;element.hidden=true;},2200);
  }else if(state.spoken){if(voiceTimer!==null)pending=state.spoken;else speech.speak(state.spoken);}
 }
 return {apply,reset};
}
