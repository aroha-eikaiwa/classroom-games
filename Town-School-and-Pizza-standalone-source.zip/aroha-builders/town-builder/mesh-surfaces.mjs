// Procedural parts sometimes share an exact face (including opposite windings
// at a joint). Resolve it once in the shared model cache, keeping the last
// authored surface. Nearby surfaces and independently animated parts stay intact.
export function uniqueStaticFaces(faces){
 const out=[],indices=new Map();
 for(const face of faces){
  if(face.animation){out.push(face);continue;}
  const points=face.points.map(p=>p.map(n=>Math.round(n*1e8)).join(','));
  let canonical=null,smallest=points[0];for(const point of points)if(point<smallest)smallest=point;
  for(let i=0;i<points.length;i++){
   if(points[i]!==smallest)continue;
   const forward=points.slice(i).concat(points.slice(0,i)).join('|');
   const reverse=[points[i],...points.slice(0,i).reverse(),...points.slice(i+1).reverse()].join('|');
   if(canonical===null||forward<canonical)canonical=forward;
   if(reverse<canonical)canonical=reverse;
  }
  const index=indices.get(canonical);
  if(index!==undefined)out[index]=face;else{indices.set(canonical,out.length);out.push(face);}
 }
 return out;
}
