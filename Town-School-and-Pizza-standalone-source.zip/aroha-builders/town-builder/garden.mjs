import {transportGroundCells} from './ground-clearance.mjs';
import {WIDTH,HEIGHT,key,inside,cells,roadLine} from './core.mjs';

// Flower beds are saved as ground-cell keys, just like rivers. Geometry and
// textures belong to the renderer; collision rules are shared with editing.
function occupiedCells(t){
 const occupied=new Set([...transportGroundCells(t),...(t.rivers||[]),...(t.pavement||[])]);
 for(const b of t.buildings||[])for(const k of cells(b))occupied.add(k);
 return occupied;
}
export function flowerBrushCells(x,y,width=1){
 if(!Number.isInteger(x)||!Number.isInteger(y))return [];
 const size=Math.max(1,Math.min(7,Math.floor(Number(width)||1))),offset=Math.floor((size-1)/2),out=[];
 for(let yy=y-offset;yy<y-offset+size;yy++)for(let xx=x-offset;xx<x-offset+size;xx++)if(inside(xx,yy))out.push(key(xx,yy));
 return out;
}
export function isFlowerCellFree(t,x,y){return inside(x,y)&&!occupiedCells(t).has(key(x,y));}
export function drawFlowers(t,x,y,width=1){
 const occupied=occupiedCells(t),flowers=new Set(t.flowers||[]);let changed=false;
 for(const k of flowerBrushCells(x,y,width))if(!occupied.has(k)&&!flowers.has(k)){flowers.add(k);changed=true;}
 if(changed)t.flowers=[...flowers];
 return changed;
}
export function eraseFlowers(t,x,y,width=1){
 const erased=new Set(flowerBrushCells(x,y,width)),old=t.flowers||[],next=old.filter(k=>!erased.has(k));
 if(next.length===old.length)return false;
 t.flowers=next;return true;
}
export function paintFlowerStroke(t,from,to,width=1){
 const occupied=occupiedCells(t),flowers=new Set(t.flowers||[]);let changed=false;
 // Clamp the stroke before interpolation so dragging far beyond the map has
 // bounded work and still paints all intervening ground up to the edge.
 const clamp=p=>({x:Math.max(0,Math.min(WIDTH-1,Math.floor(p.x))),y:Math.max(0,Math.min(HEIGHT-1,Math.floor(p.y)))});
 if(![from?.x,from?.y,to?.x,to?.y].every(Number.isFinite))return false;
 for(const p of roadLine(clamp(from),clamp(to)))for(const k of flowerBrushCells(p.x,p.y,width))if(!occupied.has(k)&&!flowers.has(k)){flowers.add(k);changed=true;}
 if(changed)t.flowers=[...flowers];
 return changed;
}
export function pruneFlowers(t){
 const occupied=occupiedCells(t),old=t.flowers||[],next=[...new Set(old)].filter(k=>Number.isInteger(k)&&k>=0&&k<WIDTH*HEIGHT&&!occupied.has(k));
 if(next.length===old.length)return false;
 t.flowers=next;return true;
}
