// Small model-derived thumbnails keep the picker responsive without creating
// another WebGL context or downloading full car meshes. The right half of
// each atlas marks only body-paint pixels; glass, tyres and lamps are untouched.
const prepared=new Map();
const linear=value=>value<=.04045?value/12.92:((value+.055)/1.055)**2.4;
const srgb=value=>value<=.0031308?12.92*value:1.055*value**(1/2.4)-.055;
const tone=value=>Math.min(1,Math.max(0,(value*(2.51*value+.03))/(value*(2.43*value+.59)+.14)));
function untone(value){const a=2.43*value-2.51,b=.59*value-.03;return (-b-Math.sqrt(b*b-4*a*.14*value))/(2*a);}
export function recolourVehiclePixels(base,mask,color){
 const target=[1,3,5].map(i=>linear(parseInt(color.slice(i,i+2),16)/255)),out=new Uint8ClampedArray(base);
 const channels=target.map(component=>Float32Array.from({length:256},(_,value)=>srgb(tone(untone(linear(value/255))*component))*255));
 for(let i=0;i<base.length;i+=4){const coverage=mask[i]/255;if(!coverage||!base[i+3])continue;for(let c=0;c<3;c++){const value=channels[c][base[i+c]];out[i+c]=base[i+c]+(value-base[i+c])*coverage;}}
 return out;
}
function loadPreview(model,doc){return Promise.reject(Error("Using offline artwork"));}
export function createVehiclePreview(picture,doc){
 // Non-canvas environments retain the ordinary accessible thumbnail.
 const supported=!!(doc.defaultView?.CanvasRenderingContext2D||globalThis.CanvasRenderingContext2D);
 let requested=0,currentModel,ready,canvas,context;
 if(supported){try{canvas=doc.createElement('canvas');canvas.width=240;canvas.height=240;context=canvas.getContext('2d');}catch{context=null;}}
 const draw=(data,color)=>{const pixels=context.createImageData(data.width,data.height);pixels.data.set(recolourVehiclePixels(data.base,data.mask,color));context.putImageData(pixels,0,0);picture.src=canvas.toDataURL('image/png');picture.style.visibility='';picture.setAttribute('aria-busy','false');picture.dataset.previewColor=color;};
 return {update(model,color){
  const request=++requested;picture.alt=model.en;
  if(!context){picture.src=model.image;return;}
  if(currentModel===model.id&&ready){draw(ready,color);return;}
  currentModel=model.id;ready=null;picture.style.visibility='hidden';picture.setAttribute('aria-busy','true');
  loadPreview(model,doc).then(data=>{if(request!==requested)return;ready=data;draw(data,color);}).catch(()=>{if(request!==requested)return;picture.src=model.image;picture.style.visibility='';picture.setAttribute('aria-busy','false');});
 }};
}
