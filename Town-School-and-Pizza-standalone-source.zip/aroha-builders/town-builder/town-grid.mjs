// One source of truth for rendering, graph keys and the saved-town coordinate grid.
export const WIDTH=60,HEIGHT=48;
export const LEGACY_WIDTH=40,LEGACY_HEIGHT=32;
export function sourceGrid(raw){
 const width=raw.width??(raw.v<5?LEGACY_WIDTH:null),height=raw.height??(raw.v<5?LEGACY_HEIGHT:null);
 if((width===WIDTH&&height===HEIGHT)||(raw.v<5&&width===LEGACY_WIDTH&&height===LEGACY_HEIGHT))return {width,height};
 throw Error('Invalid town grid. Please refresh the game before opening this town.');
}
export function expandTownGrid(raw){
 const {width,height}=sourceGrid(raw);if(width===WIDTH)return raw;
 const cell=k=>{if(!Number.isInteger(k)||k<0||k>=width*height)throw Error('Invalid map data.');return Math.floor(k/width)*WIDTH+k%width;};
 const cells=values=>Array.isArray(values)?values.map(cell):values;
 const edges=values=>Array.isArray(values)?values.map(pair=>Array.isArray(pair)?pair.map(cell):pair):values;
 // Coordinates of buildings and the start flag are already explicit x/y and
 // stay put. Only flattened cells and edge endpoints need a different stride.
 return {...raw,width:WIDTH,height:HEIGHT,roads:cells(raw.roads),rivers:cells(raw.rivers),rails:cells(raw.rails),flowers:cells(raw.flowers),pavement:cells(raw.pavement),roadEdges:edges(raw.roadEdges),railEdges:edges(raw.railEdges)};
}
