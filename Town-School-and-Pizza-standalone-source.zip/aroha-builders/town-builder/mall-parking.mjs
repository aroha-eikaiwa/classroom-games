import {createPassengerCar} from './passenger-models.mjs';
export const MALL_PARKED_CARS=Object.freeze([{x:.12,model:'car-compact',color:'#dc302b'},{x:.22,model:'car-sedan',color:'#347ebc'},{x:.42,model:'car-suv',color:'#f0eee5'},{x:.58,model:'car-compact',color:'#efbf44'},{x:.78,model:'car-sedan',color:'#abb4ba'},{x:.88,model:'car-suv',color:'#65a773'}]);
export const MALL_CAR_MODELS=Object.freeze([...new Set(MALL_PARKED_CARS.map(c=>c.model))]);
export function createMallParkedCar(spec,variant){
 const car=createPassengerCar(spec.model,spec.color);if(!car)return null;car.scale.setScalar(spec.length/.9);car.userData.parkedPassenger=true;
 if(variant.startsWith('ghost')){const materials=new Map();car.traverse(m=>{if(!m.isMesh)return;if(!materials.has(m.material)){const clone=m.material.clone();clone.userData.shared=false;clone.transparent=true;clone.opacity=.66;clone.depthWrite=false;if(variant==='ghost-invalid')clone.color.set('#ef7575');materials.set(m.material,clone);}m.material=materials.get(m.material);});}return car;
}
