export const natureRevision=()=>0,natureTreeRevision=()=>0,loadNatureModel=async()=>false,loadNatureModels=async()=>false,createNatureTree=()=>null;
