import * as THREE from './vendor/three.module.js';
import {xy} from './core.mjs';
import {bridgeObjects} from './terrain.mjs';
const pickMaterial=new THREE.MeshBasicMaterial({side:THREE.DoubleSide});
pickMaterial.userData.shared=true;
// CPU-only hit meshes retain the visible deck/rail shapes after render batching.
// They add no draw calls and are rebuilt only when transport fixtures change.
export function createBridgePickers(fixtures,analysis){
 const group=new THREE.Group(),v=new THREE.Vector3();fixtures.updateMatrixWorld(true);
 for(const bridge of fixtures.children.filter(g=>g.userData.bridge)){
  const positions=[];bridge.traverse(mesh=>{
   if(!mesh.isMesh)return;const g=mesh.geometry,p=g.attributes.position,index=g.index;
   for(let i=0;i<(index?index.count:p.count);i++){v.fromBufferAttribute(p,index?index.getX(i):i).applyMatrix4(mesh.matrixWorld);positions.push(v.x,v.y,v.z);}
  });
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.computeBoundingBox();geometry.computeBoundingSphere();
  const mesh=new THREE.Mesh(geometry,pickMaterial);mesh.userData.bridge=analysis.bridges.find(b=>b.id===bridge.userData.bridge);group.add(mesh);
 }
 group.updateMatrixWorld(true);return group;
}
export function disposeBridgePickers(group){for(const mesh of group?.children||[])mesh.geometry.dispose();}
export function bridgeEraseTarget(bridge,x,y){
 const nearest=bridge.waterCells.map(k=>({k,...xy(k)})).sort((a,b)=>Math.hypot(a.x+.5-x,a.y+.5-y)-Math.hypot(b.x+.5-x,b.y+.5-y))[0];
 return nearest?{p:{x:nearest.x,y:nearest.y},hit:null,layer:bridge.kind,bridge:bridge.id}:null;
}
export function pickBridge3D(group,ray){const hit=group&&ray.intersectObjects(group.children,false)[0];return hit?bridgeEraseTarget(hit.object.userData.bridge,hit.point.x,hit.point.z):null;}
function contains(points,x,y){
 let area=0,inside=false;for(let i=0,j=points.length-1;i<points.length;j=i++){
  const a=points[i],b=points[j];area+=a[0]*b[1]-b[0]*a[1];
  if((a[1]>y)!==(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])inside=!inside;
 }return Math.abs(area)>1e-6&&inside;
}
export function pickBridgeFlat(t,project,sx,sy){
 for(const object of bridgeObjects(t).reverse())for(const face of object.faces){if(contains(face.points.map(p=>project(...p)),sx,sy))return bridgeEraseTarget(object.bridge,object.x,object.y);}
 return null;
}
