import * as THREE from './vendor/three.module.js';
import {validateTransport,bridgeDeckHeightAt} from './transport.mjs';
import {roadTextureImage} from './terrain-map.mjs';
let roadMaterial=null;
function texturedRoadMaterial(){
 const image=roadTextureImage();if(!image)return null;if(roadMaterial)return roadMaterial;
 const map=new THREE.Texture(image);map.colorSpace=THREE.SRGBColorSpace;map.wrapS=THREE.RepeatWrapping;map.wrapT=THREE.ClampToEdgeWrapping;map.needsUpdate=true;
 roadMaterial=new THREE.MeshStandardMaterial({map,color:'#ffffff',roughness:.9,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});roadMaterial.userData.shared=true;return roadMaterial;
}
// Keep textured ramps out of the color-only fixture batch, merging all bridge
// surfaces into one shared-material draw while retaining their world-space UVs.
export function extractRoadDecks(group){
 group.updateMatrixWorld(true);const decks=[];group.traverse(o=>{if(o.userData.roadDeck)decks.push(o);});if(!decks.length)return null;
 const position=[],normal=[],uv=[];for(const deck of decks){const geometry=deck.geometry.clone().applyMatrix4(deck.matrixWorld);position.push(...geometry.attributes.position.array);normal.push(...geometry.attributes.normal.array);uv.push(...geometry.attributes.uv.array);geometry.dispose();deck.parent.remove(deck);deck.geometry.dispose();}
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(position,3));geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normal,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));const mesh=new THREE.Mesh(geometry,decks[0].material);mesh.receiveShadow=true;return mesh;
}

// These are ordinary meshes until scene.mjs folds them into its single static
// fixture draw. There is no per-frame construction or individual bridge draw.
export function createTransportFixtures(t,analysis=validateTransport(t)){
 const group=new THREE.Group(),materials=new Map();group.userData.crossingLights=[];
 const material=color=>{if(!materials.has(color))materials.set(color,new THREE.MeshStandardMaterial({color,roughness:.76}));return materials.get(color);};
 const box=(parent,w,h,d,color,x=0,y=0,z=0)=>{const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material(color));mesh.position.set(x,y+h/2,z);parent.add(mesh);return mesh;};
 const beam=(parent,a,b,width,color,depth=width)=>{const av=new THREE.Vector3(...a),bv=new THREE.Vector3(...b),delta=bv.clone().sub(av),mesh=new THREE.Mesh(new THREE.BoxGeometry(width,delta.length(),depth),material(color));mesh.position.copy(av).add(bv).multiplyScalar(.5);mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());parent.add(mesh);return mesh;};
 const pole=(parent,x,y,z,r,h,color)=>{const mesh=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,10),material(color));mesh.position.set(x,y+h/2,z);parent.add(mesh);return mesh;};
 const bridgeTop=(bridge,z)=>bridgeDeckHeightAt(bridge,z+bridge.length/2);
 const deck=(parent,bridge,width,color,offset=0,thickness=.065,surfaceMaterial=null)=>{
  const half=bridge.length/2,zs=[-half,-half+bridge.rampLength,half-bridge.rampLength,half],points=[],normals=[];
  const triangle=(a,b,c)=>{const va=new THREE.Vector3(...a),vb=new THREE.Vector3(...b),vc=new THREE.Vector3(...c),n=vb.clone().sub(va).cross(vc.clone().sub(va)).normalize();points.push(...a,...b,...c);normals.push(...n.toArray(),...n.toArray(),...n.toArray());};
  const quad=(a,b,c,d)=>{triangle(a,b,c);triangle(a,c,d);};
  for(let i=1;i<zs.length;i++){
   const za=zs[i-1],zb=zs[i];if(zb-za<1e-7)continue;const ya=bridgeTop(bridge,za)+offset,yb=bridgeTop(bridge,zb)+offset,x=width/2;
   quad([-x,ya,za],[-x,yb,zb],[x,yb,zb],[x,ya,za]);
   if(thickness){quad([-x,ya-thickness,za],[-x,yb-thickness,zb],[-x,yb,zb],[-x,ya,za]);quad([x,ya,za],[x,yb,zb],[x,yb-thickness,zb],[x,ya-thickness,za]);}
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(points,3));geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));const mesh=new THREE.Mesh(geometry,surfaceMaterial||material(color));if(surfaceMaterial){const uv=[],repeatWidth=width*(surfaceMaterial.map.image.width||surfaceMaterial.map.image.naturalWidth)/(surfaceMaterial.map.image.height||surfaceMaterial.map.image.naturalHeight);for(let i=0;i<points.length;i+=3)uv.push((points[i+2]+half)/repeatWidth,points[i]/width+.5);geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));mesh.userData.roadDeck=true;}parent.add(mesh);
 };
 for(const b of analysis.bridges){
  const bridge=new THREE.Group(),rail=b.kind==='rail',half=b.length/2;
  bridge.position.set((b.a.x+b.b.x)/2+.5,0,(b.a.y+b.b.y)/2+.5);bridge.rotation.y=Math.atan2(b.b.x-b.a.x,b.b.y-b.a.y);bridge.userData.bridge=b.id;
  deck(bridge,b,b.width,rail?'#657367':'#b4ad99');deck(bridge,b,rail?.77:.82,rail?'#958c78':'#666666',.006,0,rail?null:texturedRoadMaterial());
  // The abutments sit at the two actual land nodes, rather than being added
  // once per submerged cell. Both ramps lie wholly inside the span footprint.
  for(const side of [-1,1])box(bridge,b.width-.06,.18,.26,'#c6bda7',0,-.17,side*(half-.13));
  if(rail){
   const truss='#587d73',dark='#36574f',lift=b.deckHeight-.16;
   for(let i=0;i<=Math.floor(b.length/.18);i++){const z=-half+i*.18;if(z>half)break;box(bridge,.70,.027,.075,'#675a46',0,bridgeTop(b,z)+.012,z);}
   for(const x of [-.21,.21]){
    const zs=[-half,-half+b.rampLength,half-b.rampLength,half];for(let i=1;i<zs.length;i++)if(zs[i]-zs[i-1]>1e-7)beam(bridge,[x,bridgeTop(b,zs[i-1])+.052,zs[i-1]],[x,bridgeTop(b,zs[i])+.052,zs[i]],.035,'#c7d0c9',.034);
   }
   for(const range of b.barriers){
    const x=-range.side*range.offset,start=-half+range.start,end=-half+range.end,span=end-start,n=Math.max(2,Math.ceil(span/.78));
    beam(bridge,[x,.19+lift,start],[x,.19+lift,end],.065,dark,.055);beam(bridge,[x,.91+lift,start],[x,.91+lift,end],.068,truss,.055);
    for(let i=0;i<=n;i++){
     const z=start+span*i/n;beam(bridge,[x,.19+lift,z],[x,.91+lift,z],.052,truss,.050);
     if(i<n){const next=start+span*(i+1)/n;beam(bridge,[x,(i%2?.91:.19)+lift,z],[x,(i%2?.19:.91)+lift,next],.048,truss,.045);}
    }
   }
   // Open-top trusses keep the train/railway visibly separate from the road.
  }else{
   for(const range of b.barriers){
    const x=-range.side*range.offset,top=b.deckHeight+.29,start=-half+range.start,end=-half+range.end;
    beam(bridge,[x,top,start],[x,top,end],.047,'#d5ccb6',.050);
    beam(bridge,[x,b.deckHeight+.11,start],[x,b.deckHeight+.11,end],.026,'#a69b83',.035);
    const n=Math.max(2,Math.ceil((end-start)/.48));for(let i=0;i<=n;i++){const z=start+(end-start)*i/n;box(bridge,.052,top-bridgeTop(b,z),.060,'#b2a58c',x,bridgeTop(b,z),z);}
   }
   if(!texturedRoadMaterial())for(let z=-half+.32;z<half-.2;z+=.52){const a=z,c=Math.min(z+.25,half-.2);beam(bridge,[0,bridgeTop(b,a)+.008,a],[0,bridgeTop(b,c)+.008,c],.035,'#f1df9f',.009);}
  }
  group.add(bridge);
 }
 for(const crossing of analysis.crossings){
  const c=new THREE.Group(),r=crossing.railDirection,d=crossing.roadDirection,railAngle=Math.atan2(r.x,r.y);
  c.position.set(crossing.x+.5,0,crossing.y+.5);c.userData.crossing=crossing.id;
  const deckGroup=new THREE.Group();deckGroup.rotation.y=railAngle;
  // Rubber crossing panels sit flush enough for a car to drive over them.
  for(const x of [-.34,0,.34])box(deckGroup,.27,.020,1.14,'#5b625a',x,.041,0);
  for(const x of [-.20,.20])box(deckGroup,.035,.025,1.16,'#d7d5c6',x,.057,0);
  for(const z of [-.5,0,.5])for(const x of [-.37,.37])box(deckGroup,.08,.008,.016,'#9a9c8e',x,.063,z);
  c.add(deckGroup);
  for(const {x:px,y:pz,side} of crossing.posts){
   const post=new THREE.Group();post.position.set(px,0,pz);post.rotation.y=Math.atan2(d.x,d.y)+(side<0?Math.PI:0);
   box(post,.20,.075,.19,'#b6b49f',0,0,0);pole(post,0,.075,0,.034,.94,'#e8b946');
   for(let y=.13;y<.87;y+=.16)pole(post,0,y,0,.035,.075,'#3c4339');
   // Black-and-yellow crossbuck with round signal housings and raised gates.
   for(const angle of [-Math.PI/4,Math.PI/4]){const sign=box(post,.46,.067,.035,'#efc74f',0,.90,.010);sign.rotation.z=angle;for(const x of [-.14,.14]){const stripe=box(sign,.065,.068,.037,'#343e37',x,-.034,0);stripe.position.y=0;}}
   for(const [i,x]of [-.115,.115].entries()){
    const housing=new THREE.Mesh(new THREE.CylinderGeometry(.068,.068,.07,12),material('#303d36'));housing.rotation.x=Math.PI/2;housing.position.set(x,.76,.037);post.add(housing);
    const bulb=new THREE.Vector3(x,.76,.081);post.updateMatrix();bulb.applyMatrix4(post.matrix).add(c.position);group.userData.crossingLights.push({position:bulb,phase:i,kind:'crossing',crossingId:crossing.id});
   }
   box(post,.13,.16,.12,'#e1b951',-.10,.20,0);
   c.add(post);
  }
  group.add(c);
 }
 return group;
}
