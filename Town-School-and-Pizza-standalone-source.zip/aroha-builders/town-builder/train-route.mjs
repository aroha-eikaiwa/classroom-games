import {entrance} from './core.mjs';
import {W,edgeKey,migrateRoadEdges} from './network.mjs';
import {validateTransport,transportHeightAt} from './transport.mjs';

const EPS=1e-7;
const distance=(a,b)=>Math.hypot(b.x-a.x,b.y-a.y);
const lerp=(a,b,u)=>({x:a.x+(b.x-a.x)*u,y:a.y+(b.y-a.y)*u});
function railGraph(t,analysis){
 const blocked=new Set(analysis.issues.filter(i=>i.kind==='rail'||i.code==='bridge-overlap').flatMap(i=>i.cells||[]));
 const nodes=new Map((t.rails||[]).filter(k=>!blocked.has(k)).map(k=>[k,{id:k,x:k%W+.5,y:Math.floor(k/W)+.5,neighbors:new Set()}])),edges=[],seen=new Set();
 for(const pair of t.railEdges??migrateRoadEdges(t.rails||[])){
  if(!Array.isArray(pair)||pair.length!==2)continue;const [ka,kb]=pair,a=nodes.get(ka),b=nodes.get(kb),id=edgeKey(ka,kb);
  if(!a||!b||a===b||seen.has(id)||Math.max(Math.abs(a.x-b.x),Math.abs(a.y-b.y))!==1)continue;
  seen.add(id);a.neighbors.add(kb);b.neighbors.add(ka);edges.push({a,b});
 }
 return{nodes,edges};
}
function stationAnchor(graph,station){
 const e=entrance(station,true),candidates=[];
 for(const {a,b}of graph.edges){
  const dx=b.x-a.x,dy=b.y-a.y,u=Math.max(0,Math.min(1,((e.approach.x-a.x)*dx+(e.approach.y-a.y)*dy)/(dx*dx+dy*dy))),p=lerp(a,b,u),gap=distance(p,e.approach);
  if(gap<=.56&&(p.x-e.x)*e.dx+(p.y-e.y)*e.dy>.1)candidates.push({a,b,u,p,gap});
 }
 return candidates.sort((a,b)=>a.gap-b.gap||a.a.id-b.a.id||a.b.id-b.b.id);
}
// Diagonal rail Xs stay separate unless they share a real rail node.
function cycleThrough(graph,anchor){
 const nodes=new Map([...graph.nodes].map(([id,p])=>[id,{...p,neighbors:new Set(p.neighbors)}]));
 let start;
 if(anchor.u<EPS)start=nodes.get(anchor.a.id);else if(anchor.u>1-EPS)start=nodes.get(anchor.b.id);
 else{
  start={id:'station',...anchor.p,neighbors:new Set([anchor.a.id,anchor.b.id])};nodes.set(start.id,start);
  for(const[a,b]of [[anchor.a,anchor.b],[anchor.b,anchor.a]]){nodes.get(a.id).neighbors.delete(b.id);nodes.get(a.id).neighbors.add(start.id);}
 }
 const neighbors=[...start.neighbors].sort((a,b)=>Number(a)-Number(b));let best=null;
 for(let i=0;i<neighbors.length;i++)for(let j=i+1;j<neighbors.length;j++){
  const first=neighbors[i],last=neighbors[j],alternatives=[new Set()],tried=new Set();
  for(let attempt=0;attempt<alternatives.length&&attempt<24;attempt++){
   const banned=alternatives[attempt],banKey=[...banned].sort().join('|');if(tried.has(banKey))continue;tried.add(banKey);
   const queue=[first],previous=new Map([[first,null]]);
   for(let at=0;at<queue.length&&!previous.has(last);at++)for(const next of nodes.get(queue[at]).neighbors){if(next===start.id||previous.has(next)||banned.has(edgeKey(queue[at],next)))continue;previous.set(next,queue[at]);queue.push(next);}
   if(!previous.has(last))continue;
   const path=[];for(let id=last;id!==null;id=previous.get(id))path.push(nodes.get(id));path.reverse();
   const points=[start,...path],length=points.reduce((sum,p,k)=>sum+distance(p,points[(k+1)%points.length]),0);
   if(points.length>=3&&length>=3.8){if(!best||length<best.length)best={points,length};break;}
   // A tiny triangular shortcut must not hide the larger working loop. Search
   // alternatives with one short-path edge removed; these paths have at most
   // a few edges, so this is bounded work even in a densely connected town.
   for(let k=1;k<path.length;k++)alternatives.push(new Set([...banned,edgeKey(path[k-1].id,path[k].id)]));
  }
 }
 return best;
}
// Each station discovers its loop from a different platform. Give the shared
// physical loop one direction independent of that starting point (or station
// rotation/ID), retaining the platform as the first point for its normal stop.
function orientCycle(points){
 const rail=points.filter(p=>typeof p.id==='number');
 const first=rail.reduce((at,p,i)=>p.id<rail[at].id?i:at,0);
 const previous=rail[(first+rail.length-1)%rail.length],next=rail[(first+1)%rail.length];
 return previous.id<next.id?[points[0],...points.slice(1).reverse()]:points;
}
function smoothCycle(raw){
 const corners=raw.map((p,i)=>{
  const before=raw[(i+raw.length-1)%raw.length],after=raw[(i+1)%raw.length],d1=distance(before,p),d2=distance(p,after);
  // Keep the exact station stop point. Other sharp bends use a small quadratic
  // inside the ballast, with continuous tangents rather than snapping headings.
  const trim=i===0?0:Math.min(.22,d1*.24,d2*.24);
  return {p,in:lerp(p,before,trim/d1),out:lerp(p,after,trim/d2),trim};
 });
 const points=[{x:corners[0].p.x,y:corners[0].p.y}];
 for(let i=0;i<corners.length;i++){
  const a=corners[i],b=corners[(i+1)%corners.length];
  if(distance(points.at(-1),a.out)>EPS)points.push({...a.out});
  const lineLength=distance(a.out,b.in),steps=Math.max(1,Math.ceil(lineLength/.11));
  for(let j=1;j<=steps;j++)points.push(lerp(a.out,b.in,j/steps));
  if(b.trim)for(let j=1;j<=8;j++){const u=j/8,v=1-u;points.push({x:v*v*b.in.x+2*v*u*b.p.x+u*u*b.out.x,y:v*v*b.in.y+2*v*u*b.p.y+u*u*b.out.y});}
 }
 let length=0;const samples=points.map((p,i)=>{if(i)length+=distance(points[i-1],p);return {...p,distance:length};});
 return{samples,length};
}
function smoothLine(raw){
 const corners=raw.map((p,i)=>{const before=raw[i-1],after=raw[i+1],trim=!before||!after||p.stationIds?.length?0:Math.min(.22,distance(before,p)*.24,distance(p,after)*.24);return {p,trim,in:trim?lerp(p,before,trim/distance(before,p)):p,out:trim?lerp(p,after,trim/distance(p,after)):p};});
 const points=[{x:raw[0].x,y:raw[0].y}];
 for(let i=1;i<corners.length;i++){const a=corners[i-1],b=corners[i],steps=Math.max(1,Math.ceil(distance(a.out,b.in)/.11));for(let j=1;j<=steps;j++)points.push(lerp(a.out,b.in,j/steps));if(b.trim)for(let j=1;j<=8;j++){const u=j/8,v=1-u;points.push({x:v*v*b.in.x+2*v*u*b.p.x+u*u*b.out.x,y:v*v*b.in.y+2*v*u*b.p.y+u*u*b.out.y});}}
 let length=0;return {samples:points.map((p,i)=>{if(i)length+=distance(points[i-1],p);return {...p,distance:length};}),get length(){return length;}};
}
function platformGraph(graph,stations){
 const nodes=new Map([...graph.nodes].map(([id,p])=>[id,{...p,neighbors:new Set(),stationIds:[]}])),platforms=[];
 const onEdge=new Map();
 for(const station of stations){const anchor=stationAnchor(graph,station)[0];if(!anchor)continue;const {a,b,u,p}=anchor,id=u<EPS?a.id:u>1-EPS?b.id:`platform:${p.x.toFixed(6)},${p.y.toFixed(6)}`;
  if(!nodes.has(id))nodes.set(id,{id,...p,neighbors:new Set(),stationIds:[]});nodes.get(id).stationIds.push(station.id);platforms.push({stationId:station.id,node:nodes.get(id)});
  if(id!==a.id&&id!==b.id){const key=edgeKey(a.id,b.id);if(!onEdge.has(key))onEdge.set(key,[]);onEdge.get(key).push(nodes.get(id));}
 }
 const edges=[];
 for(const {a,b}of graph.edges){const between=[...new Set(onEdge.get(edgeKey(a.id,b.id))||[])].sort((p,q)=>distance(a,p)-distance(a,q)),chain=[nodes.get(a.id),...between,nodes.get(b.id)];for(let i=1;i<chain.length;i++){const a=chain[i-1],b=chain[i];a.neighbors.add(b.id);b.neighbors.add(a.id);edges.push({a,b});}}
 return {nodes,edges,platforms};
}
function stationShuttles(graph,stations,loops,analysis){
 const g=platformGraph(graph,stations),active=new Set(loops.map(r=>r.stationId)),routes=[],used=new Set();
 let cycleCore;
 for(const platform of g.platforms.filter(p=>!active.has(p.stationId)).sort((a,b)=>a.node.x-b.node.x||a.node.y-b.node.y||a.stationId-b.stationId)){
  if(routes.some(r=>r.stops.some(s=>s.stationId===platform.stationId)))continue;
  const root=platform.node,queue=[root.id],previous=new Map([[root.id,null]]);let target=null;
  for(let i=0;i<queue.length;i++){const node=g.nodes.get(queue[i]);if(node!==root&&node.stationIds.length)target=node;for(const id of [...node.neighbors].sort((a,b)=>String(a).localeCompare(String(b))))if(!previous.has(id)){previous.set(id,node.id);queue.push(id);}}
  const pathTo=node=>{const path=[];for(let id=node.id;id!==null;id=previous.get(id))path.push(g.nodes.get(id));return path.reverse();};
  let path;
  if(target){const key=[String(root.id),String(target.id)].sort().join('|');if(used.has(key))continue;used.add(key);path=pathTo(target);}
  else{
   // A terminal may feed a loop even when it is the only station. Travel to
   // the connected cycle, around it and back; reverse only at the platform.
   if(!cycleCore){const degrees=new Map([...g.nodes].map(([id,p])=>[id,p.neighbors.size])),tips=[...degrees].filter(([,n])=>n<2).map(([id])=>id);cycleCore=new Set(g.nodes.keys());for(let i=0;i<tips.length;i++){const id=tips[i];cycleCore.delete(id);for(const next of g.nodes.get(id).neighbors)if(cycleCore.has(next)){degrees.set(next,degrees.get(next)-1);if(degrees.get(next)===1)tips.push(next);}}}
   for(const id of queue){const node=g.nodes.get(id);if(node===root||!cycleCore.has(id))continue;const neighbor=g.nodes.get([...node.neighbors][0]),loop=cycleThrough(g,{a:node,b:neighbor,u:0,p:node});if(!loop)continue;const spur=pathTo(node),cycle=orientCycle(loop.points);path=[...spur,...cycle.slice(1),node,...spur.slice(0,-1).reverse()];break;}
  }
  if(!path)continue;const line=smoothLine(path);if(line.length<3.8)continue;
  const stops=[];
  for(const p of path.filter(p=>p.stationIds?.length)){for(const sample of line.samples)if(distance(p,sample)<EPS)for(const stationId of p.stationIds)if(!stops.some(s=>s.stationId===stationId&&Math.abs(s.distance-sample.distance)<.05))stops.push({stationId,distance:sample.distance});}
  routes.push({stationId:platform.stationId,kind:'shuttle',...line,cells:path.filter(p=>typeof p.id==='number').map(p=>p.id),stops:stops.sort((a,b)=>a.distance-b.distance),analysis});
 }
 return routes;
}
export function buildTrainRoutes(t,analysis=validateTransport(t)){
 const graph=railGraph(t,analysis),routes=[];
 for(const station of t.buildings.filter(b=>b.type==='station')){
  let loop=null;for(const anchor of stationAnchor(graph,station)){const candidate=cycleThrough(graph,anchor);if(candidate){loop=candidate;break;}}
  if(!loop)continue;
  loop.points=orientCycle(loop.points);
  const route={stationId:station.id,...smoothCycle(loop.points),analysis};
  route.cells=loop.points.filter(p=>typeof p.id==='number').map(p=>p.id);routes.push(route);
 }
 // Group the same directed physical cycle independently of its platform start.
 // Every service calls at each platform on that loop, in travel order.
 const loops=new Map();
 for(const route of routes){const first=route.cells.indexOf(Math.min(...route.cells)),id=[...route.cells.slice(first),...route.cells.slice(0,first)].join(',');if(!loops.has(id))loops.set(id,[]);loops.get(id).push(route);}
 for(const group of loops.values())for(const route of group){
  const stops=[{stationId:route.stationId,distance:0}];
  for(const other of group){if(other===route)continue;const target=other.samples[0];let best=null;
   for(let i=1;i<route.samples.length;i++){const a=route.samples[i-1],b=route.samples[i],dx=b.x-a.x,dy=b.y-a.y,u=Math.max(0,Math.min(1,((target.x-a.x)*dx+(target.y-a.y)*dy)/(dx*dx+dy*dy||1))),gap=Math.hypot(a.x+u*dx-target.x,a.y+u*dy-target.y);if(!best||gap<best.gap)best={gap,distance:a.distance+u*(b.distance-a.distance)};}
   if(best&&best.gap<.12&&best.distance>.05&&best.distance<route.length-.05&&!stops.some(stop=>Math.abs(stop.distance-best.distance)<.05))stops.push({stationId:other.stationId,distance:best.distance});
  }
  route.stops=stops.sort((a,b)=>a.distance-b.distance);
 }
 return [...routes,...stationShuttles(graph,t.buildings.filter(b=>b.type==='station'),routes,analysis)];
}
function pointAt(route,distanceAlong){
 const length=route.length,d=route.kind==='shuttle'?Math.max(0,Math.min(length,distanceAlong)):((distanceAlong%length)+length)%length,s=route.samples;let low=0,high=s.length-1;
 while(low+1<high){const mid=(low+high)>>1;if(s[mid].distance>d)high=mid;else low=mid;}
 const a=s[low],b=s[high],u=(d-a.distance)/(b.distance-a.distance||1);return lerp(a,b,u);
}
export function trainPose(route,distanceAlong){
 const p=pointAt(route,distanceAlong),a=pointAt(route,distanceAlong-.47),b=pointAt(route,distanceAlong+.47),ha=transportHeightAt(route.analysis,a.x,a.y,'rail'),hb=transportHeightAt(route.analysis,b.x,b.y,'rail');
 return {...p,height:(ha+hb)/2,heading:Math.atan2(b.x-a.x,b.y-a.y),pitch:Math.atan2(hb-ha,Math.hypot(b.x-a.x,b.y-a.y))};
}
export class TrainMotion{
 constructor(route,{speed=1.45,dwell=1,acceleration=.62}={}){
  this.route=route;this.time=0;this.dwell=dwell;this.acceleration=acceleration;
  const shuttle=route.kind==='shuttle',low=shuttle?1.14:0,high=shuttle?route.length-1.14:route.length;
  const stops=[...new Set([low,...(route.stops||[]).map(s=>s.distance)].filter(d=>Number.isFinite(d)&&d>=low&&d<high))].sort((a,b)=>a-b);
  const legs=shuttle?[...stops,high,...stops.slice(1).reverse(),low]:[...stops,high];
  this.segments=legs.slice(0,-1).map((start,i)=>{const end=legs[i+1],direction=Math.sign(end-start),length=Math.abs(end-start),peakSpeed=Math.min(speed,Math.sqrt(length*acceleration)),rampTime=peakSpeed/acceleration,rampDistance=.5*acceleration*rampTime**2,cruiseTime=Math.max(0,(length-2*rampDistance)/peakSpeed),travelTime=2*rampTime+cruiseTime;return {start,end,direction,length,peakSpeed,rampTime,rampDistance,cruiseTime,travelTime,duration:dwell+travelTime};});
  const first=this.segments[0];Object.assign(this,{peakSpeed:first.peakSpeed,rampTime:first.rampTime,rampDistance:first.rampDistance,cruiseTime:first.cruiseTime});
  this.travelTime=this.segments.reduce((n,s)=>n+s.travelTime,0);this.period=this.segments.reduce((n,s)=>n+s.duration,0);this.distance=low;this.direction=1;this.speed=0;this.stopped=true;this.lap=0;
 }
 update(dt){
  if(Number.isFinite(dt)&&dt>0)this.time+=dt;this.lap=Math.floor(this.time/this.period);let cycle=this.time%this.period,segment=this.segments.at(-1);
  for(const candidate of this.segments){segment=candidate;if(cycle<candidate.duration)break;cycle-=candidate.duration;}
  const t=cycle-this.dwell,direction=segment.direction;this.direction=direction;this.stopped=t<=0;this.distance=segment.start;this.speed=0;
  if(t>0&&t<segment.rampTime){this.speed=this.acceleration*t;this.distance+=direction*.5*this.acceleration*t*t;}
  else if(t>=segment.rampTime&&t<segment.rampTime+segment.cruiseTime){this.speed=segment.peakSpeed;this.distance+=direction*(segment.rampDistance+(t-segment.rampTime)*segment.peakSpeed);}
  else if(t>=segment.rampTime+segment.cruiseTime){const remaining=segment.travelTime-t;this.speed=Math.max(0,this.acceleration*remaining);this.distance=segment.end-direction*.5*this.acceleration*remaining*remaining;}
  return this;
 }
 // Keep each physical carriage on the same side of the consist centre when
 // reversing. Swapping the lead-car sample would teleport/overlap the cars.
 pose(offset=0){return trainPose(this.route,this.distance+offset+(this.route.kind==='shuttle'?.84:0));}
}

// Incomplete railways still show one carriage waiting at the rear platform.
// A return loop upgrades it to the full two-car service on the next map edit.
export function buildParkedTrains(t,active=buildTrainRoutes(t),analysis=validateTransport(t)){
 const activeStations=new Set(active.flatMap(r=>[r.stationId,...(r.stops||[]).map(s=>s.stationId)])),graph=railGraph(t,analysis),parked=[];
 for(const station of t.buildings.filter(b=>b.type==='station'&&!activeStations.has(b.id))){
  const anchor=stationAnchor(graph,station)[0];if(!anchor)continue;
  parked.push({stationId:station.id,pose:{...anchor.p,height:transportHeightAt(analysis,anchor.p.x,anchor.p.y,'rail'),heading:Math.atan2(anchor.b.x-anchor.a.x,anchor.b.y-anchor.a.y)}});
 }
 return parked;
}
