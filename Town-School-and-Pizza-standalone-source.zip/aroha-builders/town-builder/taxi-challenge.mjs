import {WIDTH,HEIGHT,cells,destinationBuildings,entranceAccess,entrance} from './core.mjs';
import {validateTransport,transportHeightAt} from './transport.mjs';
import {roadGraph,connectedNodes} from './network.mjs';
import {transportGroundCells} from './ground-clearance.mjs';
import {TAXI_EXIT_SECONDS,TAXI_DANCE_SECONDS,TAXI_PASSENGER_MODELS,chooseTaxiReaction} from './taxi-effects.mjs';
import {SpokenGps} from './gps-directions.mjs';

export const TAXI_VEHICLE=Object.freeze({model:'taxi',color:'#efbf44'});
export const TAXI_REQUIREMENTS=Object.freeze({footpaths:12,parks:1,grass:6});
export const PICKUP_STOP_SECONDS=.75;
export const PICKUP_MAX_SPEED=.08;
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const project=(p,a,b)=>{const dx=b.x-a.x,dy=b.y-a.y,u=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy)));return {x:a.x+u*dx,y:a.y+u*dy};};

// Only dry, unobstructed tiles immediately beside the start-connected road
// network count. A distant path, disconnected road or bridge cannot earn a stop.
export function taxiWalkability(town,area={width:WIDTH,height:HEIGHT}){
 const graph=roadGraph(town),connected=connectedNodes(town),water=new Set(town.rivers||[]);
 const blocked=new Set([...transportGroundCells(town),...water,...(town.flowers||[])]);
 for(const b of town.buildings)for(const k of cells(b))blocked.add(k);
 const pavement=new Set(town.pavement||[]),footpaths=[],grass=[];
 const links=graph.links.filter(({a,b})=>connected.has(a.id)&&connected.has(b.id)&&![a,b].some(p=>water.has(Math.floor(p.y)*WIDTH+Math.floor(p.x))));
 for(let y=0;y<Math.min(HEIGHT,area.height);y++)for(let x=0;x<Math.min(WIDTH,area.width);x++){
  const k=y*WIDTH+x;if(blocked.has(k))continue;const p={x,y};let stop=null,best=Infinity;
  for(const {a,b}of links){if(x<Math.min(a.x,b.x)-1.05||x>Math.max(a.x,b.x)+1.05||y<Math.min(a.y,b.y)-1.05||y>Math.max(a.y,b.y)+1.05)continue;
   const q=project(p,a,b),d=distance(p,q);if(d>.64&&d<=1.05&&d<best){best=d;stop=q;}
  }
  if(stop)(pavement.has(k)?footpaths:grass).push({id:k,x:x+.5,z:y+.5,stop,heading:Math.atan2(stop.x-x,stop.y-y)});
 }
 const parks=town.buildings.filter(b=>b.type==='park'&&entranceAccess(town,b,{connected:true})).length;
 return {ready:footpaths.length>=12&&parks>=1&&grass.length>=6,footpaths,grass,parks};
}

export function rideTimeLimit(routeLength){return Math.ceil(25+Math.max(0,routeLength)*2.4);}
export function ridePoints(remaining){return 100+Math.floor(Math.max(0,remaining)*10);}

export class TaxiChallenge{
 constructor(town,{area,random=Math.random,walkability=taxiWalkability(town,area)}={}){
  this.town=town;this.random=random;this.walkability=walkability;this.gps=new SpokenGps(town,{random});
  this.clock=0;this.score=0;this.deliveries=0;this.phase='searching';this.passenger=null;this.destination=null;this.remaining=0;this.limit=0;this.stopTime=0;this.candidate=null;this.arrests=0;this.message='';this.messageUntil=0;
  // Spread visible passengers along the roadside, rather than filling every tile.
  const candidates=[...walkability.footpaths];this.passengers=[];
  while(candidates.length&&this.passengers.length<6){const site=candidates.shift();if(this.passengers.some(p=>Math.hypot(p.x-site.x,p.z-site.z)<2.2))continue;this.passengers.push({...site,index:this.passengers.length,model:TAXI_PASSENGER_MODELS[this.passengers.length%TAXI_PASSENGER_MODELS.length],availableAt:0});}
 }
 get celebrating(){return this.clock<(this.celebrationUntil||0);}
 get waiting(){return this.passengers.filter(p=>p!==this.passenger&&p.availableAt<=this.clock);}
 clearRide(){this.gps.stop();this.phase='searching';this.passenger=null;this.destination=null;this.remaining=0;this.limit=0;this.candidate=null;this.stopTime=0;}
 leavePassenger(pose,kind){
  const p=this.passenger;if(!p)return;
  const sites=[...this.walkability.footpaths,...this.walkability.grass];
  const target=sites.reduce((best,q)=>!best||Math.hypot(q.x-pose.x-.5,q.z-pose.y-.5)<Math.hypot(best.x-pose.x-.5,best.z-pose.y-.5)?q:best,null)||p;
  const x=pose.x+.5,z=pose.y+.5,door=kind==='delivered'?entrance(this.destination):null;
  const dx=door?door.x-x:Math.cos(pose.heading||0),dz=door?door.y-z:-Math.sin(pose.heading||0),length=Math.hypot(dx,dz)||1,exitDistance=door?Math.min(.65,Math.max(0,length-.14)):.65;
  p.exit={kind,time:this.clock,x:x+dx/length*.23,z:z+dz/length*.23,tx:door?x+dx/length*exitDistance:target.x,tz:door?z+dz/length*exitDistance:target.z,heading:Math.atan2(dx,dz),base:transportHeightAt(validateTransport(this.town),x,z,'road')};
  if(kind==='delivered'){
   p.exit.reaction=chooseTaxiReaction(this.random,p.model,this.lastReaction);this.lastReaction=p.exit.reaction;
   const wx=door.x+door.dx*.1-p.exit.tx,wz=door.y+door.dy*.1-p.exit.tz,walkLength=Math.hypot(wx,wz)||1,travel=Math.min(1.3,walkLength);
   p.exit.walkX=p.exit.tx+wx/walkLength*travel;p.exit.walkZ=p.exit.tz+wz/walkLength*travel;
  }
  p.availableAt=this.clock+18;
 }
 finish(kind,pose){
  const destination=this.destination,award=kind==='delivered'?ridePoints(this.remaining):0;
  if(kind==='delivered'){this.score+=award;this.deliveries++;}
  this.leavePassenger(pose,kind);this.clearRide();
  if(kind==='delivered')this.celebrationUntil=this.clock+TAXI_EXIT_SECONDS+TAXI_DANCE_SECONDS;
  this.message=kind==='delivered'?`到着！ ＋${award}点`:kind==='arrested'?'つかまった！ 送迎失敗':'時間切れ！ お客さんが降りたよ';this.messageUntil=this.clock+3.5;
  return {kind,destination,award};
 }
 pickup(p,pose){
  // Prefer a meaningful journey and only destinations the existing GPS accepts.
  const choices=destinationBuildings(this.town).map(b=>({b,access:entranceAccess(this.town,b,{connected:true})})).filter(q=>q.access);
  const far=choices.filter(q=>Math.hypot(q.access.x-.5-pose.x,q.access.y-.5-pose.y)>=3);
  const pool=far.length?far:choices;if(!pool.length)return null;
  const offset=Math.min(pool.length-1,Math.floor(this.random()*pool.length));let state=null;
  for(let i=0;i<pool.length&&!state;i++)state=this.gps.start(pose,{destinationId:pool[(i+offset)%pool.length].b.id});
  if(!state)return null;
  this.passenger=p;this.destination=state.destination;this.phase='ride';this.limit=rideTimeLimit(this.gps.plan.length);this.remaining=this.limit;this.stopTime=0;this.candidate=null;
  p.board={time:this.clock,x:p.x,z:p.z,tx:pose.x+.5,tz:pose.y+.5};
  this.message='';return {kind:'pickup',state,destination:this.destination};
 }
 update(dt,pose,{canArrive=true}={}){
  this.clock+=Math.max(0,Number.isFinite(dt)?dt:0);
  if(this.celebrating)return null;
  const arrests=pose.police?.arrests||0;
  if(arrests!==this.arrests){this.arrests=arrests;if(this.passenger)return this.finish('arrested',pose);this.candidate=null;this.stopTime=0;return null;}
  if(this.phase==='ride'){
   this.remaining=Math.max(0,this.remaining-dt);
   if(this.remaining<=0)return this.finish('timeout',pose);
   const stopped=Math.abs(pose.speed||0)<=PICKUP_MAX_SPEED;
   const state=this.gps.update(pose,dt,{allowArrival:canArrive&&stopped});
   // Drop-offs use the normal building entrance arrival point. There is no
   // footpath, grass or pickup-site restriction at the destination.
   if(state?.arrived&&canArrive&&stopped)return this.finish('delivered',pose);
   return {kind:'navigation',state};
  }
  if(!canArrive||pose.police?.phase==='chasing'||(pose.police?.hold||0)>0){this.candidate=null;this.stopTime=0;return null;}
  const p=this.waiting.find(p=>distance(pose,p.stop)<=.72&&Math.hypot(p.x-pose.x-.5,p.z-pose.y-.5)<=1.55);
  if(!p||Math.abs(pose.speed||0)>PICKUP_MAX_SPEED){this.candidate=null;this.stopTime=0;return null;}
  if(this.candidate!==p){this.candidate=p;this.stopTime=0;}
  this.stopTime+=dt;if(this.stopTime<PICKUP_STOP_SECONDS)return null;
  return this.pickup(p,pose);
 }
}
