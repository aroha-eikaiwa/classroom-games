import {transportGroundCells} from './ground-clearance.mjs';
import {validateTransport} from './transport.mjs';
import {migrateRoadEdges,connectedNodes,nodeKey,roadGraph,segmentTouchesBox} from './network.mjs';
import {addedRoad,roadRules} from './road-limits.mjs';
import {WIDTH,HEIGHT,LEGACY_WIDTH,LEGACY_HEIGHT,sourceGrid,expandTownGrid} from './town-grid.mjs';
export {WIDTH,HEIGHT} from './town-grid.mjs';
// Bound saved towns and classroom rendering while allowing the expanded board.
export const MAX_BUILDINGS=192;
const LEGACY_LOTS={museum:[4,3],hospital:[4,3],station:[4,2],castle:[4,4],'elementary-school':[4,3],'junior-high-school':[4,3]};
export const CATALOG=[
['house','house','家',2,2,'#e58b63'],['park','park','公園',3,3,'#76a754'],['library','library','図書館',3,2,'#b58bc4'],['museum','museum','博物館・美術館',5,4,'#d7b88b'],['hospital','hospital','病院',5,4,'#ed8292'],['bus-stop','bus stop','バス停',1,1,'#efbf55'],['station','station','駅',5,3,'#84b9c7'],['police-station','police station','警察署',2,2,'#729aca'],['fire-station','fire station','消防署',3,2,'#d96f59'],['post-office','post office','郵便局',2,2,'#d77d78'],['bookstore','bookstore','書店',2,2,'#ac906c'],['restaurant','restaurant','レストラン',2,2,'#e49b61'],['supermarket','supermarket','スーパーマーケット',4,3,'#77b8a1'],['castle','castle','城',7,6,'#a4a0c7'],['shrine','shrine','神社',3,3,'#c8795a'],['temple','temple','寺',3,3,'#9c9c71'],['church','church','教会',2,3,'#b49acb'],['aquarium','aquarium','水族館',6,4,'#5cacb6'],['stadium','stadium','スタジアム',10,8,'#a1b179'],['zoo','zoo','動物園',8,6,'#c4a26b'],['amusement-park','amusement park','遊園地',8,7,'#e0a0b1'],['convenience-store','convenience store','コンビニ',2,2,'#6eb6b0'],['elementary-school','elementary school','小学校',6,5,'#e6b453'],['junior-high-school','junior high school','中学校',7,5,'#91b6cf'],['arcade','game center','ゲームセンター',3,3,'#b278d2'],['shopping-mall','shopping mall','ショッピングモール',10,8,'#85b8bb'],['tree','tree','木',1,1,'#6e9d4d'],['bakery','bakery','パン屋',3,3,'#ce9b66'],['apartment','apartment building','マンション',5,4,'#b2b3ba'],['cinema','movie theatre','映画館',4,3,'#b76476'],['airport','airport','空港',24,6,'#91b9cc'],['bank','bank','銀行',5,5,'#b3bd98'],['high-school','high school','高校',7,8,'#c4b49b'],['university','university','大学',14,10,'#c6b6a2'],['hotel','hotel','ホテル',6,6,'#b9a59e'],['factory','factory','工場',6,3,'#b49c86'],['city-hall','city hall','市役所',6,6,'#c0bca7'],['prison','prison','刑務所',12,10,'#a3aaa5']
].map(([id,en,ja,w,d,color])=>({id,en,ja,w,d,color,...(['arcade','shopping-mall','tree','bakery','apartment','cinema','airport','bank','high-school','university','hotel','factory','city-hall','prison','amusement-park','church','aquarium','stadium','shrine','temple','zoo','castle'].includes(id)?{optional:true}:{}),...(id==='tree'?{decorative:true}:{})}));
export const REQUIRED_CATALOG=CATALOG.filter(c=>!c.optional);

export const byType=Object.fromEntries(CATALOG.map(b=>[b.id,b]));
export const key=(x,y)=>y*WIDTH+x;
export const xy=k=>({x:k%WIDTH,y:Math.floor(k/WIDTH)});
export const inside=(x,y)=>Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<WIDTH&&y<HEIGHT;
const V6_LOTS={castle:[5,5],stadium:[6,4]};
const V15_LOTS={aquarium:[4,3],stadium:[8,6],zoo:[5,4],'amusement-park':[5,5]};
export const newPlot=type=>V15_LOTS[type]?4:V6_LOTS[type]?3:2;
const RESTAURANT_LOTS=[[2,2],[3,3],[2,2],[3,2],[3,3],[3,3]];
export function lotSize(b){
 if(b.type==='park'&&b.variant===2)return {w:5,d:6};
 if(b.type==='temple'&&b.variant===1)return {w:5,d:5};
 if(b.type==='station'&&b.variant===1)return {w:3,d:2};
 if(b.type==='hotel')return b.variant===1?{w:5,d:5}:{w:6,d:6};
 if(b.type==='factory')return b.variant===1?{w:8,d:5}:{w:6,d:3};
 if(b.type==='park')return {w:b.size,d:b.size};
 if(b.type==='house'&&(b.variant??0)>=6)return {w:3,d:3};
 if(b.type==='restaurant'){const [w,d]=RESTAURANT_LOTS[b.variant??0]||RESTAURANT_LOTS[0];return {w,d};}
 const c=byType[b.type],legacy=b.plot>=4?null:b.plot===3?V15_LOTS[b.type]:b.plot===2?(V6_LOTS[b.type]||V15_LOTS[b.type]):(LEGACY_LOTS[b.type]||V6_LOTS[b.type]||V15_LOTS[b.type]);
 return {w:legacy?legacy[0]:c.w,d:legacy?legacy[1]:c.d};
}
export function variantCount(type){return type==='house'?8:type==='tree'?7:type==='restaurant'?6:type==='park'?3:['castle','temple','apartment','hotel','factory','station'].includes(type)?2:1;}
export function hasEntrance(buildingOrType){const type=typeof buildingOrType==='string'?buildingOrType:buildingOrType?.type;return !!byType[type]&&!byType[type].decorative;}
export function isDestination(b){return hasEntrance(b)&&!['house','police-station','prison'].includes(b.type);}
export function destinationBuildings(t){return (t.buildings||[]).filter(isDestination);}
export const POINT_TOKENS=Object.freeze([1,1,1,2,2,2,3,3,5]);
export const pointEligible=b=>!!b&&isDestination(b);
export function validatePointPlacements(raw,buildings){
 if(!Array.isArray(raw)||raw.length>POINT_TOKENS.length)throw Error('Invalid hidden points.');
 const tokens=new Set(),places=new Set(),out=[];
 for(const p of raw){if(!p||!Number.isInteger(p.token)||p.token<0||p.token>=POINT_TOKENS.length||!Number.isInteger(p.building))throw Error('Invalid hidden points.');if(tokens.has(p.token)||places.has(p.building))throw Error('Invalid hidden points.');tokens.add(p.token);places.add(p.building);if(pointEligible(buildings.find(b=>b.id===p.building)))out.push({token:p.token,building:p.building});}
 return out.sort((a,b)=>a.token-b.token);
}
export function prunePoints(t){t.points=validatePointPlacements(t.points||[],t.buildings);}
export function assignPoint(t,token,building){
 if(!Number.isInteger(token)||token<0||token>=POINT_TOKENS.length||!pointEligible(t.buildings.find(b=>b.id===building))||(t.points||[]).some(p=>p.building===building&&p.token!==token))return false;
 if((t.points||[]).some(p=>p.token===token&&p.building===building))return false;
 t.points=[...(t.points||[]).filter(p=>p.token!==token),{token,building}].sort((a,b)=>a.token-b.token);return true;
}
export function footprint(b){const {w,d}=lotSize(b),a=b.rotation*Math.PI/4;return {w:Math.ceil(Math.abs(w*Math.cos(a))+Math.abs(d*Math.sin(a))-1e-8),d:Math.ceil(Math.abs(w*Math.sin(a))+Math.abs(d*Math.cos(a))-1e-8)};}
export function worldPoint(b,x,y){const f=footprint(b),s=lotSize(b),a=b.rotation*Math.PI/4,c=Math.cos(a),sn=Math.sin(a),dx=x-s.w/2,dy=y-s.d/2;return {x:b.x+f.w/2+dx*c-dy*sn,y:b.y+f.d/2+dx*sn+dy*c};}
export function lotPolygon(b){const {w,d}=lotSize(b),f=footprint(b),a=b.rotation*Math.PI/4,c=Math.cos(a),sn=Math.sin(a),cx=b.x+f.w/2,cy=b.y+f.d/2;return [[-w/2,-d/2],[w/2,-d/2],[w/2,d/2],[-w/2,d/2]].map(([x,y])=>({x:cx+x*c-y*sn,y:cy+x*sn+y*c}));}
export function polygonsOverlap(a,b){for(const poly of [a,b])for(let i=0;i<poly.length;i++){const p=poly[i],q=poly[(i+1)%poly.length],nx=p.y-q.y,ny=q.x-p.x;let a0=Infinity,a1=-Infinity,b0=Infinity,b1=-Infinity;for(const v of a){const n=v.x*nx+v.y*ny;a0=Math.min(a0,n);a1=Math.max(a1,n);}for(const v of b){const n=v.x*nx+v.y*ny;b0=Math.min(b0,n);b1=Math.max(b1,n);}if(a1<=b0+1e-7||b1<=a0+1e-7)return false;}return true;}
export function cells(b){const f=footprint(b),axisAligned=b.rotation%2===0,poly=axisAligned?null:lotPolygon(b),a=[];for(let y=b.y;y<b.y+f.d;y++)for(let x=b.x;x<b.x+f.w;x++)if(axisAligned||polygonsOverlap(poly,[{x,y},{x:x+1,y},{x:x+1,y:y+1},{x,y:y+1}]))a.push(key(x,y));return a;}
export function pointInLot(b,x,y,pad=0){const s=lotSize(b),f=footprint(b),a=-b.rotation*Math.PI/4,dx=x-b.x-f.w/2,dy=y-b.y-f.d/2,lx=dx*Math.cos(a)-dy*Math.sin(a),ly=dx*Math.sin(a)+dy*Math.cos(a);return Math.abs(lx)<s.w/2+pad-1e-7&&Math.abs(ly)<s.d/2+pad-1e-7;}
export function buildingAt(t,x,y){return t.buildings.find(b=>pointInLot(b,x+.5,y+.5));}
export function pointSegment(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,q=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1)));return {x:a.x+dx*q,y:a.y+dy*q,distance:Math.hypot(p.x-a.x-dx*q,p.y-a.y-dy*q)};}
export function segmentHitsLot(a,b,lot,pad=.4){const f=footprint(lot),s=lotSize(lot),angle=-lot.rotation*Math.PI/4;const local=p=>{const dx=p.x+.5-lot.x-f.w/2,dy=p.y+.5-lot.y-f.d/2;return {x:dx*Math.cos(angle)-dy*Math.sin(angle),y:dx*Math.sin(angle)+dy*Math.cos(angle)};};const p=local(a),q=local(b),dx=q.x-p.x,dy=q.y-p.y;let lo=0,hi=1;for(const[u,v]of [[-dx,p.x+s.w/2+pad],[dx,s.w/2+pad-p.x],[-dy,p.y+s.d/2+pad],[dy,s.d/2+pad-p.y]]){if(Math.abs(u)<1e-12){if(v<0)return false;}else{const n=v/u;if(u<0)lo=Math.max(lo,n);else hi=Math.min(hi,n);if(lo>hi)return false;}}return true;}
export function blankTown(){return {v:5,width:WIDTH,height:HEIGHT,apartmentFacing:2,mallLayout:2,universityLayout:2,progressionVersion:1,optionalUnlocked:false,expandedUnlocked:false,expansionStages:2,fullMapUnlocked:false,roads:[],roadEdges:[],rivers:[],rails:[],railEdges:[],flowers:[],pavement:[],points:[],buildings:[],start:null};}
function placementValidator(t){
 // One validation request shares its geometry/index. Nothing about a student's
 // town is cached between requests, and the exact overlap tests stay intact.
 const water=new Set(t.rivers||[]),points=new Map([...t.roads,...(t.rails||[])].map(k=>[k,xy(k)])),edges=new Map(),lots=new WeakMap();
 for(const pair of [...(t.roadEdges||[]),...(t.railEdges||[])]){
  const edge=pair.map(xy);for(const k of pair){if(!edges.has(k))edges.set(k,[]);edges.get(k).push(edge);}
 }
 const geometry=b=>{let g=lots.get(b);if(!g){g={f:footprint(b),poly:lotPolygon(b)};lots.set(b,g);}return g;};
 return (b,ignoreId=null)=>{
  const {f,poly}=geometry(b);if(!inside(b.x,b.y)||!inside(b.x+f.w-1,b.y+f.d-1))return false;
  for(const v of t.buildings){if(v.id===ignoreId)continue;const g=geometry(v);if(b.x+f.w<=v.x||v.x+g.f.w<=b.x||b.y+f.d<=v.y||v.y+g.f.d<=b.y)continue;if(polygonsOverlap(poly,g.poly))return false;}
  if(water.size)for(let y=b.y;y<b.y+f.d;y++)for(let x=b.x;x<b.x+f.w;x++)if(water.has(key(x,y))&&polygonsOverlap(poly,[{x,y},{x:x+1,y},{x:x+1,y:y+1},{x,y:y+1}]))return false;
  const tested=new Set();
  // A rotated .4-tile road clearance projects less than one tile on either
  // axis. Every adjacent segment touching that area has an endpoint here.
  for(let y=Math.max(0,b.y-2);y<=Math.min(HEIGHT-1,b.y+f.d+1);y++)for(let x=Math.max(0,b.x-2);x<=Math.min(WIDTH-1,b.x+f.w+1);x++){
   const k=key(x,y),p=points.get(k);if(p&&segmentHitsLot(p,p,b))return false;
   for(const edge of edges.get(k)||[]){if(tested.has(edge))continue;tested.add(edge);if(segmentHitsLot(edge[0],edge[1],b))return false;}
  }
  return true;
 };
}
export function canPlace(t,b,ignoreId=null){return placementValidator(t)(b,ignoreId);}
export function neighbors(x,y){return [[x-1,y],[x+1,y],[x,y-1],[x,y+1]].filter(([a,b])=>inside(a,b));}
export function perimeter(b){const occupied=new Set(cells(b)),out=new Set();for(const k of occupied){const {x,y}=xy(k);for(const [a,c]of neighbors(x,y))if(!occupied.has(key(a,c)))out.add(key(a,c));}return [...out].map(k=>{const p=xy(k);return[p.x,p.y];});}
export function entrance(b,back=false){const {w,d}=lotSize(b),a=b.rotation*Math.PI/4,sign=back?-1:1;const edge=worldPoint(b,w/2,back?0:d),out={x:-Math.sin(a)*sign,y:Math.cos(a)*sign};return {...edge,dx:out.x,dy:out.y,approach:{x:edge.x+out.x*.5,y:edge.y+out.y*.5}};}
// Only adjacent roads or a continuous painted pavement path provide access.
const ENTRANCE_ROAD_REACH=.56;
const entranceCache=new WeakMap();
const entranceGeometry=b=>[b.id,b.type,b.x,b.y,b.rotation,b.size,b.plot,b.variant].join(':');
function clearEntrancePath(a,b,buildings,water){
 const from={x:a.x-.5,y:a.y-.5},to={x:b.x-.5,y:b.y-.5};
 return !buildings.some(lot=>segmentHitsLot(from,to,lot,.08))&&!water.some(k=>{const p=xy(k);return segmentTouchesBox(from,to,{...p,w:1,d:1},.02);});
}
function directEntranceAccess(t,b,g,allowed,back=false,buildings=t.buildings||[]){
 const e=entrance(b,back),candidates=[],accept=p=>{
  if(p.distance>(back ? .56 : ENTRANCE_ROAD_REACH)+1e-9||(p.x-e.x)*e.dx+(p.y-e.y)*e.dy<=.1)return;
  if(!back&&!clearEntrancePath(e.approach,p,buildings,t.rivers||[]))return;
  candidates.push(p);
 };
 for(const link of g.links){if(allowed&&!allowed.has(link.a.id))continue;accept(pointSegment(e.approach,{x:link.a.x+.5,y:link.a.y+.5},{x:link.b.x+.5,y:link.b.y+.5}));}
 for(const n of g.nodes.values()){if(allowed&&!allowed.has(n.id))continue;const p={x:n.x+.5,y:n.y+.5};accept({...p,distance:Math.hypot(p.x-e.approach.x,p.y-e.approach.y)});}
 return candidates.sort((a,b)=>a.distance-b.distance)[0]||null;
}
function entranceConnections(t,connected,b=null){
 const source=t.buildings||[],old=b&&source.find(v=>v.id===b.id),buildings=!b||old===b||old&&entranceGeometry(old)===entranceGeometry(b)?source:[...source.filter(v=>v.id!==b.id),b];
 const graph=roadGraph(t),stamp=buildings.map(entranceGeometry).join('|')+';'+(t.rivers||[]).join(',')+';'+(t.pavement||[]).join(',')+';'+(t.rails||[]).join(',')+';'+(t.railEdges||[]).map(e=>e.join(':')).join(',')+';'+(t.start?key(t.start.x,t.start.y):'');
 const cached=entranceCache.get(t);if(cached?.graph===graph&&cached.stamp===stamp&&cached.connected===connected)return cached.access;
 const allowed=connected?connectedNodes(t):null,places=buildings.filter(hasEntrance).map(b=>({b,e:entrance(b),direct:directEntranceAccess(t,b,graph,allowed,false,buildings)})),access=new Map();
 for(const place of places)if(place.direct)access.set(place.b.id,{...place.direct,shared:false,via:place.b.id});
 if(t.pavement?.length){
  // Ignore stale/forged pavement under obstacles as well as ordinary pruning.
  const blocked=new Set([...transportGroundCells(t),...(t.rivers||[]),...buildings.flatMap(cells)]),paving=new Map((t.pavement||[]).filter(k=>!blocked.has(k)&&Number.isInteger(k)&&k>=0&&k<WIDTH*HEIGHT).map(k=>[k,{k,...xy(k)}])),paths=new Map(),queue=[];
  const roads=[...graph.links.filter(link=>!allowed||allowed.has(link.a.id)).map(link=>({a:{x:link.a.x+.5,y:link.a.y+.5},b:{x:link.b.x+.5,y:link.b.y+.5}})),...([...graph.nodes.values()].filter(n=>!allowed||allowed.has(n.id)).map(n=>({a:{x:n.x+.5,y:n.y+.5},b:{x:n.x+.5,y:n.y+.5}})))];
  const nearbyRoads=new Map();
  for(const road of roads)for(let y=Math.max(0,Math.floor(Math.min(road.a.y,road.b.y)-1.51));y<=Math.min(HEIGHT-1,Math.ceil(Math.max(road.a.y,road.b.y)+.51));y++)for(let x=Math.max(0,Math.floor(Math.min(road.a.x,road.b.x)-1.51));x<=Math.min(WIDTH-1,Math.ceil(Math.max(road.a.x,road.b.x)+.51));x++){const k=key(x,y);if(!paving.has(k))continue;if(!nearbyRoads.has(k))nearbyRoads.set(k,[]);nearbyRoads.get(k).push(road);}
  for(const cell of paving.values()){
   const center={x:cell.x+.5,y:cell.y+.5};let best=null;
   for(const road of nearbyRoads.get(cell.k)||[]){const p=pointSegment(center,road.a,road.b);if(p.distance>1.01||best&&p.distance>=best.distance||!clearEntrancePath(center,p,buildings,t.rivers||[]))continue;best=p;}
   if(best){const via=places.find(place=>place.direct&&Math.hypot(place.direct.x-best.x,place.direct.y-best.y)<.56)?.b.id??null;paths.set(cell.k,{...best,shared:true,paved:true,via});queue.push(cell.k);}
  }
  // Four-way neighbours share a full tile edge. Diagonal corner contact alone
  // is not a walkable path, and buildings never act as links across grass.
  for(let i=0;i<queue.length;i++){
   const k=queue[i],cell=paving.get(k),route=paths.get(k);
   for(const [x,y]of neighbors(cell.x,cell.y)){const next=key(x,y);if(!paving.has(next))continue;const distance=route.distance+1,old=paths.get(next);if(old&&old.distance<=distance+1e-9)continue;paths.set(next,{...route,distance});queue.push(next);}
  }
  for(const place of places){if(place.direct)continue;let best=null;const ownCells=new Set(cells(place.b));
   for(const cell of paving.values()){
    const route=paths.get(cell.k);if(!route)continue;
    const p=place.e.approach,center={x:cell.x+.5,y:cell.y+.5};
    // Connect the front approach to the pavement, never to unrelated paving
    // elsewhere beside or behind the building.
    const gap=Math.hypot(Math.max(cell.x-p.x,0,p.x-cell.x-1),Math.max(cell.y-p.y,0,p.y-cell.y-1));
    if(gap>.56||(center.x-place.e.x)*place.e.dx+(center.y-place.e.y)*place.e.dy<=.1||!clearEntrancePath(p,center,buildings,t.rivers||[]))continue;
    // A rotated lot can occupy the approach's whole grid tile, which the
    // brush cannot paint. Permit only that unpaintable boundary sliver;
    // every paintable tile between the entrance and path must be paved.
    const steps=Math.max(1,Math.ceil(Math.hypot(center.x-p.x,center.y-p.y)/.08));let covered=true;
    for(let i=0;i<=steps;i++){const x=p.x+(center.x-p.x)*i/steps,y=p.y+(center.y-p.y)*i/steps,k=key(Math.floor(x),Math.floor(y));if((x<cell.x-1e-7||x>cell.x+1+1e-7||y<cell.y-1e-7||y>cell.y+1+1e-7)&&!ownCells.has(k)){covered=false;break;}}
    if(!covered)continue;
    const distance=route.distance+Math.hypot(p.x-center.x,p.y-center.y);if(!best||distance<best.distance)best={...route,distance};
   }
   if(best)access.set(place.b.id,best);
  }
 }
 entranceCache.set(t,{graph,stamp,connected,access});return access;
}
export function entranceAccess(t,b,{back=false,connected=false}={}){
 if(back)return directEntranceAccess(t,b,roadGraph({roads:t.rails||[],roadEdges:t.railEdges||[]}),connected?connectedNodes(t):null,true);
 return entranceConnections(t,connected,b).get(b.id)||null;
}
function arrivalPoint(b,access){if(!access)return null;return access.shared||access.distance>.56?{x:access.x,y:access.y}:entrance(b).approach;}
export function entranceTarget(t,b){return arrivalPoint(b,entranceAccess(t,b,{connected:true}));}
export function connectedRoads(t){const nodes=connectedNodes(t);return new Set(t.roads.filter(k=>{const p=xy(k);return nodes.has(nodeKey(p.x,p.y));}));}
export function readiness(t){const missing=REQUIRED_CATALOG.filter(c=>!t.buildings.some(b=>b.type===c.id)),blocked=t.buildings.filter(b=>hasEntrance(b)&&!entranceAccess(t,b,{connected:true})),railBlocked=t.buildings.filter(b=>b.type==='station'&&!entranceAccess(t,b,{back:true}));const transport=validateTransport(t);return {ready:!!t.start&&!missing.length&&!blocked.length&&!railBlocked.length&&transport.valid,missing,blocked,railBlocked,transport,connected:connectedRoads(t)};}
// Progress is stored independently of grid stride: locked towns still use 60-column keys.
export const EXPANSION_BUILDINGS=50;
export const FULL_MAP_BUILDINGS=70;
export const buildingCount=t=>(t.buildings||[]).length;
function savedExpansionFootprint(t,source){
 const version=t.v??5,b={...source,rotation:version<3?source.rotation*2:source.rotation,plot:version<4?1:(source.plot??1),variant:version<4?0:(source.variant??0)};
 // Judge the lot that was actually placed, before model replacements remove
 // it. Later enlargements and newer save-format fields cannot earn expansion.
 const oldLot=b.type==='university'&&t.universityLayout!==2?[10,7]:b.type==='shopping-mall'&&t.mallLayout!==2?[8,5]:null;
 if(!oldLot)return footprint(b);
 const [w,d]=oldLot,a=b.rotation*Math.PI/4;
 return {w:Math.ceil(Math.abs(w*Math.cos(a))+Math.abs(d*Math.sin(a))-1e-8),d:Math.ceil(Math.abs(w*Math.sin(a))+Math.abs(d*Math.cos(a))-1e-8)};
}
export function usesExpandedLand(t,width=LEGACY_WIDTH,height=LEGACY_HEIGHT){
 const outside=(x,y)=>x>=width||y>=height;
 if(t.start&&outside(t.start.x,t.start.y))return true;
 if(['roads','rails','rivers','flowers','pavement'].some(layer=>(t[layer]||[]).some(k=>{const p=xy(k);return outside(p.x,p.y);})))return true;
 return (t.buildings||[]).some(b=>{if(!byType[b?.type])return false;const f=savedExpansionFootprint(t,b);return b.x+f.w>width||b.y+f.d>height;});
}
export function advanceTownProgress(t,{grandfather=false}={}){
 const oldFull=t.expansionStages!==2&&t.expandedUnlocked===true;
 t.expansionStages=2;
 t.fullMapUnlocked=t.fullMapUnlocked===true||oldFull||buildingCount(t)>=FULL_MAP_BUILDINGS||(grandfather&&usesExpandedLand(t,WIDTH,LEGACY_HEIGHT));
 t.progressionVersion=1;
 t.optionalUnlocked=t.optionalUnlocked===true||readiness(t).ready;
 t.expandedUnlocked=t.expandedUnlocked===true||t.fullMapUnlocked===true||buildingCount(t)>=EXPANSION_BUILDINGS||(grandfather&&usesExpandedLand(t));
 return t;
}
export function buildArea(t,staff=false){return staff||t.fullMapUnlocked===true||t.expansionStages!==2&&t.expandedUnlocked===true?{width:WIDTH,height:HEIGHT}:t.expandedUnlocked===true?{width:WIDTH,height:LEGACY_HEIGHT}:{width:LEGACY_WIDTH,height:LEGACY_HEIGHT};}
export function canAddOptional(t,type,staff=false){return staff||!byType[type]?.optional||t.optionalUnlocked===true;}
export function preserveTownProgress(previous,next){
 // Undo and rollback snapshots may predate a canonical progress correction.
 // Carry trusted current grants, then evaluate the restored layout itself.
 next.optionalUnlocked=previous?.optionalUnlocked===true;
 next.expandedUnlocked=previous?.expandedUnlocked===true;
 next.expansionStages=2;
 next.fullMapUnlocked=previous?.fullMapUnlocked===true||previous?.expansionStages!==2&&previous?.expandedUnlocked===true;
 return advanceTownProgress(next);
}
// Only the stored town grants previous access. Browser-supplied unlock flags
// cannot bypass either gate; old tabs can still save existing optional places.
export function validateStudentProgress(previous,incoming,{staff=false}={}){
 const before=previous?validateTown(previous):blankTown(),next=validateTown(incoming);
 next.optionalUnlocked=before.optionalUnlocked;
 next.expandedUnlocked=before.expandedUnlocked;
 next.expansionStages=2;next.fullMapUnlocked=before.fullMapUnlocked;
 advanceTownProgress(next);
 // A student may finish the checklist and place an optional building before
 // the autosave debounce fires. Its initially unconnected entrance must not
 // erase the readiness achievement that permitted the placement.
 if(!next.optionalUnlocked){const earned={...next,buildings:next.buildings.filter(b=>!byType[b.type].optional||before.buildings.some(old=>old.id===b.id&&old.type===b.type))};if(readiness(earned).ready)next.optionalUnlocked=true;}
 if(!staff){
  // Erasing and rebuilding can share one autosave. Judge the completed layout,
  // rather than keeping a repaired town blocked by its last saved violation.
  if(addedRoad(before,next)&&!roadRules(next).valid)throw Error('Please remove roads to fix the road limit or junctions before adding roads.');
  if(!next.optionalUnlocked&&next.buildings.some(b=>byType[b.type].optional&&!before.buildings.some(old=>old.id===b.id&&old.type===b.type)))throw Error('Invalid progression: optional buildings unlock when your town meets the Directions requirements. Refresh the game; your local changes are retained.');
  if(usesExpandedLand(next,buildArea(next).width,buildArea(next).height))throw Error('Invalid progression: the right side unlocks at 50 buildings and the bottom at 70. Refresh the game; your local changes are retained.');
 }else if(usesExpandedLand(next)){next.expandedUnlocked=true;if(usesExpandedLand(next,WIDTH,LEGACY_HEIGHT))next.fullMapUnlocked=true;}
 return next;
}
export function revealAt(t,x,y,seen){const found=[],access=entranceConnections(t,true);for(const b of t.buildings)if(hasEntrance(b)&&!seen.has(b.id)){const p=arrivalPoint(b,access.get(b.id))||entrance(b).approach;if(p&&Math.hypot(x+.5-p.x,y+.5-p.y)<1.15){seen.add(b.id);found.push(b);}}return found;}
export function roadLine(a,b){const p=[a];let x=a.x,y=a.y;while(x!==b.x||y!==b.y){if(x!==b.x){x+=Math.sign(b.x-x);p.push({x,y});}if(y!==b.y){y+=Math.sign(b.y-y);p.push({x,y});}}return p;}
function validCells(raw){if(!Array.isArray(raw)||raw.length>WIDTH*HEIGHT||raw.some(k=>!Number.isInteger(k)||k<0||k>=WIDTH*HEIGHT))throw Error('Invalid map data.');return [...new Set(raw)];}
function validEdges(raw,nodes){if(!Array.isArray(raw)||raw.length>6000)throw Error('Invalid road data.');const set=new Set(nodes),out=new Map();for(const e of raw){if(!Array.isArray(e)||e.length!==2||!Number.isInteger(e[0])||!Number.isInteger(e[1])||!set.has(e[0])||!set.has(e[1])||e[0]===e[1])throw Error('Invalid road data.');const a=e[0],b=e[1];if(Math.max(Math.abs(a%WIDTH-b%WIDTH),Math.abs(Math.floor(a/WIDTH)-Math.floor(b/WIDTH)))!==1)throw Error('Invalid road connections.');const lo=Math.min(a,b),hi=Math.max(a,b);out.set(lo*WIDTH*HEIGHT+hi,[lo,hi]);}return [...out.values()];}
export function validateTown(raw){if(!raw||![1,2,3,4,5].includes(raw.v)||!Array.isArray(raw.buildings)||raw.buildings.length>MAX_BUILDINGS)throw Error('Invalid town data.');const source=sourceGrid(raw);raw=expandTownGrid(raw);const legacyExpanded=raw.progressionVersion!==1&&usesExpandedLand(raw),legacyFull=raw.progressionVersion!==1&&usesExpandedLand(raw,WIDTH,LEGACY_HEIGHT);const t=blankTown(),ids=new Set();t.roads=validCells(raw.roads);t.rivers=validCells(raw.rivers??[]);t.rails=validCells(raw.rails??[]);t.flowers=validCells(raw.flowers??[]);t.pavement=validCells(raw.pavement??[]);t.roadEdges=validEdges(raw.roadEdges??migrateRoadEdges(t.roads),t.roads);t.railEdges=validEdges(raw.railEdges??migrateRoadEdges(t.rails),t.rails);const roadFootprint=new Set(t.flowers.length||t.pavement.length?[...transportGroundCells(t),...t.rivers]:[]);t.pavement=t.pavement.filter(k=>!roadFootprint.has(k));t.flowers=t.flowers.filter(k=>!roadFootprint.has(k)&&!t.pavement.includes(k));if(raw.start!==null){if(!raw.start||!inside(raw.start.x,raw.start.y)||!t.roads.includes(key(raw.start.x,raw.start.y)))throw Error('Invalid start position.');t.start={x:raw.start.x,y:raw.start.y};}const placement=placementValidator(t);for(const r of raw.buildings){if(r?.type==='apartment'&&raw.apartmentFacing!==2)continue;if(r?.type==='shopping-mall'&&raw.mallLayout!==2)continue;if(r?.type==='university'&&raw.universityLayout!==2)continue;if(!r||!byType[r.type]||!Number.isInteger(r.id)||r.id<1||r.id>1000000||ids.has(r.id)||!Number.isInteger(r.rotation)||r.rotation<0||r.rotation>(raw.v>=3?7:3)||![2,3,5].includes(r.size))throw Error('Invalid building data.');const plot=raw.v>=4?(r.plot??1):1,variant=raw.v>=4?(r.variant??0):0;if(![1,2,3,4].includes(plot)||(plot===3&&!V6_LOTS[r.type])||(plot===4&&!V15_LOTS[r.type])||!Number.isInteger(variant)||variant<0||variant>=variantCount(r.type))throw Error('Invalid building type.');const b={id:r.id,type:r.type,x:r.x,y:r.y,size:r.size,rotation:raw.v>=3?r.rotation:r.rotation*2,plot,variant};const bounds=footprint(b);if(b.x<0||b.y<0||b.x+bounds.w>source.width||b.y+bounds.d>source.height||!placement(b))throw Error('Buildings overlap or are outside the town.');t.buildings.push(b);ids.add(b.id);}migrateEnlargedLots(t);const occupiedLots=new Set(t.buildings.flatMap(cells));t.pavement=t.pavement.filter(k=>!occupiedLots.has(k));t.flowers=t.flowers.filter(k=>!occupiedLots.has(k));t.points=validatePointPlacements(raw.points??[],t.buildings);t.optionalUnlocked=raw.progressionVersion===1&&raw.optionalUnlocked===true;t.expandedUnlocked=legacyExpanded||raw.progressionVersion===1&&raw.expandedUnlocked===true;t.fullMapUnlocked=raw.expansionStages===2?raw.fullMapUnlocked===true:raw.progressionVersion===1&&raw.expandedUnlocked===true;t.fullMapUnlocked||=legacyFull;return advanceTownProgress(t);}
// Source lots have already passed validation. Only the four enlarged types may
// move or be removed; reserve every unaffected lot while seeking their new fit.
function migrateEnlargedLots(t){
 const source=t.buildings,changed=source.filter(b=>V15_LOTS[b.type]&&b.plot!==4);
 if(!changed.length)return;
 const changedIds=new Set(changed.map(b=>b.id));
 t.buildings=source.filter(b=>!changedIds.has(b.id));
 for(const old of changed){
  const next={...old,plot:4},before=entrance(old),after=entrance(next);
  const ideal={x:old.x+before.x-after.x,y:old.y+before.y-after.y};
  const connected=!!entranceAccess(t,old,{connected:true}),access=connected||!!entranceAccess(t,old);
  const candidates=[];
  for(let y=Math.floor(ideal.y)-1;y<=Math.ceil(ideal.y)+1;y++)for(let x=Math.floor(ideal.x)-1;x<=Math.ceil(ideal.x)+1;x++){
   const candidate={...next,x,y},e=entrance(candidate);
   candidates.push({candidate,distance:Math.hypot(e.x-before.x,e.y-before.y),movement:Math.hypot(x-old.x,y-old.y)});
  }
  candidates.sort((a,b)=>a.distance-b.distance||a.movement-b.movement||a.candidate.y-b.candidate.y||a.candidate.x-b.candidate.x);
  const fit=candidates.find(({candidate})=>canPlace(t,candidate)&&(!access||entranceAccess(t,candidate,{connected})));
  if(fit)t.buildings.push(fit.candidate);
 }
 const byId=new Map(t.buildings.map(b=>[b.id,b]));t.buildings=source.map(b=>byId.get(b.id)).filter(Boolean);
}
export function exampleTown(){
 const t=blankTown(),rows=[
  {road:6,types:['house','park','library','museum','hospital','bus-stop','convenience-store','shrine','church']},
  {road:15,types:['stadium','amusement-park','castle','aquarium']},
  {road:23,types:['zoo','elementary-school','junior-high-school','supermarket','temple']},
  {road:30,types:['station','police-station','fire-station','post-office','bookstore','restaurant']}
 ];
 for(const row of rows){for(let x=0;x<WIDTH;x++)t.roads.push(key(x,row.road));let x=2;
  for(const type of row.types){const c=byType[type],b={id:CATALOG.indexOf(c)+1,type,x,y:row.road-c.d,size:3,rotation:0,plot:newPlot(type),variant:0};t.buildings.push(b);x+=c.w+1;}}
 for(let y=0;y<HEIGHT;y++)t.roads.push(key(0,y));t.roads=[...new Set(t.roads)];t.roadEdges=migrateRoadEdges(t.roads);t.buildings.sort((a,b)=>a.id-b.id);
 const station=t.buildings.find(b=>b.type==='station');for(let x=station.x;x<station.x+lotSize(station).w;x++)t.rails.push(key(x,station.y-1));t.railEdges=migrateRoadEdges(t.rails);t.start={x:0,y:6};return validateTown(t);
}
