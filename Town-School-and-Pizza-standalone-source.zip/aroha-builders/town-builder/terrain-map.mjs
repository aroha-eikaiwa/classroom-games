import {WIDTH,HEIGHT,xy,key} from './core.mjs';
import {roadGraph} from './network.mjs';
import {validateTransport} from './transport.mjs';
// Packed river field: R = depth, G = water coverage, B = exposed-bank coverage.
// Work is done only after the river changes, never in the animation loop. The
// smooth distance field removes grid corners while preserving every painted cell.
const clamp01 = n => Math.max(0, Math.min(1, n));
const smoothstep = (a, b, n) => { const t = clamp01((n - a) / (b - a)); return t * t * (3 - 2 * t); };
export function makeRiverField(t, res = 24) {
 const width = WIDTH * res, height = HEIGHT * res, count = width * height;
 const data = new Uint8ClampedArray(count * 4), field = new Float32Array(count);
 field.fill(-1);
 const set = new Set((t.rivers || []).filter(k => Number.isInteger(k) && k >= 0 && k < WIDTH * HEIGHT));
 if (!set.size) return {width, height, data, riverCount: 0};
 const radius = .54, reach = radius + .28;
 let minX = width, minY = height, maxX = 0, maxY = 0;
 for (const k of set) {
  const p = xy(k);
  minX = Math.min(minX, Math.max(0, Math.floor((p.x + .5 - reach) * res)));
  minY = Math.min(minY, Math.max(0, Math.floor((p.y + .5 - reach) * res)));
  maxX = Math.max(maxX, Math.min(width - 1, Math.ceil((p.x + .5 + reach) * res)));
  maxY = Math.max(maxY, Math.min(height - 1, Math.ceil((p.y + .5 + reach) * res)));
 }
 minX = Math.max(0, minX - 3); minY = Math.max(0, minY - 3);
 maxX = Math.min(width - 1, maxX + 3); maxY = Math.min(height - 1, maxY + 3);
 const stamp = (ax, ay, bx, by) => {
  const dx = bx - ax, dy = by - ay, len2 = dx * dx + dy * dy;
  const x0 = Math.max(0, Math.floor((Math.min(ax, bx) - reach) * res));
  const x1 = Math.min(width - 1, Math.ceil((Math.max(ax, bx) + reach) * res));
  const y0 = Math.max(0, Math.floor((Math.min(ay, by) - reach) * res));
  const y1 = Math.min(height - 1, Math.ceil((Math.max(ay, by) + reach) * res));
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
   const px = (x + .5) / res - ax, py = (y + .5) / res - ay;
   const u = len2 ? clamp01((px * dx + py * dy) / len2) : 0;
   const ex = px - u * dx, ey = py - u * dy;
   const distance = radius - Math.sqrt(ex * ex + ey * ey);
   const i = y * width + x;
   if (distance > field[i]) field[i] = distance;
  }
 };
 for (const k of set) {
  const p = xy(k), cx = p.x + .5, cy = p.y + .5;
  if (p.x > 0 && p.x + 1 < WIDTH && p.y > 0 && p.y + 1 < HEIGHT &&
      [-1,0,1].every(dy => [-1,0,1].every(dx => set.has(key(p.x + dx, p.y + dy))))) {
   for (let y = p.y * res; y < (p.y + 1) * res; y++) field.fill(radius, y * width + p.x * res, y * width + (p.x + 1) * res);
   continue;
  }
  const neighbours = [];
  for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]]) {
   if (p.x + dx < 0 || p.x + dx >= WIDTH || p.y + dy < 0 || p.y + dy >= HEIGHT || !set.has(key(p.x + dx, p.y + dy))) continue;
   // Do not cut diagonally through a corner that already has an orthogonal
   // connection. This lets a one-cell stream follow a smooth centreline.
   if (dx && dy && (set.has(key(p.x + dx, p.y)) || set.has(key(p.x, p.y + dy)))) continue;
   neighbours.push([cx + dx * .5, cy + dy * .5]);
  }
  if (neighbours.length === 2) {
   const [a,b] = neighbours, bent = Math.abs((a[0]-cx)+(b[0]-cx)) + Math.abs((a[1]-cy)+(b[1]-cy)) > .01;
   if (!bent) stamp(a[0],a[1],b[0],b[1]);
   else {
    // A quadratic through neighbouring midpoints creates real curved bends,
    // rather than only rounding the outline of a zig-zag grid stroke.
    let ax=a[0], ay=a[1];
    for(let step=1;step<=4;step++) {
     const u=step/4,v=1-u,bx=v*v*a[0]+2*v*u*cx+u*u*b[0],by=v*v*a[1]+2*v*u*cy+u*u*b[1];
     stamp(ax,ay,bx,by);ax=bx;ay=by;
    }
   }
  } else {
   stamp(cx,cy,cx,cy);
   for(const [x,y] of neighbours)stamp(cx,cy,x,y);
  }
 }
 // A compact, separable blur rounds the inside bends of each joined capsule.
 const soft = new Float32Array(count), blur = 2; soft.fill(-1);
 for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
  let sum = 0; for (let d = -blur; d <= blur; d++) sum += field[y * width + Math.max(0, Math.min(width - 1, x + d))];
  soft[y * width + x] = sum / (blur * 2 + 1);
 }
 for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
  let sum = 0; for (let d = -blur; d <= blur; d++) sum += soft[Math.max(0, Math.min(height - 1, y + d)) * width + x];
  let distance = sum / (blur * 2 + 1);
  if (distance < -.24) continue;
  const wx = (x + .5) / res, wy = (y + .5) / res;
  // Gentle, deterministic irregularity avoids a machined outline without
  // changing collision cells or making a one-cell river discontinuous.
  distance += .021 * Math.sin(wx * 5.1 + wy * 2.8) + .012 * Math.sin(wy * 10.7 - wx * 6.3);
  const i = (y * width + x) * 4;
  data[i] = Math.round(smoothstep(.01, .56, distance) * 255);
  data[i + 1] = Math.round(smoothstep(-.018, .045, distance) * 255);
  data[i + 2] = Math.round(smoothstep(-.22, -.11, distance) * 255);
  data[i + 3] = 255;
 }
 // Actual distance to the shoreline supplies depth, rather than distance to
 // a cell centre: wide stretches cannot reveal a grid in their water colour.
 const maxDepth = res * .8, diagonal = Math.SQRT2;
 for (let i = 0; i < count; i++) field[i] = data[i * 4 + 1] >= 128 ? maxDepth : 0;
 for (let y = minY; y <= maxY; y++) for (let x = minX; x <= maxX; x++) {
  const i = y * width + x; if (!field[i]) continue;
  let value = field[i];
  if (x) value = Math.min(value, field[i - 1] + 1);
  if (y) value = Math.min(value, field[i - width] + 1);
  if (x && y) value = Math.min(value, field[i - width - 1] + diagonal);
  if (x + 1 < width && y) value = Math.min(value, field[i - width + 1] + diagonal);
  field[i] = value;
 }
 for (let y = maxY; y >= minY; y--) for (let x = maxX; x >= minX; x--) {
  const i = y * width + x; if (!field[i]) continue;
  let value = field[i];
  if (x + 1 < width) value = Math.min(value, field[i + 1] + 1);
  if (y + 1 < height) value = Math.min(value, field[i + width] + 1);
  if (x + 1 < width && y + 1 < height) value = Math.min(value, field[i + width + 1] + diagonal);
  if (x && y + 1 < height) value = Math.min(value, field[i + width - 1] + diagonal);
  field[i] = value;
  data[i * 4] = Math.round(smoothstep(0, .75, value / res) * 255);
 }
 return {width, height, data, riverCount: set.size};
}
// Compatibility for the non-WebGL renderer and external mask consumers.
export function makeRiverMask(canvas, t, res = 24) {
 const field = makeRiverField(t, res); canvas.width = field.width; canvas.height = field.height;
 const c = canvas.getContext('2d'), out = c.createImageData(field.width, field.height);
 for (let i = 0; i < field.data.length; i += 4) {
  out.data[i] = out.data[i + 1] = out.data[i + 2] = 255;
  out.data[i + 3] = field.data[i + 1];
 }
 c.putImageData(out, 0, 0); return canvas;
}
let roadImage=null,asphaltImage=null,roadPromise=null,roadRevision=0;
export const ROAD_GREY='#666666';
export const roadArtRevision=()=>roadRevision;
export const roadTextureImage=()=>roadImage;
function roadCanvases(image){
 if(typeof document==='undefined')return null;
 const asphalt=document.createElement('canvas');asphalt.width=asphalt.height=256;
 const c=asphalt.getContext('2d');if(!c)return null;
 c.fillStyle=ROAD_GREY;c.fillRect(0,0,256,256);
 if(image){c.filter='grayscale(1) brightness(1.35)';c.drawImage(image,0,0,256,256);c.filter='none';c.fillStyle='rgba(128,128,128,.20)';c.fillRect(0,0,256,256);}
 const tile=document.createElement('canvas');tile.width=512;tile.height=256;
 const t=tile.getContext('2d');if(!t)return null;
 t.drawImage(asphalt,0,0);t.drawImage(asphalt,256,0);
 // Four complete .41-unit dash periods make the bridge tile seamless.
 const unit=256/.82;t.strokeStyle='#e7c85a';t.lineWidth=.03*unit;
 for(const y of [-.36,.36]){t.beginPath();t.moveTo(0,128+y*unit);t.lineTo(512,128+y*unit);t.stroke();}
 t.strokeStyle='#f4f2e6';t.lineWidth=.035*unit;t.setLineDash([.21*unit,.20*unit]);
 t.beginPath();t.moveTo(0,128);t.lineTo(512,128);t.stroke();
 return {asphalt,tile};
}
export function loadRoadTexture(){return Promise.resolve(false);}
// Trace each edge once, through bends and ordinary degree-two road nodes.
// A single stroke preserves dash spacing instead of restarting at every cell.
export function roadMarkingPaths(g){
 const visited=new Set(),paths=[],nodes=[...g.nodes.values()].sort((a,b)=>a.x-b.x||a.y-b.y);
 const edge=(a,b)=>a.id<b.id?a.id+'|'+b.id:b.id+'|'+a.id;
 const neighbors=n=>[...n.neighbors].map(id=>g.nodes.get(id)).sort((a,b)=>a.x-b.x||a.y-b.y);
 const walk=(start,next)=>{
  const path=[start];let a=start,b=next;
  while(!visited.has(edge(a,b))){visited.add(edge(a,b));path.push(b);if(b.neighbors.size!==2)break;const n=neighbors(b).find(n=>n.id!==a.id);a=b;b=n;}
  paths.push(path);
 };
 for(const n of nodes)if(n.neighbors.size!==2)for(const next of neighbors(n))if(!visited.has(edge(n,next)))walk(n,next);
 // Remaining edges belong to closed loops.
 for(const n of nodes)for(const next of neighbors(n))if(!visited.has(edge(n,next)))walk(n,next);
 return paths;
}
// Leave real water visible below each elevated deck, rather than painting a
// second flat road/track across it. Clip works on both textures and the 2D view.
function clipBelowBridges(c,t,kind){
 const bridges=validateTransport(t).bridges.filter(b=>b.kind===kind);if(!bridges.length)return;
 c.beginPath();c.rect(0,0,WIDTH,HEIGHT);
 for(const b of bridges){b.polygon.forEach((p,i)=>i?c.lineTo(p.x+.5,p.y+.5):c.moveTo(p.x+.5,p.y+.5));c.closePath();}
 c.clip('evenodd');
}
export function paintRoadMap(c,t,res=40,preview=null,clear=true){
 if(clear)c.clearRect(0,0,WIDTH*res,HEIGHT*res);
 c.save();c.scale(res,res);clipBelowBridges(c,t,'road');c.lineCap='round';c.lineJoin='round';const g=roadGraph(t),paths=roadMarkingPaths(g);
 let asphalt=ROAD_GREY;
 if(asphaltImage&&c.createPattern&&typeof DOMMatrix!=='undefined'){const pattern=c.createPattern(asphaltImage,'repeat');if(pattern?.setTransform){pattern.setTransform(new DOMMatrix().scale(.82/(asphaltImage.naturalWidth||asphaltImage.width),.82/(asphaltImage.naturalHeight||asphaltImage.height)));asphalt=pattern;}}
 const path=(isolated=false)=>{c.beginPath();for(const points of paths){c.moveTo(points[0].x+.5,points[0].y+.5);for(const n of points.slice(1))c.lineTo(n.x+.5,n.y+.5);}if(isolated)for(const n of g.nodes.values())if(!n.neighbors.size){c.moveTo(n.x+.499,n.y+.5);c.lineTo(n.x+.501,n.y+.5);}};
 path(true);c.lineWidth=.98;c.strokeStyle='#c6cebd';c.stroke();path(true);c.lineWidth=.82;c.strokeStyle=asphalt;c.stroke();
 // Layer all outlines before all inner surfaces, so bends and joins have no
 // overlapping image rectangles or transverse yellow lines.
 path();c.lineWidth=.75;c.strokeStyle='#e7c85a';c.stroke();
 path();c.lineWidth=.69;c.strokeStyle=asphalt;c.stroke();
 path();c.lineCap='butt';c.setLineDash([.21,.20]);c.lineWidth=.035;c.strokeStyle='#f4f2e6';c.stroke();c.setLineDash([]);c.lineCap='round';
 for(const n of g.intersections){c.beginPath();c.arc(n.x+.5,n.y+.5,.43,0,Math.PI*2);c.fillStyle=asphalt;c.fill();for(const id of n.neighbors){const b=g.nodes.get(id),len=Math.hypot(b.x-n.x,b.y-n.y),dx=(b.x-n.x)/len,dy=(b.y-n.y)/len;for(let i=0;i<4;i++){const q=-.23+i*.15,x=n.x+.5+dx*.53-dy*q,y=n.y+.5+dy*.53+dx*q;c.beginPath();c.moveTo(x-dx*.08,y-dy*.08);c.lineTo(x+dx*.08,y+dy*.08);c.lineWidth=.035;c.strokeStyle='#f3f4de';c.stroke();}}}
 c.restore();
}
let trackImage=null,trackPromise=null,trackRevision=0;
export const trackArtRevision=()=>trackRevision;
export function loadTrackTexture(){return Promise.resolve(false);}
export function paintRailMap(c,t,res=40){
 const connected=new Set((t.railEdges||[]).flat());c.clearRect(0,0,WIDTH*res,HEIGHT*res);c.save();c.scale(res,res);clipBelowBridges(c,t,'rail');c.lineCap='round';
 let ballast='#a09b8c';
 if(trackImage&&c.createPattern&&typeof DOMMatrix!=='undefined'){const pattern=c.createPattern(trackImage,'repeat');if(pattern?.setTransform){pattern.setTransform(new DOMMatrix().scale(1.8/trackImage.naturalWidth,1.8/trackImage.naturalHeight));ballast=pattern;}}
 for(const [ka,kb]of t.railEdges||[]){
  const a=xy(ka),b=xy(kb),dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),nx=-dy/len,ny=dx/len;
  const segment=(offset,width,color)=>{c.beginPath();c.moveTo(a.x+.5+nx*offset,a.y+.5+ny*offset);c.lineTo(b.x+.5+nx*offset,b.y+.5+ny*offset);c.lineWidth=width;c.strokeStyle=color;c.stroke();};
  segment(0,.78,'#aaa899');segment(0,.72,ballast);
  const ties=Math.max(1,Math.round(len/.20));
  for(let i=0;i<=ties;i++){
   const u=i/ties,x=a.x+.5+dx*u,y=a.y+.5+dy*u;
   const tie=(width,color,shift=0)=>{c.beginPath();c.moveTo(x+nx*.31+dx*shift,y+ny*.31+dy*shift);c.lineTo(x-nx*.31+dx*shift,y-ny*.31+dy*shift);c.lineWidth=width;c.strokeStyle=color;c.stroke();};
   tie(.080,'#4d514b');tie(.048,'#a8a394',-.012);
   for(const side of [-1,1]){c.beginPath();c.arc(x+nx*.20*side,y+ny*.20*side,.034,0,Math.PI*2);c.fillStyle='#585c55';c.fill();}
  }
  for(const side of [-1,1]){segment(.20*side,.066,'#615c4c');segment(.20*side,.037,'#c4cbc4');segment(.20*side-.008,.011,'#f0f0de');}
 }
 for(const k of t.rails||[]){if(connected.has(k))continue;const{x,y}=xy(k);c.fillStyle=ballast;c.fillRect(x+.14,y+.14,.72,.72);c.strokeStyle='#dedfd6';c.lineWidth=.04;for(const side of [.3,.7]){c.beginPath();c.moveTo(x+side,y+.2);c.lineTo(x+side,y+.8);c.stroke();}}
 c.restore();
}
