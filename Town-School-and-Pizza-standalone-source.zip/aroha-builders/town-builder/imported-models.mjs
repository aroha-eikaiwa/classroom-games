import * as THREE from './vendor/three.module.js';
import {lighterApartment} from './apartment-variant.mjs';
import {base64Bytes} from './base64-bytes.mjs';
import {loadImportedLandscape,attachImportedLandscape} from './imported-landscape.mjs';
import {appendImportedGroundSupports} from './imported-supports.mjs';

// Optimized mesh data stays in binary asset responses, outside the JS bundle.
export const IMPORTED_MODELS=Object.freeze(['house-milestone','house-japanese','restaurant-japanese','bakery','apartment','apartment-light','stadium','skyline','ambulance','fire-truck','police','cinema','porsche','airport','bank','high-school','university','hotel','hotel-marina','factory','factory-restored','city-hall','prison','japanese-garden','temple-pagoda']);
const models=new Map(),pending=new Map(),textures=new Map(),approaches=new Map();let revision=0;
const pathMaterial=new THREE.MeshStandardMaterial({color:'#c9bca6',roughness:.95});pathMaterial.userData.shared=true;
export const importedModelsRevision=()=>revision;
export const importedModelRevision=name=>models.has(name)?1:0;
export function importedModelName(b){
 if(b.type==='park'&&b.variant===2)return 'japanese-garden';
 if(b.type==='temple'&&b.variant===1)return 'temple-pagoda';
 if(b.type==='house')return b.variant===6?'house-milestone':b.variant===7?'house-japanese':null;
 if(b.type==='restaurant')return b.variant===5?'restaurant-japanese':null;
 if(b.type==='hotel')return b.variant===1?'hotel-marina':'hotel';
 if(b.type==='factory')return b.variant===1?'factory-restored':'factory';
 if(b.type==='apartment')return b.variant===1?'apartment-light':'apartment';
 return ['bakery','stadium','cinema','airport','bank','high-school','university','city-hall','prison'].includes(b.type)?b.type:null;
}
function loadTexture(name,color=false,flipY=true){return Promise.resolve(false);}
export function packedGeometry(part){
 if(part.encoding!=='quantized16-v1'||![2,4].includes(part.indexBytes))throw Error('Unsupported packed model geometry');
 const vertices=base64Bytes(part.vertices),source=new DataView(vertices.buffer),values=new Float32Array(vertices.length/2);
 if(vertices.length%16||part.min.length!==8||part.step.length!==8)throw Error('Invalid packed model vertices');
 for(let i=0;i<values.length;i++)values[i]=part.min[i%8]+source.getUint16(i*2,true)*part.step[i%8];
 const indexBytes=base64Bytes(part.indices),indices=part.indexBytes===2?new Uint16Array(indexBytes.length/2):new Uint32Array(indexBytes.length/4),view=new DataView(indexBytes.buffer);
 for(let i=0;i<indices.length;i++)indices[i]=part.indexBytes===2?view.getUint16(i*2,true):view.getUint32(i*4,true);
 const buffer=new THREE.InterleavedBuffer(values,8),geometry=new THREE.BufferGeometry();
 geometry.setAttribute('position',new THREE.InterleavedBufferAttribute(buffer,3,0));
 geometry.setAttribute('normal',new THREE.InterleavedBufferAttribute(buffer,3,3));
 geometry.setAttribute('uv',new THREE.InterleavedBufferAttribute(buffer,2,6));
 geometry.setIndex(new THREE.BufferAttribute(indices,1));geometry.computeBoundingBox();geometry.computeBoundingSphere();return geometry;
}
async function makeMaterial(spec){
 // These supplied atlases contain real cutout alpha. Keep them opaque in the
 // render queue, discarding the empty pixels in both colour and shadow passes.
 const alphaTest=spec.alphaTest??(['bakery-foliage','bakery-bike'].includes(spec.key)?.4:0);
 const [map,normalMap,roughnessMap,metalnessMap,emissiveMap]=await Promise.all(['map','normalMap','roughnessMap','metalnessMap','emissiveMap'].map(key=>spec[key]?loadTexture(spec[key],key==='map'||key==='emissiveMap',spec.flipY??true):null));
 const common={map,color:new THREE.Color().setRGB(...(spec.color||[1,1,1])),side:THREE.DoubleSide,alphaTest,transparent:!!spec.transparent,opacity:spec.opacity??1,depthWrite:!spec.transparent};
 // Scanned/baked source materials already contain their lighting. Applying
 // dynamic PBR shading again muddies the facade and exaggerates mesh seams.
 const material=spec.unlit?new THREE.MeshBasicMaterial(common):new THREE.MeshStandardMaterial({...common,normalMap,roughnessMap,metalnessMap,emissiveMap,roughness:spec.roughness??.8,metalness:spec.metalness??0});
 if(spec.emissive){material.emissive.setRGB(...spec.emissive);material.emissiveIntensity=spec.emissiveIntensity??1;}
 material.name=spec.key;material.userData.shared=true;return material;
}
export function loadImportedModel(name){return Promise.resolve(false);}
export async function loadImportedModels(){const loaded=await Promise.all(IMPORTED_MODELS.map(loadImportedModel));return loaded.every(Boolean);}
function instanceMaterial(material,variant,privateMaterials){
 if(!variant.startsWith('ghost'))return material;
 if(!privateMaterials.has(material)){
  const clone=material.clone();clone.userData.shared=false;clone.transparent=true;clone.opacity=Math.min(material.opacity,.66);clone.depthWrite=false;
  if(variant==='ghost-invalid')clone.color.set('#ef7575');privateMaterials.set(material,clone);
 }
 return privateMaterials.get(material);
}
export function createImportedModel(name,variant='normal'){
 const model=models.get(name);if(!model)return null;
 const group=new THREE.Group(),wheelGroups=new Map(),privateMaterials=new Map();group.name=name;group.userData.importedModel=name;group.userData.front=model.front;group.userData.lot=model.lot;group.userData.approach=model.approach;
 for(const part of model.parts){
  const mesh=new THREE.Mesh(part.geometry,instanceMaterial(part.material,variant,privateMaterials));mesh.name=part.name||part.material.name;mesh.userData.sharedGeometry=true;mesh.userData.groundSupport=!!part.groundSupport;
  mesh.castShadow=!variant.startsWith('ghost')&&!part.material.transparent&&part.shadowCaster!==false;mesh.receiveShadow=true;mesh.userData.shadowCaster=mesh.castShadow;
  if(part.role==='wheel'){
   if(!wheelGroups.has(part.wheel)){const pivot=new THREE.Group(),spin=new THREE.Group();pivot.position.fromArray(part.pivot);pivot.add(spin);group.add(pivot);wheelGroups.set(part.wheel,{pivot,spin,front:!!part.front});}
   wheelGroups.get(part.wheel).spin.add(mesh);
  }else group.add(mesh);
 }
 if(model.parkedAircraft)model.parkedAircraft.forEach((p,i)=>{const plane=createImportedModel('airport-plane',variant);if(!plane)return;plane.name='parked-jet-'+i;plane.position.set(p.x,p.y,p.z);plane.rotation.y=-p.heading;group.add(plane);});
 if(model.landscapeTrees)attachImportedLandscape(group,model.landscapeTrees,variant);
 if(wheelGroups.size){
  group.userData.wheels=[...wheelGroups.values()];
  group.userData.update=(dt,speed=0,turn=0)=>{
   const delta=Math.min(.08,Math.max(0,dt||0)),steer=THREE.MathUtils.clamp(turn,-1,1)*.24;
   for(const {pivot,spin,front}of wheelGroups.values()){spin.rotation.x-=speed*delta/.063329;if(front)pivot.rotation.y=THREE.MathUtils.lerp(pivot.rotation.y,steer,Math.min(1,delta*12));}
  };
 }
 return group;
}
export function createImportedBuilding(b,variant='normal',size){
 const name=importedModelName(b),group=createImportedModel(name,variant);if(!group)return null;
 const lot=group.userData.lot,scale=size&&lot?Math.min(size.w/lot[0],size.d/lot[1]):1;
 if(lot){
  // A visible, centered approach joins the prepared +Z frontage to the lot edge.
  const points=(group.userData.approach||[[0,0],[0,lot[1]/2]]).map(point=>[...point]);
  // Uniformly enlarged models can leave unequal lot padding. Extend the last
  // walking segment in source coordinates to the actual saved front boundary.
  if(size)points.at(-1)[1]=size.d/(2*scale);
  const key=lot.join('x')+JSON.stringify(points);
  if(!approaches.has(key)){const positions=[];for(let i=1;i<points.length;i++){const [ax,az]=points[i-1],[bx,bz]=points[i],length=Math.hypot(bx-ax,bz-az),dx=(bz-az)/length*.21,dz=-(bx-ax)/length*.21,a=[ax+dx,.006,az+dz],b=[ax-dx,.006,az-dz],c=[bx-dx,.006,bz-dz],d=[bx+dx,.006,bz+dz];positions.push(...a,...b,...d,...b,...c,...d);}const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.computeVertexNormals();approaches.set(key,geometry);}
  const path=new THREE.Mesh(approaches.get(key),instanceMaterial(pathMaterial,variant,new Map()));path.name='entrance-approach';path.userData.sharedGeometry=true;path.userData.shadowCaster=false;path.receiveShadow=true;group.add(path);
 }
 if(size&&lot)group.scale.setScalar(scale);
 // The stadium's exporter has a sub-millimetre negative base. Keep it above grass.
 group.position.y=.004;return group;
}
