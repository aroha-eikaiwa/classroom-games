// Transient taxi cues share the GPS arrival target; nothing is stored in a town.
export const TAXI_DROPOFF_RADIUS=.85;
export const TAXI_APPROACH_DISTANCE=8;
export const TAXI_EXIT_SECONDS=.6;
export const TAXI_DANCE_SECONDS=2;
export const TAXI_DANCER_MODEL='taxi-dancer';
export const TAXI_DANCE_SPEED=3;
export const TAXI_PASSENGER_MODELS=Object.freeze([TAXI_DANCER_MODEL,'taxi-clapper','taxi-groover']);
export function taxiReactionOptions(model=TAXI_DANCER_MODEL){return [model==='taxi-clapper'?'clap':model==='taxi-groover'?'cheer':'dance','walk','fly','jump','wave'];}
export function chooseTaxiReaction(random,model,previous){
 const choices=taxiReactionOptions(model).filter(r=>r!==previous),value=random();
 return choices[Math.max(0,Math.min(choices.length-1,Math.floor((Number.isFinite(value)?value:0)*choices.length)))];
}

export function taxiDropoffMarker(challenge,avatar){
 const target=challenge?.gps?.plan?.arrivalTarget;
 if(challenge?.phase!=='ride'||!challenge.destination||!avatar||!target)return null;
 if(Math.hypot(avatar.x+.5-target.x,avatar.y+.5-target.y)>TAXI_APPROACH_DISTANCE)return null;
 return {x:target.x,z:target.y,radius:TAXI_DROPOFF_RADIUS,building:challenge.destination.id,pulse:(1+Math.sin(challenge.clock*Math.PI*3))/2};
}

export function taxiPassengerPose(challenge,p,phase=p.index||0){
 const t=challenge.clock,waiting=p!==challenge.passenger&&p.availableAt<=t;
 let x=p.x,z=p.z,heading=p.heading,clip='stand',clock=t+phase,base=0,hidden=!waiting,tiltX=0,scale=1,reaction=null;
 if(p===challenge.passenger&&p.board&&t-p.board.time<.65){
  const u=Math.max(0,(t-p.board.time)/.65);x=p.board.x+(p.board.tx-p.board.x)*u;z=p.board.z+(p.board.tz-p.board.z)*u;clip='walk';hidden=false;
 }else if(p.exit){
  const e=p.exit,elapsed=t-e.time,delivered=e.kind==='delivered',duration=delivered?TAXI_EXIT_SECONDS+TAXI_DANCE_SECONDS:2.5;
  if(elapsed>=0&&elapsed<duration){
   const u=Math.min(1,elapsed/(delivered?TAXI_EXIT_SECONDS:1.1));x=e.x+(e.tx-e.x)*u;z=e.z+(e.tz-e.z)*u;heading=e.heading??heading;base=e.base||0;hidden=false;
   clip='walk';clock=elapsed;
   if(delivered&&elapsed>=TAXI_EXIT_SECONDS){
    const age=elapsed-TAXI_EXIT_SECONDS,u=age/TAXI_DANCE_SECONDS;reaction=e.reaction||'dance';
    if(reaction==='walk'){x=e.tx+((e.walkX??e.tx)-e.tx)*u;z=e.tz+((e.walkZ??e.tz)-e.tz)*u;}
    else if(reaction==='fly'){
     clip='fly';tiltX=Math.PI/2*Math.min(1,age/.35);heading+=Math.PI*Math.min(1,age/.2);const lift=u*u;
     // Turn away from the doorway and climb before travelling over the street.
     x+=Math.sin(heading)*2.2*lift;z+=Math.cos(heading)*2.2*lift;base+=.16*Math.min(1,age/.2)+2.6*u;scale=1-.8*Math.max(0,(u-.75)/.25);
    }else if(reaction==='jump'){clip='celebrate';base+=Math.abs(Math.sin(u*Math.PI*2))*.5;}
    else if(reaction==='wave'){clip='wave';clock=age;}
    else if(reaction==='clap'||reaction==='cheer'){clip='crowdReaction';clock=age*1.5;}
    else{clip='taxiDance';clock=age*TAXI_DANCE_SPEED;}
   }
  }
 }
 return {x,z,heading,clip,clock,base,hidden,tiltX,scale,reaction,tint:waiting&&challenge.phase==='searching'?(Math.sin(t*6)>0?'#43ff70':'#ffffff'):'#ffffff'};
}
