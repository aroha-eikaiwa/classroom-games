// Shared signal plans and clock for rendering, prediction and authoritative driving.
// Neighbour vectors point out of a junction, toward approaching traffic.
const plans=new WeakMap();
export function signalJunctions(graph){
 if(plans.has(graph))return plans.get(graph);
 const result=graph.intersections.map(n=>{
  const directions=[...n.neighbors].map(id=>{const p=graph.nodes.get(id),length=Math.hypot(p.x-n.x,p.y-n.y);return {dx:(p.x-n.x)/length,dy:(p.y-n.y)/length};});
  const canonical=directions.map(p=>p.dx<-.0001||Math.abs(p.dx)<.0001&&p.dy<0?{dx:-p.dx,dy:-p.dy}:p).sort((a,b)=>Math.atan2(a.dy,a.dx)-Math.atan2(b.dy,b.dx)),axes=[];
  for(const p of canonical)if(!axes.some(a=>Math.abs(a.dx*p.dx+a.dy*p.dy)>.9999))axes.push(p);
  return {id:n.id,x:n.x+.5,y:n.y+.5,phaseCount:axes.length,approaches:directions.map(p=>({...p,phase:axes.findIndex(a=>Math.abs(p.dx*a.dx+p.dy*a.dy)>.9999)}))};
 });plans.set(graph,result);return result;
}
// Each axis gets six seconds of green; two seconds of all-red clears the box.
export function signalAspect(phase,time,phaseCount=2){const t=Math.max(0,time||0),stage=Math.floor(t/8)%phaseCount;return t%8>=2&&stage===phase?'green':'red';}
export function redSignalAhead(junctions,current,next,time){
 const vx=next.x-current.x,vy=next.y-current.y,length=Math.hypot(vx,vy);if(length<1e-10||Math.abs(current.height||0)>.55)return null;
 const dx=vx/length,dy=vy/length,limit=.62+(current.halfLength??.45)+.10;
 for(const junction of junctions||[]){
  const x=current.x-junction.x,y=current.y-junction.y,along=-(x*dx+y*dy),across=Math.abs(x*dy-y*dx);
  // Cars already inside the stop line clear the junction, even after red.
  if(along<limit-1e-8||along-length>limit||across>.55)continue;
  let approach=null,score=-Infinity;
  for(const a of junction.approaches){const alignment=(x*a.dx+y*a.dy)/(Math.hypot(x,y)||1);if(a.dx*dx+a.dy*dy<-.5&&alignment>score){score=alignment;approach=a;}}
  if(approach&&score>.8&&(signalAspect(approach.phase,time,junction.phaseCount)==='red'||signalAspect(approach.phase,time+.05,junction.phaseCount)==='red'))return {junction,approach};
 }
 return null;
}
