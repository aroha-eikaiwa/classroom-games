import * as THREE from './vendor/three.module.js';
import {WIDTH, HEIGHT} from './core.mjs';
import {makeRiverField} from './terrain-map.mjs';

const vertexShader = `
 varying vec2 vUv;
 varying vec3 vWorld;
 void main() {
  vUv = uv;
  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorld = world.xyz;
  gl_Position = projectionMatrix * viewMatrix * world;
 }
`;
const fieldSample = `
 uniform sampler2D riverField;
 varying vec2 vUv;
 varying vec3 vWorld;
 vec3 river() { return texture2D(riverField, vec2(vUv.x, 1.0-vUv.y)).rgb; }
`;
const bedFragment = fieldSample + `
 uniform sampler2D pebbles;
 uniform float textured;
 void main() {
  vec3 field = river();
  if (field.b < .003) discard;
  vec3 sediment = mix(vec3(.64,.57,.40), texture2D(pebbles, vWorld.xz / 2.1).rgb, textured);
  // Pale dry upper banks darken naturally towards the submerged bed. The
  // outer feather reveals the existing map grass, so the greens always match.
  vec3 damp = mix(vec3(.91,.91,.80), vec3(.63,.74,.67), field.g);
  vec3 colour = sediment * damp;
  gl_FragColor = vec4(colour, field.b);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
 }
`;
// The uploaded woodland pond's W material is a pale green transmitting surface.
// Both use a clearer blue adaptation of its tint and the same normal texture, so their
// appearance and animation stay consistent at every camera angle.
export const NATURAL_WATER_STYLE = Object.freeze({
 linearColor: Object.freeze([.26, .61, .82]),
 roughness: .0772727132,
 normal: null
});
const waterTime = {value: 0};
const normalFallback = new THREE.DataTexture(new Uint8Array([128,128,255,255]),1,1,THREE.RGBAFormat);
normalFallback.needsUpdate = true;
const waterNormal = {value: normalFallback}, normalAmount = {value: 0};
let normalRequested = false;
function loadWaterNormal() {}
const waterLighting = `
 uniform float time;
 uniform float opacity;
 uniform vec3 waterTint;
 uniform sampler2D waterNormal;
 uniform float normalAmount;
 vec4 naturalWater(float depth, float coverage) {
  vec2 p = vWorld.xz;
  float a = p.x * 5.7 + p.y * 3.3 - time * 1.35;
  float b = p.x * -8.2 + p.y * 10.8 + time * .87;
  float c = p.x * 15.1 + p.y * 6.9 - time * 2.1;
  float slopeX = .045 * cos(a) - .024 * cos(b) + .014 * cos(c);
  float slopeZ = .026 * cos(a) + .032 * cos(b) + .006 * cos(c);
  vec2 detailA = texture2D(waterNormal, p / 1.8 + vec2(time*.008,time*.004)).rg * 2.0 - 1.0;
  vec2 detailB = texture2D(waterNormal, p / 2.3 + vec2(-time*.006,time*.005)).rg * 2.0 - 1.0;
  slopeX += (detailA.x + detailB.x) * .10 * normalAmount;
  slopeZ += (detailA.y + detailB.y) * .10 * normalAmount;
  vec3 normal = normalize(vec3(-slopeX, 1.0, -slopeZ));
  vec3 view = normalize(cameraPosition - vWorld);
  vec3 light = normalize(vec3(-.32, .85, .42));
  float fresnel = pow(1.0 - max(0.0, dot(normal, view)), 3.0);
  float glint = pow(max(0.0, dot(reflect(-light, normal), view)), 85.0);
  float caustic = pow(max(0.0, sin(a + .7 * sin(b))), 12.0) * .026;
  vec3 colour = mix(waterTint, waterTint * vec3(.48,.64,.79), depth*.72);
  colour = mix(colour, vec3(.69,.85,.96), fresnel * .26);
  colour += caustic + glint * .23;
  return vec4(colour, coverage * mix(.56, .80, depth) * opacity);
 }
`;
const waterFragment = fieldSample + waterLighting + `
 void main() {
  vec3 field = river();
  if (field.g < .003) discard;
  gl_FragColor = naturalWater(field.r, field.g);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
 }
`;
const pondFragment = `varying vec3 vWorld;\n` + waterLighting + `
 void main() {
  gl_FragColor = naturalWater(.78, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
 }
`;

/** Identical animated water for both imported park meshes and painted rivers. */
export function createNaturalWaterMaterial({riverField = null, loadTextures = true, opacity = 1} = {}) {
 if (loadTextures) loadWaterNormal();
 const material = new THREE.ShaderMaterial({
  transparent: true, depthWrite: false, side: riverField ? THREE.FrontSide : THREE.DoubleSide,
  polygonOffset: !!riverField, polygonOffsetFactor: -1, polygonOffsetUnits: -1,
  uniforms: {
   ...(riverField ? {riverField: {value: riverField}} : {}),
   time: waterTime, waterNormal, normalAmount,
   waterTint: {value: new THREE.Color(...NATURAL_WATER_STYLE.linearColor)},
   opacity: {value: opacity}
  },
  vertexShader, fragmentShader: riverField ? waterFragment : pondFragment
 });
 material.userData.waterStyle = 'woodland-pond';
 return material;
}
export function updateNaturalWater(seconds) {
 if (Number.isFinite(seconds)) waterTime.value = seconds % 4096;
}

/** Two draw calls regardless of the number of river cells. */
export function createRiverSurface({resolution = 24, loadTextures = true} = {}) {
 const group = new THREE.Group();
 group.name = 'river-and-natural-banks';
 const empty = new Uint8Array(4);
 const fieldTexture = new THREE.DataTexture(empty, 1, 1, THREE.RGBAFormat);
 fieldTexture.minFilter = fieldTexture.magFilter = THREE.LinearFilter;
 fieldTexture.generateMipmaps = false;
 fieldTexture.needsUpdate = true;
 const fallback = new THREE.DataTexture(new Uint8Array([205,186,143,255]),1,1,THREE.RGBAFormat);
 fallback.colorSpace = THREE.SRGBColorSpace;
 fallback.needsUpdate = true;
 const bedMaterial = new THREE.ShaderMaterial({
  transparent: true, depthWrite: false, side: THREE.FrontSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1,
  uniforms: {riverField: {value: fieldTexture}, pebbles: {value: fallback}, textured: {value: 0}},
  vertexShader, fragmentShader: bedFragment
 });
 const waterMaterial = createNaturalWaterMaterial({riverField: fieldTexture, loadTextures});
 const geometry = new THREE.PlaneGeometry(WIDTH, HEIGHT);
 const makePlane = (mat, height, order) => {
  const mesh = new THREE.Mesh(geometry, mat);
  mesh.rotation.x = -Math.PI/2;
  mesh.position.set(WIDTH/2, height, HEIGHT/2);
  mesh.renderOrder = order;
  mesh.frustumCulled = false;
  group.add(mesh);
 };
 // Roads/bridges at .027 and above remain on top of both river layers.
 makePlane(bedMaterial, .006, -2);
 makePlane(waterMaterial, .014, -1);
 group.visible = false;
 let signature = '', disposed = false, pebbleTexture;

 return {
  group,
  update(town) {
   const next = (town.rivers || []).join(',');
   if (next === signature) return false;
   signature = next;
   const field = makeRiverField(town, resolution);
   fieldTexture.image = {data: field.data, width: field.width, height: field.height};
   fieldTexture.needsUpdate = true;
   group.visible = field.riverCount > 0;
   return true;
  },
  tick(seconds) { updateNaturalWater(seconds); },
  dispose() {
   disposed = true;
   geometry.dispose(); bedMaterial.dispose(); waterMaterial.dispose();
   fieldTexture.dispose(); fallback.dispose(); pebbleTexture?.dispose();
  }
 };
}
