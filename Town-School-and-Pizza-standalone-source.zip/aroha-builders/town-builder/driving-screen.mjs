// Fullscreen must start during the student's Go click. Keep the viewport layout
// usable when the browser/device does not grant native fullscreen.
export function createDrivingScreen({document:doc=globalThis.document,onResize=()=>{},onChange=()=>{}}={}){
 let active=false,owned=false,pending=null;
 const supported=()=>typeof doc.documentElement?.requestFullscreen==='function'&&doc.fullscreenEnabled!==false;
 const notify=()=>{onChange({fullscreen:!!doc.fullscreenElement,supported:supported()});onResize();};
 async function exitOwned(){if(!owned)return;owned=false;if(doc.fullscreenElement===doc.documentElement){try{await doc.exitFullscreen();}catch{}}}
 function request(){
  if(!active||pending||doc.fullscreenElement||!supported())return;
  try{
   pending=Promise.resolve(doc.documentElement.requestFullscreen({navigationUI:'hide'})).then(async()=>{
    owned=doc.fullscreenElement===doc.documentElement;if(!active)await exitOwned();
   }).catch(()=>{}).finally(()=>{pending=null;notify();});
  }catch{notify();}
 }
 doc.addEventListener('fullscreenchange',notify);
 return {
  enter(){if(active)return;active=true;doc.body.classList.add('directions-driving');request();notify();},
  leave(){if(!active)return;active=false;doc.body.classList.remove('directions-driving');void exitOwned();notify();},
  request
 };
}
