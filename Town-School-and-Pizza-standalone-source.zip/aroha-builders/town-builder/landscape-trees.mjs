import * as THREE from './vendor/three.module.js';
import {loadNatureModel,natureTreeRevision,createNatureTree} from './nature-models.mjs';
import {loadCherryTree,cherryTreeRevision,createCherryTree} from './cherry-tree.mjs';
import {P} from './model-kit.mjs';

// Only request species actually planted in this model's grounds.
export function landscapeTreeVariants(b){
 if(b.type==='park')return b.variant===1?[]:[0];
 if(b.type==='castle')return [b.variant===1?2:5];
 if(b.type==='elementary-school')return [2];
 if(['zoo','junior-high-school','shopping-mall'].includes(b.type))return [5];
 if(b.type==='house'&&[1,3,4,5].includes(b.variant))return [5];
 return [];
}
export function landscapeTreeAssets(b){return landscapeTreeVariants(b).map(v=>v===2?{key:'cherry',load:loadCherryTree,ready:!!cherryTreeRevision()}:{key:'nature-'+v,load:()=>loadNatureModel(v),ready:!!natureTreeRevision(v)});}
export function landscapeTreeRevision(b){return landscapeTreeVariants(b).map(v=>v===2?cherryTreeRevision():natureTreeRevision(v)).join('.');}
const bounds=new Map();
export function createLandscapeTree(b,part,variant='normal'){
 const v=part.animation.color===P.pink?2:landscapeTreeVariants(b)[0]??5;
 const tree=v===2?createCherryTree(variant):createNatureTree(v,variant);if(!tree)return null;
 let box=bounds.get(v);if(!box){box=new THREE.Box3().setFromObject(tree);bounds.set(v,box);}
 const size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3()),s=part.animation.scale;
 // Keep the imported canopy inside its original planting space and entrances clear.
 const scale=Math.min((.69*s-.035)*part.height/size.y,.28*s*Math.min(part.w,part.d)/Math.max(size.x,size.z));
 tree.scale.multiplyScalar(scale);tree.position.set(-center.x*scale,-box.min.y*scale,-center.z*scale);
 tree.userData.landscapeVariant=v;return tree;
}
