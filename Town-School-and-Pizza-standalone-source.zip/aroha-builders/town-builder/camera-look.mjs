// Local view state only: never writes driving keys, steering, heading or room packets.
export function installCameraLook(canvas,renderer,enabled){
 let previous=null;
 const clear=()=>{previous=null;};
 canvas.addEventListener('pointermove',event=>{
  if(event.pointerType!=='mouse'||!enabled()){clear();return;}
  const next={x:event.clientX,y:event.clientY};
  if(previous){renderer.look(next.x-previous.x,next.y-previous.y);}
  previous=next;
 });
 canvas.addEventListener('pointerleave',clear);canvas.addEventListener('pointercancel',clear);
 globalThis.window?.addEventListener('blur',clear);
 return {clear};
}
