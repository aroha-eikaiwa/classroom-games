import {redSignalAhead,signalAspect} from './traffic-signals.mjs';
import {busPose} from './bus-route.mjs';
import {patrolPose} from './patrol-route.mjs';
import {crossingClosed} from './train-traffic.mjs';

const poseAt=(route,time)=>(route.kind?patrolPose:busPose)(route,time);
// All coordinates here are world coordinates, including the road's half-cell.
export function vehicleAhead(vehicle,bodies,lookAhead=.12){
 const s=Math.sin(vehicle.heading),c=Math.cos(vehicle.heading);let nearest=null;
 for(const body of bodies){
  if(body===vehicle||body.clearingJam||Math.abs((body.height||0)-(vehicle.height||0))>.55)continue;
  const dx=body.x-vehicle.x,dy=body.y-vehicle.y,along=dx*s+dy*c,across=Math.abs(dx*c-dy*s);
  if(along<=.001)continue;
  const turn=body.heading-vehicle.heading;
  const width=Math.abs(Math.cos(turn))*(body.halfWidth??.18)+Math.abs(Math.sin(turn))*(body.halfLength??.45);
  const length=Math.abs(Math.cos(turn))*(body.halfLength??.45)+Math.abs(Math.sin(turn))*(body.halfWidth??.18);
  const gap=along-(vehicle.halfLength??.45)-length;
  if(across<(vehicle.halfWidth??.17)+width+.025&&gap<.18+lookAhead&&(!nearest||gap<nearest.gap))nearest={body,gap};
 }
 return nearest;
}

// Clocks are part of Driving snapshots, so prediction, host rendering and the
// authoritative room stop the same vehicles instead of applying visual offsets.
export class RoadTraffic{
 constructor(traffic,{jamRecovery=true}={}){this.traffic=traffic;this.jamRecovery=jamRecovery;this.routes=[...(traffic.buses||[]),...(traffic.patrols||[]),...(traffic.cars||[])];this.states=this.routes.map(()=>({clock:0,waiting:false,train:false,light:false,jam:0,clearance:0}));}
 snapshot(){return this.states.map(s=>({...s}));}
 restore(states,time=0){this.states=this.routes.map((_,i)=>({clock:Number.isFinite(states?.[i]?.clock)?Math.max(0,states[i].clock):Math.max(0,time),waiting:!!states?.[i]?.waiting,train:!!states?.[i]?.train,light:!!states?.[i]?.light,jam:Number.isFinite(states?.[i]?.jam)?Math.max(0,Math.min(3.05,states[i].jam)):0,clearance:Number.isFinite(states?.[i]?.clearance)?Math.max(0,Math.min(3,states[i].clearance)):0}));return this;}
 poses(states=this.states){return this.routes.map((route,i)=>{if(this.police?.index===i)return {...this.police.pose};const state=states[i]||this.states[i],p=poseAt(route,state.clock);if(state.waiting||state.train||state.light)p.speed=0;return {...p,waitingForTraffic:state.waiting,waitingForTrain:state.train,waitingForLight:state.light,...(state.clearance>0?{clearingJam:true}:{})};});}
 update(dt,player=null,time=0){
  if(!this.routes.length)return this;
  let remaining=Math.max(0,dt),now=time-remaining;
  while(remaining>1e-9){const step=Math.min(.05,remaining),poses=this.poses(),nextStates=[];
   // Every vehicle reads the same immutable clocks until this substep finishes.
   // Reuse the predicted poses across junctions and collision checks.
   const moving=this.routes.map((r,i)=>this.police?.index===i?{...this.police.pose}:poseAt(r,this.states[i].clock)),nextPoses=this.routes.map((r,i)=>this.police?.index===i?{...this.police.pose}:poseAt(r,this.states[i].clock+step)),owners=new Map(),junctions=this.traffic.roadJunctions||this.traffic.junctions||[];
   for(const j of junctions){
    const candidates=[];
    for(let i=0;i<moving.length;i++){
     const p=moving[i],next=nextPoses[i],d=Math.hypot(p.x-j.x,p.y-j.y);if(d>1.9||Math.abs(p.height||0)>.55)continue;
     const approaching=Math.hypot(next.x-j.x,next.y-j.y)<d;
     if(d>=1.1&&!approaching)continue;
     const signal=this.traffic.junctions?.find(s=>s.id===j.id),approach=signal?.approaches.reduce((best,a)=>!best||(p.x-j.x)*a.dx+(p.y-j.y)*a.dy>(p.x-j.x)*best.dx+(p.y-j.y)*best.dy?a:best,null);
     if(d>=1.1&&approach&&signalAspect(approach.phase,now,signal.phaseCount)==='red')continue;
     candidates.push({i,d,inside:d<1.1});
    }
    if(player&&Math.hypot(player.x-j.x,player.y-j.y)<1.1&&Math.abs(player.height||0)<.55)candidates.push({i:-1,d:0,inside:true});
    candidates.sort((a,b)=>Number(b.inside)-Number(a.inside)||a.d-b.d||a.i-b.i);if(candidates.length)owners.set(j.id,candidates[0].i);
   }
   for(let i=0;i<this.routes.length;i++){
    if(this.police?.index===i){nextStates.push({...this.states[i],waiting:false,train:false,light:false,jam:0,clearance:0});continue;}
    const state=this.states[i],current=moving[i],next=nextPoses[i],others=poses.filter((_,j)=>j!==i);
    if(player)others.push(player);
    let train=false;
    if(current.speed||next.speed)for(const crossing of this.traffic.analysis.crossings||[]){const before=Math.hypot(current.x-crossing.x-.5,current.y-crossing.y-.5),after=Math.hypot(next.x-crossing.x-.5,next.y-crossing.y-.5);if(before>=1.18&&after<1.30&&after<before&&(crossingClosed(this.traffic,crossing,now)||crossingClosed(this.traffic,crossing,now+1.2))){train=true;break;}}
    const light=!!redSignalAhead(this.traffic.junctions,current,next,now);
    // Parallel traffic queues in its lane. Cross traffic takes turns through the
    // junction box, avoiding two turning cars waiting forever for one another.
    const junctionWait=junctions.some(j=>owners.has(j.id)&&owners.get(j.id)!==i&&Math.abs(current.height||0)<.55&&Math.hypot(current.x-j.x,current.y-j.y)>=1.1&&Math.hypot(next.x-j.x,next.y-j.y)<1.7&&Math.hypot(next.x-j.x,next.y-j.y)<Math.hypot(current.x-j.x,current.y-j.y));
    const obstruction=junctionWait||!!((current.speed||next.speed)&&vehicleAhead(current,others.filter(p=>p===player||Math.cos(p.heading-current.heading)>.3),Math.max(.06,current.speed*.12)));
    const intendedMove=Math.hypot(next.x-current.x,next.y-current.y),jam=this.jamRecovery&&obstruction&&!train&&!light&&intendedMove>1e-8?(state.jam||0)+step:0;
    // A genuine queue may phase through road vehicles after MORE than three
    // seconds. Clear three road units, then restore ordinary collision rules.
    // Red signals, trains and authored dwell times never earn an escape.
    let clearance=state.clearance||0;if(jam>3+1e-8)clearance=3;
    const waiting=obstruction&&clearance<=0,movingNow=!waiting&&!train&&!light;
    if(movingNow&&clearance>0)clearance=Math.max(0,clearance-intendedMove);
    nextStates.push({clock:state.clock+(movingNow?step:0),waiting,train,light,jam:clearance>0?0:jam,clearance});
   }
   this.states=nextStates;remaining-=step;now+=step;
  }
  return this;
 }
}
