// Use motion shared by both fingers for tilt. Pointer events arrive separately:
// the first half of a pinch or twist must not be mistaken for a vertical swipe.
export function beginMapGesture(a,b,zoom){
 return {a:{...a},b:{...b},angle:Math.atan2(b.y-a.y,b.x-a.x),dist:Math.max(1,Math.hypot(b.x-a.x,b.y-a.y)),zoom,x:(a.x+b.x)/2,tilt:0};
}
export function moveMapGesture(g,a,b){
 const angle=Math.atan2(b.y-a.y,b.x-a.x),turn=Math.atan2(Math.sin(angle-g.angle),Math.cos(angle-g.angle));
 const ay=a.y-g.a.y,by=b.y-g.b.y;
 const common=Math.sign(ay)===Math.sign(by)?Math.sign(ay)*Math.min(Math.abs(ay),Math.abs(by)):0;
 const tilt=Math.sign(common)*Math.max(0,Math.abs(common)-4),x=(a.x+b.x)/2;
 const result={turn,tilt:tilt-g.tilt,panX:x-g.x,zoom:g.zoom*Math.hypot(b.x-a.x,b.y-a.y)/g.dist};
 g.angle=angle;g.tilt=tilt;g.x=x;
 return result;
}
