import * as THREE from './vendor/three.module.js';
import {packedGeometry} from './imported-models.mjs';
import {base64Bytes} from './base64-bytes.mjs';
let model,pending,revision=0,lastTime;
export const fountainRevision=()=>revision;
async function jsonAsset(name){return Promise.resolve(false);}
export function loadFountain(){return Promise.resolve(false);}
function animate(time){if(!model||lastTime===time)return;lastTime=time;const phase=((time%model.animation.duration)+model.animation.duration)%model.animation.duration*model.animation.fps,a=Math.floor(phase),b=Math.min(a+1,model.frames.length-1),u=phase-a;
 model.parts.forEach((part,index)=>{const source=model.frames[a][index],target=model.frames[b][index],array=part.geometry.attributes.position.data.array,{min,step}=part.bounds;for(let i=0;i<source.length/3;i++)for(let axis=0;axis<3;axis++)array[i*8+axis]=min[axis]+(source[i*3+axis]+(target[i*3+axis]-source[i*3+axis])*u)*step[axis];part.geometry.attributes.position.data.needsUpdate=true;});
}
export function createFountain(width=1,variant='normal'){
 if(!model)return null;const group=new THREE.Group();group.name='imported-animated-fountain';group.userData.importedFountain=true;group.scale.setScalar(width);
 for(const part of model.parts){let material=part.material;if(variant.startsWith('ghost')){material=material.clone();material.userData.shared=false;material.transparent=true;material.opacity=Math.min(material.opacity,.6);if(variant==='ghost-invalid')material.color.set('#ef7575');}const mesh=new THREE.Mesh(part.geometry,material);mesh.userData.sharedGeometry=true;mesh.userData.shadowCaster=false;mesh.castShadow=false;mesh.receiveShadow=true;group.add(mesh);}group.userData.animate=animate;group.userData.frameCount=model.frames.length;return group;
}
