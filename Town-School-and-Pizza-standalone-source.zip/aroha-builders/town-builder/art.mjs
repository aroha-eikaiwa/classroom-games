import {CATALOG} from './core.mjs';
export const artwork={images:new Map(),meta:{},grass:null,loaded:0,total:47};
let loadedPromise;
const primaryAssets={};
const variantAssets={};
const singleView=new Set(['park-japanese','temple-pagoda','station-japanese','city-hall','prison','airport','bank','high-school','university','hotel','hotel-marina','factory','factory-restored','cinema','apartment-light','bakery','apartment','car','house-milestone','house-japanese-new','restaurant-japanese','park-woodland','tree-cedar','tree-sakura','tree-palm','tree-maple','tree-variegated','tree-wind','arcade','shopping-mall','tree','house-townhouse','house-bungalow','house-villa','restaurant-burger','restaurant-ramen','restaurant-sushi','restaurant-pizza','zoo','castle','stadium','park-small','park-large','house-japanese','house-modern','castle-japanese','elementary-school','junior-high-school']);
artwork.total=3+Object.keys(variantAssets).length+CATALOG.length;
export async function loadArtwork(onProgress=()=>{}){onProgress(0,0);return Promise.resolve(artwork);}

// Menu and drag pictures need at most 160px. Keep four aspect-correct 252px views
// instead of retaining the original 1024–1254px decoded sheets for the whole game.
export function compactSpriteSheet(image,meta={}){
 const original={image,meta};if(typeof document==='undefined'||!document.createElement)return original;
 try{
  const sourceViews=meta?.views||[],single=sourceViews.length===4&&sourceViews.every(v=>['x','y','w','h'].every(k=>v[k]===sourceViews[0][k]));
  const canvas=document.createElement('canvas');canvas.width=single?256:512;canvas.height=single?256:512;const ctx=canvas.getContext('2d');if(!ctx)return original;
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';const width=image.naturalWidth||image.width,height=image.naturalHeight||image.height;
  if(!width||!height)return original;
  const views=[];
  for(let i=0;i<4;i++){
   const frame=meta?.views?.[i]||{},sx=frame.x??(i%2)*width/2,sy=frame.y??Math.floor(i/2)*height/2,sw=frame.w??width/2,sh=frame.h??height/2;
   if(![sx,sy,sw,sh].every(Number.isFinite)||sw<=0||sh<=0)return original;
   const scale=Math.min(252/sw,252/sh,1),w=sw*scale,h=sh*scale,x=(single?0:(i%2)*256)+(256-w)/2,y=(single?0:Math.floor(i/2)*256)+(256-h)/2;
   if(!single||i===0)ctx.drawImage(image,sx,sy,sw,sh,x,y,w,h);views.push({...frame,x,y,w,h});
  }
  return {image:canvas,meta:{...meta,views}};
 }catch{return original;}
}

export function spriteView(type,rotation=0){const image=artwork.images.get(type);if(!image)return null;const view=((Math.round(rotation)%4)+4)%4,m=artwork.meta[type]?.views?.[view],w=image.naturalWidth||image.width,h=image.naturalHeight||image.height;return {image,sx:m?.x??(view%2)*w/2,sy:m?.y??Math.floor(view/2)*h/2,sw:m?.w??w/2,sh:m?.h??h/2,alpha:m?.alpha};}
export function paintSprite(ctx,type,rotation,x,y,w,h,alpha=1){const v=spriteView(type,rotation);if(!v)return false;ctx.save();ctx.globalAlpha=alpha;ctx.drawImage(v.image,v.sx,v.sy,v.sw,v.sh,x,y,w,h);ctx.restore();return true;}
export function drawArtThumbnail(canvas,type,rotation=0){const c=canvas.getContext('2d'),v=spriteView(type,rotation);if(!v)return false;c.clearRect(0,0,canvas.width,canvas.height);const s=Math.min((canvas.width-14)/v.sw,(canvas.height-8)/v.sh),w=v.sw*s,h=v.sh*s;return paintSprite(c,type,rotation,(canvas.width-w)/2,canvas.height-h-3,w,h);}
export function buildingDragImage(type,rotation=0,variant=0,plot=2,size=3){const c=document.createElement('canvas');c.width=160;c.height=140;c.className='model-drag-image';c.style.cssText='position:fixed;left:-200px;top:0;width:160px;height:140px;pointer-events:none';drawArtThumbnail(c,artType(type,size,variant,plot),rotation);document.body.append(c);return c;}

export function variantArtId(type,size=3,variant=0){
 if(type==='park'&&variant===2)return 'park-japanese';
 if(type==='temple'&&variant===1)return 'temple-pagoda';
 if(type==='station'&&variant===1)return 'station-japanese';
 if(type==='hotel'&&variant===1)return 'hotel-marina';
 if(type==='factory'&&variant===1)return 'factory-restored';
 if(type==='tree')return ['tree','tree-cedar','tree-sakura','tree-palm','tree-maple','tree-variegated','tree-wind'][variant]||type;
 if(type==='house')return ['house','house-japanese','house-modern','house-townhouse','house-bungalow','house-villa','house-milestone','house-japanese-new'][variant]||type;
 if(type==='restaurant')return ['restaurant','restaurant-burger','restaurant-ramen','restaurant-sushi','restaurant-pizza','restaurant-japanese'][variant]||type;
 if(type==='apartment'&&variant===1)return 'apartment-light';
 if(type==='castle'&&variant===1)return 'castle-japanese';
 if(type==='park'&&variant===1)return 'park-woodland';
 if(type==='park'&&size!==3)return size===2?'park-small':'park-large';
 return type;
}
export function artType(type,size=3,variant=0,plot=2){const id=variantArtId(type,size,variant);return artwork.images.has(id)?id:type;}

// Native destination images do not depend on canvas painting or the 3D context.
export function destinationImage(type,size=3,variant=0){return 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20160%20100%22%3E%3Crect%20width%3D%22160%22%20height%3D%22100%22%20rx%3D%2216%22%20fill%3D%22%23dbeace%22%2F%3E%3Cpath%20d%3D%22M0%2076h160M86%200v100%22%20stroke%3D%22%235b6870%22%20stroke-width%3D%2216%22%2F%3E%3Cpath%20d%3D%22m12%2053%2024-21%2025%2021v19H12z%22%20fill%3D%22%23cc6a46%22%2F%3E%3Cpath%20d%3D%22M107%2065V39h38v26z%22%20fill%3D%22%23f3dd9c%22%2F%3E%3Ccircle%20cx%3D%22116%22%20cy%3D%2221%22%20r%3D%2211%22%20fill%3D%22%23549467%22%2F%3E%3C%2Fsvg%3E';}

let grassPromise;
export function loadGrass(){return Promise.resolve(null);}
