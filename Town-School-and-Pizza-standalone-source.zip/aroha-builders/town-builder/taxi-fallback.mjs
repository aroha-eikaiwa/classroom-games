import {trainTraffic} from './train-traffic.mjs';
import {RoadTraffic} from './road-traffic.mjs';
import {taxiDropoffMarker,taxiPassengerPose} from './taxi-effects.mjs';
import {validateTransport,transportHeightAt} from './transport.mjs';
let sprite;
const fleets=new WeakMap();
// The software fallback uses views rasterised from the very same supplied taxi.
export function drawTaxiFallback(r,taxi,avatar,add){
 if(!taxi||!avatar)return;
 const t=taxi.town,c=r.ctx;
 const stop=taxiDropoffMarker(taxi,avatar);
 if(stop)add(stop.x,stop.z,()=>{
  const height=.055+transportHeightAt(validateTransport(t),stop.x,stop.z,'road');c.save();c.beginPath();
  for(let i=0;i<=48;i++){const angle=i/48*Math.PI*2,p=r.project(stop.x+Math.cos(angle)*stop.radius,stop.z+Math.sin(angle)*stop.radius,height);i?c.lineTo(...p):c.moveTo(...p);}
  c.closePath();c.globalAlpha=.45+.55*stop.pulse;c.fillStyle='#25ffd54d';c.strokeStyle='#ffe14f';c.lineWidth=Math.max(3,r.scale*.1);c.shadowColor='#ffe14f';c.shadowBlur=10;c.fill();c.stroke();c.restore();
 });
 let traffic=fleets.get(t);if(!traffic){traffic=new RoadTraffic(trainTraffic(t));fleets.set(t,traffic);}traffic.restore(avatar.roadTraffic,avatar.trainTime);
 for(const p of traffic.poses())add(p.x,p.y,()=>{
  const [x,y]=r.project(p.x,p.y,(p.height||0)+.15),size=Math.max(5,r.scale*.7);c.save();c.translate(x,y);c.rotate(-p.heading-r.angle*Math.PI/2+Math.PI/4);c.fillStyle=p.kind==='police'?'#243849':p.kind==='bus'?'#e9d5ae':'#59969b';c.fillRect(-size*.22,-size*.5,size*.44,size);c.fillStyle=p.kind==='police'?'#f4f3ea':'#bddce5';c.fillRect(-size*.19,-size*.17,size*.38,size*.32);c.restore();
 });
 add(avatar.x+.5,avatar.y+.5,()=>{
  const [x,y]=r.project(avatar.x+.5,avatar.y+.5,.15),size=Math.max(22,r.scale*1.25),index=((Math.round((avatar.heading+r.angle*Math.PI/2)/(Math.PI/4))%8)+8)%8;
  if(sprite?.complete&&sprite.naturalWidth)c.drawImage(sprite,index*256,0,256,256,x-size/2,y-size/2,size,size);
  else{c.fillStyle='#f9c931';c.fillRect(x-size*.2,y-size*.35,size*.4,size*.7);}
 });
 for(const p of taxi.passengers){const pose=taxiPassengerPose(taxi,p);if(pose.hidden)continue;add(pose.x,pose.z,()=>{
  const [x,y]=r.project(pose.x,pose.z,.3+pose.base),waiting=p!==taxi.passenger&&p.availableAt<=taxi.clock,green=waiting&&taxi.phase==='searching'&&Math.sin(taxi.clock*6)>0;
  c.save();c.translate(x,y);c.scale(pose.scale??1,pose.scale??1);if(pose.reaction==='fly')c.rotate(-Math.PI/3);if(pose.clip==='taxiDance')c.rotate(Math.sin(pose.clock*8)*1.2);c.fillStyle=green?'#2dff59':'#537c71';c.beginPath();c.arc(0,-3,3,0,Math.PI*2);c.fill();c.fillRect(-2,0,4,6);if(['wave','clap','cheer','jump','fly'].includes(pose.reaction)){c.strokeStyle='#537c71';c.lineWidth=2;c.beginPath();c.moveTo(-1,1);c.lineTo(-6,-7+Math.sin(pose.clock*8)*2);if(pose.reaction!=='wave'){c.moveTo(1,1);c.lineTo(6,-7-Math.sin(pose.clock*8)*2);}c.stroke();}
  if(waiting&&taxi.phase==='searching'){c.fillStyle='#2dff59';c.strokeStyle='#23693b';c.lineWidth=1;c.beginPath();c.moveTo(-5,-17);c.lineTo(5,-17);c.lineTo(5,-12);c.lineTo(8,-12);c.lineTo(0,-6);c.lineTo(-8,-12);c.lineTo(-5,-12);c.closePath();c.fill();c.stroke();}c.restore();
 });}
}
