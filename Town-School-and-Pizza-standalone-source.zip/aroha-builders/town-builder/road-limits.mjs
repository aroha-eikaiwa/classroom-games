import {roadGraph,edgeKey,migrateRoadEdges} from './network.mjs';
import {WIDTH} from './town-grid.mjs';

export const ROAD_LIMIT=500;
// Distances are measured along each section, so diagonals cost sqrt(2).
export function roadRules(t){
 const edges=t.roadEdges??migrateRoadEdges(t.roads||[]);
 const connected=new Set(edges.flat());
 const length=edges.reduce((sum,[a,b])=>sum+Math.hypot(a%WIDTH-b%WIDTH,Math.floor(a/WIDTH)-Math.floor(b/WIDTH)),0)+(t.roads||[]).filter(k=>!connected.has(k)).length;
 const junctions=roadGraph(t).intersections;
 const affected=new Map();let crowded=false,close=false;
 for(const n of junctions)if(n.neighbors.size>4){crowded=true;affected.set(n.id,{x:n.x,y:n.y});}
 for(let i=0;i<junctions.length;i++)for(let j=i+1;j<junctions.length;j++){const a=junctions[i],b=junctions[j];if(Math.hypot(a.x-b.x,a.y-b.y)<2){close=true;affected.set(a.id,{x:a.x,y:a.y});affected.set(b.id,{x:b.x,y:b.y});}}
 return {length,remaining:Math.max(0,ROAD_LIMIT-length),over:length>ROAD_LIMIT+1e-8,crowded,close,affected:[...affected.values()],valid:length<=ROAD_LIMIT+1e-8&&!crowded&&!close};
}
export function addedRoad(before,after){
 const edges=t=>new Set((t.roadEdges??migrateRoadEdges(t.roads||[])).map(e=>edgeKey(...e)));
 const old=edges(before);return (after.roadEdges??migrateRoadEdges(after.roads||[])).some(e=>!old.has(edgeKey(...e)))||(after.roads||[]).some(k=>!(before.roads||[]).includes(k));
}
export function roadRuleMessage(t){const r=roadRules(t);return r.over?`道路の合計が${Math.ceil(r.length)}で、上限は${ROAD_LIMIT}だよ。あと${Math.ceil(r.length-ROAD_LIMIT)}以上、道路を短くしてね。`:r.crowded?'交差点につながる道路が多すぎるよ。赤い交差点につながる道路を減らして、4本以下にしてね。':r.close?'交差点が近すぎるよ。赤い交差点の道路を消して、2マス以上離してね。':'';}
