import * as THREE from './vendor/three.module.js';
import {cherryGeometry} from './cherry-tree.mjs';
import {createNaturalWaterMaterial, updateNaturalWater} from './water.mjs';
import {base64Bytes} from './base64-bytes.mjs';

let loaded = null, pending = null, revision = 0;
export const woodlandParkRevision = () => revision;

function unpack(part) {
 const source = base64Bytes(part.vertices), view = new DataView(source.buffer);
 const vertices = new Float32Array(source.length / 2);
 for (let i = 0; i < vertices.length; i++) vertices[i] = part.min[i%8] + view.getUint16(i*2,true) * part.step[i%8];
 const indexData = base64Bytes(part.indices), indices = new Array(indexData.length / part.indexBytes), indexView = new DataView(indexData.buffer);
 for (let i = 0; i < indices.length; i++) indices[i] = part.indexBytes === 2 ? indexView.getUint16(i*2,true) : indexView.getUint32(i*4,true);
 return {vertices,indices};
}

export function loadWoodlandPark() {return Promise.resolve(false);}

export function createWoodlandPark(variant = 'normal') {
 if (!loaded) return null;
 const group = new THREE.Group();
 group.name = 'woodland-pond-park';
 group.userData.importedPark = true;
 group.userData.animate = updateNaturalWater;
 for (const part of loaded) {
  let material = part.material;
  if (variant.startsWith('ghost')) {
   material = material.clone();
   material.userData.shared = false;
   material.transparent = true;
   material.opacity = .66;
   if (material.uniforms) {
    material.uniforms.time = part.material.uniforms.time;
    material.uniforms.waterNormal = part.material.uniforms.waterNormal;
    material.uniforms.normalAmount = part.material.uniforms.normalAmount;
    material.uniforms.opacity.value = .66;
    if (variant === 'ghost-invalid') material.uniforms.waterTint.value.set('#ef7575');
   } else if (variant === 'ghost-invalid') material.color.set('#ef7575');
  }
  const mesh = new THREE.Mesh(part.geometry,material);
  mesh.name = 'woodland-' + part.name;
  mesh.userData.sharedGeometry = true;
  mesh.castShadow = !['soil','water','path','grass'].includes(part.name);
  mesh.receiveShadow = part.name !== 'water';
  mesh.userData.shadowCaster = mesh.castShadow;
  mesh.userData.shadowReceiver = mesh.receiveShadow;
  if (part.name === 'water') mesh.renderOrder = 1;
  group.add(mesh);
 }
 return group;
}
