import * as THREE from './vendor/three.module.js';
import {createKit} from './model-kit.mjs';
import {createImportedModel,loadImportedModel,importedModelRevision} from './imported-models.mjs';
let policeGeometry,policeMaterial;
let lightGeometry,redLight,blueLight,dimLight;
export function attachPoliceLights(group){
 if(!lightGeometry){lightGeometry=new THREE.BoxGeometry(.085,.035,.055);redLight=new THREE.MeshBasicMaterial({color:'#ff253e',toneMapped:false});blueLight=new THREE.MeshBasicMaterial({color:'#2385ff',toneMapped:false});dimLight=new THREE.MeshBasicMaterial({color:'#3c4453'});for(const m of [redLight,blueLight,dimLight])m.userData.shared=true;}
 group.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(group),inverse=group.matrixWorld.clone().invert(),top=new THREE.Vector3((bounds.min.x+bounds.max.x)/2,bounds.max.y+.018,(bounds.min.z+bounds.max.z)/2).applyMatrix4(inverse),lamps=[];
 for(const side of [-1,1]){const mesh=new THREE.Mesh(lightGeometry,dimLight);mesh.position.copy(top);mesh.position.x+=side*.055;mesh.userData.sharedGeometry=true;mesh.userData.shadowCaster=false;group.add(mesh);lamps.push(mesh);}
 group.userData.policeLights=(active,time)=>{const phase=Math.floor((time||0)*3)%2;lamps[0].material=active&&phase===0?redLight:dimLight;lamps[1].material=active&&phase===1?blueLight:dimLight;};
 return group;
}
export const emergencyRevision=type=>type==='hospital'?importedModelRevision('ambulance'):type==='fire-station'?importedModelRevision('fire-truck'):type==='police-station'?importedModelRevision('police'):0;
export const loadEmergencyModel=type=>loadImportedModel(type);
function policeCar(){
 if(!policeGeometry){
  const k=createKit(1,1);k.car(0,0,0,.34,.72,'#f4f5ed','police');k.box(-.001,.05,.08,.342,.59,.045,'#202b36');
  const positions=[],colors=[];
  for(const f of k.faces){const c=new THREE.Color(f.color);for(let i=1;i<f.points.length-1;i++)for(const index of [0,i+1,i]){const p=f.points[index];positions.push(p[0]-.17,p[2]-.02,.36-p[1]);colors.push(c.r,c.g,c.b);}}
  policeGeometry=new THREE.BufferGeometry();policeGeometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));policeGeometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));policeGeometry.computeVertexNormals();policeGeometry.computeBoundingBox();policeGeometry.computeBoundingSphere();
  policeMaterial=new THREE.MeshLambertMaterial({vertexColors:true});policeMaterial.userData.shared=true;
 }
 const group=new THREE.Group(),mesh=new THREE.Mesh(policeGeometry,policeMaterial);mesh.userData.sharedGeometry=true;mesh.userData.shadowCaster=false;group.add(mesh);group.scale.setScalar(.9/.736);return group;
}
export function createEmergencyVehicle(kind,length=.9,variant='normal'){
 const imported=createImportedModel(kind,variant),group=imported||(kind==='police'?policeCar():null);if(!group)return null;
 group.scale.multiplyScalar(length/.9);group.userData.emergencyVehicle=kind;group.userData.front='-Z';
 group.traverse(o=>{if(o.isMesh){o.castShadow=false;o.userData.shadowCaster=false;if(!imported&&variant.startsWith('ghost')){o.material=o.material.clone();o.material.userData.shared=false;o.material.transparent=true;o.material.opacity=.66;if(variant==='ghost-invalid')o.material.color.set('#ef7575');}}});if(kind==='police'&&!variant.startsWith('ghost'))attachPoliceLights(group);return group;
}
