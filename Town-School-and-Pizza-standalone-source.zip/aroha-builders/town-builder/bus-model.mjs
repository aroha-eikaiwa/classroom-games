import {applyVehicleRoadPose} from './vehicle-road-pose.mjs';
import * as THREE from './vendor/three.module.js';
const paint=new THREE.MeshStandardMaterial({color:'#f3c447',roughness:.48,metalness:.12}),cream=new THREE.MeshStandardMaterial({color:'#fff5d8',roughness:.55}),glass=new THREE.MeshStandardMaterial({color:'#285664',roughness:.22,metalness:.25}),dark=new THREE.MeshStandardMaterial({color:'#293b39',roughness:.7}),metal=new THREE.MeshStandardMaterial({color:'#b9c7c8',metalness:.6,roughness:.35}),lamp=new THREE.MeshStandardMaterial({color:'#fff6bf',emissive:'#fff1a2',emissiveIntensity:.65}),red=new THREE.MeshStandardMaterial({color:'#d95439',emissive:'#dc4528',emissiveIntensity:.3});
for(const m of [paint,cream,glass,dark,metal,lamp,red])m.userData.shared=true;
let promise;
export function loadBusTexture(){return Promise.resolve(false);}
function rounded(w,h,d,r){const s=new THREE.Shape(),x=-w/2,y=-h/2;s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);const g=new THREE.ExtrudeGeometry(s,{depth:Math.max(.005,d-2*r),bevelEnabled:true,bevelSegments:3,steps:1,bevelSize:r*.35,bevelThickness:r,curveSegments:8});g.translate(0,0,-(d-2*r)/2);return g;}
export function createBus(){
 const group=new THREE.Group();group.name='school-bus';const add=(geo,mat,x,y,z)=>{const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;group.add(m);return m;};const box=(w,h,d,mat,x,y,z)=>add(new THREE.BoxGeometry(w,h,d),mat,x,y,z);
 // Conventional school-bus silhouette: tall passenger cabin and a distinct low hood.
 add(rounded(.39,.47,.82,.045),paint,0,.35,-.10);add(rounded(.395,.075,.82,.035),paint,0,.605,-.10);box(.35,.055,.94,dark,0,.145,0);
 add(rounded(.33,.23,.28,.04),paint,0,.285,.40);add(rounded(.34,.05,.26,.025),paint,0,.416,.40);
 for(const side of [-1,1]){
  for(const z of [-.40,-.245,-.09,.065,.20]){box(.012,.19,.132,dark,side*.202,.46,z);box(.014,.166,.110,glass,side*.205,.46,z);box(.016,.008,.114,metal,side*.207,.46,z);}
  for(const y of [.21,.255,.337])box(.012,.015,.79,dark,side*.204,y,-.10);
  // Passenger door behind the hood, with two tall framed glass panels.
  if(side===1)for(const z of [.16,.24]){box(.016,.37,.075,dark,.209,.34,z);box(.020,.23,.057,glass,.212,.40,z);}
  box(.035,.035,.10,metal,side*.22,.47,.26);box(.034,.10,.065,dark,side*.26,.48,.30);
  box(.018,.022,.03,red,side*.2,.59,-.40);
 }
 box(.335,.19,.018,dark,0,.47,.315);box(.30,.16,.022,glass,0,.47,.327);box(.008,.17,.025,metal,0,.47,.338);
 for(const x of [-.09,.09]){box(.008,.075,.01,dark,x,.443,.344).rotation.z=-.55;}
 box(.21,.22,.014,dark,0,.38,-.518);box(.17,.17,.018,glass,0,.40,-.528);box(.012,.05,.015,metal,.09,.29,-.53);
 box(.23,.15,.02,dark,0,.27,.546);for(let i=0;i<7;i++)box(.22,.009,.023,metal,0,.21+i*.021,.558);
 for(const x of [-.145,.145]){add(new THREE.SphereGeometry(.035,16,10),lamp,x,.30,.545).scale.set(1,1,.3);for(const z of [-.08,.04])add(new THREE.SphereGeometry(.014,10,6),red,x,.605,z+.29).scale.set(1,1,.4);box(.045,.06,.018,red,x,.28,-.522);}
 box(.41,.045,.04,dark,0,.16,.55);box(.39,.045,.035,dark,0,.16,-.53);box(.095,.035,.025,cream,0,.16,.573);
 const wheels=[];for(const side of [-1,1])for(const z of [-.32,.38]){const w=add(new THREE.CylinderGeometry(.108,.108,.048,32),dark,side*.20,.12,z);w.rotation.z=Math.PI/2;const hub=add(new THREE.CylinderGeometry(.061,.061,.051,24),metal,side*.205,.12,z);hub.rotation.z=Math.PI/2;wheels.push(w,hub);}
 if(typeof document!=='undefined'){const canvas=document.createElement('canvas');canvas.width=512;canvas.height=128;const c=canvas.getContext('2d');if(c){c.fillStyle='#f3c447';c.fillRect(0,0,512,128);c.fillStyle='#18201e';c.font='bold 53px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText('SCHOOL BUS',256,64);const map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace;const mat=new THREE.MeshBasicMaterial({map});box(.29,.065,.012,mat,0,.587,.324);box(.29,.065,.012,mat,0,.587,-.525);}}
 // Batch the static body by material; wheels remain independently animated.
 group.updateMatrixWorld(true);const buckets=new Map();for(const mesh of [...group.children]){if(!mesh.isMesh||wheels.includes(mesh))continue;const geometry=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone();geometry.applyMatrix4(mesh.matrixWorld);if(!buckets.has(mesh.material))buckets.set(mesh.material,[]);buckets.get(mesh.material).push(geometry);group.remove(mesh);mesh.geometry.dispose();}
 for(const [mat,parts]of buckets){const geometry=new THREE.BufferGeometry();for(const name of ['position','normal','uv']){const size=name==='uv'?2:3,arrays=parts.map(g=>g.getAttribute(name)?.array||new Float32Array(g.getAttribute('position').count*size)),data=new Float32Array(arrays.reduce((n,a)=>n+a.length,0));let offset=0;for(const a of arrays){data.set(a,offset);offset+=a.length;}geometry.setAttribute(name,new THREE.BufferAttribute(data,size));}const mesh=new THREE.Mesh(geometry,mat);mesh.castShadow=true;mesh.receiveShadow=true;group.add(mesh);parts.forEach(g=>g.dispose());}
 group.userData.update=(pose,time,analysis)=>{if(analysis)applyVehicleRoadPose(group,analysis,pose,{wheelbase:.70,offset:.015,front:1});else{group.position.set(pose.x,pose.height+.015,pose.y);group.rotation.set(0,pose.heading,0,'YXZ');}for(const w of wheels)w.rotation.x=pose.speed?time*pose.speed/.105:w.rotation.x;};return group;
}
