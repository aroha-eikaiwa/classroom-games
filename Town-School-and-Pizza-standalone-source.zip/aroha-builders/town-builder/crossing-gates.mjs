import * as THREE from './vendor/three.module.js';
import {crossingClosed} from './train-traffic.mjs';
export {crossingClosed} from './train-traffic.mjs';
export function createCrossingGates(analysis){const group=new THREE.Group(),gates=[];const yellow=new THREE.MeshStandardMaterial({color:'#f4c64a',roughness:.6}),black=new THREE.MeshStandardMaterial({color:'#2e3833',roughness:.65});
 for(const crossing of analysis.crossings)for(const {x,y,side} of crossing.posts){const d=crossing.roadDirection,base=new THREE.Group(),pivot=new THREE.Group();base.position.set(crossing.x+.5+x,.34,crossing.y+.5+y);base.rotation.y=Math.atan2(d.x,d.y)+(side<0?Math.PI:0);base.add(pivot);pivot.rotation.z=Math.PI/2;
  const arm=new THREE.Mesh(new THREE.BoxGeometry(1.08,.045,.05),yellow);arm.position.x=.54;pivot.add(arm);for(let i=1;i<10;i+=2){const stripe=new THREE.Mesh(new THREE.BoxGeometry(.108,.048,.053),black);stripe.position.x=(i+.5)*.108;pivot.add(stripe);}group.add(base);gates.push({crossing,pivot,amount:0});
 }group.userData.gates=gates;return group;}
export function updateCrossingGates(group,traffic,time,dt){const closed=new Map();for(const gate of group.userData.gates){if(!closed.has(gate.crossing.id))closed.set(gate.crossing.id,crossingClosed(traffic,gate.crossing,time));const target=closed.get(gate.crossing.id)?1:0;gate.amount+=Math.max(-dt/1.1,Math.min(dt/1.1,target-gate.amount));gate.pivot.rotation.z=(1-gate.amount)*Math.PI/2;}return closed;}
