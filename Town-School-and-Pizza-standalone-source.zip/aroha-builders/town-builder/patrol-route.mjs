import {entranceAccess} from './core.mjs';
import {roadGraph} from './network.mjs';
import {validateTransport} from './transport.mjs';
import {busPose} from './bus-route.mjs';
const ordered=n=>[...n.neighbors].sort();
export function reachable(graph,start){const queue=[start],seen=new Set([start.id]);for(let i=0;i<queue.length;i++)for(const id of ordered(queue[i]))if(!seen.has(id)){seen.add(id);queue.push(graph.nodes.get(id));}return seen;}
export function cycleCore(graph,component){
 const degree=new Map([...component].map(id=>[id,[...graph.nodes.get(id).neighbors].filter(n=>component.has(n)).length])),queue=[...degree].filter(([,n])=>n<2).map(([id])=>id),core=new Set(component);
 for(let i=0;i<queue.length;i++){const id=queue[i];if(!core.delete(id))continue;for(const next of graph.nodes.get(id).neighbors)if(core.has(next)){degree.set(next,degree.get(next)-1);if(degree.get(next)===1)queue.push(next);}}
 return core;
}
export function path(graph,start,target,allowed=null){const q=[start],prev=new Map([[start.id,null]]);let end=null;for(let i=0;i<q.length;i++){if(target(q[i])){end=q[i];break;}for(const id of ordered(q[i]))if((!allowed||allowed.has(id))&&!prev.has(id)){prev.set(id,q[i].id);q.push(graph.nodes.get(id));}}if(!end)return [];const out=[];for(let id=end.id;id!==null;id=prev.get(id))out.push(graph.nodes.get(id));return out.reverse();}
function roadAnchor(graph,p){let best;for(const n of graph.nodes.values())if(!best||Math.hypot(n.x+.5-p.x,n.y+.5-p.y)<Math.hypot(best.x+.5-p.x,best.y+.5-p.y))best=n;return best;}
function policeRoute(t,graph,analysis,building,home){
 const component=reachable(graph,home);if(component.size<2)return null;
 const nodes=[...component].sort().map(id=>graph.nodes.get(id)),places=[];
 for(const b of t.buildings.filter(b=>['bank','prison','police-station'].includes(b.type)).sort((a,b)=>a.id-b.id)){
  const access=entranceAccess(t,b),node=access&&roadAnchor(graph,access);
  if(node&&component.has(node.id))places.push({building:b,node,weight:b.type==='police-station'?1:3});
 }
 let seed=(building.id*2654435761+17)|0,duration=0,current=home;
 const random=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296;};
 const speed=1.12,timeline=[];
 const move=target=>{const points=path(graph,current,n=>n.id===target.id,component);for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],end=duration+Math.hypot(b.x-a.x,b.y-a.y)/speed;timeline.push({start:duration,end,a,b});duration=end;}current=target;};
 const stop=b=>{const end=duration+(b.type==='police-station'?6+Math.floor(random()*7):2+Math.floor(random()*3));timeline.push({start:duration,end,a:current,b:current,stopId:b.id});duration=end;};
 for(let tour=0;tour<5;tour++){
  stop(building);
  for(let leg=0;leg<6;leg++){
   const candidates=places.filter(p=>p.node.id!==current.id);let chosen=null;
   // Most legs check civic/security sites; the rest explore any connected
   // road, including spurs and dead ends. No cycle core is required.
   if(candidates.length&&random()<.7){let pick=random()*candidates.reduce((sum,p)=>sum+p.weight,0);chosen=candidates.find(p=>(pick-=p.weight)<0)||candidates.at(-1);}
   const others=nodes.filter(n=>n.id!==current.id),target=chosen?.node||others[Math.floor(random()*others.length)];
   move(target);const visit=chosen||places.find(p=>p.node.id===target.id);if(visit)stop(visit.building);
  }
  move(home);
 }
 return {id:building.id,kind:'police',speed,timeline,duration,analysis,home:home.id};
}
// Each usable police station has a patrol. Ambulances remain limited to one.
// Random choices are seeded for multiplayer replay.
export function buildPatrolRoutes(t){
 const graph=roadGraph(t),analysis=validateTransport(t),routes=[];
 for(const [type,kind]of [['police-station','police'],['hospital','ambulance']]){
  for(const building of t.buildings.filter(b=>b.type===type).sort((a,b)=>a.id-b.id)){
   const access=entranceAccess(t,building);if(!access)continue;
   const home=roadAnchor(graph,access);if(!home)continue;
   if(kind==='police'){const route=policeRoute(t,graph,analysis,building,home);if(route)routes.push(route);continue;}
   const core=cycleCore(graph,reachable(graph,home));if(!core.size)continue;
   const outbound=path(graph,home,n=>core.has(n.id));const timeline=[];let duration=0,seed=(building.id*2654435761+(kind==='police'?17:59))|0;
   const random=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296;};
   const speed=kind==='police'?1.12:1.0;
   const move=points=>{for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],end=duration+Math.hypot(b.x-a.x,b.y-a.y)/speed;timeline.push({start:duration,end,a,b});duration=end;}};
   for(let tour=0;tour<5;tour++){
    const end=duration+6+Math.floor(random()*7);timeline.push({start:duration,end,a:home,b:home,stopId:building.id});duration=end;move(outbound);
    let current=outbound.at(-1),previous=null;const trip=[current],steps=20+Math.floor(random()*25);
    for(let i=0;i<steps;i++){const choices=ordered(current).filter(id=>core.has(id)&&id!==previous?.id);if(!choices.length)break;const next=graph.nodes.get(choices[Math.floor(random()*choices.length)]);trip.push(next);previous=current;current=next;}
    move(trip);move(path(graph,current,n=>n.id===home.id));
   }
   routes.push({id:building.id,kind,speed,timeline,duration,analysis,home:home.id});break;
  }
 }
 return routes;
}
export function patrolPose(route,time){const pose=busPose(route,time);return {...pose,kind:route.kind,speed:pose.stopId?0:route.speed,halfLength:.45,halfWidth:.19};}
