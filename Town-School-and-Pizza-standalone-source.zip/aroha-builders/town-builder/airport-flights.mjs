import * as THREE from './vendor/three.module.js';
import {createImportedModel,importedModelRevision} from './imported-models.mjs';
import {AirportFlightMotion} from './airport-flight-motion.mjs';

export const airportFlightSignature=town=>(town.buildings||[]).filter(b=>b.type==='airport').map(b=>[b.id,b.x,b.y,b.rotation].join(':')).join('|')+':'+importedModelRevision('airport');
/** Shared source aircraft are separate world-space decorations, outside picking,
 * building shadows, route markers and collision simulation. The parent renderer
 * can clear the group normally: geometry and materials remain shared. */
export function createAirportFlights(town){
 const group=new THREE.Group();group.name='airport-flights';const records=(town.buildings||[]).filter(b=>b.type==='airport').map(b=>({id:b.id,building:{...b},motion:new AirportFlightMotion(b),plane:null,pose:null}));
 const up=new THREE.Vector3(0,1,0),forward=new THREE.Vector3(1,0,0),side=new THREE.Vector3(0,0,1),yaw=new THREE.Quaternion(),pitch=new THREE.Quaternion(),bank=new THREE.Quaternion();let startTime=null;
 const attach=record=>{const plane=createImportedModel('airport-plane');if(!plane)return;plane.name='airport-plane-'+record.id;plane.userData.airport=record.id;plane.traverse(m=>{if(!m.isMesh)return;m.castShadow=false;m.receiveShadow=false;m.userData.shadowCaster=false;m.userData.sharedGeometry=true;});record.plane=plane;group.add(plane);};
 for(const r of records)attach(r);
 group.userData.records=records;group.userData.signature=airportFlightSignature(town);
 group.userData.update=seconds=>{
  if(!Number.isFinite(seconds))return;startTime??=seconds;const elapsed=Math.max(0,seconds-startTime);
  for(const r of records){if(!r.plane)attach(r);const p=r.motion.pose(elapsed);r.pose=p;if(!r.plane)continue;r.plane.visible=p.visible;if(!p.visible)continue;r.plane.position.set(p.x,p.y,p.z);yaw.setFromAxisAngle(up,-p.heading);pitch.setFromAxisAngle(side,p.pitch);bank.setFromAxisAngle(forward,p.bank);r.plane.quaternion.copy(yaw).multiply(pitch).multiply(bank);}
 };
 return group;
}
