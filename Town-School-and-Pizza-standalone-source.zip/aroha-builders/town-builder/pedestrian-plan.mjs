// Cosmetic population only. Never modifies saved towns or multiplayer traffic.
import {WIDTH,HEIGHT,cells,footprint,lotSize,worldPoint,entrance} from './core.mjs';
import {transportGroundCells} from './ground-clearance.mjs';
import {findBreakdancePlaza,breakdanceState} from './pedestrian-events.mjs';
export const PEDESTRIAN_HEIGHT=.38;
export const hash=n=>{let h=(n|0)^0x9e3779b9;h=Math.imul(h^(h>>>16),0x85ebca6b);h=Math.imul(h^(h>>>13),0xc2b2ae35);return(h^(h>>>16))>>>0;};
const random=(s,n)=>hash(s+n*7919)/4294967296;
const tile=(x,z)=>Math.floor(z)*WIDTH+Math.floor(x);
export function pedestrianPlan(t,area={width:WIDTH,height:HEIGHT}){
 const width=Math.min(WIDTH,area.width??WIDTH),height=Math.min(HEIGHT,area.height??HEIGHT),buildings=t.buildings||[],homes=buildings.filter(b=>b.type==='house');
 const demand=Math.floor(homes.length/2);if(!demand)return [];
 const blocked=new Set([...transportGroundCells(t),...(t.rivers||[]),...(t.flowers||[])]),shade=new Set(),special=[];
 for(const b of buildings){for(const k of cells(b))blocked.add(k);if(b.type==='tree')for(let z=b.y-1;z<=b.y+1;z++)for(let x=b.x-1;x<=b.x+1;x++)shade.add(z*WIDTH+x);}
 const safe=(x,z)=>x>=.18&&z>=.18&&x<width-.18&&z<height-.18&&!blocked.has(tile(x,z));
 const anchor=(b,x,z,extra={})=>{const p=worldPoint(b,x,z);if(p.x>=.18&&p.y>=.18&&p.x<width-.18&&p.y<height-.18)special.push({x:p.x,z:p.y,heading:-b.rotation*Math.PI/4,...extra});};
 for(const b of buildings){
  if(b.type==='bus-stop'){
   // Exact authored bench centre, plus an unobstructed paved waiting position.
   anchor(b,.48,.40,{mode:'sit',base:.075,zone:'bus-seat'});
   const e=entrance(b);if(safe(e.approach.x,e.approach.y))special.push({x:e.approach.x,z:e.approach.y,heading:Math.atan2(-e.dx,-e.dy),mode:'stand',zone:'bus-wait'});
  }
  if(b.type==='park'&&!(b.variant>0)){
   const s=lotSize(b),small=b.size<3,x=small?.295:.28,z=small?.72:.75;
   anchor(b,x*s.w,z*s.d,{mode:'sit',base:.16,zone:'park-seat',heading:-b.rotation*Math.PI/4+(small?.32:.3)});
   anchor(b,.85*s.w,.66*s.d,{mode:'ground',zone:'park-grass'});
  }
 }
 const paving=new Set(t.pavement||[]),paths=[],grass=[];
 for(let z=0;z<height;z++)for(let x=0;x<width;x++)if(safe(x+.5,z+.5)){const p={x:x+.5,z:z+.5,zone:paving.has(z*WIDTH+x)?'path':shade.has(z*WIDTH+x)?'shade':'grass'};(p.zone==='path'?paths:grass).push(p);}
 const seed=hash(homes.reduce((s,b)=>s+hash(Number(b.id)||tile(b.x,b.y)),homes.length)),plaza=findBreakdancePlaza(paths,seed),used=new Set(),plan=[];
 const lookup=new Map([...paths,...grass].map(p=>[tile(p.x,p.z),p]));
 const make=(p,i)=>{
  const s=hash(seed+i*997),mode=p.mode||(p.zone==='shade'&&random(s,1)<.5?'ground':random(s,2)<.78?'walk':'stand');
  const route=[{x:p.x,z:p.z}];
  if(mode==='walk'){
   const routeUsed=new Set([tile(p.x,p.z)]);let at=p;
   for(let j=0;j<6;j++){
    const options=[[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dz])=>safe(at.x+dx,at.z+dz)).map(([dx,dz])=>lookup.get(tile(at.x+dx,at.z+dz))).filter(q=>q&&q.zone===p.zone&&!routeUsed.has(tile(q.x,q.z))&&!used.has(tile(q.x,q.z)));
    if(!options.length)break;at=options[hash(s+j)%options.length];routeUsed.add(tile(at.x,at.z));route.push({x:at.x,z:at.z});
   }
  }
  const model=plaza&&demand>=4?(i===0?5:[0,1,2,3,4,6,7][(i-1)%7]):i%8;
  return {...p,seed:s,model,mode:mode==='walk'&&route.length<2?'stand':mode,route,phase:random(s,3)*6.28,speed:.15+random(s,4)*.08,heading:p.heading??random(s,5)*Math.PI*2,base:p.base||0};
 };
 // The breakdancer spends ordinary time in the same safe plaza. The event
 // uses original supplied clips, and never creates additional residents.
 if(plaza&&demand>=4){
  const points=[[.5,.5],[plaza.size-.5,plaza.size-.5],[plaza.size-.5,.5],[.5,plaza.size-.5]].map(([x,z])=>paths.find(p=>p.x===plaza.x+x&&p.z===plaza.z+z)).filter(Boolean);
  for(let i=0;i<Math.min(4,demand,points.length);i++){
   const p=points[i],m=make({...p,mode:'walk'},i),a=(i-1)*Math.PI*2/3;
   m.route=[{x:p.x,z:p.z},{x:p.x+(p.x<plaza.cx?1:-1),z:p.z}];
   m.model=i===0?5:(i-1)%7;m.event={seed:plaza.seed,role:i===0?'dancer':'spectator',x:plaza.cx+(i?Math.sin(a)*.62:0),z:plaza.cz+(i?Math.cos(a)*.62:0)};
   used.add(tile(p.x,p.z));plan.push(m);
  }
 }
 const candidates=[...special,...paths,...grass];
 // Score once, then consume every eligible spot if necessary: no probabilistic
 // trial limit can leave demand unfilled when a valid tile remains available.
 const sorted=candidates.map((p,i)=>({p,score:p.mode!==undefined?random(seed,i)*.12:random(seed,i)+((p.zone==='path'||p.zone==='shade')?0:.2)})).sort((a,b)=>a.score-b.score);
 for(const {p}of sorted){if(plan.length>=demand)break;const k=tile(p.x,p.z);if(used.has(k))continue;used.add(k);plan.push(make(p,plan.length));}
 return plan;
}
export function pedestrianPose(p,time){
 let x=p.x,z=p.z,heading=p.heading,clip=p.mode,clock=time+p.phase;
 if(p.mode==='walk'){
  const n=p.route.length-1,trip=(time*p.speed+p.phase)%(2*n),forward=trip<n,u=forward?trip:2*n-trip,j=Math.min(n-1,Math.floor(u)),f=u-j,a=p.route[j],b=p.route[j+1];
  x=a.x+(b.x-a.x)*f;z=a.z+(b.z-a.z)*f;heading=Math.atan2((b.x-a.x)*(forward?1:-1),(b.z-a.z)*(forward?1:-1));
  // Pause naturally every few lengths without advancing off the safe route.
  clock=time*(p.speed/.18)+p.phase;
 }
 if(p.event){
  const e=breakdanceState(time,p.event.seed);x+=(p.event.x-x)*e.gathering;z+=(p.event.z-z)*e.gathering;
  if(e.active){heading=p.event.role==='spectator'?Math.atan2(-Math.sin((p.event.x-p.x)||.1),-(p.event.z-p.z)):p.heading;if(e.stage==='dance'||e.stage==='cheer'){clip='source';clock=e.phase-4;}}
 }
 return {x,z,heading,clip,clock,base:p.base};
}
