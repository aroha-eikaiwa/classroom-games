import {roadGraph} from './network.mjs';
import {validateTransport,transportHeightAt} from './transport.mjs';
import {reachable,cycleCore,path,patrolPose} from './patrol-route.mjs';
import {signalJunctions} from './traffic-signals.mjs';
import {busPose} from './bus-route.mjs';

export const PASSENGER_MODELS=Object.freeze(['compact','coupe','hatchback','minivan','offroad','pickup','sedan','sport','suv','wagon'].map(n=>'car-'+n));
export const TRAFFIC_PAINTS=Object.freeze(['#e75e51','#f3bd4b','#397fb9','#67aa79','#f1eee4','#546b82','#a77da8','#d68346','#85b5ba','#5e6268']);
const ordered=n=>[...n.neighbors].sort();
const randomSource=value=>{let seed=value|0||1;return()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296;};};

// Two houses earn one car. Only cycle-bearing road components can accept traffic;
// capacity and spawn clearances reserve space for the player and service vehicles.
// Every choice is seeded by house IDs, so all room participants get the same cars.
export function buildCivilianRoutes(t,existing=[]){
 const houses=t.buildings.filter(b=>b.type==='house').sort((a,b)=>a.id-b.id);if(houses.length<2)return [];
 const graph=roadGraph(t),analysis=validateTransport(t),handled=new Set(),components=[];
 for(const node of graph.nodes.values()){
  if(handled.has(node.id))continue;const connected=reachable(graph,node);for(const id of connected)handled.add(id);
  const core=cycleCore(graph,connected);if(!core.size)continue;
  const edges=graph.links.filter(e=>core.has(e.a.id)&&core.has(e.b.id)),length=edges.reduce((n,e)=>n+Math.hypot(e.a.x-e.b.x,e.a.y-e.b.y),0);
  const reserved=existing.filter(r=>r.timeline.some(item=>connected.has(item.a.id)||connected.has(item.b.id))).length;
  const capacity=Math.max(0,Math.floor(length/3)-reserved-1);if(!capacity)continue;
  components.push({core,edges,capacity,used:0});
 }
 const occupied=existing.map(r=>(r.kind?patrolPose:busPose)(r,0));if(t.start)occupied.push({x:t.start.x+.5,y:t.start.y+.5,height:0});
 const routes=[];
 for(let pair=0;pair+1<houses.length;pair+=2){
  const h=houses[pair],random=randomSource(Math.imul(h.id,2654435761)^houses[pair+1].id^0x51c3);
  const available=components.filter(c=>c.used<c.capacity).sort((a,b)=>distance(a,h)-distance(b,h));let selected=null;
  for(const component of available){
   const candidates=component.edges.flatMap(({a,b})=>[{a,b},{a:b,b:a}]);
   for(let i=candidates.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[candidates[i],candidates[j]]=[candidates[j],candidates[i]];}
   for(const {a,b}of candidates){
    const speed=1.05+random()*.2,mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2},timeline=[];let duration=0;
    const move=(from,to)=>{const end=duration+Math.hypot(to.x-from.x,to.y-from.y)/speed;if(end>duration){timeline.push({start:duration,end,a:from,b:to});duration=end;}};
    const heading=Math.atan2(b.x-a.x,b.y-a.y),spawn={x:mid.x+.5+Math.cos(heading)*.21,y:mid.y+.5-Math.sin(heading)*.21};spawn.height=transportHeightAt(analysis,spawn.x,spawn.y,'road');
    if(occupied.some(p=>Math.abs((p.height||0)-spawn.height)<.55&&Math.hypot(p.x-spawn.x,p.y-spawn.y)<1.8))continue;
    if(signalJunctions(graph).some(j=>Math.hypot(spawn.x-j.x,spawn.y-j.y)<1.8))continue;
    move(mid,b);let current=b,previous=a;
    // A long closed random walk branches at junctions and never enters a dead end.
    for(let step=0;step<160;step++){const choices=ordered(current).filter(id=>component.core.has(id)&&id!==previous.id);if(!choices.length)break;const next=graph.nodes.get(choices[Math.floor(random()*choices.length)]);move(current,next);previous=current;current=next;}
    for(const next of path(graph,current,n=>n.id===a.id,component.core).slice(1)){move(current,next);current=next;}
    move(a,mid);
    const route={id:'car-'+h.id+'-'+houses[pair+1].id,kind:'civilian',model:PASSENGER_MODELS[Math.floor(random()*PASSENGER_MODELS.length)],paint:TRAFFIC_PAINTS[Math.floor(random()*TRAFFIC_PAINTS.length)],speed,timeline,duration,analysis};
    const pose=patrolPose(route,0);
    if(occupied.some(p=>Math.abs((p.height||0)-pose.height)<.55&&Math.hypot(p.x-pose.x,p.y-pose.y)<1.8))continue;
    selected={route,pose,component};break;
   }
   if(selected)break;
  }
  if(selected){routes.push(selected.route);occupied.push(selected.pose);selected.component.used++;}
 }
 return routes;
}
function distance(component,house){return Math.min(...component.edges.map(({a,b})=>Math.hypot((a.x+b.x)/2-house.x,(a.y+b.y)/2-house.y)));}
