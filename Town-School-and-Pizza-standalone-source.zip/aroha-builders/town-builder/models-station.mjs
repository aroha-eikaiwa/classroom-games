import {M,P} from './model-kit.mjs';

// A small local Japanese station. Front access is +Y and the platform is -Y,
// matching the existing saved station/entrance and railway conventions.
export function buildJapaneseStation(type,k,w,d,variant){
 if(type!=='station'||variant!==1)return false;
 const {box,roof,beam,wallWindow,door,path,clock}=k;
 const timber='#68513d',roofColor='#505d64',green='#36816c';
 path(.05,0,.90,.29);box(.05,0,0,.90,.29,.075,'#c2bdae',M.stone);
 // Yellow tactile strip and platform canopy, kept wholly inside the plot.
 box(.06,.012,.077,.88,.023,.009,'#e3c65b',M.paving);
 for(const x of [.13,.46,.83]){box(x,.22,.075,.015,.018,.65,timber,M.wood);beam([x,.22,.69],[x+.045,.22,.60],.009,timber,M.wood,6);}
 roof(.04,.02,.74,.92,.30,.10,roofColor,M.slate);
 // White plaster, exposed timber and a low tiled gable roof.
 box(.17,.37,0,.66,.38,.075,'#a89c88',M.stone);
 box(.19,.39,.075,.62,.34,.61,'#e9e4d4',M.stucco);
 for(const x of [.19,.40,.60,.795])box(x,.39,.075,.015,.34,.62,timber,M.wood);
 for(const y of [.385,.72]){box(.19,y,.10,.62,.012,.035,timber,M.wood);box(.19,y,.65,.62,.012,.035,timber,M.wood);}
 roof(.13,.335,.71,.74,.45,.23,roofColor,M.slate);
 // Ridge caps and narrow tile ribs make the roof read at classroom zoom.
 for(let i=0;i<14;i++){const y=.342+i*.032;beam([.135,y,.713],[.50,y,.944],.006,'#647078',M.slate,5);beam([.50,y,.944],[.865,y,.713],.006,'#647078',M.slate,5);}
 door(.50,.737,.075,.155,.43,{glass:true,arched:false,frame:timber});
 wallWindow(0,.29,.74,.27,.13,.22,{arched:false,frame:timber,glass:'#7eaba7'});
 wallWindow(0,.71,.74,.27,.13,.22,{arched:false,frame:timber,glass:'#7eaba7'});
 wallWindow(2,.48,.385,.27,.22,.22,{arched:false,frame:timber,glass:'#7eaba7'});
 // Green railway sign, ticket machine, clock and platform waiting bench.
 box(.355,.753,.56,.29,.014,.085,P.ivory);box(.355,.770,.56,.29,.003,.018,green);
 for(const x of [.395,.43,.465,.50,.535,.57])box(x,.774,.593,.014,.003,.023,green);
 box(.795,.75,.075,.055,.055,.30,green,M.metal);box(.802,.807,.24,.041,.003,.067,'#274b53');box(.806,.808,.19,.033,.003,.025,'#dce4d9');
 clock(.69,.754,.59,.041);
 k.bench(.70,.28,.08);path(.43,.76,.14,.24);
 // Station-name board and a simple paved forecourt with two bollards.
 for(const x of [.18,.81])box(x,.91,0,.012,.012,.17,'#687373',M.metal);
 return true;
}
