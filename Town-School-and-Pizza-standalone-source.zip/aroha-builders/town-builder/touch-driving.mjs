// A relative drag pad works anywhere on the driving canvas, including on the car.
export function installTouchDriving(canvas,enabled){
 let drag=null,held={};const clear=()=>{drag=null;held={};};
 canvas.addEventListener('pointerdown',e=>{if(e.pointerType!=='touch'||!enabled())return;e.preventDefault();e.stopImmediatePropagation();if(drag)return;drag={id:e.pointerId,x:e.clientX,y:e.clientY};held={};canvas.setPointerCapture(e.pointerId);},true);
 canvas.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;e.preventDefault();e.stopImmediatePropagation();if(!enabled()){clear();return;}const x=e.clientX-drag.x,y=e.clientY-drag.y;held={w:y<-12,s:y>12,a:x<-16,d:x>16};},true);
 const end=e=>{if(drag?.id===e.pointerId){clear();e.stopImmediatePropagation();}};
 for(const name of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(name,end,true);
 window.addEventListener('blur',clear);document.addEventListener?.('visibilitychange',clear);
 return {input(){if(!enabled())clear();return held;},clear};
}
