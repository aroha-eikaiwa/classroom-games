import {buildSchoolGrounds} from './models-schools.mjs';
import {M,P} from './model-kit.mjs';

// Small synchronous stand-ins keep editing usable while v18 assets arrive.
export function buildImportedFallback(type,k,variant=0){
 if(type==='park'&&variant===2){k.grass();k.path(.43,.63,.14,.37);k.box(.18,.20,.015,.64,.44,.8,P.ivory,M.stucco);k.box(.12,.14,.815,.76,.56,.09,P.slate,M.slate);for(const y of [.06,.90])k.box(.06,y,.01,.88,.04,.35,P.ivory,M.stone);for(const x of [.06,.90])k.box(x,.06,.01,.04,.88,.35,P.ivory,M.stone);return true;}
 if(type==='temple'&&variant===1){k.grass();k.path(.44,.66,.12,.34);for(let i=0;i<5;i++){const width=.64-i*.08,side=(1-width)/2,z=.04+i*.56;k.box(side,side,z,width,width,.44,P.ivory,M.stucco);k.box(side-.06,side-.06,z+.44,width+.12,width+.12,.10,P.slate,M.slate);}return true;}
 if(type==='prison'){
  k.grass();k.path(.46,.84,.08,.16);k.box(.17,.18,.015,.66,.32,.8,'#a56d58',M.brick);
  for(const y of [.04,.92])for(const [x,w]of y>.5?[[.04,.39],[.57,.39]]:[[.04,.92]])k.box(x,y,.015,w,.035,.42,'#a8aaa1',M.stone);
  for(const x of [.04,.925])k.box(x,.06,.015,.035,.88,.42,'#a8aaa1',M.stone);
  for(const x of [.02,.86])for(const y of [.02,.86]){k.box(x,y,.015,.12,.12,.75,'#b2b4ab',M.stone);k.box(x-.01,y-.01,.765,.14,.14,.06,P.slate,M.slate);}
  return true;
 }
 if(type==='city-hall'){
  k.grass();k.path(.44,.72,.12,.28);
  for(const [x,y,w,d,z,h]of [[.10,.20,.80,.58,.015,.38],[.22,.25,.56,.44,.395,.37],[.35,.30,.30,.32,.765,.75]])k.box(x,y,z,w,d,h,P.ivory,M.stone);
  k.door(.5,.79,.015,.10,.25,{glass:true});return true;
 }
 if(type==='high-school'){k.grass();k.path(.46,.40,.08,.59);k.softBox(.10,.08,.025,.80,.34,.9,'#d6c6a5',M.stone,.01);for(let floor=0;floor<3;floor++)for(const x of [.18,.30,.42,.58,.70,.82])k.wallWindow(0,x,.423,.12+floor*.25,.08,.16,{glass:P.glass});k.door(.5,.43,.025,.13,.25,{glass:true});buildSchoolGrounds(k);return true;}
 if(type==='airport'){k.grass();k.box(.02,.10,.005,.96,.22,.015,'#555e65',M.asphalt);for(let x=.06;x<.95;x+=.08)k.box(x,.205,.022,.04,.012,.002,P.white);k.box(.03,.45,.025,.21,.37,.4,P.ivory,M.stucco);k.box(.25,.55,.025,.035,.09,.7,P.ivory,M.stucco);k.box(.235,.53,.725,.065,.13,.12,P.glass,M.stone);k.path(.44,.82,.12,.18);return true;}
 if(['bank','university','hotel','factory','city-hall','prison'].includes(type)){k.grass();k.path(.44,.78,.12,.22);k.box(.16,.15,.025,.68,.63,1,P.ivory,M.stone);for(let floor=0;floor<5;floor++)for(const x of [.23,.36,.49,.62,.75])k.wallWindow(0,x,.785,.10+floor*.17,.08,.10,{glass:P.glass});k.box(.14,.13,1.025,.72,.67,.045,P.slate,M.slate);k.door(.5,.79,.025,.12,.20,{glass:true});return true;}
 if(type!=='bakery'&&type!=='apartment'&&type!=='cinema')return false;
 k.grass();k.path(.44,.75,.12,.25);
 const apartment=type==='apartment',floors=apartment?6:2,storey=apartment?.34:.50;
 k.box(.12,.14,.025,.76,.61,floors*storey,apartment?'#c4c9c3':'#efdebd',M.stucco);
 for(let floor=0;floor<floors;floor++){
  const z=.08+floor*storey;
  for(const x of [.24,.42,.60,.78])k.wallWindow(0,x,.758,z+.06,.12,storey*.53,{arched:false,frame:P.ivory,glass:P.glass});
  for(const y of [.28,.48,.66])for(const side of [1,3])k.wallWindow(side,side===1?.885:.115,y,z+.06,.12,storey*.53,{arched:false,frame:P.ivory,glass:P.glass});
  if(apartment)k.box(.10,.73,z,.80,.09,.032,P.ivory,M.stone);
 }
 k.box(.10,.12,floors*storey+.025,.80,.65,.06,P.slate,M.slate);
 k.door(.50,.772,.025,.15,.31,{arched:false,color:P.honey,glass:true});
 if(!apartment){k.awning(.15,.78,.45,.70,.15,P.blue);for(const x of [.18,.78])k.planter(x,.87,.10);}
 return true;
}
