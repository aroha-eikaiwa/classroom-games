import * as THREE from './vendor/three.module.js';
import {createNatureTree,loadNatureModel} from './nature-models.mjs';

const bounds=new Map();
export async function loadImportedLandscape(entries=[]){
 const loaded=await Promise.all([...new Set(entries.map(p=>p.variant??5))].map(loadNatureModel));
 if(loaded.some(ok=>!ok))throw Error('Imported landscape unavailable');
 return loaded;
}
// A campus shares each source tree geometry/material and batches all its
// placements per species/material. Instance buffers belong only to this campus.
export function attachImportedLandscape(group,entries=[],variant='normal'){
 const species=new Map();for(const entry of entries){const v=entry.variant??5;if(!species.has(v))species.set(v,[]);species.get(v).push(entry);}
 for(const [v,rows]of species){
  const tree=createNatureTree(v,variant);if(!tree)continue;tree.updateMatrixWorld(true);
  let box=bounds.get(v);if(!box){box=new THREE.Box3().setFromObject(tree);bounds.set(v,box);}
  const size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3()),rebase=new THREE.Matrix4().makeTranslation(-center.x,-box.min.y,-center.z);
  tree.traverse(source=>{
   if(!source.isMesh)return;
   const batch=new THREE.InstancedMesh(source.geometry,source.material,rows.length);batch.name='campus-trees-'+v;batch.userData.sharedGeometry=true;batch.userData.landscapeVariant=v;batch.castShadow=!variant.startsWith('ghost');batch.receiveShadow=true;
   rows.forEach((p,i)=>{const s=p.height/size.y,matrix=new THREE.Matrix4().compose(new THREE.Vector3(p.x,p.y??0,p.z),new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),p.rotation??0),new THREE.Vector3(s,s,s));matrix.multiply(rebase).multiply(source.matrixWorld);batch.setMatrixAt(i,matrix);});
   batch.instanceMatrix.needsUpdate=true;batch.computeBoundingBox();batch.computeBoundingSphere();group.add(batch);
  });
 }
 group.userData.landscapeTrees=entries;
}
