import {WIDTH,HEIGHT} from './town-grid.mjs';
import {worldPoint} from './core.mjs';
import {AIRPORT_LAYOUT} from './airport-layout.mjs';

const TAU=Math.PI*2,smooth=u=>u*u*(3-2*u),mix=(a,b,u)=>a+(b-a)*u;
const inside=(x,z,margin=0)=>x>=margin&&x<=WIDTH-margin&&z>=margin&&z<=HEIGHT-margin;
const local=(b,p)=>{const v=worldPoint(b,p[0]+12,p[1]+3);return {x:v.x,z:v.y};};
const randomFor=(seed,index)=>{let s=(seed^Math.imul(index+1,0x9e3779b9))>>>0;return()=>{s=(s+0x6d2b79f5)>>>0;let v=s;v=Math.imul(v^(v>>>15),v|1);v^=v+Math.imul(v^(v>>>7),v|61);return((v^(v>>>14))>>>0)/4294967296;};};
export function airportFlightSeed(b){let n=2166136261;for(const c of [b.id,b.x,b.y,b.rotation].join(':'))n=Math.imul(n^c.charCodeAt(0),16777619);return n>>>0;}
function exitDistance(p,dx,dz){
 const candidates=[];if(dx>1e-9)candidates.push((WIDTH-p.x)/dx);if(dx< -1e-9)candidates.push(-p.x/dx);if(dz>1e-9)candidates.push((HEIGHT-p.z)/dz);if(dz< -1e-9)candidates.push(-p.z/dz);
 return Math.max(0,Math.min(...candidates.filter(v=>v>=0)));
}

/** A decoration-only schedule. Positions are world X/Y(height)/Z, in tiles.
 * The schedule is deterministic per airport, independent of frame size. Plane
 * visibility is strictly clipped to map bounds, including the entire away wait.
 */
export class AirportFlightMotion{
 constructor(building){
  this.building={...building};this.seed=airportFlightSeed(building);this.cycles=[];this.ends=[];
  const r=AIRPORT_LAYOUT.runway;this.runway=r;this.start=local(building,r.start);this.rotate=local(building,r.rotate);this.touchdown=local(building,r.touchdown);this.rollEnd=local(building,r.rollEnd);
  const a=building.rotation*Math.PI/4;this.dx=Math.cos(a);this.dz=Math.sin(a);this.heading=Math.atan2(this.dz,this.dx);
  this.departDistance=exitDistance(this.rotate,this.dx,this.dz)+4;
  this.finalStart={x:this.touchdown.x-this.dx*18,z:this.touchdown.z-this.dz*18};
  const back=Math.max(23,exitDistance(this.touchdown,-this.dx,-this.dz)+4);
  this.arrivalStart={x:this.touchdown.x-this.dx*back,z:this.touchdown.z-this.dz*back};
  this.approachDistance=back-18;
 }
 groundTurnInset(angle){
  const r=Math.abs(Math.cos(angle))*AIRPORT_LAYOUT.aircraftLength/2+Math.abs(Math.sin(angle))*AIRPORT_LAYOUT.aircraftWidth/2;
  return Math.max(0,r-(this.runway.start[1]+3-.03));
 }
 makeCycle(index,start){
  const random=randomFor(this.seed,index),ground=18+random()*26,away=22+random()*46,radius=2.6,side=random()<.5?-1:1;
  const sx=-this.dz*side,sz=this.dx*side,center={x:this.finalStart.x+sx*radius,z:this.finalStart.z+sz*radius};
  const canHold=inside(center.x,center.z,radius+AIRPORT_LAYOUT.aircraftClearance),holding=canHold&&random()<.5;
  const phases=[['ground',ground],['takeoff',6.8],['departure',Math.max(2,this.departDistance/4.6)],['away',away],['approach',Math.max(1,this.approachDistance/5)],...(holding?[['holding',14]]:[]),['landing',6],['rollout',5],['stopped',3],['turn-out',1.6],['taxi',7.5],['turn-in',1.6]];
  let elapsed=start;const timeline=phases.map(([phase,duration])=>{const p={phase,start:elapsed,end:elapsed+duration,duration};elapsed+=duration;return p;});
  return {index,start,end:elapsed,groundWait:ground,awayWait:away,holding,side,radius,sx,sz,timeline};
 }
 cycleAt(time){
  while(!this.ends.length||time>=this.ends.at(-1)){const c=this.makeCycle(this.cycles.length,this.ends.at(-1)||0);this.cycles.push(c);this.ends.push(c.end);}
  let lo=0,hi=this.ends.length-1;while(lo<hi){const mid=(lo+hi)>>1;if(time<this.ends[mid])hi=mid;else lo=mid+1;}return this.cycles[lo];
 }
 pose(seconds){
  const time=Number.isFinite(seconds)?Math.max(0,seconds):0,c=this.cycleAt(time),phase=c.timeline.find(p=>time<p.end)||c.timeline.at(-1),u=Math.max(0,Math.min(1,(time-phase.start)/phase.duration));
  const h=this.runway.groundHeight;let x=this.start.x,z=this.start.z,y=h,heading=this.heading,pitch=0,bank=0,visible=true;
  switch(phase.phase){
   case 'takeoff':{const p=u*u;x=mix(this.start.x,this.rotate.x,p);z=mix(this.start.z,this.rotate.z,p);pitch=Math.max(0,(u-.72)/.28)*.11;break;}
   case 'departure':{
    const distance=this.departDistance*u,climbDistance=Math.min(10,this.departDistance),q=Math.min(1,distance/climbDistance),rise=6.7-h;
    // Finish the climb inside/near the airport boundary, then cruise above the
    // town. Hermite's initial slope matches the .11-radian rotation at takeoff.
    const initialSlope=Math.tan(.11)*climbDistance/rise,climb=smooth(q)+initialSlope*q*(1-q)*(1-q),gradient=q<1?rise/climbDistance*(6*q*(1-q)+initialSlope*(3*q*q-4*q+1)):0;
    x=this.rotate.x+this.dx*distance;z=this.rotate.z+this.dz*distance;y=h+rise*climb;pitch=Math.atan(gradient);break;
   }
   case 'away':x=this.rotate.x+this.dx*this.departDistance;z=this.rotate.z+this.dz*this.departDistance;y=6.7;visible=false;break;
   case 'approach':x=mix(this.arrivalStart.x,this.finalStart.x,u);z=mix(this.arrivalStart.z,this.finalStart.z,u);y=mix(h+8.2,6.7,u);pitch=Math.atan2(6.7-h-8.2,this.approachDistance);break;
   case 'holding':{const a=u*TAU;x=this.finalStart.x+this.dx*c.radius*Math.sin(a)+c.sx*c.radius*(1-Math.cos(a));z=this.finalStart.z+this.dz*c.radius*Math.sin(a)+c.sz*c.radius*(1-Math.cos(a));y=6.7;heading=Math.atan2(this.dz*Math.cos(a)+c.sz*Math.sin(a),this.dx*Math.cos(a)+c.sx*Math.sin(a));bank=c.side*.20*Math.sin(Math.min(1,u*8)*Math.PI/2)*Math.sin(Math.min(1,(1-u)*8)*Math.PI/2);break;}
   case 'landing':x=mix(this.finalStart.x,this.touchdown.x,u);z=mix(this.finalStart.z,this.touchdown.z,u);y=mix(6.7,h,u);pitch=Math.atan2(h-6.7,18)*(1-smooth(Math.max(0,(u-.85)/.15)));break;
   case 'rollout':{const p=2*u-u*u;x=mix(this.touchdown.x,this.rollEnd.x,p);z=mix(this.touchdown.z,this.rollEnd.z,p);break;}
   case 'stopped':x=this.rollEnd.x;z=this.rollEnd.z;break;
   case 'turn-out':{const angle=Math.PI*smooth(u),inset=this.groundTurnInset(angle);x=this.rollEnd.x-this.dz*inset;z=this.rollEnd.z+this.dx*inset;heading+=angle;break;}
   case 'taxi':x=mix(this.rollEnd.x,this.start.x,smooth(u));z=mix(this.rollEnd.z,this.start.z,smooth(u));heading+=Math.PI;break;
   case 'turn-in':{const angle=Math.PI*(1-smooth(u)),inset=this.groundTurnInset(angle);x-=this.dz*inset;z+=this.dx*inset;heading+=angle;break;}
  }
  return {x,y,z,heading,pitch,bank,visible:visible&&inside(x,z),phase:phase.phase,cycle:c.index,progress:u,holding:c.holding};
 }
}
