import {TaxiPassengers} from './taxi-passengers.mjs';
import {taxiDropoffMarker} from './taxi-effects.mjs';
import {Pedestrians} from './pedestrians.mjs';
import {applyVehicleRoadPose} from './vehicle-road-pose.mjs';
import {airportFlightSignature,createAirportFlights} from './airport-flights.mjs';
import {MALL_CAR_MODELS} from './mall-parking.mjs';
import {landscapeTreeAssets,landscapeTreeRevision} from './landscape-trees.mjs';
import {createBridgePickers,disposeBridgePickers,pickBridge3D,pickBridgeFlat} from './bridge-picking.mjs';
import {ModelLoads} from './model-loading.mjs';
import {loadFountain,fountainRevision} from './fountain-model.mjs';
import {renderVehicle} from './vehicle-choice.mjs';
import {createPassengerFleet,loadPassengerModel,passengerRevision,passengerModelRevision} from './passenger-models.mjs';
import {createPavementSurface,loadPavementTexture} from './pavement-surface.mjs';
import {RoadTraffic} from './road-traffic.mjs';
import {emergencyRevision,loadEmergencyModel,createEmergencyVehicle} from './emergency-models.mjs';
import {loadImportedModel,loadImportedModels,importedModelsRevision,importedModelRevision,importedModelName,createImportedBuilding} from './imported-models.mjs';
import {groundStaticBaseFaces} from './imported-grounding.mjs';
import {uniqueStaticFaces} from './mesh-surfaces.mjs';
import {loadGiraffe,giraffeRevision} from './giraffe-model.mjs';
import {loadElephant,elephantRevision} from './elephant-model.mjs';
import {loadNatureModel,natureRevision,natureTreeRevision,createNatureTree} from './nature-models.mjs';
import {loadWoodlandPark,woodlandParkRevision,createWoodlandPark} from './park-model.mjs';
import {loadCherryTree,createCherryTree,cherryTreeRevision} from './cherry-tree.mjs';
import {attachAttractionAnimation,createDestinationArrow} from './attraction-animation.mjs';
import {createBus,loadBusTexture} from './bus-model.mjs';
import {buildBusRoutes,busPose} from './bus-route.mjs';
import {trainTraffic,busTrafficPose} from './train-traffic.mjs';
import {signalAspect} from './traffic-signals.mjs';
import {createCrossingGates,updateCrossingGates} from './crossing-gates.mjs';
import * as THREE from './vendor/three.module.js';
import {CATALOG,WIDTH,HEIGHT,byType,lotSize,footprint,worldPoint,cells,xy,key,entrance,entranceAccess,readiness} from './core.mjs';
import {makeModel,modelHeight} from './models.mjs';
import {roadGraph,trafficLightPlacements} from './network.mjs';
import {validateTransport,transportHeightAt} from './transport.mjs';
import {createTransportFixtures,extractRoadDecks} from './transport-fixtures.mjs';
import {paintRoadMap,paintRailMap,loadTrackTexture,trackArtRevision,loadRoadTexture,roadArtRevision} from './terrain-map.mjs';
import {createTrain,loadTrainTextures} from './train.mjs';
import {buildTrainRoutes,buildParkedTrains,TrainMotion} from './train-route.mjs';
import {createFlowerSurface} from './flowers.mjs';
import {createRiverSurface} from './water.mjs';
import {createCar,loadCarTextures,carModelRevision} from './car-model.mjs';
import {buildingMaterial,loadBuildingMaterials,setBuildingGrass,updateBuildingGlow,MATERIAL_SCALE} from './building-materials.mjs';
export {createCar,loadBuildingMaterials};
export const loadCarArt=loadCarTextures;
import {TownRenderer as FlatRenderer,drawThumbnail as flatThumbnail,hitBuilding as flatHitBuilding} from './render.mjs';
import {artwork} from './art.mjs';
import {watchGraphicsContext,graphicsPixelRatio} from './graphics-recovery.mjs';
import {roadRules} from './road-limits.mjs';
const loadingGeometry=new THREE.BoxGeometry(1,1,1),loadingMaterial=new THREE.MeshStandardMaterial({color:'#b5c9c5',roughness:.9,transparent:true,opacity:.42,depthWrite:false});loadingMaterial.userData.shared=true;
const RES=Math.round(40*40/WIDTH),UP=new THREE.Vector3(0,1,0),geometryCache=new Map();
const canvas2d=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c;};
const texture=c=>{const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=4;return t;};
function material(color,extra={}){return new THREE.MeshLambertMaterial({color,side:THREE.DoubleSide,...extra});}
export function geometryFromFaces(faces,{height=1,centerX=0,centerY=0}={}){
 const pos=[],cols=[],uv=[],surfaces=[],groups=[],smoothKeys=[],explicitNormals=[];
 for(const f of [...faces].sort((a,b)=>(a.material??-1)-(b.material??-1))){
  const textured=Number.isInteger(f.material),surface=textured?f.material+1:0,color=new THREE.Color(f.color);
  if((f.material>=16&&f.material<=20)||f.material===26||f.material===27)color.set('#ffffff');
  const uvScale=MATERIAL_SCALE[f.material]||1.6,start=pos.length/3,points=f.points;
  let nx=0,ny=0,nz=0;for(let i=0;i<points.length;i++){const a=points[i],b=points[(i+1)%points.length];nx+=(a[1]-b[1])*(a[2]+b[2])*height;ny+=(a[2]-b[2])*height*(a[0]+b[0]);nz+=(a[0]-b[0])*(a[1]+b[1]);}
  const ax=Math.abs(nx),ay=Math.abs(ny),az=Math.abs(nz),plane=az>=ax&&az>=ay?'xy':ax>=ay?'yz':'xz';
  for(let i=1;i<points.length-1;i++){
   const a=points[0],b=points[i],c=points[i+1],ab=[b[0]-a[0],b[1]-a[1],(b[2]-a[2])*height],ac=[c[0]-a[0],c[1]-a[1],(c[2]-a[2])*height];
   if(Math.hypot(ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0])<1e-10)continue;
   // Swapping source Y/Z changes handedness; reverse the fan so outward
   // normals also remain outward for the shadow camera's normal bias.
   for(const index of [0,i+1,i]){const p=points[index];pos.push(p[0]-centerX,p[2]*height,p[1]-centerY);cols.push(color.r,color.g,color.b);uv.push((plane==='yz'?p[1]:p[0])/uvScale,(plane==='xy'?p[1]:p[2]*height)/uvScale);surfaces.push(surface);smoothKeys.push(f.smooth===undefined?null:`${f.smooth}:${p.map(v=>Math.round(v*1e6)).join(',')}`);const n=f.normals?.[index];explicitNormals.push(n?[n[0],n[2]/height,n[1]]:null);}
  }
  const count=pos.length/3-start;if(groups.at(-1)?.materialIndex===surface)groups.at(-1).count+=count;else groups.push({start,count,materialIndex:surface});
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setAttribute('color',new THREE.Float32BufferAttribute(cols,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setAttribute('surface',new THREE.Float32BufferAttribute(surfaces,1));for(const group of groups)g.addGroup(group.start,group.count,group.materialIndex);g.computeVertexNormals();
 // Only curved primitives share normals. Unmarked caps, masonry and roof edges
 // keep their crisp creases, while transformed ellipses receive correct normals.
 const averaged=new Map(),normal=g.attributes.normal;
 for(let i=0;i<pos.length/3;i+=3){if(!smoothKeys[i]&&!smoothKeys[i+1]&&!smoothKeys[i+2])continue;const a=i*3,b=a+3,c=a+6,ab=[pos[b]-pos[a],pos[b+1]-pos[a+1],pos[b+2]-pos[a+2]],ac=[pos[c]-pos[a],pos[c+1]-pos[a+1],pos[c+2]-pos[a+2]],n=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]];for(let j=i;j<i+3;j++){const k=smoothKeys[j];if(k===null)continue;const sum=averaged.get(k)||[0,0,0];for(let axis=0;axis<3;axis++)sum[axis]+=n[axis];averaged.set(k,sum);}}
 for(let i=0;i<normal.count;i++){const n=explicitNormals[i]||averaged.get(smoothKeys[i]);if(n){const l=Math.hypot(...n);if(l>1e-10)normal.setXYZ(i,n[0]/l,n[1]/l,n[2]/l);}}
 g.computeBoundingBox();g.computeBoundingSphere();return g;
}
export function buildingModelKey(b){const {w,d}=lotSize(b);return `${b.type}:${b.size||1}:${b.plot||1}:${b.variant||0}:${w}x${d}${importedModelName(b)?':'+importedModelRevision(importedModelName(b)):''}${['hospital','fire-station','police-station'].includes(b.type)?':'+emergencyRevision(b.type):''}${b.type==='shopping-mall'?':'+MALL_CAR_MODELS.map(passengerModelRevision).join('.'):''}${b.type==='zoo'?':'+giraffeRevision()+':'+elephantRevision():''}${b.type==='tree'?':'+(b.variant===2?cherryTreeRevision():natureTreeRevision(b.variant||0)):''}${b.type==='park'&&b.variant===1?':'+woodlandParkRevision():b.type==='park'?':'+fountainRevision():''}:${landscapeTreeRevision(b)}`;}
const animationCache=new Map();
export function buildingGeometry(b){const {w,d}=lotSize(b),id=buildingModelKey(b);if(!geometryCache.has(id)){
 // Ground-level lawn boxes duplicate the terrain and cast rectangular seams.
 // Leave grass areas open to the continuous world lawn; retain every path,
 // playground, foundation and elevated model surface. Saved plots are unchanged.
 const height=modelHeight(b.type,b.variant||0),faces=groundStaticBaseFaces(makeModel(b.type,w,d,b.variant||0).filter(f=>f.material!==16),{maxBase:b.type==='library'?.12:.055}),groups=new Map();
 geometryCache.set(id,geometryFromFaces(uniqueStaticFaces(faces.filter(f=>!f.animation)),{height,centerX:w/2,centerY:d/2}));
 for(const f of faces)if(f.animation){if(!groups.has(f.animation))groups.set(f.animation,[]);groups.get(f.animation).push(f);}
 animationCache.set(id,[...groups].map(([animation,faces])=>{const [x,y,z]=animation.center,geometry=geometryFromFaces(faces,{height,centerX:x,centerY:y});geometry.translate(0,-z*height,0);return {animation,geometry,origin:[x-w/2,z*height,y-d/2],w,d,height};}));
 }return geometryCache.get(id);}
function box(w,h,d,color,x=0,y=0,z=0){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material(color));m.position.set(x,y+h/2,z);return m;}
export function groundPlane(map,y=0,order=2){const m=new THREE.Mesh(new THREE.PlaneGeometry(WIDTH,HEIGHT),new THREE.MeshStandardMaterial({map,roughness:.96,transparent:true,depthWrite:false,side:THREE.FrontSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1}));m.rotation.x=-Math.PI/2;m.position.set(WIDTH/2,y,HEIGHT/2);m.renderOrder=order;m.receiveShadow=true;return m;}
function clearGroup(group){const disposed=new Set(),dispose=value=>{if(value&&!disposed.has(value)){disposed.add(value);value.dispose();}};for(const child of [...group.children]){group.remove(child);child.traverse(o=>{if(o.isInstancedMesh)dispose(o);if(o.geometry&&!o.userData.sharedGeometry)dispose(o.geometry);if(o.material){for(const m of Array.isArray(o.material)?o.material:[o.material])if(!m.userData.shared)dispose(m);}if(o.userData.highlightBase&&!o.userData.highlightBase.userData.shared)dispose(o.userData.highlightBase);});}}
// Imported models keep their own textures. Highlight only this placed instance,
// retaining shared materials for all the other copies on the map.
const importedHighlightColors={destination:new THREE.Color('#ffd75a'),points:new THREE.Color('#50e6aa'),blocked:new THREE.Color('#ef645b')};
export function setImportedHighlight(group,state,time=0){
 if(group.userData.highlightState!==state){
  group.traverse(mesh=>{if(!mesh.isMesh||(!mesh.material?.emissive&&!mesh.material?.isMeshBasicMaterial))return;
   const original=mesh.userData.highlightBase||mesh.material;
   if(mesh.userData.highlightBase){mesh.material.dispose();mesh.material=original;delete mesh.userData.highlightBase;}
   if(state!=='normal'){mesh.userData.highlightBase=original;mesh.material=original.clone();mesh.material.userData.shared=false;if(mesh.material.emissive)mesh.material.emissive.set(state==='destination'?'#ffd75a':state==='points'?'#50e6aa':'#ef645b');}
  });group.userData.highlightState=state;
 }
 if(state!=='normal')group.traverse(mesh=>{if(mesh.userData.highlightBase){const strength=state==='destination'?.32+.15*Math.sin(time*3):.3;if(mesh.material.emissive)mesh.material.emissiveIntensity=strength;else mesh.material.color.copy(mesh.userData.highlightBase.color).lerp(importedHighlightColors[state]||importedHighlightColors.blocked,strength);}});
}
const signMaps=new Map(),signMaterials=new Map(),signGeometries=new Map(),hiddenGeometry=new Map();
function addBuildingSign(group,b){
 if(typeof document==='undefined'||byType[b.type].decorative)return;const name=byType[b.type].en;let map=signMaps.get(name);
 if(!map){const c=canvas2d(512,192),ctx=c.getContext('2d');ctx.fillStyle='#fff7dc';ctx.fillRect(0,0,512,192);ctx.strokeStyle='#4b7055';ctx.lineWidth=12;ctx.strokeRect(6,6,500,180);ctx.fillStyle='#315542';ctx.font='bold 44px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';const words=name.split(' ');if(name.length>17&&words.length>1){ctx.fillText(words.slice(0,-1).join(' '),256,65,475);ctx.fillText(words.at(-1),256,125,475);}else ctx.fillText(name,256,96,475);map=texture(c);signMaps.set(name,map);}
 const {w,d}=lotSize(b),geometryKey=w+'x'+d;let signMaterial=signMaterials.get(name);if(!signMaterial){signMaterial=new THREE.MeshBasicMaterial({map,vertexColors:true,side:THREE.DoubleSide});signMaterial.userData.shared=true;signMaterials.set(name,signMaterial);}if(signGeometries.has(geometryKey)){const mesh=new THREE.Mesh(signGeometries.get(geometryKey),signMaterial);mesh.userData.sharedGeometry=true;mesh.userData.shadowCaster=false;group.add(mesh);return;}const width=Math.min(1.05,w*.32),height=width*192/512,x=-w*.32,z=d/2-.13,parts=new THREE.Group();parts.add(box(.035,.42,.035,'#816d49',x-width*.35,0,z),box(.035,.42,.035,'#816d49',x+width*.35,0,z));
 const sign=new THREE.Mesh(new THREE.PlaneGeometry(width,height),new THREE.MeshBasicMaterial({color:'#ffffff'}));sign.position.set(x,.37,z+.02);parts.add(sign);const merged=mergeColoredMeshes(parts),count=merged.geometry.attributes.position.count,uv=new Float32Array(count*2);
 // The tiny posts sample a blank cream corner; the sign face uses the full image.
 for(let i=0;i<count-6;i++){uv[i*2]=.5/512;uv[i*2+1]=.5/192;}uv.set([0,1,0,0,1,1,0,0,1,0,1,1],(count-6)*2);merged.geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));merged.material.dispose();merged.material=signMaterial;merged.userData.sharedGeometry=true;merged.userData.shadowCaster=false;signGeometries.set(geometryKey,merged.geometry);group.add(merged);clearGroup(parts);
}
// Static decorative geometry is uploaded once per edit and drawn in one batch.
export function mergeColoredMeshes(group,{shared=false}={}){
 const pos=[],normals=[],colors=[],normalMatrix=new THREE.Matrix3(),v=new THREE.Vector3(),n=new THREE.Vector3();group.updateMatrixWorld(true);
 group.traverse(o=>{if(!o.isMesh||o.userData.dynamic)return;const g=o.geometry,p=g.attributes.position,normal=g.attributes.normal,index=g.index,color=o.material.color||new THREE.Color('#ffffff');normalMatrix.getNormalMatrix(o.matrixWorld);for(let i=0;i<(index?index.count:p.count);i++){const j=index?index.getX(i):i;v.fromBufferAttribute(p,j).applyMatrix4(o.matrixWorld);n.fromBufferAttribute(normal,j).applyMatrix3(normalMatrix).normalize();pos.push(v.x,v.y,v.z);normals.push(n.x,n.y,n.z);colors.push(color.r,color.g,color.b);}});
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));geometry.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geometry.computeBoundingSphere();const mesh=new THREE.Mesh(geometry,material('#ffffff',{vertexColors:true}));mesh.userData.sharedGeometry=shared;return mesh;
}
export class TownRenderer{
 constructor(canvas){this.canvas=canvas;this.w=1;this.h=1;this.zoom=1;this.pan={x:0,y:0};this.angle=0;this.yaw=Math.PI/4;this.pitch=.80;this.cx=WIDTH/2;this.cy=HEIGHT/2;this.baseScale=15;this.scale=15;this.mode='build';this.driveDistance=2.8;this.lookYaw=0;this.lookPitch=0;this.cameraTarget=new THREE.Vector3(WIDTH/2,0,HEIGHT/2);this.camera=new THREE.PerspectiveCamera(45,1,.08,180);this.scene=new THREE.Scene();this.scene.background=new THREE.Color('#dbe9e0');this.scene.fog=new THREE.Fog('#dbe9e0',90,155);this.ray=new THREE.Raycaster();this.ground=new THREE.Plane(UP,0);this.buildings=new THREE.Group();this.fixtures=new THREE.Group();this.preview=new THREE.Group();this.trains=new THREE.Group();this.trainRecords=new Map();this.scene.add(this.buildings,this.fixtures,this.preview,this.trains);this.initializeLighting();this.car=createCar();this.car.visible=false;this.scene.add(this.car);this.pedestrians=new Pedestrians(this.scene);this.signature='';this.terrainSignature='';this.ghostSignature='';this.meshById=new Map();this.lastTick=0;
  try{this.reducedGraphics=sessionStorage.getItem('town-graphics-reduced')==='1';}catch{}
  try{this.webgl=new THREE.WebGLRenderer({canvas,antialias:!this.reducedGraphics,alpha:false,powerPreference:'high-performance'});this.webgl.setPixelRatio(Math.min(globalThis.devicePixelRatio||1,this.reducedGraphics?1:1.35));this.webgl.outputColorSpace=THREE.SRGBColorSpace;this.webgl.toneMapping=THREE.ACESFilmicToneMapping;this.webgl.toneMappingExposure=1.02;this.webgl.shadowMap.enabled=true;this.webgl.shadowMap.type=THREE.PCFShadowMap;this.webgl.shadowMap.autoUpdate=false;this.webgl.shadowMap.needsUpdate=true;}catch{this.graphicsUnavailable=true;if(this.webgl&&canvas.ownerDocument&&canvas.parentElement)this.useSoftwareMap();else this.fallback=new FlatRenderer(canvas,{gpu:false,pixelRatioLimit:1});return;}
  this.graphicsRecovery=watchGraphicsContext(canvas,this.webgl,globalThis,{onLost:()=>{this.reducedGraphics=true;try{sessionStorage.setItem('town-graphics-reduced','1');}catch{}},onRestored:()=>{this.invalidateShadows();this.resize();},onUnavailable:()=>this.useSoftwareMap()});
  this.initializeTerrain();

 }
 buildingAssets(b){
  const assets=[],add=(key,load,ready)=>assets.push({key,load,ready});
  const name=importedModelName(b);if(name)add(name,()=>loadImportedModel(name),!!importedModelRevision(name));
  if(b.type==='shopping-mall')for(const model of MALL_CAR_MODELS)add(model,()=>loadPassengerModel(model),!!passengerModelRevision(model));
  if(b.type==='police-station')add('police',()=>loadEmergencyModel('police'),!!emergencyRevision(b.type));
  if(b.type==='hospital')add('ambulance',()=>loadEmergencyModel('ambulance'),!!emergencyRevision(b.type));
  if(b.type==='fire-station')add('fire-truck',()=>loadEmergencyModel('fire-truck'),!!emergencyRevision(b.type));
  if(b.type==='zoo'){add('giraffe',loadGiraffe,!!giraffeRevision());add('elephant',loadElephant,!!elephantRevision());}
  if(b.type==='tree'){
   if(b.variant===2)add('cherry',loadCherryTree,!!cherryTreeRevision());
   else if([0,4,5,6].includes(b.variant||0))add('nature-'+(b.variant||0),()=>loadNatureModel(b.variant||0),!!natureTreeRevision(b.variant||0));
  }
  if(b.type==='park'&&b.variant===1)add('woodland',loadWoodlandPark,!!woodlandParkRevision());
  if(b.type==='park'&&(b.variant??0)===0&&b.size>=3)add('fountain',loadFountain,!!fountainRevision());
  assets.push(...landscapeTreeAssets(b));
  return assets;
 }
 preloadBuilding(b){
  if(typeof Image==='undefined'||this.fallback)return;
  this.modelLoads??=new ModelLoads();for(const asset of this.buildingAssets(b))this.modelLoads.request(asset.key,asset.load,asset.ready);
 }
 buildingLoading(b){return !!this.modelLoads?.loading(this.buildingAssets(b).map(asset=>asset.key));}
 renderBuildingKey(b){return buildingModelKey(b)+(this.buildingLoading(b)?':loading':'');}
 updateLoadingStatus(){
  const loading=!!this.modelLoads?.pending;if(this.lastLoadingStatus===loading)return;this.lastLoadingStatus=loading;
  this.canvas?.setAttribute?.('aria-busy',String(loading));
  if(!this.modelStatus&&loading&&this.canvas?.ownerDocument&&this.canvas.parentElement){const status=this.canvas.ownerDocument.createElement('div');status.className='model-loading';status.setAttribute('role','status');status.textContent='Loading models…';this.canvas.parentElement.append(status);this.modelStatus=status;}
  if(this.modelStatus)this.modelStatus.hidden=!loading;
 }
 ensureResources(t,ghost,mode,revision){
  if(typeof Image==='undefined')return;
  const ghostKey=ghost?buildingModelKey(ghost):'',car=mode==='walk'||mode==='host',carModel=renderVehicle(this.lastAvatar?.vehicle).model;
  if(this.resourceTown===t&&this.resourceBuildings===t.buildings&&this.resourceRevision===revision&&this.resourceGhost===ghostKey&&this.resourceCar===car&&this.resourceCarModel===carModel)return;
  this.resourceTown=t;this.resourceBuildings=t.buildings;this.resourceRevision=revision;this.resourceGhost=ghostKey;this.resourceCar=car;this.resourceCarModel=carModel;
  this.modelLoads??=new ModelLoads();
  const once=(key,load,ready=false)=>this.modelLoads.request(key,load,ready);
  once('surfaces',async()=>{await Promise.all([loadBuildingMaterials(),loadTrackTexture(),loadRoadTexture(),loadPavementTexture()]);});
  for(const b of ghost?[...t.buildings,ghost]:t.buildings){
   this.preloadBuilding(b);
   if(b.type==='bus-stop')once('bus',loadBusTexture);
   if(b.type==='station')once('train',loadTrainTextures);
  }
  if(car)once('player-'+carModel,()=>loadCarTextures(carModel),!!carModelRevision(carModel));
  for(const name of new Set(trainTraffic(t).cars.map(r=>r.model)))once(name,()=>loadPassengerModel(name));
 }
 rayBuildingCandidates(){
  const hit=this.cameraRayHit??=new THREE.Vector3(),candidates=this.cameraCandidates??=[];candidates.length=0;
  for(const group of this.buildings.children){if(!group.visible)continue;const bounds=group.userData.cameraBounds;if(!bounds||bounds.containsPoint(this.ray.ray.origin)||(this.ray.ray.intersectBox(bounds,hit)&&hit.distanceTo(this.ray.ray.origin)<=this.ray.far))candidates.push(group);}
  return candidates;
 }
 initializeLighting(){
  // One cached sun shadow is shared by the whole town. Sky and warm ground fill
  // keep shaded entrances readable without adding a light for every building.
  this.scene.add(new THREE.HemisphereLight('#e7f0ff','#b8aa7e',2.0));
  this.sun=new THREE.DirectionalLight('#fff0d0',2.8);this.sun.position.set(WIDTH/2-28,44,HEIGHT/2-16);this.sun.target.position.set(WIDTH/2,0,HEIGHT/2);this.sun.castShadow=true;
  Object.assign(this.sun.shadow.camera,{left:-32*WIDTH/40,right:32*WIDTH/40,top:29*HEIGHT/32,bottom:-29*HEIGHT/32,near:1,far:140});this.sun.shadow.camera.updateProjectionMatrix();this.sun.shadow.mapSize.set(2048,2048);this.sun.shadow.bias=-.00018;this.sun.shadow.normalBias=.025;this.sun.shadow.radius=2;this.sun.shadow.autoUpdate=false;this.sun.shadow.needsUpdate=true;this.scene.add(this.sun,this.sun.target);
 }
 invalidateShadows(){if(this.webgl?.shadowMap)this.webgl.shadowMap.needsUpdate=true;if(this.sun?.shadow)this.sun.shadow.needsUpdate=true;}
 initializeTerrain(){const base=box(WIDTH,.18,HEIGHT,'#8aaf69',WIDTH/2,-.18,HEIGHT/2);this.scene.add(base);this.grassMaterial=new THREE.MeshStandardMaterial({color:'#afc98e',roughness:.87,side:THREE.DoubleSide});const ground=new THREE.Mesh(new THREE.PlaneGeometry(WIDTH,HEIGHT),this.grassMaterial);ground.rotation.x=-Math.PI/2;ground.position.set(WIDTH/2,.001,HEIGHT/2);ground.receiveShadow=true;this.scene.add(ground);
  this.river=createRiverSurface({resolution:Math.round(24*40/WIDTH)});this.scene.add(this.river.group);this.flowers=createFlowerSurface();this.scene.add(this.flowers.group);this.pavement=createPavementSurface();this.scene.add(this.pavement.mesh);
  this.roadCanvas=canvas2d(WIDTH*RES,HEIGHT*RES);this.roadTex=texture(this.roadCanvas);this.scene.add(groundPlane(this.roadTex,.027));this.railCanvas=canvas2d(WIDTH*RES,HEIGHT*RES);this.railTex=texture(this.railCanvas);this.scene.add(groundPlane(this.railTex,.035,3));const lines=[];for(let x=0;x<=WIDTH;x++)lines.push(x,.04,0,x,.04,HEIGHT);for(let z=0;z<=HEIGHT;z++)lines.push(0,.04,z,WIDTH,.04,z);const gg=new THREE.BufferGeometry();gg.setAttribute('position',new THREE.Float32BufferAttribute(lines,3));this.grid=new THREE.LineSegments(gg,new THREE.LineBasicMaterial({color:'#edf4db'}));this.grid.material.transparent=true;this.grid.material.opacity=.25;this.grid.visible=false;this.scene.add(this.grid);this.initializeCarShadow();
 }
 initializeCarShadow(){
  const c=canvas2d(64,64),ctx=c.getContext('2d'),fade=ctx.createRadialGradient(32,32,6,32,32,32);fade.addColorStop(0,'rgba(28,41,32,.30)');fade.addColorStop(.65,'rgba(28,41,32,.17)');fade.addColorStop(1,'rgba(28,41,32,0)');ctx.fillStyle=fade;ctx.fillRect(0,0,64,64);
  const mat=new THREE.MeshBasicMaterial({map:texture(c),transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1});this.carShadow=new THREE.Mesh(new THREE.PlaneGeometry(.50,1.02),mat);this.carShadow.rotation.x=-Math.PI/2;this.carShadow.visible=false;this.scene.add(this.carShadow);
 }
 setBuildArea(area={width:WIDTH,height:HEIGHT}){
  const width=Math.max(1,Math.min(WIDTH,Math.floor(area?.width||WIDTH))),height=Math.max(1,Math.min(HEIGHT,Math.floor(area?.height||HEIGHT)));
  if(this.buildArea?.width===width&&this.buildArea?.height===height)return;
  this.buildArea={width,height};this.fallback?.setBuildArea(this.buildArea);
  if(this.fallback||width===WIDTH&&height===HEIGHT){if(this.lockedLand)this.lockedLand.visible=false;return;}
  // Reuse two unit planes and one boundary buffer as access changes. Locked
  // land is presentation only; coordinates and the saved grid never shrink.
  if(!this.lockedLand){
   const group=new THREE.Group(),geometry=new THREE.PlaneGeometry(1,1),shade=new THREE.MeshBasicMaterial({color:'#586b68',transparent:true,opacity:.58,depthWrite:false,side:THREE.DoubleSide});
   const planes=[new THREE.Mesh(geometry,shade),new THREE.Mesh(geometry,shade)];
   for(const plane of planes){plane.rotation.x=-Math.PI/2;plane.renderOrder=3;group.add(plane);}
   const edgeGeometry=new THREE.BufferGeometry();edgeGeometry.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(12),3));
   const edge=new THREE.LineSegments(edgeGeometry,new THREE.LineBasicMaterial({color:'#e3d9a0',transparent:true,opacity:.9,depthWrite:false}));edge.renderOrder=4;group.add(edge);
   this.scene.add(group);this.lockedLand=group;this.lockedLandPlanes=planes;this.lockedLandEdge=edge;
  }
  const [right,bottom]=this.lockedLandPlanes;right.visible=width<WIDTH;right.scale.set(WIDTH-width,HEIGHT,1);right.position.set((WIDTH+width)/2,.065,HEIGHT/2);
  bottom.visible=height<HEIGHT;bottom.scale.set(width,HEIGHT-height,1);bottom.position.set(width/2,.065,(HEIGHT+height)/2);
  const position=this.lockedLandEdge.geometry.attributes.position;position.array.set([width,.08,0,width,.08,height,0,.08,height,width,.08,height]);position.needsUpdate=true;this.lockedLandEdge.geometry.computeBoundingSphere();
  this.lockedLand.visible=this.mode==='build';
 }
 resize(){const rect=this.canvas.getBoundingClientRect();this.w=Math.max(1,rect.width);this.h=Math.max(1,rect.height);this.camera.aspect=this.w/this.h;this.camera.updateProjectionMatrix();if(this.webgl&&!this.fallback){this.webgl.setDrawingBufferSize(this.w,this.h,graphicsPixelRatio(this.w,this.h,{reduced:this.reducedGraphics}));}if(this.fallback)this.fallback.resize();this.fit();}
 useSoftwareMap(){
  if(this.fallback)return;
  this.reducedGraphics=true;try{sessionStorage.setItem('town-graphics-reduced','1');}catch{}
  // A WebGL canvas cannot become a 2D canvas. Keep it as the input surface
  // and draw on a separate, non-interactive canvas so all tools keep working.
  const surface=this.canvas.ownerDocument.createElement('canvas');surface.className='graphics-map-fallback';surface.setAttribute('aria-hidden','true');
  Object.assign(surface.style,{position:'absolute',inset:'0',width:'100%',height:'100%',pointerEvents:'none'});
  if(this.canvas.parentElement.insertBefore)this.canvas.parentElement.insertBefore(surface,this.canvas.nextSibling);else this.canvas.parentElement.append(surface);
  this.fallback=new FlatRenderer(surface,{gpu:false,pixelRatioLimit:1});this.fallbackCanvas=surface;this.graphicsUnavailable=true;
  this.canvas.style.opacity='0';this.canvas.setAttribute?.('aria-busy','false');if(this.modelStatus)this.modelStatus.hidden=true;
  this.graphicsRecovery?.useFallback();
  try{this.webgl?.dispose();this.webgl?.forceContextLoss();}catch{}
  this.resize();
 }
 fit(){this.baseScale=Math.min(this.w/(58*WIDTH/40),this.h/(42*HEIGHT/32));this.scale=this.baseScale*this.zoom;this.updateCamera(this.mode==='walk'?this.lastAvatar:null,true);}
 toggleFollow(){this.followLocked=!this.followLocked;if(this.followLocked)this.resetView('walk');return this.followLocked;}
 look(dx,dy){if(this.mode!=='walk'||this.followLocked)return;this.lookYaw=(this.lookYaw-dx*.006)%(Math.PI*2);this.lookPitch=Math.max(-.16,Math.min(1.0,this.lookPitch+dy*.004));this.updateCamera(this.lastAvatar,true);}
 orbit(dx,dy){if(this.mode==='walk')return;{this.yaw-=dx*.006;this.pitch=Math.max(.35,Math.min(1.42,this.pitch+dy*.004));}this.updateCamera(this.lastAvatar,true);}
 panBy(dx,dy){if(this.fallback){const a=this.groundPoint(0,0),b=this.groundPoint(dx,dy);this.cx-=b.x-a.x;this.cy-=b.y-a.y;this.updateCamera(null,true);return;}const s=this.mode==='walk'?this.driveDistance/this.h*1.1:(65*WIDTH/40)/this.zoom/this.h;this.cx-=dx*Math.cos(this.yaw)*s+dy*Math.sin(this.yaw)*s;this.cy+=dx*Math.sin(this.yaw)*s-dy*Math.cos(this.yaw)*s;this.updateCamera(null,true);}
 zoomBy(factor){if(this.mode==='walk')return;else this.zoom=Math.max(1,Math.min(12,this.zoom*factor));this.fit();}
 resetView(mode=this.mode){this.pan={x:0,y:0};if(mode==='walk'){this.driveDistance=2.8;this.lookYaw=0;this.lookPitch=0;}else{this.zoom=1;this.cx=WIDTH/2;this.cy=HEIGHT/2;this.yaw=Math.PI/4;this.pitch=.80;}this.updateCamera(this.lastAvatar,true);}
 setMode(mode,avatar){if(this.mode!==mode){this.mode=mode;this.followLocked=false;this.lookYaw=0;this.lookPitch=0;this.driveDistance=2.8;this.cameraTarget.set(avatar?avatar.x+.5:WIDTH/2,avatar?.45:0,avatar?avatar.y+.5:HEIGHT/2);}this.lastAvatar=avatar;this.updateCamera(avatar,true);}
 updateCamera(avatar=this.lastAvatar,snap=false){
 // Apply shared limits for wheel/buttons, touch gestures, resize and fallback rendering.
 this.zoom=Math.max(1,Math.min(12,this.zoom));
 this.driveDistance=2.8;
 this.cx=Math.max(2,Math.min(WIDTH-2,this.cx));this.cy=Math.max(2,Math.min(HEIGHT-2,this.cy));
 let target,yaw,pitch,dist;if(this.mode==='walk'&&avatar){target=new THREE.Vector3(avatar.x+.5,.5,avatar.y+.5);yaw=avatar.heading+Math.PI+this.lookYaw;pitch=.24+this.lookPitch;dist=2.8;this.driveDistance=2.8;target.y+=transportHeightAt(this.transport,avatar.x+.5,avatar.y+.5,'road');this.camera.fov=55;}else{target=new THREE.Vector3(this.cx,0,this.cy);yaw=this.yaw;pitch=this.pitch;dist=(65*WIDTH/40)/this.zoom*Math.max(1,1.25/this.camera.aspect);this.camera.fov=45;}
  this.cameraTarget.lerp(target,snap?1:.22);const offset=new THREE.Vector3(Math.sin(yaw)*Math.cos(pitch)*dist,Math.sin(pitch)*dist,Math.cos(yaw)*Math.cos(pitch)*dist);let desired=this.cameraTarget.clone().add(offset);
  if(this.mode==='walk'&&avatar&&dist<18){this.ray.set(this.cameraTarget,offset.clone().normalize());this.ray.far=dist;const hit=this.ray.intersectObjects(this.rayBuildingCandidates(),true).find(h=>h.object.visible&&h.distance>1);if(hit)desired=this.cameraTarget.clone().add(offset.normalize().multiplyScalar(Math.max(1.4,hit.distance-.35)));}
  this.camera.position.lerp(desired,snap?1:.22);this.camera.lookAt(this.cameraTarget);this.camera.near=this.mode==='walk'&&avatar ? .08 : Math.max(.25,Math.min(2,dist/100));this.camera.far=Math.max(180,dist+100);if(this.scene.fog){this.scene.fog.near=Math.max(90,dist+25);this.scene.fog.far=Math.max(155,dist+90);}if(this.lastFov!==this.camera.fov||this.lastNear!==this.camera.near||this.lastFar!==this.camera.far){this.camera.updateProjectionMatrix();this.lastFov=this.camera.fov;this.lastNear=this.camera.near;this.lastFar=this.camera.far;}this.camera.updateMatrixWorld();this.scale=this.h/(2*Math.tan(this.camera.fov*Math.PI/360)*dist);if(this.fallback){Object.assign(this.fallback,{zoom:this.zoom,pan:this.pan,cx:this.cx,cy:this.cy,angle:Math.round((this.yaw-Math.PI/4)/(Math.PI/2)+4)%4});this.fallback.fit();}
 }
 project(x,y,z=0){if(this.fallback)return this.fallback.project(x,y,z);const p=new THREE.Vector3(x,z,y).project(this.camera);return[(p.x+1)*this.w/2,(1-p.y)*this.h/2];}
 groundPoint(sx,sy){if(this.fallback){const r=this.fallback,a=(sx-r.w/2-r.pan.x)/(.7071*r.scale),b=(sy-r.h/2-25-r.pan.y)/(.3889*r.scale);let x=(a+b)/2,y=(b-a)/2;for(let n=0;n<(4-r.angle)%4;n++)[x,y]=[-y,x];return{x:x+r.cx,y:y+r.cy};}this.ray.setFromCamera(new THREE.Vector2(sx/this.w*2-1,1-sy/this.h*2),this.camera);const p=this.ray.ray.intersectPlane(this.ground,new THREE.Vector3());return p?{x:p.x,y:p.z}:{x:-999,y:-999};}
 unproject(x,y){if(this.fallback)return this.fallback.unproject(x,y);const p=this.groundPoint(x,y);return{x:Math.floor(p.x),y:Math.floor(p.y)};}
 pick(t,sx,sy){this.ray.far=Infinity;if(this.fallback)return flatHitBuilding(this.fallback,t,sx,sy);this.ray.setFromCamera(new THREE.Vector2(sx/this.w*2-1,1-sy/this.h*2),this.camera);for(const h of this.ray.intersectObjects(this.rayBuildingCandidates(),true)){let o=h.object,visible=true;while(o){if(!o.visible)visible=false;if(o.userData.building)break;o=o.parent;}if(visible&&o?.userData.building){const surface=h.object.geometry?.attributes.surface,vertex=h.faceIndex*3;if(h.point.y<.10||(surface&&surface.getX(vertex)===17))continue;return t.buildings.find(b=>b.id===o.userData.building);}}return null;}
 pickErase(t,sx,sy,{layer=null}={}){
  const p=this.unproject(sx,sy),hit=(!layer||layer==='building')?this.pick(t,sx,sy):null;
  if(hit)return {p,hit,layer:'building'};
  if(!layer||layer==='road'||layer==='rail'){
   let bridge;
   if(this.fallback)bridge=pickBridgeFlat(t,(...p)=>this.project(...p),sx,sy);
   else{this.ray.far=Infinity;this.ray.setFromCamera(new THREE.Vector2(sx/this.w*2-1,1-sy/this.h*2),this.camera);bridge=pickBridge3D(this.bridgePickers,this.ray);}
   if(bridge&&(!layer||bridge.layer===layer))return bridge;
  }
  // The road is elevated here: visible ground inside its cell is river water.
  if(!layer&&t.rivers?.includes(key(p.x,p.y))&&validateTransport(t).bridges.some(b=>b.waterCells.includes(key(p.x,p.y))))return {p,hit:null,layer:'river'};
  return {p,hit:null,layer};
 }
 makeBuilding(b,hidden=false,variant='normal'){const loading=!hidden&&this.buildingLoading(b),group=new THREE.Group(),size=lotSize(b),bounds=footprint(b),imported=!hidden&&!loading?createImportedBuilding(b,variant,size):null,natureTree=!hidden&&!loading&&b.type==='tree'?createNatureTree(b.variant||0,variant):null;group.userData.building=b.id;group.position.set(b.x+bounds.w/2,0,b.y+bounds.d/2);group.rotation.y=-b.rotation*Math.PI/4;
  if(hidden){const id=size.w+'x'+size.d;if(!hiddenGeometry.has(id)){const blocks=new THREE.Group();for(let y=0;y<size.d;y++)for(let x=0;x<size.w;x++)blocks.add(box(.92,1.35,.92,'#aab2af',x+.5-size.w/2,0,y+.5-size.d/2));const mesh=mergeColoredMeshes(blocks);hiddenGeometry.set(id,mesh.geometry);clearGroup(blocks);mesh.material.dispose();}const mesh=new THREE.Mesh(hiddenGeometry.get(id),material('#aab2af'));mesh.userData.sharedGeometry=true;group.add(mesh);}
  else if(loading){const height=Math.max(.45,Math.min(3,modelHeight(b.type,b.variant||0))),mat=variant.startsWith('ghost')?loadingMaterial.clone():loadingMaterial;if(mat!==loadingMaterial){mat.userData.shared=false;if(variant==='ghost-invalid')mat.color.set('#ef7575');}const mesh=new THREE.Mesh(loadingGeometry,mat);mesh.scale.set(size.w*.82,height,size.d*.82);mesh.position.y=height/2+.04;mesh.userData.sharedGeometry=true;mesh.userData.shadowCaster=false;group.add(mesh);group.userData.loadingModel=true;group.userData.importedModel=true;addBuildingSign(group,b);}
  else if(imported){group.add(imported);group.userData.importedModel=true;group.userData.animate=t=>imported.userData.animate?.(t);addBuildingSign(group,b);}
  else if(b.type==='tree'&&b.variant===2&&cherryTreeRevision()){group.add(createCherryTree(variant));group.userData.importedTree=true;}
  else if(natureTree){group.add(natureTree);group.userData.importedTree=true;group.userData.animate=t=>natureTree.userData.animate?.(t);}
  else if(b.type==='park'&&b.variant===1&&woodlandParkRevision()){const park=createWoodlandPark(variant);park.scale.setScalar(size.w/5);group.add(park);group.userData.importedModel=true;group.userData.animate=t=>park.userData.animate?.(t);addBuildingSign(group,b);}
  else{const mesh=new THREE.Mesh(buildingGeometry(b),buildingMaterial(variant));mesh.userData.sharedGeometry=true;if(b.type==='tree'&&b.variant===2)mesh.scale.setScalar(1.6);group.add(mesh);attachAttractionAnimation(group,b,animationCache.get(buildingModelKey(b))||[],buildingMaterial(variant),variant);addBuildingSign(group,b);}
  group.traverse(o=>{if(o.isMesh){o.castShadow=!variant.startsWith('ghost')&&o.userData.shadowCaster!==false;o.receiveShadow=o.userData.shadowReceiver!==false;}});group.userData.hidden=hidden;group.userData.model=this.renderBuildingKey(b);group.userData.rotation=b.rotation;
  return group;
 }
 syncBuildings(t,seen,mode,revealAll=false){
  const ids=new Set(t.buildings.map(b=>b.id));for(const[id,g]of this.meshById)if(!ids.has(id)){clearGroup(g);this.buildings.remove(g);this.meshById.delete(id);}
  for(const b of t.buildings){const hidden=mode==='walk'&&!revealAll&&!byType[b.type].decorative&&!seen.has(b.id),model=this.renderBuildingKey(b);let g=this.meshById.get(b.id);if(!g||g.userData.hidden!==hidden||g.userData.model!==model){if(g){clearGroup(g);this.buildings.remove(g);}g=this.makeBuilding(b,hidden);this.buildings.add(g);this.meshById.set(b.id,g);}const f=footprint(b);g.position.set(b.x+f.w/2,0,b.y+f.d/2);g.rotation.y=-b.rotation*Math.PI/4;g.userData.rotation=b.rotation;
   const boundsKey=b.x+':'+b.y+':'+b.rotation+':'+model;if(g.userData.cameraBoundsKey!==boundsKey){g.updateMatrixWorld(true);g.userData.cameraBounds=new THREE.Box3().setFromObject(g);g.userData.cameraBounds.expandByScalar(.04);g.userData.cameraBoundsKey=boundsKey;}
  }
 }
 rebuildBuildings(t,seen,mode){this.syncBuildings(t,seen,mode);this.invalidateShadows();}
 addEntrance(b,valid,back=false){const e=entrance(b,back),group=new THREE.Group(),color=valid?(back?'#a9bad1':'#efca66'):'#ed6259';group.position.set(e.x,.045,e.y);group.rotation.y=-b.rotation*Math.PI/4+(back?Math.PI:0);group.add(box(.58,.025,.30,color,0,0,-.15));if(!back){group.add(box(.04,.33,.04,color,-.28,0,-.07),box(.04,.33,.04,color,.28,0,-.07));const shape=new THREE.Shape();shape.moveTo(0,-.25);shape.lineTo(-.12,-.09);shape.lineTo(.12,-.09);shape.closePath();const arrow=new THREE.Mesh(new THREE.ShapeGeometry(shape),new THREE.MeshBasicMaterial({color:'#fff8df',side:THREE.DoubleSide}));arrow.rotation.x=-Math.PI/2;arrow.position.y=.03;group.add(arrow);}this.fixtures.add(group);}
 rebuildFixtures(t,mode){clearGroup(this.fixtures);this.redIds=[];const connected=!!t.start;for(const b of t.buildings){if(byType[b.type].decorative)continue;const okay=!!entranceAccess(t,b,{connected}),railOkay=b.type!=='station'||!!entranceAccess(t,b,{back:true});if(!okay||!railOkay)this.redIds.push(b.id);if(mode==='build'){this.addEntrance(b,okay);if(b.type==='station')this.addEntrance(b,railOkay,true);}}
  this.transport=validateTransport(t);this.syncTrains(t,this.transport);this.syncRoadTraffic(t,this.transport);const transport=createTransportFixtures(t,this.transport);disposeBridgePickers(this.bridgePickers);this.bridgePickers=createBridgePickers(transport,this.transport);this.fixtures.add(transport);const crossingLights=transport.userData.crossingLights||[];
  this.signals=[];for(const {x,y,rotation,phase,phaseCount} of trafficLightPlacements(t)){const g=new THREE.Group();g.position.set(x,0,y);g.rotation.y=rotation;g.add(box(.045,.78,.045,'#43584f'),box(.15,.35,.12,'#294039',0,.72,0));for(let i=0;i<3;i++){const bulb=new THREE.Mesh(new THREE.SphereGeometry(.045,8,6),new THREE.MeshBasicMaterial({color:'#42574c'}));bulb.position.set(0,1.0-i*.10,.068);bulb.userData.dynamic=true;g.add(bulb);this.signals.push({bulb,i,phase,phaseCount});}this.fixtures.add(g);}
  if(t.start){const flag=new THREE.Group();flag.position.set(t.start.x+.5,.04,t.start.y+.5);flag.add(box(.045,1.1,.045,'#80694d',-.3,0,0),box(.40,.24,.018,'#ffffff',-.10,.88,0));for(let y=0;y<3;y++)for(let x=0;x<5;x++)if((x+y)%2===0)flag.add(box(.08,.08,.022,'#151515',-.26+x*.08,.88+y*.08,0));this.fixtures.add(flag);}
  this.fixtures.updateMatrixWorld(true);const roadDeck=extractRoadDecks(this.fixtures);const lightPositions=[...this.signals.map(s=>({position:s.bulb.getWorldPosition(new THREE.Vector3()),i:s.i,phase:s.phase,phaseCount:s.phaseCount,kind:'traffic'})),...crossingLights.map(s=>({...s,kind:'crossing'}))],merged=mergeColoredMeshes(this.fixtures);merged.castShadow=true;merged.receiveShadow=true;clearGroup(this.fixtures);this.fixtures.add(merged);if(roadDeck)this.fixtures.add(roadDeck);this.signalMesh=null;
  if(lightPositions.length){const mesh=new THREE.InstancedMesh(new THREE.SphereGeometry(.045,8,6),new THREE.MeshBasicMaterial({color:'#ffffff'}),lightPositions.length),matrix=new THREE.Matrix4();for(let i=0;i<lightPositions.length;i++){matrix.makeTranslation(...lightPositions[i].position.toArray());mesh.setMatrixAt(i,matrix);mesh.setColorAt(i,new THREE.Color('#42574c'));}mesh.instanceMatrix.needsUpdate=true;this.fixtures.add(mesh);this.signalMesh=mesh;}this.signals=lightPositions;this.signalPhase=-1;this.invalidateShadows();
 }
 syncAirportFlights(t,tick,{mode='build',seen=new Set(),revealAll=false,ghost=null}={}){
  const visible=t.buildings.filter(b=>b.type==='airport'&&b.id!==ghost?.id&&(mode!=='walk'||revealAll||seen.has(b.id))),flightTown={buildings:visible},signature=airportFlightSignature(flightTown);
  if(this.airportFlightKey!==signature){if(this.airportFlights){clearGroup(this.airportFlights);this.scene?.remove(this.airportFlights);}this.airportFlights=createAirportFlights(flightTown);this.airportFlightKey=signature;this.scene?.add(this.airportFlights);}
  this.airportFlights?.userData.update(tick);
 }
 syncRoadTraffic(t,analysis){
  const previousRoadTraffic=this.roadTraffic;
  if(this.busGroup){clearGroup(this.busGroup);this.scene?.remove(this.busGroup);}if(this.crossingGates){clearGroup(this.crossingGates);this.scene?.remove(this.crossingGates);}
  this.busGroup=new THREE.Group();this.traffic=trainTraffic(t);this.busRecords=this.traffic.buses.map(route=>{const group=createBus();this.busGroup.add(group);return {route,group};});this.patrolRecords=(this.traffic.patrols||[]).map(route=>{const group=createEmergencyVehicle(route.kind);if(group)this.busGroup.add(group);return {route,group};});this.scene?.add(this.busGroup);this.crossingGates=createCrossingGates(analysis);this.scene?.add(this.crossingGates);this.passengerFleet=null;this.passengerVersion=-1;this.traffic=trainTraffic(t);this.roadTraffic=new RoadTraffic(this.traffic);if(previousRoadTraffic?.traffic.signature===this.traffic.signature)this.roadTraffic.restore(previousRoadTraffic.snapshot());this.trafficTime??=0;
 }
 syncTrains(t,analysis){
  this.trainRecords??=new Map();if(!this.trains){this.trains=new THREE.Group();this.scene?.add(this.trains);}
  const routes=buildTrainRoutes(t,analysis),parked=buildParkedTrains(t,routes,analysis),keep=new Set();
  for(const route of routes){
   keep.add(route.stationId);const signature=JSON.stringify([route.kind,route.samples.map(p=>[p.x,p.y]),route.stops,analysis.bridges.filter(b=>b.kind==='rail').map(b=>[b.id,b.deckHeight])]);let record=this.trainRecords.get(route.stationId);
   if(record?.signature===signature)continue;
   if(record){clearGroup(record.group);this.trains.remove(record.group);}
   const group=createTrain(),motion=new TrainMotion(route);group.userData.stationId=route.stationId;group.userData.update(motion);this.trains.add(group);this.trainRecords.set(route.stationId,{signature,group,motion});
  }
  for(const waiting of parked){
   keep.add(waiting.stationId);const signature='parked:'+JSON.stringify(waiting.pose);let record=this.trainRecords.get(waiting.stationId);if(record?.signature===signature)continue;
   if(record){clearGroup(record.group);this.trains.remove(record.group);}
   const group=createTrain({carCount:1}),motion={route:{stationId:waiting.stationId},update(){},pose(){return waiting.pose;}};group.userData.stationId=waiting.stationId;group.userData.update(motion);this.trains.add(group);this.trainRecords.set(waiting.stationId,{signature,group,motion});
  }
  for(const[id,record]of this.trainRecords)if(!keep.has(id)){clearGroup(record.group);this.trains.remove(record.group);this.trainRecords.delete(id);}
 }
 draw(t,options={}){
  try{return this.drawScene(t,options);}catch(error){
   if(this.fallback)throw error;
   this.useSoftwareMap();
   return this.drawScene(t,options);
  }
 }
 drawScene(t,{mode='build',seen=new Set(),avatar=null,ghost=null,valid=true,grid=false,selected=null,destination=null,tick=0,roadPreview=null,pointHover=null,revision,guidance=true,revealAll=false,buildArea=this.buildArea,taxi=null}={}){
  if(!this.fallback&&this.webgl?.getContext?.()?.isContextLost?.())this.graphicsRecovery?.lostNow();
  if(this.graphicsRecovery?.lost&&!this.fallback)return;
  const taxiStop=taxiDropoffMarker(taxi,avatar);
  destination=taxiStop?.building??(mode==='host'&&guidance?destination:null);selected=guidance?(destination??selected):null;
  const dt=Math.min(.05,Math.max(0,tick-(this.lastTick||tick)));this.lastTick=tick;this.lastAvatar=avatar;if(this.mode!==mode)this.setMode(mode,avatar);this.updateCamera(avatar);
  this.setBuildArea(buildArea);if(this.lockedLand)this.lockedLand.visible=mode==='build'&&(this.buildArea.width<WIDTH||this.buildArea.height<HEIGHT);
  if(this.fallback){this.fallback.draw(t,{mode,seen,avatar,ghost,valid,grid,selected,destination,tick,roadPreview,pointHover,guidance,revealAll,buildArea:this.buildArea,taxi});return;}
  this.ensureResources(t,ghost,mode,revision);
  this.updateLoadingStatus();
  this.syncAirportFlights(t,tick,{mode,seen,revealAll,ghost});
  if(artwork.grass&&!this.grassMaterial.map){const tex=new THREE.Texture(artwork.grass);tex.needsUpdate=true;tex.colorSpace=THREE.SRGBColorSpace;tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(WIDTH/8,HEIGHT/8);tex.anisotropy=4;this.grassMaterial.map=tex;this.grassMaterial.color.set('#ffffff');this.grassMaterial.needsUpdate=true;setBuildingGrass(tex);}
  const references=[t,t.roads,t.roadEdges,t.rivers,t.rivers?.length,t.rails,t.railEdges,t.flowers,t.flowers?.length,t.pavement,t.pavement?.length,trackArtRevision(),roadArtRevision(),revision],terrainInputsChanged=!this.terrainInputs||references.some((v,i)=>v!==this.terrainInputs[i]);
  if(terrainInputsChanged){this.terrainInputs=references;const terrain=JSON.stringify([t.roads,t.roadEdges,t.rivers,t.rails,t.railEdges,t.flowers,t.pavement,trackArtRevision(),roadArtRevision()]);if(this.terrainSignature!==terrain){this.terrainSignature=terrain;this.river.update(t);this.flowers?.update(t);this.pavement?.update(t);paintRoadMap(this.roadCanvas.getContext('2d'),t,RES);this.roadTex.needsUpdate=true;paintRailMap(this.railCanvas.getContext('2d'),t,RES);this.railTex.needsUpdate=true;}}
  const buildingKey=[importedModelsRevision(),giraffeRevision(),elephantRevision(),cherryTreeRevision(),natureRevision(),woodlandParkRevision(),fountainRevision(),this.modelLoads?.revision||0].join(':')+':'+(revision===undefined?t.buildings.map(b=>`${b.id}:${buildingModelKey(b)}:${b.x}:${b.y}:${b.rotation}`).join('|'):revision);
  const seenKey=mode==='walk'&&!revealAll?[...seen].join(','):'',modelMode=mode+':'+revealAll;
  const modelsChanged=this.modelTown!==t||this.modelKey!==buildingKey||this.modelMode!==modelMode;
  if(modelsChanged||seenKey!==this.seenKey){this.syncBuildings(t,seen,mode,revealAll);this.modelTown=t;this.modelKey=buildingKey;this.modelMode=modelMode;this.seenKey=seenKey;this.invalidateShadows();}
  const fixturesKey=this.terrainSignature+'|'+(mode==='build')+'|'+buildingKey+'|'+t.start?.x+','+t.start?.y;
  if(fixturesKey!==this.fixturesSignature){this.fixturesSignature=fixturesKey;this.rebuildFixtures(t,mode);this.redSet=new Set(this.redIds);}
  if(this.pedestrians){const inputs=[t,buildingKey,this.terrainSignature,this.buildArea.width,this.buildArea.height];
   if(!this.pedestrianInputs||inputs.some((v,i)=>v!==this.pedestrianInputs[i])){this.pedestrianInputs=inputs;this.pedestrians.sync(t,this.buildArea,(this.pedestrianRevision=(this.pedestrianRevision||0)+1));}
   this.pedestrians.lowPower=!!this.reducedGraphics;this.pedestrians.tick(tick);}
  if(taxi||this.taxiPassengers){this.taxiPassengers??=new TaxiPassengers(this.scene);this.taxiPassengers.syncChallenge(taxi,avatar);this.taxiPassengers.lowPower=!!this.reducedGraphics;this.taxiPassengers.tick(tick);}
  updateBuildingGlow(tick);
  if(this.shadowGhostId!==ghost?.id){this.shadowGhostId=ghost?.id;this.invalidateShadows();}
  for(const[id,g]of this.meshById){g.visible=ghost?.id!==id;if(g.userData.hidden)continue;const state=mode==='build'&&id===pointHover?'points':id===destination?'destination':mode==='build'&&this.redSet.has(id)?'blocked':'normal';if(g.userData.importedModel)setImportedHighlight(g,state,tick);else if(!g.userData.importedTree){const mat=buildingMaterial(state);g.children[0].material=mat;for(const p of g.userData.animationParts||[]){if(p.mesh?.userData.importedLandscapeTree||p.mesh?.userData.parkedPassenger)setImportedHighlight(p.mesh,state,tick);else if(p.mesh&&!p.mesh.userData.importedAnimal&&!p.mesh.userData.importedVehicle&&!['fountain','stadium-light','arcade-light'].includes(p.a.kind))p.mesh.material=mat;}}g.userData.animate?.(tick);}
  if(!this.destinationArrow){this.destinationArrow=createDestinationArrow();this.scene.add(this.destinationArrow);}
  const destinationGroup=!taxi&&this.meshById.get(destination);this.destinationArrow.visible=!!destinationGroup;
  if(destinationGroup){if(this.arrowTarget!==destinationGroup){this.arrowTarget=destinationGroup;destinationGroup.updateMatrixWorld(true);this.arrowHeight=new THREE.Box3().setFromObject(destinationGroup).max.y+.85;}this.destinationArrow.position.set(destinationGroup.position.x,this.arrowHeight+Math.sin(tick*2.5)*.13,destinationGroup.position.z);this.destinationArrow.rotation.y=tick*.5;}

  this.trafficTime=Number.isFinite(avatar?.trainTime)?avatar.trainTime:(this.trafficTime||0)+dt;
  for(const record of this.trainRecords?.values()||[]){if(record.motion instanceof TrainMotion){record.motion.time=this.trafficTime;record.motion.update(0);}else record.motion.update(dt);record.group.userData.update(record.motion);record.group.visible=true;}
  const roadTrafficVisible=mode!=='host'&&avatar?.roadTrafficEnabled!==false;if(this.busGroup&&this.busGroup.visible!==roadTrafficVisible){this.busGroup.visible=roadTrafficVisible;this.invalidateShadows();}
  if(roadTrafficVisible&&this.roadTraffic){if(avatar?.roadTraffic)this.roadTraffic.restore(avatar.roadTraffic,this.trafficTime);else this.roadTraffic.update(dt,null,this.trafficTime);}
  if(roadTrafficVisible){
  if(this.roadTraffic){const p=avatar?.police;this.roadTraffic.police=p?.phase?{index:p.routeIndex,pose:{...p,height:transportHeightAt(this.transport,p.x,p.y,'road'),kind:'police',halfLength:.45,halfWidth:.19,pursuit:true,chasing:p.phase==='chasing'}}:null;}
  const roadPoses=this.roadTraffic?.poses()||[],poseByRoute=new Map(this.roadTraffic?.routes.map((route,i)=>[route,roadPoses[i]])||[]);
  if(this.busGroup&&this.passengerVersion!==passengerRevision()){if(this.passengerFleet){clearGroup(this.passengerFleet);this.busGroup.remove(this.passengerFleet);}this.passengerFleet=createPassengerFleet(this.traffic.cars||[]);this.busGroup.add(this.passengerFleet);this.passengerVersion=passengerRevision();}this.passengerFleet?.userData.update(poseByRoute,this.transport);
  for(const record of this.patrolRecords||[]){if(!record.group){record.group=createEmergencyVehicle(record.route.kind);if(record.group)this.busGroup.add(record.group);}if(record.group){const pose=poseByRoute.get(record.route)||busTrafficPose(this.traffic,record.route,this.trafficTime);applyVehicleRoadPose(record.group,this.transport,pose,{offset:.03});record.group.userData.policeLights?.(!!pose.chasing,this.trafficTime);}}
  for(const record of this.busRecords||[])record.group.userData.update(poseByRoute.get(record.route)||busTrafficPose(this.traffic,record.route,this.trafficTime),this.trafficTime,this.transport);}
  const closedCrossings=this.crossingGates?updateCrossingGates(this.crossingGates,this.traffic,this.trafficTime,dt):new Map();
  const vehicle=renderVehicle(avatar?.vehicle),carKey=vehicle.model+':'+vehicle.color+':'+carModelRevision(vehicle.model);
  if((mode==='walk'||mode==='host')&&this.playerCarKey!==carKey){this.playerCarKey=carKey;const old=this.car;this.car=createCar(vehicle);this.scene.remove(old);clearGroup(old);this.scene.add(this.car);}
  this.river.tick(tick);this.grid.visible=grid&&mode==='build';this.car.visible=(mode==='walk'||mode==='host')&&!!avatar;
  if(this.carShadow)this.carShadow.visible=this.car.visible;
  if(avatar){const pose={x:avatar.x+.5,y:avatar.y+.5,heading:avatar.heading||0},road=applyVehicleRoadPose(this.car,this.transport,pose,{roll:-(avatar.turn||0)*Math.min(.035,(avatar.speed||0)*.012)});if(this.carShadow){this.carShadow.position.set(pose.x,road.height+.042,pose.y);this.carShadow.rotation.set(road.pitch-Math.PI/2,pose.heading+Math.PI,0,'YXZ');}this.car.userData.update?.(dt,avatar.speed||0,avatar.turn||0);}
  const signalPhase=(this.traffic?.junctions||[]).map(j=>Math.floor(this.trafficTime/8)%j.phaseCount+':'+(this.trafficTime%8>=2)).join(','),crossingPhase=Math.floor(tick/.6)%2,signalKey=signalPhase+':'+crossingPhase+':'+[...closedCrossings.values()].map(Number).join('');if(this.signalMesh&&signalKey!==this.signalPhase){this.signalPhase=signalKey;const color=new THREE.Color();this.signals.forEach((s,index)=>{const active=s.kind==='crossing'?closedCrossings.get(s.crossingId)&&crossingPhase===s.phase:s.i===(signalAspect(s.phase,this.trafficTime,s.phaseCount)==='green'?2:0);color.set(active?(s.kind==='crossing'||s.i===0?'#ff5b43':'#8ce88c'):'#42574c');this.signalMesh.setColorAt(index,color);});this.signalMesh.instanceColor.needsUpdate=true;}
  if(this.roadWarningTown!==t||this.roadWarningRevision!==revision){this.roadWarningTown=t;this.roadWarningRevision=revision;this.roadWarnings=roadRules(t).affected;this.roadWarningKey=JSON.stringify(this.roadWarnings);}
  const warnings=mode==='build'?this.roadWarnings:[];
  const previewSignature=JSON.stringify([ghost,valid,roadPreview,selected,mode==='build'?this.roadWarningKey:'',importedModelsRevision(),cherryTreeRevision(),giraffeRevision(),elephantRevision(),natureRevision(),woodlandParkRevision(),fountainRevision(),this.modelLoads?.revision||0]);
  if(previewSignature!==this.ghostSignature){
   this.ghostSignature=previewSignature;const modelKey=ghost?this.renderBuildingKey(ghost)+':'+valid:'',warningKey=mode==='build'?this.roadWarningKey:'';
   const reuse=ghost&&!roadPreview&&this.previewBuilding&&this.previewModelKey===modelKey&&this.previousWarningKey===warningKey;this.previousWarningKey=warningKey;
   if(!reuse){clearGroup(this.preview);this.previewBuilding=null;this.previewLot=null;this.previewModelKey=modelKey;
    if(ghost){const g=this.makeBuilding(ghost,false,valid?'ghost':'ghost-invalid');g.traverse(o=>{if(o.material&&!o.material.userData.shared){o.material.transparent=true;o.material.opacity=Math.min(o.material.opacity,.66);}});this.preview.add(g);this.previewBuilding=g;this.addPreviewLot(ghost,valid?'#f3d473':'#ef645b');this.previewLot=this.preview.children.at(-1);}
    else if(selected){const b=t.buildings.find(b=>b.id===selected);if(b)this.addPreviewLot(b,'#f3d473');}
    if(roadPreview?.line?.length){const points=roadPreview.line.map(p=>new THREE.Vector3(p.x+.5,.10,p.y+.5));if(points.length===1)points.push(points[0].clone().add(new THREE.Vector3(.01,0,0)));const curve=new THREE.CatmullRomCurve3(points,false,'catmullrom',0),tube=new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(2,points.length*2),.27,6,false),new THREE.MeshBasicMaterial({color:roadPreview.valid?'#f4cf74':'#f06a58',transparent:true,opacity:.7}));tube.scale.y=.12;this.preview.add(tube);}
    if(warnings?.length){const m=new THREE.InstancedMesh(new THREE.CircleGeometry(.5,12),new THREE.MeshBasicMaterial({color:'#f12e24',transparent:true,opacity:.65,side:THREE.DoubleSide,depthWrite:false}),warnings.length),matrix=new THREE.Matrix4();warnings.forEach((p,i)=>{matrix.makeRotationX(-Math.PI/2);matrix.setPosition(p.x+.5,transportHeightAt(this.transport,p.x+.5,p.y+.5,'road')+.16,p.y+.5);m.setMatrixAt(i,matrix);});m.instanceMatrix.needsUpdate=true;m.frustumCulled=false;this.preview.add(m);}
   }else{const f=footprint(ghost);this.previewBuilding.position.set(ghost.x+f.w/2,0,ghost.y+f.d/2);this.previewBuilding.rotation.y=-ghost.rotation*Math.PI/4;if(this.previewLot){this.previewLot.position.set(ghost.x+f.w/2,.055,ghost.y+f.d/2);this.previewLot.rotation.y=-ghost.rotation*Math.PI/4;}}
  }
  try{this.webgl.render(this.scene,this.camera);}catch(error){
   if(this.graphicsRecovery?.lost||this.webgl.getContext().isContextLost())return;
   throw error;
  }
  this.graphicsRecovery?.rendered();
 }
 addPreviewLot(b,color){const {w,d}=lotSize(b),f=footprint(b),g=new THREE.Group();g.position.set(b.x+f.w/2,.055,b.y+f.d/2);g.rotation.y=-b.rotation*Math.PI/4;const m=new THREE.Mesh(new THREE.PlaneGeometry(w,d),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.35,side:THREE.DoubleSide,depthWrite:false}));m.rotation.x=-Math.PI/2;g.add(m);this.preview.add(g);}
}
export const hitBuilding=(r,t,x,y)=>r.pick(t,x,y);
export const drawThumbnail=flatThumbnail;
