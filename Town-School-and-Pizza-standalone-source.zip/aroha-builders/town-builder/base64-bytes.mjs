// Avoid the generic iterable callback for every byte of large model buffers.
// atob keeps the browser and Worker decoding/validation behavior unchanged.
export function base64Bytes(value){
 const decoded=atob(value),bytes=new Uint8Array(decoded.length);
 for(let i=0;i<decoded.length;i++)bytes[i]=decoded.charCodeAt(i);
 return bytes;
}
