import * as THREE from './vendor/three.module.js';
import {WIDTH,xy} from './core.mjs';

// One shared generated texture and one mesh for the entire flower layer.
let flowerTexture=null;
function texture(){
 if(flowerTexture)return flowerTexture;
 flowerTexture=new THREE.Texture();flowerTexture.colorSpace=THREE.SRGBColorSpace;flowerTexture.wrapS=flowerTexture.wrapT=THREE.RepeatWrapping;flowerTexture.anisotropy=4;

 const canvas=document.createElement('canvas');canvas.width=canvas.height=80;const p=canvas.getContext('2d');
 for(let i=0;i<26;i++){const x=(i*31)%80,y=(i*47)%80;p.fillStyle=['#e0b64e','#e17d87','#f0eac9'][i%3];p.beginPath();p.arc(x,y,2+i%3,0,2*Math.PI);p.fill();}
 flowerTexture.image=canvas;flowerTexture.needsUpdate=true;
 return flowerTexture;
}
export function flowerGeometry(cells=[]){
 const set=new Set(cells),p=[],uv=[],edges=[];
 for(const key of set){const {x,y}=xy(key),e=[x>0&&set.has(key-1)?1:0,x<WIDTH-1&&set.has(key+1)?1:0,set.has(key-WIDTH)?1:0,set.has(key+WIDTH)?1:0];
  for(const [u,v]of [[0,0],[0,1],[1,0],[0,1],[1,1],[1,0]]){p.push(x+u,.021,y+v);uv.push(u,v);edges.push(...e);}
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setAttribute('flowerEdges',new THREE.Float32BufferAttribute(edges,4));g.computeVertexNormals();g.computeBoundingSphere();return g;
}
export function createFlowerSurface(){
 const group=new THREE.Group(),material=new THREE.MeshStandardMaterial({map:texture(),transparent:true,alphaTest:.075,depthWrite:false,roughness:.92,side:THREE.FrontSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});
 material.onBeforeCompile=shader=>{
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nattribute vec4 flowerEdges; varying vec4 vFlowerEdges; varying vec2 vFlowerUv;').replace('#include <begin_vertex>','#include <begin_vertex>\nvFlowerEdges=flowerEdges; vFlowerUv=uv;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nvarying vec4 vFlowerEdges; varying vec2 vFlowerUv;').replace('#include <alphatest_fragment>',`float fade=mix(smoothstep(0.,.18,vFlowerUv.x),1.,vFlowerEdges.x)*mix(smoothstep(0.,.18,1.-vFlowerUv.x),1.,vFlowerEdges.y)*mix(smoothstep(0.,.18,vFlowerUv.y),1.,vFlowerEdges.z)*mix(smoothstep(0.,.18,1.-vFlowerUv.y),1.,vFlowerEdges.w);diffuseColor.a*=fade;\n#include <alphatest_fragment>`);
 };material.customProgramCacheKey=()=> 'town-flowers-v8';
 const mesh=new THREE.Mesh(flowerGeometry(),material);mesh.receiveShadow=true;mesh.renderOrder=1;group.add(mesh);let signature='';
 return {group,update(town){const next=(town.flowers||[]).join(',');if(next===signature)return;signature=next;mesh.geometry.dispose();mesh.geometry=flowerGeometry(town.flowers);mesh.visible=!!town.flowers?.length;},dispose(){mesh.geometry.dispose();material.dispose();}};
}
