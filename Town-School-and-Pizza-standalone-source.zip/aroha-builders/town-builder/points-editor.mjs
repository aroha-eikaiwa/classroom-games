import {POINT_TOKENS,pointEligible,assignPoint,buildingAt,footprint} from './core.mjs';

// Screen-facing, bevelled number coins follow the rendered roofs. A shared DOM
// layer keeps them easy to grab on touchscreens without extra WebGL contexts.
export function pointMarkerScale(renderer,x,y,height){
 const right=renderer.fallback?null:renderer.camera?.matrixWorld?.elements;
 let diameter;
 if(right){const a=renderer.project(x-right[0]*.55,y-right[2]*.55,height-right[1]*.55),b=renderer.project(x+right[0]*.55,y+right[2]*.55,height+right[1]*.55);diameter=Math.hypot(a[0]-b[0],a[1]-b[1]);}
 else diameter=(renderer.scale??16)*1.1;
 return Number.isFinite(diameter)?Math.max(.10,diameter/48):1;
}
export function installPointEditor({canvas,renderer,layer,toggle,tray,getTown,isBuild,snapshot,changed,prepare,redraw,toast,doc=globalThis.document,win=globalThis.window}){
 let active=null,hover=null,press=null,stamp='',buttons=new Map();
 const coin=(token,floating=false)=>{const b=doc.createElement('button');b.type='button';b.className='point-token'+(floating?' point-marker':'');b.dataset.pointToken=String(token);b.dataset.value=String(POINT_TOKENS[token]);b.setAttribute('aria-label',POINT_TOKENS[token]+' point token');const number=doc.createElement('span');number.className='point-number';number.textContent=String(POINT_TOKENS[token]);b.append(number);b.addEventListener('pointerdown',e=>{if(e.button!==0||!isBuild())return;e.preventDefault();e.stopPropagation();prepare();active=token;press={id:e.pointerId,x:e.clientX,y:e.clientY,moved:false};b.setPointerCapture?.(e.pointerId);canvas.focus({preventScroll:true});refresh();redraw();});b.onclick=e=>{if(e?.detail||!isBuild()||b.disabled)return;prepare();active=token;press=null;refresh();redraw();};return b;};
 for(let token=0;token<POINT_TOKENS.length;token++){const button=coin(token);tray.append(button);buttons.set(token,button);}
 const hint=doc.createElement('p');hint.className='points-help';hint.textContent='Drag a point onto a building. Houses and trees cannot hold points. One token per building. Drag it back here to return it.';tray.append(hint);
 const drag=doc.createElement('div');drag.className='point-token point-drag';drag.hidden=true;drag.setAttribute('aria-hidden','true');doc.body.append(drag);
 const inside=(rect,e)=>e.clientX>=rect.left&&e.clientX<=rect.right&&e.clientY>=rect.top&&e.clientY<=rect.bottom;
 const eligible=b=>pointEligible(b)&&!(getTown().points||[]).some(p=>p.building===b.id&&p.token!==active);
 function target(e){const rect=canvas.getBoundingClientRect();if(!inside(rect,e))return null;const t=getTown(),b=renderer.pick(t,e.clientX-rect.left,e.clientY-rect.top)||(()=>{const p=renderer.unproject(e.clientX-rect.left,e.clientY-rect.top);return buildingAt(t,p.x,p.y);})();return eligible(b)?b:null;}
 function refresh(){const placed=new Set((getTown().points||[]).map(p=>p.token));for(const [token,b]of buttons){b.disabled=placed.has(token);b.classList.toggle('point-active',active===token);b.classList.toggle('point-placed',placed.has(token));}toggle.setAttribute('aria-expanded',String(!tray.hidden));}
 function cancel(){active=null;hover=null;press=null;drag.hidden=true;refresh();redraw();}
 function drop(e){const t=getTown(),b=target(e);if(b){const before=JSON.stringify(t);if(assignPoint(t,active,b.id)){snapshot(before);changed();}cancel();return;}
  if(!tray.hidden&&inside(tray.getBoundingClientRect(),e)&&(t.points||[]).some(p=>p.token===active)){snapshot();t.points=t.points.filter(p=>p.token!==active);changed();cancel();return;}
  toast('Choose a building without another point token. Houses and trees cannot hold points.');cancel();
 }
 toggle.onclick=()=>{tray.hidden=!tray.hidden;if(tray.hidden)cancel();refresh();};
 win.addEventListener('pointermove',e=>{if(active===null||!isBuild())return;if(press){press.moved||=Math.hypot(e.clientX-press.x,e.clientY-press.y)>5;if(press.moved){drag.hidden=false;drag.dataset.value=String(POINT_TOKENS[active]);drag.textContent=String(POINT_TOKENS[active]);drag.style.left=e.clientX+'px';drag.style.top=e.clientY+'px';}}const next=target(e)?.id??null;if(next!==hover){hover=next;redraw();}});
 win.addEventListener('pointerup',e=>{if(active===null||!press||press.id!==e.pointerId)return;const moved=press.moved;press=null;if(moved)drop(e);});
 win.addEventListener('pointercancel',()=>{if(active!==null)cancel();});win.addEventListener('blur',cancel);
 canvas.addEventListener('pointerdown',e=>{if(active===null||!isBuild())return;if(e.button===2){cancel();return;}if(e.button!==0)return;e.preventDefault();e.stopImmediatePropagation();drop(e);},true);
 win.addEventListener('keydown',e=>{if(active===null||!isBuild()||['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName)||e.target?.isContentEditable)return;if(e.key==='Escape'){e.preventDefault();cancel();}else if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();const t=getTown();if((t.points||[]).some(p=>p.token===active)){snapshot();t.points=t.points.filter(p=>p.token!==active);changed();}cancel();}},true);
 function render(){layer.hidden=!isBuild();if(!isBuild()){if(active!==null)cancel();return;}const t=getTown(),next=JSON.stringify(t.points||[]);if(stamp!==next){stamp=next;layer.replaceChildren();for(const point of t.points||[]){const b=coin(point.token,true);b.dataset.building=String(point.building);b.style.setProperty?.('--point-phase',(-point.token*.32)+'s');layer.append(b);}refresh();}
  for(const button of layer.children){const b=t.buildings.find(b=>b.id===Number(button.dataset.building));if(!b){button.hidden=true;continue;}const f=footprint(b),height=(renderer.meshById?.get(b.id)?.userData.cameraBounds?.max.y??2.3)+.45,cx=b.x+f.w/2,cy=b.y+f.d/2,[x,y]=renderer.project(cx,cy,height);button.hidden=!Number.isFinite(x+y)||x<0||x>renderer.w||y<0||y>renderer.h;button.style.left=x+'px';button.style.top=y+'px';button.style.setProperty?.('--point-scale',String(pointMarkerScale(renderer,cx,cy,height)));button.classList.toggle('point-active',active===Number(button.dataset.pointToken));}
 }
 refresh();return {render,refresh,cancel,get hover(){return hover;},get active(){return active;}};
}
