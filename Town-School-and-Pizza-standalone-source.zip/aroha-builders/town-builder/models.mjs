/** Actual 3D toy-town asset geometry. Front doors face +localY. */
import {createKit} from './model-kit.mjs';
import {buildArchitecture} from './models-architecture.mjs';
import {buildAttractions} from './models-attractions.mjs';
import {buildLandmarks} from './models-landmarks.mjs';
import {buildVariant} from './models-variants.mjs';
import {buildSchool} from './models-schools.mjs';
import {buildExpansion} from './models-expansion.mjs';
import {buildImportedFallback} from './models-imported-fallbacks.mjs';
import {buildJapaneseStation} from './models-station.mjs';
export const MODEL_TYPES=Object.freeze(['house','park','library','museum','hospital','bus-stop','station','police-station','fire-station','post-office','bookstore','restaurant','supermarket','castle','shrine','temple','church','aquarium','stadium','zoo','amusement-park','convenience-store','elementary-school','junior-high-school','arcade','shopping-mall','tree','bakery','apartment','cinema','airport','bank','high-school','university','hotel','factory','city-hall','prison']);
export function makeModel(type,w=1,d=1,variant=0){
 if(!MODEL_TYPES.includes(type))throw new RangeError('Unknown town building: '+type);
 if(!Number.isFinite(w)||!Number.isFinite(d)||w<=0||d<=0)throw new TypeError('Positive lot dimensions required');
 const k=createKit(w,d);
 if(buildJapaneseStation(type,k,w,d,variant)||buildImportedFallback(type,k,variant)||buildExpansion(type,k,w,d,variant)||buildVariant(type,k,w,d,variant)||buildSchool(type,k,w,d)||buildArchitecture(type,k,w,d)||buildAttractions(type,k,w,d)||buildLandmarks(type,k,w,d))return k.faces;
 throw new Error('Missing geometry for '+type);
}

// Match the menu silhouettes without changing saved-map footprints.
export const modelHeight=(type,variant=0)=>type==='university'?4:type==='airport'?.6:type==='bank'?2.6:type==='castle'?2.7:type==='stadium'?2.4:type==='tree'?1.7:type==='bus-stop'?1.3:['house','library','police-station','post-office','bookstore','restaurant'].includes(type)?1.65:2;
