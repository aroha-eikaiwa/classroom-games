import {W,edgeKey,migrateRoadEdges} from './network.mjs';

// Transport analysis is shared by painting, readiness and the renderer. It is
// rebuilt only after one of the small grid-network arrays is replaced/changed.
const EMPTY=Object.freeze([]),cache=new WeakMap(),EPS=1e-7;
const point=k=>({x:k%W,y:Math.floor(k/W)}),cell=(x,y)=>y*W+x;
const sub=(a,b)=>({x:a.x-b.x,y:a.y-b.y}),cross=(a,b)=>a.x*b.y-a.y*b.x;
const dot=(a,b)=>a.x*b.x+a.y*b.y,length=a=>Math.hypot(a.x,a.y);
const unit=(a,b)=>{const d=sub(b,a),n=length(d)||1;return{x:d.x/n,y:d.y/n};};
const coordKey=p=>`${Math.round(p.x*2)},${Math.round(p.y*2)}`;
const canonicalDirection=d=>d.x<-EPS||Math.abs(d.x)<EPS&&d.y<0?{x:-d.x,y:-d.y}:d;
const REASONS={
 'bridge-end':'Extend bridges to dry land on both banks.',
 'bridge-turn':'Draw bridges straight across the river without bends.',
 'bridge-branch':'Roads and tracks cannot branch on bridges.',
 'bridge-overlap':'Bridges overlap. Choose a different crossing.',
 'rail-road-overlap':'Cross roads and tracks; do not run them along the same space.'
};
function network(t,kind){
 const cells=kind==='road'?(t.roads||EMPTY):(t.rails||EMPTY),raw=kind==='road'?t.roadEdges:t.railEdges;
 const nodes=new Map(cells.map(k=>[k,{k,...point(k),neighbors:[]}])) ,seen=new Set(),edges=[];
 for(const pair of raw??migrateRoadEdges(cells)){
  if(!Array.isArray(pair)||pair.length!==2)continue;
  const [ka,kb]=pair,a=nodes.get(ka),b=nodes.get(kb),id=edgeKey(ka,kb);
  if(!a||!b||ka===kb||seen.has(id)||Math.max(Math.abs(a.x-b.x),Math.abs(a.y-b.y))!==1)continue;
  seen.add(id);a.neighbors.push(b);b.neighbors.push(a);edges.push({id,a,b});
 }
 return{kind,nodes,edges};
}
function bridgePolygon(b){
 const d=unit(b.a,b.b),n={x:-d.y*b.width/2,y:d.x*b.width/2};
 return[{x:b.a.x+n.x,y:b.a.y+n.y},{x:b.b.x+n.x,y:b.b.y+n.y},{x:b.b.x-n.x,y:b.b.y-n.y},{x:b.a.x-n.x,y:b.a.y-n.y}];
}
function overlaps(a,b){
 for(const poly of [a,b])for(let i=0;i<poly.length;i++){
  const p=poly[i],q=poly[(i+1)%poly.length],axis={x:p.y-q.y,y:q.x-p.x};
  const aa=a.map(v=>dot(v,axis)),bb=b.map(v=>dot(v,axis));
  if(Math.max(...aa)<=Math.min(...bb)+EPS||Math.max(...bb)<=Math.min(...aa)+EPS)return false;
 }
 return true;
}
function bridgeBankInset(bank,direction,other){
 // Junction asphalt and its approach crosswalk reach .61 tiles from the node.
 // Keep the bridge's physical end beyond that shared, flat turning space.
 const branches=[...bank.neighbors,...(other.nodes.get(bank.k)?.neighbors||EMPTY)];
 return branches.some(next=>Math.abs(cross(sub(next,bank),direction))>EPS)?.64:0;
}
function barrierClearance(bank,direction,other,side,offset){
 const p={x:-direction.y*side*offset,y:direction.x*side*offset},radius=.55;
 let end=0;
 for(const next of [...bank.neighbors,...(other.nodes.get(bank.k)?.neighbors||EMPTY)]){
  const edge=sub(next,bank),len=length(edge),v={x:edge.x/len,y:edge.y/len};if(Math.abs(cross(v,direction))<EPS)continue;
  // A side rail is a line. Clip it against the neighbouring lane's capsule,
  // including both round ends, so oblique junctions keep their corners open.
  const q=cross(v,p),s=cross(v,direction),a=dot(p,v),b=dot(direction,v);
  let lo=Math.min((-radius-q)/s,(radius-q)/s),hi=Math.max((-radius-q)/s,(radius-q)/s);
  if(Math.abs(b)>EPS){lo=Math.max(lo,Math.min(-a/b,(len-a)/b));hi=Math.min(hi,Math.max(-a/b,(len-a)/b));}else if(a<0||a>len)hi=-Infinity;
  if(hi>=Math.max(lo,0))end=Math.max(end,hi);
  for(const center of [{x:0,y:0},edge]){
   const delta=sub(p,center),projection=dot(delta,direction),disc=projection*projection-dot(delta,delta)+radius*radius;
   if(disc>=0)end=Math.max(end,-projection+Math.sqrt(disc));
  }
 }
 return end;
}
function waterBridges(net,other,water,issues){
 const visited=new Set(),bridges=[];
 for(const first of net.nodes.values()){
  if(!water.has(first.k)||visited.has(first.k))continue;
  const queue=[first],wet=[],banks=new Map();visited.add(first.k);
  for(let i=0;i<queue.length;i++){
   const n=queue[i];wet.push(n);
   for(const next of n.neighbors)if(water.has(next.k)){if(!visited.has(next.k)){visited.add(next.k);queue.push(next);}}else banks.set(next.k,next);
  }
  const keys=wet.map(p=>p.k).sort((a,b)=>a-b),id=`${net.kind}:${keys.join(',')}`;
  const problem=code=>issues.push({code,key:`${code}:${id}`,kind:net.kind,cells:keys,reason:REASONS[code]});
  let bad=false;
  if(banks.size!==2||wet.some(n=>n.neighbors.length<2)){problem('bridge-end');bad=true;}
  if(wet.some(n=>n.neighbors.length>2)){problem('bridge-branch');bad=true;}
  if(wet.some(n=>n.neighbors.length===2&&Math.abs(cross(sub(n.neighbors[0],n),sub(n.neighbors[1],n)))>EPS)){problem('bridge-turn');bad=true;}
  if(bad)continue;
  const [start,end]=[...banks.values()].sort((a,b)=>a.k-b.k),d=sub(end,start);
  if(wet.some(n=>Math.abs(cross(sub(n,start),d))>EPS)){problem('bridge-turn');continue;}
  const ordered=[start,...wet,end].sort((a,b)=>dot(sub(a,start),d)-dot(sub(b,start),d));
  const direction=unit(start,end),startInset=bridgeBankInset(start,direction,other),endInset=bridgeBankInset(end,direction,other),span=length(d)-startInset-endInset;
  const nominalRamp=net.kind==='road'?.70:.95,rampLength=Math.min(nominalRamp,span/2),nominalHeight=net.kind==='road'?.42:.25;
  const bridge={id,kind:net.kind,bankA:{x:start.x,y:start.y},bankB:{x:end.x,y:end.y},startInset,endInset,a:{x:start.x+direction.x*startInset,y:start.y+direction.y*startInset},b:{x:end.x-direction.x*endInset,y:end.y-direction.y*endInset},cells:ordered.map(n=>n.k),waterCells:keys,width:net.kind==='road'?1.04:1.0,length:span,deckHeight:.03+(nominalHeight-.03)*rampLength/nominalRamp,rampLength};
  const margin=net.kind==='road'?.16:.20,offset=net.kind==='road'?.49:.465;
  bridge.barriers=[-1,1].map(side=>({side,offset,start:Math.max(margin,barrierClearance(start,direction,other,side,offset)-startInset+.03),end:span-Math.max(margin,barrierClearance(end,{x:-direction.x,y:-direction.y},other,-side,offset)-endInset+.03)})).filter(r=>r.end-r.start>.06);
  bridge.polygon=bridgePolygon(bridge);bridges.push(bridge);
 }
 return bridges;
}
// Inclusive segment intersection catches diagonal Xs in the middle of a cell,
// as well as crossings at a shared node. Collinear sections are not crossings.
function intersection(a,b,c,d){
 const r=sub(b,a),s=sub(d,c),den=cross(r,s),q=sub(c,a);
 if(Math.abs(den)<EPS){
  if(Math.abs(cross(q,r))>EPS)return null;
  const rr=dot(r,r),lo=Math.max(0,Math.min(dot(q,r)/rr,dot(sub(d,a),r)/rr)),hi=Math.min(1,Math.max(dot(q,r)/rr,dot(sub(d,a),r)/rr));
  return hi-lo>EPS?{overlap:true}:null;
 }
 const u=cross(q,r)/den,v=cross(q,s)/den;
 return u>=-EPS&&u<=1+EPS&&v>=-EPS&&v<=1+EPS?{x:a.x+r.x*v,y:a.y+r.y*v}:null;
}
function buckets(edge){const out=[];for(let y=Math.floor(Math.min(edge.a.y,edge.b.y));y<=Math.floor(Math.max(edge.a.y,edge.b.y));y++)for(let x=Math.floor(Math.min(edge.a.x,edge.b.x));x<=Math.floor(Math.max(edge.a.x,edge.b.x));x++)out.push(cell(x,y));return out;}
function railwayCrossings(roads,rails,water,issues){
 const index=new Map(),found=new Map(),overlapKeys=new Set();
 for(const edge of roads.edges)for(const k of buckets(edge)){if(!index.has(k))index.set(k,[]);index.get(k).push(edge);}
 for(const rail of rails.edges){
  const seen=new Set();for(const k of buckets(rail))for(const road of index.get(k)||EMPTY){
   if(seen.has(road.id))continue;seen.add(road.id);
   const p=intersection(road.a,road.b,rail.a,rail.b);if(!p)continue;
   if(p.overlap){const key=`rail-road-overlap:${road.id}:${rail.id}`;if(!overlapKeys.has(key)){overlapKeys.add(key);issues.push({code:'rail-road-overlap',key,cells:[road.a.k,road.b.k,rail.a.k,rail.b.k],reason:REASONS['rail-road-overlap']});}continue;}
   // A road/rail intersection over water is a conflicting pair of bridges,
   // never an at-grade crossing perched on the river.
   if(water.has(cell(Math.floor(p.x+.5),Math.floor(p.y+.5))))continue;
   const roadDirection=canonicalDirection(unit(road.a,road.b)),railDirection=canonicalDirection(unit(rail.a,rail.b)),angle=Math.abs(cross(roadDirection,railDirection)),key=coordKey(p),old=found.get(key);
   if(!old||angle>old.angle)found.set(key,{id:`crossing:${key}`,x:p.x,y:p.y,roadDirection,railDirection,angle});
  }
 }
 for(const crossing of found.values()){
  const d=crossing.roadDirection,n={x:-d.y,y:d.x};crossing.posts=[];
  const distance=(p,e)=>{const vx=e.b.x-e.a.x,vy=e.b.y-e.a.y,t=Math.max(0,Math.min(1,((p.x-e.a.x)*vx+(p.y-e.a.y)*vy)/(vx*vx+vy*vy)));return Math.hypot(p.x-e.a.x-vx*t,p.y-e.a.y-vy*t);};
  for(const side of [-1,1]){
   let chosen=null;
   // Recess along the approach at junctions; keep the arm spanning its lane.
   for(let step=0;step<=14&&!chosen;step++){
    const along=.64+step*.25,p={x:crossing.x+d.x*along*side+n.x*.59*side,y:crossing.y+d.y*along*side+n.y*.59*side};
    if(p.x<0||p.x>39||p.y<0||p.y>31||water.has(cell(Math.floor(p.x+.5),Math.floor(p.y+.5))))continue;
    if(roads.edges.some(e=>distance(p,e)<.55)||rails.edges.some(e=>distance(p,e)<.43))continue;
    chosen={x:p.x-crossing.x,y:p.y-crossing.y,side};
   }
   if(chosen)crossing.posts.push(chosen);
  }
 }
 return [...found.values()];
}
export function validateTransport(t){
 const refs=[t.roads||EMPTY,t.roadEdges||EMPTY,t.rails||EMPTY,t.railEdges||EMPTY,t.rivers||EMPTY],lengths=refs.map(a=>a.length),old=cache.get(t);
 if(old&&old.refs.every((a,i)=>a===refs[i]&&old.lengths[i]===lengths[i]))return old.result;
 const water=new Set(t.rivers||EMPTY),issues=[],roads=network(t,'road'),rails=network(t,'rail');
 const bridges=[...waterBridges(roads,rails,water,issues),...waterBridges(rails,roads,water,issues)];
 // Broad-phase grid buckets keep dense towns linear in the number of nearby
 // spans. A full pairwise comparison becomes costly with many small rivers.
 const bridgeIndex=new Map();
 for(const b of bridges){
  const xs=b.polygon.map(p=>p.x),ys=b.polygon.map(p=>p.y),near=new Set(),keys=[];
  for(let y=Math.floor(Math.min(...ys));y<=Math.floor(Math.max(...ys));y++)for(let x=Math.floor(Math.min(...xs));x<=Math.floor(Math.max(...xs));x++){
   const k=`${x},${y}`;keys.push(k);for(const other of bridgeIndex.get(k)||EMPTY)near.add(other);
  }
  for(const a of near)if(overlaps(a.polygon,b.polygon))issues.push({code:'bridge-overlap',key:`bridge-overlap:${[a.id,b.id].sort().join('|')}`,cells:[...new Set([...a.waterCells,...b.waterCells])].sort((a,b)=>a-b),bridges:[a.id,b.id],reason:REASONS['bridge-overlap']});
  for(const k of keys){if(!bridgeIndex.has(k))bridgeIndex.set(k,[]);bridgeIndex.get(k).push(b);}
 }
 const crossings=railwayCrossings(roads,rails,water,issues),result={valid:!issues.length,reason:issues[0]?.reason||'',bridges,crossings,issues};
 cache.set(t,{refs,lengths,result});return result;
}
export function bridgeDeckHeightAt(b,along){return .03+(b.deckHeight-.03)*Math.max(0,Math.min(1,along/b.rampLength,(b.length-along)/b.rampLength));}
/** World coordinates, including the half-cell offset used by the 3D renderer. */
export function transportHeightAt(analysis,x,y,kind='road'){
 let height=0;
 for(const b of analysis?.bridges||EMPTY){
  if(b.kind!==kind)continue;
  const d=unit(b.a,b.b),p={x:x-.5-b.a.x,y:y-.5-b.a.y},along=dot(p,d),side=Math.abs(cross(p,d));
  // Render meshes use float32 vertices; retain their boundary points too.
  if(along<-1e-5||along>b.length+1e-5||side>b.width/2+1e-5)continue;
  height=Math.max(height,bridgeDeckHeightAt(b,along)+.006);
 }
 return height;
}
