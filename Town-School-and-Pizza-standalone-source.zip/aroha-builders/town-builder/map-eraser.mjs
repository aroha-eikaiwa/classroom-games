import {buildingAt,inside,key} from './core.mjs';
import {eraseRoad} from './network.mjs';
import {validateTransport} from './transport.mjs';
import {eraseFlowers} from './garden.mjs';
import {erasePavement} from './pavement.mjs';
export function eraseLayerAt(t,p,hit=null){if(hit||buildingAt(t,p.x,p.y))return 'building';if(!inside(p.x,p.y))return null;const k=key(p.x,p.y);return t.roads.includes(k)?'road':t.rails.includes(k)?'rail':t.rivers.includes(k)?'river':(t.flowers||[]).includes(k)?'flowers':(t.pavement||[]).includes(k)?'pavement':null;}
export function eraseMapLayer(t,p,layer,hit=null){
 if(layer==='building'){const b=hit||buildingAt(t,p.x,p.y);if(!b)return false;t.buildings=t.buildings.filter(v=>v.id!==b.id);return true;}
 if(!inside(p.x,p.y))return false;const k=key(p.x,p.y);
 if(layer==='road'||layer==='rail'){
  const bridge=validateTransport(t).bridges.find(b=>b.kind===layer&&b.cells.includes(k));
  const targets=bridge?[...new Set([k,...bridge.waterCells])]:[k];let changed=false;
  for(const cell of targets)if(layer==='road')changed=eraseRoad(t,cell)||changed;else if(t.rails.includes(cell)){t.rails=t.rails.filter(v=>v!==cell);t.railEdges=t.railEdges.filter(e=>!e.includes(cell));changed=true;}
  return changed;
 }
 if(layer==='flowers')return eraseFlowers(t,p.x,p.y);
 if(layer==='pavement')return erasePavement(t,p.x,p.y);
 if(layer!=='river')return false;const next=t.rivers.filter(v=>v!==k);if(next.length===t.rivers.length)return false;t.rivers=next;return true;
}
