import * as THREE from './vendor/three.module.js';
// Existing UV atlas wall patches, measured in image coordinates (top-left).
// Furniture, windows, signs, air conditioners, roof and shop fronts retain their materials.
export function apartmentWallAt(material,u,v){
 const x=((u%1)+1)%1,y=1-((v%1)+1)%1;
 if(material==='apartment-1')return x>=.34&&x<=.675&&y<=.54;
 if(material==='apartment-2')return x<=.50&&(y<=.085||y>=.845||(y>=.335&&y<=.59));
 return false;
}
function indexedSubset(source,indices){
 const geometry=new THREE.BufferGeometry();
 for(const [name,attribute]of Object.entries(source.attributes))geometry.setAttribute(name,attribute);
 geometry.setIndex(new THREE.BufferAttribute(new source.index.array.constructor(indices),1));
 geometry.boundingBox=source.boundingBox.clone();geometry.boundingSphere=source.boundingSphere.clone();return geometry;
}
export function lighterApartment(base){
 const parts=[];
 for(const part of base.parts){
  const g=part.geometry,uv=g.attributes.uv,normals=g.attributes.normal,index=g.index,wall=[],unchanged=[];
  for(let i=0;i<index.count;i+=3){
   const ids=[index.getX(i),index.getX(i+1),index.getX(i+2)];
   const u=ids.reduce((s,n)=>s+uv.getX(n),0)/3,v=ids.reduce((s,n)=>s+uv.getY(n),0)/3,ny=ids.reduce((s,n)=>s+normals.getY(n),0)/3;
   const target=Math.abs(ny)<.4&&apartmentWallAt(part.material.name,u,v)?wall:unchanged;target.push(...ids);
  }
  if(!wall.length){parts.push(part);continue;}
  if(unchanged.length)parts.push({...part,geometry:indexedSubset(g,unchanged)});
  const material=part.material.clone();material.name+='-light-wall';material.color.setRGB(3.0,2.85,2.60);material.userData.shared=true;
  parts.push({...part,name:'light-cream-walls',geometry:indexedSubset(g,wall),material});
 }
 return {...base,parts};
}
