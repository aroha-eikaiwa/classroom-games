import {installStudentUI} from './offline-town.mjs';
import {TaxiChallenge,taxiWalkability,TAXI_VEHICLE} from './taxi-challenge.mjs';
import {createDrivingScreen} from './driving-screen.mjs';
import {createPoliceFeedback} from './police-feedback.mjs';
import {SpokenGps} from './gps-directions.mjs';
import {createGpsSpeech} from './gps-speech.mjs';
import {createGpsFeedback} from './gps-feedback.mjs';
const LOCAL_DIRECTIONS_NOTICE_JA='Single-player directions';
import {eraseLayerAt,eraseMapLayer} from './map-eraser.mjs';
import {installPointEditor} from './points-editor.mjs';
import {emptyPointGame,collectDestinationPoints} from './point-game.mjs';
import {mountVehiclePicker} from './vehicle-picker.mjs';
import {savedVehicle,DEFAULT_VEHICLE} from './vehicle-choice.mjs';
import {paintPavement,paintPavementStroke,prunePavement} from './pavement.mjs';
import {beginMapGesture,moveMapGesture} from './map-gesture.mjs';
import {roadRules,roadRuleMessage,addedRoad,ROAD_LIMIT} from './road-limits.mjs';
import {installDrivingControls} from './driving-controls.mjs';
import {installTouchDriving} from './touch-driving.mjs';
import {installCameraLook} from './camera-look.mjs';
import {installInterfaceLanguage,interfaceEnglish} from './interface-language.mjs';
import {printMapSvg} from './print-map.mjs';
import {CATALOG,byType,WIDTH,HEIGHT,MAX_BUILDINGS,EXPANSION_BUILDINGS,FULL_MAP_BUILDINGS,buildArea,buildingCount,canAddOptional,advanceTownProgress,preserveTownProgress,key,xy,inside,footprint,blankTown,buildingAt,canPlace,readiness,revealAt,roadLine,validateTown,cells,segmentHitsLot,entranceAccess,entranceTarget,newPlot,variantCount,lotSize,REQUIRED_CATALOG,destinationBuildings,hasEntrance,isDestination,prunePoints} from './core.mjs';
import {TownRenderer,drawThumbnail,hitBuilding} from './scene.mjs';
import {straightRoad,addRoad,roadGraph,roadStep,segmentTouchesBox} from './network.mjs';
import {loadArtwork,buildingDragImage,drawArtThumbnail,destinationImage} from './art.mjs';
import {Driving} from './driving.mjs';
import {validateTransport} from './transport.mjs';
import {drawFlowers,paintFlowerStroke,pruneFlowers} from './garden.mjs';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const canvas=$('#town-canvas'),renderer=new TownRenderer(canvas);
const drivingScreen=createDrivingScreen({onResize:resize,onChange:({fullscreen,supported})=>{const button=$('#drive-fullscreen');if(button){button.textContent=interfaceEnglish()?'Full screen':'全画面';button.hidden=fullscreen||!supported;}}});
$('#drive-fullscreen').onclick=()=>drivingScreen.request();
let studentUI;
let town=blankTown(),mode='build',tool='pan',selected=null,rotation=0,parkSize=3,moveId=null,ghost=null,showGrid=false,history=[],pointer=null,space=false,lastCell=null,seen=new Set(),avatar=null,walkTarget=null,walkTimer=0,follow=true,blocked=[],muted=false,dirty=false,saveCode='',lastSaved='',draftTimer=0,toastTimer=0,raf=0,saving=false;
let artworkStarted=false;
let audioCtx=null,engine=null,roadPreview=null,riverWidth=2,selectionCenter=null,townRevision=0,placementVariant=0,castleVariant=0,lastHouseVariant=null,lastTreeVariant=null,shiftHeld=false,repeatPlacement=false,flowerWidth=2,variantAnchor=null,variantType=null;
let localDestination=null,localWon=false,localPointGame=emptyPointGame(),pointEditor=null,localGps=null,localGpsState=null;
const gpsSpeech=createGpsSpeech({isMuted:()=>muted,onState:state=>{const el=$('#local-gps-status');if(el){el.dataset.state=state;el.textContent=state==='muted'?'Sound is off. Turn it on to hear the directions.':state==='unavailable'||state==='error'?'The voice could not play. Press Listen again.':state==='speaking'?'Listen to the English directions.':'Follow the English directions. Press Listen again whenever you need.';}}});
const gpsFeedback=createGpsFeedback({element:$('#gps-feedback'),speech:gpsSpeech,buzz:()=>sound('wrong-way')});
const keysHeld=new Set();let driver=null,needsDraw=true,lastFrame=0,lastDiscovery=0,animationId=0;
const local={get(k){try{return localStorage.getItem(k);}catch{return null;}},set(k,v){try{localStorage.setItem(k,v);}catch{}}};
let playerVehicle=savedVehicle((()=>{try{return JSON.parse(local.get('town-player-vehicle')||'null');}catch{return null;}})());
muted=local.get('town-muted')==='1';
let handledArrests=0,taxi=null,taxiRequirements=null,taxiRevision=-1;
const drivingVehicle=()=>taxi?TAXI_VEHICLE:playerVehicle;
function stopTaxi(){taxi=null;document.body.classList.remove('taxi-driving');}
function taxiRequirementsForTown(){if(taxiRevision!==townRevision){taxiRevision=townRevision;taxiRequirements=taxiWalkability(town,buildArea(town,editorStaff()));}return taxiRequirements;}
const policeFeedback=createPoliceFeedback({document,getContext:()=>audioCtx,isMuted:()=>muted,isEnglish:()=>interfaceEnglish()});
function sound(kind='click'){
 if(muted)return;try{audioCtx??=new(window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')void audioCtx.resume();const now=audioCtx.currentTime;
 const play=(freq,end,dur,vol=.1,delay=0,type='sine')=>{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.setValueAtTime(freq,now+delay);o.frequency.exponentialRampToValueAtTime(Math.max(20,end),now+delay+dur);g.gain.setValueAtTime(vol,now+delay);g.gain.exponentialRampToValueAtTime(.001,now+delay+dur);o.connect(g);g.connect(audioCtx.destination);o.start(now+delay);o.stop(now+delay+dur);};
 if(kind==='water'){play(320+Math.random()*150,180,.11,.035,0,'sine');}else if(kind==='drop'){play(160,45,.18,.28,0,'triangle');play(340,100,.06,.07);}else if(kind==='road')play(190,100,.065,.05,0,'triangle');else if(kind==='step')play(105,50,.045,.035);else if(kind==='wrong-way'){play(145,115,.30,.075,0,'sawtooth');play(145,105,.32,.075,.38,'sawtooth');}else if(kind==='error')play(220,150,.17,.08,0,'triangle');else if(kind==='reveal'||kind==='save'||kind==='win'){[523,659,784,...(kind==='win'?[1047]:[])].forEach((f,i)=>play(f,f,.22,.08,i*.075));}else if(kind==='erase')play(320,70,.14,.07,0,'triangle');else play(530,360,.055,.055);
 }catch{}
}
function engineSound(speed){speed=Math.abs(speed);if(!audioCtx)return;try{if(!engine){const oscillator=audioCtx.createOscillator(),filter=audioCtx.createBiquadFilter(),gain=audioCtx.createGain();oscillator.type='triangle';filter.type='lowpass';filter.frequency.value=210;gain.gain.value=0;oscillator.connect(filter);filter.connect(gain);gain.connect(audioCtx.destination);oscillator.start();engine={oscillator,gain};}const now=audioCtx.currentTime;engine.oscillator.frequency.setTargetAtTime(48+speed*22,now,.12);engine.gain.gain.setTargetAtTime(!muted&&speed>.02?.018:0,now,.12);}catch{}}
function speak(word){if(muted||!('speechSynthesis'in window))return;try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(word);const vs=speechSynthesis.getVoices();u.voice=vs.find(v=>/^en-(NZ|GB|AU)/i.test(v.lang))||vs.find(v=>/^en/i.test(v.lang))||null;u.lang=u.voice?.lang||'en-GB';u.rate=.85;u.volume=.9;speechSynthesis.speak(u);}catch{}}
function toast(text,ms=2500){$('#toast').textContent=text;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),ms);}
function snapshot(value=JSON.stringify(town)){history.push(value);if(history.length>70)history.shift();}
function changed(){advanceTownProgress(town);prunePoints(town);prunePavement(town);pruneFlowers(town);studentUI?.changed(town);townRevision++;dirty=true;blocked=[];clearTimeout(draftTimer);const committedDraft=JSON.stringify(town);draftTimer=setTimeout(()=>local.set('aroha-town-draft',committedDraft),250);updateUI();draw();}
function draw(){needsDraw=true;}
function resize(){if(!$('#game').hidden){renderer.resize();draw();}}
window.addEventListener('resize',resize);
function editorLocked(){return studentUI?.editingAllowed()===false;}
function editorStaff(){return studentUI?.progressionBypassAllowed()===true;}
function insideBuildArea(x,y){const area=buildArea(town,editorStaff());return inside(x,y)&&x<area.width&&y<area.height;}
function editorCanPlace(t,b,ignoreId=null){const area=buildArea(t,editorStaff()),f=footprint(b);return (ignoreId!==null||canAddOptional(t,b.type,editorStaff()))&&b.x+f.w<=area.width&&b.y+f.d<=area.height&&canPlace(t,b,ignoreId);}
function optionalLocked(type){return !canAddOptional(town,type,editorStaff());}
function optionalNotice(){toast(interfaceEnglish()?'Complete the Directions requirements to unlock optional buildings.':'道案内の条件を満たすと、追加の建物が使えるよ。',4000);}
function trimLockedGround(){if(editorStaff()||town.fullMapUnlocked)return;for(const layer of ['rivers','flowers','pavement'])town[layer]=town[layer].filter(k=>{const p=xy(k);return insideBuildArea(p.x,p.y);});}
function buildFlowers(...args){const result=drawFlowers(...args);trimLockedGround();return result;}
function buildFlowerStroke(...args){const result=paintFlowerStroke(...args);trimLockedGround();return result;}
function updateUI(){if(mode!=='walk')drivingScreen.leave();pointEditor?.refresh();$('#local-tab').classList.toggle('locked',!readiness(town).ready||studentUI?.localDirectionsAllowed()!==true);if(mode!=='walk')driveControls.clear();
 const counts=new Map();for(const b of town.buildings)counts.set(b.type,(counts.get(b.type)||0)+1);const used=new Set(REQUIRED_CATALOG.filter(c=>counts.has(c.id)).map(c=>c.id));$('#placed-count').textContent=used.size+' / '+REQUIRED_CATALOG.length+' types';$('#empty-note').hidden=town.roads.length>0||town.buildings.length>0||(town.rivers||[]).length>0||(town.rails||[]).length>0||(town.flowers||[]).length>0||(town.pavement||[]).length>0;$('#undo').disabled=!history.length||mode==='walk'||editorLocked();$('#grid').hidden=mode==='walk';$('#sidebar').hidden=mode==='walk';$('#walk-panel').hidden=mode!=='walk';$('#dpad').hidden=mode!=='walk';$('#build-tab').classList.toggle('active',mode==='build');$('#local-tab').classList.toggle('active',mode==='walk'&&!taxi);$('#taxi-tab').classList.toggle('active',mode==='walk'&&!!taxi);$('#taxi-tab').classList.toggle('locked',studentUI?.localDirectionsAllowed()!==true||!readiness(town).ready||!taxiRequirementsForTown().ready);$('#taxi-hud').hidden=!taxi;$('#local-repeat').hidden=!!taxi;$('#zoom-in').hidden=mode==='walk';$('#zoom-out').hidden=mode==='walk';$('#view-left').hidden=mode==='walk';$('#view-right').hidden=mode==='walk';$('#pan-hint').hidden=mode==='walk';
 $$('.catalog button').forEach(b=>{const count=counts.get(b.dataset.type)||0,locked=optionalLocked(b.dataset.type);b.disabled=locked||editorLocked();b.draggable=!locked&&!editorLocked();b.classList.toggle('progress-locked',locked);b.title=locked?(interfaceEnglish()?'Complete the Directions requirements to unlock.':'道案内の条件を満たすと使えるよ。'):byType[b.dataset.type].en;b.classList.toggle('active',selected===b.dataset.type);b.classList.toggle('unplaced',count===0);b.classList.toggle('placed',count>0);b.querySelector('.check').textContent=locked?(interfaceEnglish()?'Locked'+(count?' · '+count:''):'ロック中'+(count?' ・ '+count:'')):count?'✓ '+count:'Not placed';b.setAttribute('aria-label',`${byType[b.dataset.type].en}・${count?count+' placed':'Not placed yet'}`);});
 $$('.tools button').forEach(b=>b.classList.toggle('active',b.dataset.tool===tool));$('#selection-bar').hidden=!selected||mode==='walk';$('#selected-name').textContent=selected?byType[selected].en:'';
 $('#river-widths').hidden=tool!=='river';$('#flower-widths').hidden=tool!=='flowers';setToolCursor();
 const hints={pan:'Drag to move the map; click a building to pick it up',river:'Drag to paint a river',flowers:'Paint flowers on grass; buildings, roads and rivers replace them',pavement:'Paint pavement one tile at a time; drag to make a path',road:'Drag and release to build a straight or diagonal road',rail:'Drag to lay tracks; connect behind the station',start:'Click a road to place the start flag',move:selected?'Tap to place / touch-drag to move / Left and Right: rotate':'Click a building to select it / drag empty space to pan',erase:'Drag to erase only the first object type touched',building:'Click to place / hold Shift to repeat / Left and Right: rotate'};
 $('#tool-hint').textContent=mode==='walk'?'Steer on the left · Hold GO or BACK on the right · Wait at red lights and crossings':hints[tool];
 $('#sound').textContent=muted?'Sound: off':'Sound: on';$('#sound').setAttribute('aria-pressed',String(!muted));
 const destinations=destinationBuildings(town),discovered=destinations.filter(b=>seen.has(b.id)).length;$('#discover-count').textContent=discovered;$('#discover-total').textContent=destinations.length;$('#discover-progress').style.width=(discovered/Math.max(1,destinations.length)*100)+'%';$('#pan-map').classList.toggle('active',tool==='pan');$('#pan-map').hidden=mode==='walk';$('#fit-view').textContent=mode==='walk'?'Follow car':'Fit map';$('#fit-view').setAttribute('aria-pressed',String(mode==='walk'&&!!renderer.followLocked));$('#fit-view').classList.toggle('active',mode==='walk'&&!!renderer.followLocked);
 $('#building-panel').hidden=mode!=='build';
 $('#map-status').textContent=mode==='walk'?'Follow the road from just behind the car':`${buildArea(town,editorStaff()).width} × ${buildArea(town,editorStaff()).height} / ${buildingCount(town)}${interfaceEnglish()?' buildings + trees':' 建物・木'}${editorStaff()?(interfaceEnglish()?' · Staff: full map access':' ・ 先生：全マップ使用可能'):town.fullMapUnlocked?(interfaceEnglish()?' · Full map unlocked (kept once unlocked)':' ・ 全マップ解放済み（一度解放すると維持）'):interfaceEnglish()?' · '+(town.expandedUnlocked?'Bottom':'Right side')+' unlocks in '+Math.max(0,(town.expandedUnlocked?FULL_MAP_BUILDINGS:EXPANSION_BUILDINGS)-buildingCount(town))+' more buildings or trees':' ・ '+(town.expandedUnlocked?'下側':'右側')+'の解放まで、建物か木をあと'+Math.max(0,(town.expandedUnlocked?FULL_MAP_BUILDINGS:EXPANSION_BUILDINGS)-buildingCount(town))+'こ'}`;
 if(mode==='build'&&!editorStaff()){const roads=roadRules(town);$('#map-status').textContent+=interfaceEnglish()?` · Roads: ${Math.ceil(roads.length)} / ${ROAD_LIMIT}`:` ・ 道路：${Math.ceil(roads.length)} / ${ROAD_LIMIT}`;if(!roads.valid)$('#map-status').textContent+=' ・ '+roadRuleMessage(town);}
 if(editorLocked()&&mode==='build'){$('#building-panel').hidden=true;$('#selection-bar').hidden=true;$('#undo').disabled=true;$('#points-toggle').hidden=true;$('#tool-hint').textContent='まちの編集は先生がロックしています。道案内をしよう。';}else $('#points-toggle').hidden=false;
}
function selectTool(next){if(editorLocked()&&next!=='pan')return;pointEditor?.cancel();closeVariantMenu();repeatPlacement=false;tool=next;selected=null;moveId=null;selectionCenter=null;ghost=null;roadPreview=null;sound();updateUI();draw();}
const VARIANT_LABELS={
 temple:['Original temple','Pagoda'],
 station:['Original station','Japanese local station'],
 tree:['Oak','Cedar','Cherry blossom','Palm','Maple','Variegated tree','Wind-swept tree'],
 house:['Flower cottage','Japanese house','Modern house','Townhouse','Bungalow','Villa'],
 restaurant:['Restaurant','Burger restaurant','Ramen shop','Sushi restaurant','Pizza restaurant'],
 apartment:['Original grey','Light cream'],
 hotel:['City hotel','Skyscraper hotel'],factory:['Brick factory','Restored factory'],
 castle:['European castle','Japanese castle']
};
const ERASER_CURSOR='url("data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><path d="m5 20 14-14a3 3 0 0 1 4 0l5 5a3 3 0 0 1 0 4L16 27H9z" fill="#f2a5aa" stroke="#334c42" stroke-width="2"/><path d="m5 20 6-6 11 11-2 2H9z" fill="#fff9e9" stroke="#334c42" stroke-width="2"/><path d="M8 29h19" stroke="#334c42" stroke-width="2" stroke-linecap="round"/></svg>')+'") 7 26, crosshair';
const START_CURSOR='url("data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><path d="M6 30V3" stroke="#222" stroke-width="3"/><path d="M7 3h23v16H7z" fill="white" stroke="#222"/><path d="M7 3h6v5H7m12-5h6v5h-6M13 8h6v5h-6m12-5h5v5h-5M7 13h6v6H7m12-6h6v6h-6" fill="#111"/></svg>')+'") 6 29, crosshair';
function setToolCursor(){canvas.style.cursor=mode==='build'?(tool==='erase'?ERASER_CURSOR:tool==='start'?START_CURSOR:tool==='pan'?'grab':'default'):(mode==='walk'?'none':'default');}
function randomHouseVariant(exclude=lastHouseVariant,type='house'){const choices=Array.from({length:variantCount(type)},(_,i)=>i).filter(v=>v!==exclude);return choices[Math.floor(Math.random()*choices.length)];}
function selectBuilding(type,choice=null){if(editorLocked())return;if(optionalLocked(type)){optionalNotice();return;}pointEditor?.cancel();closeVariantMenu();repeatPlacement=false;selected=type;tool='building';moveId=null;selectionCenter=null;ghost=null;rotation=0;
 if(type==='park'&&choice?.size)parkSize=choice.size;
 placementVariant=choice?.variant??(type==='house'?randomHouseVariant():type==='tree'?0:type==='castle'?castleVariant:0);if(type==='castle')castleVariant=placementVariant;
 renderer.preloadBuilding({type,variant:placementVariant,size:parkSize,plot:newPlot(type)});
 sound();speak(byType[type].en);updateUI();refreshSelectedThumbnail();if(lastCell)updateGhost(lastCell);
}
function refreshSelectedThumbnail(){if(!selected)return;const button=$$('.catalog button').find(b=>b.dataset.type===selected),current=town.buildings.find(b=>b.id===moveId);if(button){drawThumbnail(button.querySelector('canvas'),selected,current?.size??parkSize,Math.round(rotation/2),placementVariant,current?.plot??newPlot(selected));const size=lotSize(current||{type:selected,size:parkSize,variant:placementVariant,plot:newPlot(selected)});button.querySelector('.footprint').textContent=size.w+'×'+size.d;}}
function variantChoices(type){return type==='park'?[{size:2,variant:0,label:'Small flower garden'},{size:3,variant:0,label:'Medium fountain park'},{size:5,variant:0,label:'Large pond garden'},{size:5,variant:1,label:'Woodland pond park'},{size:5,variant:2,label:'Japanese garden'}]:Array.from({length:variantCount(type)},(_,variant)=>({size:parkSize,variant,label:VARIANT_LABELS[type]?.[variant]||byType[type].en}));}
function closeVariantMenu(){const panel=$('#variant-popover');if(panel)panel.hidden=true;if(variantAnchor)variantAnchor.setAttribute('aria-expanded','false');variantAnchor=null;variantType=null;}
function positionVariantMenu(){if(!variantAnchor)return;const panel=$('#variant-popover'),rect=variantAnchor.getBoundingClientRect(),width=Math.min(360,(window.innerWidth||1000)-24),viewportHeight=window.innerHeight||700;panel.style.width=width+'px';const height=Math.min(panel.getBoundingClientRect().height||280,viewportHeight-24);panel.style.left=Math.max(12,Math.min((window.innerWidth||1000)-width-12,rect.right-width))+'px';panel.style.top=Math.max(12,Math.min(viewportHeight-height-12,rect.top-height-10))+'px';panel.style.setProperty?.('--anchor-x',Math.max(20,Math.min(width-20,rect.left+rect.width/2-parseFloat(panel.style.left)))+'px');}
function openVariantMenu(type,anchor){if(mode!=='build')return;if(optionalLocked(type)){optionalNotice();return;}if(variantType===type){closeVariantMenu();return;}selectTool('pan');variantAnchor=anchor;variantType=type;anchor.setAttribute('aria-expanded','true');const panel=$('#variant-popover');$('#variant-title').textContent=byType[type].en+' models';$('#variant-note').textContent=type==='house'?'Choose the first model. Hold Shift while placing to cycle through the other houses.':'';$('#variant-note').hidden=type!=='house';const options=$('#variant-options');options.replaceChildren();
 for(const choice of variantChoices(type)){const button=document.createElement('button');button.dataset.variant=String(choice.variant);button.dataset.size=String(choice.size);button.setAttribute('aria-label',choice.label);const img=document.createElement('img');img.src=destinationImage(type,choice.size,choice.variant);img.alt=choice.label;img.draggable=false;img.decoding='async';const label=document.createElement('strong');label.textContent=choice.label;const dimensions=lotSize({type,size:choice.size,variant:choice.variant,plot:newPlot(type)}),size=document.createElement('small');size.textContent=dimensions.w+'×'+dimensions.d;button.append(img);button.append(label);button.append(size);options.append(button);button.onclick=()=>{selectBuilding(type,choice);canvas.focus({preventScroll:true});};}
 panel.hidden=false;positionVariantMenu();options.children[0]?.focus({preventScroll:true});
}
function catalogClick(type,anchor){if(type==='park'||variantCount(type)>1)openVariantMenu(type,anchor);else selectBuilding(type);}
$('#variant-close').onclick=closeVariantMenu;
window.addEventListener('resize',positionVariantMenu);
$('#catalog').addEventListener('scroll',closeVariantMenu);
window.addEventListener('pointerdown',e=>{if(variantAnchor&&!$('#variant-popover').contains(e.target)&&!variantAnchor.contains(e.target))closeVariantMenu();});
function makeGhost(p){const previous=moveId!==null?town.buildings.find(b=>b.id===moveId):null;return previous?{...previous,x:p.x,y:p.y,rotation}:{id:Math.max(0,...town.buildings.map(b=>b.id))+1,type:selected,x:p.x,y:p.y,size:parkSize,rotation,plot:newPlot(selected),variant:placementVariant};}
function updateGhost(p){lastCell=p;if(selected){if(ghost&&ghost.x===p.x&&ghost.y===p.y&&ghost.rotation===rotation&&ghost.type===selected&&ghost.variant===placementVariant&&(selected!=='park'||ghost.size===parkSize))return;ghost=makeGhost(p);if(moveId!==null){const f=footprint(ghost);selectionCenter={x:ghost.x+f.w/2,y:ghost.y+f.d/2};}draw();}}
function finishPlacement(b,keep){moveId=null;selectionCenter=null;ghost=null;repeatPlacement=keep;if(keep){tool='building';if(b.type==='house')placementVariant=randomHouseVariant(b.variant,b.type);else placementVariant=b.variant??0;}else{selected=null;tool='pan';}updateUI();draw();}
function place(p,keep=shiftHeld){if(editorLocked())return false;
 if(mode!=='build'||!selected)return false;const b=makeGhost(p);
 if(!editorCanPlace(town,b,moveId)){sound('error');toast('Choose a clear space to place this building.');ghost=b;draw();return false;}
 if(moveId===null&&town.buildings.length>=MAX_BUILDINGS){toast(`You can place up to ${MAX_BUILDINGS} buildings.`);return false;}
 const previous=moveId!==null?town.buildings.find(v=>v.id===moveId):null;
 if(previous&&previous.x===b.x&&previous.y===b.y&&previous.rotation===b.rotation){finishPlacement(b,keep);return true;}
 snapshot();if(moveId!==null)town.buildings=town.buildings.filter(v=>v.id!==moveId);town.buildings.push(b);if(!previous&&b.type==='house')lastHouseVariant=b.variant;if(!previous&&b.type==='tree')lastTreeVariant=b.variant;sound('drop');speak(byType[b.type].en);
 if(hasEntrance(b)&&!entranceAccess(town,b))toast('Connect a road to the entrance. Red buildings are not connected yet.',3500);
 finishPlacement(b,keep);changed();refreshSelectedThumbnail();return true;
}
function riverPaint(p,erase=false){let changed=false;for(let y=p.y-Math.floor((riverWidth-1)/2);y<p.y-Math.floor((riverWidth-1)/2)+riverWidth;y++)for(let x=p.x-Math.floor((riverWidth-1)/2);x<p.x-Math.floor((riverWidth-1)/2)+riverWidth;x++){if(!insideBuildArea(x,y))continue;const k=key(x,y),i=town.rivers.indexOf(k);if(erase){if(i>=0){town.rivers.splice(i,1);changed=true;}}else if(i<0&&!town.buildings.some(b=>cells(b).includes(k))){town.rivers.push(k);changed=true;}}if(changed)pruneFlowers(town);return changed;}
function eraseAt(p,hit=null,layerHint=null){
 if(!pointer?.eraseLayer)pointer.eraseLayer=layerHint||eraseLayerAt(town,p,hit);
 return pointer?.eraseLayer?eraseMapLayer(town,p,pointer.eraseLayer,hit):false;
}
function erasePicked(e){const r=canvas.getBoundingClientRect();return renderer.pickErase(town,e.clientX-r.left,e.clientY-r.top,{layer:pointer?.eraseLayer});}
function lineAllowed(line){if(line.some(p=>!insideBuildArea(p.x,p.y)||town.buildings.some(b=>segmentHitsLot(p,p,b))))return false;for(let i=1;i<line.length;i++)for(const b of town.buildings)if(segmentHitsLot(line[i-1],line[i],b))return false;return true;}
function transportEditError(before,after){const existing=new Set(validateTransport(before).issues.map(issue=>issue.key));return validateTransport(after).issues.find(issue=>!existing.has(issue.key))?.reason||'';}
function roadCandidate(a,b,kind){
 const line=straightRoad(a,b);if(!lineAllowed(line))return {line,error:'Keep roads and tracks clear of buildings.'};
 const candidate={...town};if(kind==='rail'){const net={roads:town.rails,roadEdges:town.railEdges};addRoad(net,a,line.at(-1));candidate.rails=net.roads;candidate.railEdges=net.roadEdges;}else addRoad(candidate,a,line.at(-1));
 pruneFlowers(candidate);const roadError=kind==='road'&&!editorStaff()&&addedRoad(town,candidate)?roadRuleMessage(candidate):'';return {line,town:candidate,error:roadError||transportEditError(town,candidate)};
}
function previewRoad(a,b){const candidate=roadCandidate(a,b,tool);roadPreview={line:candidate.line,valid:!candidate.error,kind:tool};draw();}
function finishGroundStroke(op,cancel=false){
 if(!op?.before||!op.changed)return;
 const before=JSON.parse(op.before),error=cancel?'':transportEditError(before,town);
 if(cancel||error){town=before;townRevision++;if(error){sound('error');toast(error,4500);}updateUI();draw();return;}
 snapshot(op.before);changed();
}
function cellAtEvent(e){const r=canvas.getBoundingClientRect();return renderer.unproject(e.clientX-r.left,e.clientY-r.top);}
function picked(e){const r=canvas.getBoundingClientRect();return hitBuilding(renderer,town,e.clientX-r.left,e.clientY-r.top);}
function restorePlacedSelection(resetCenter=false){ghost=null;const current=town.buildings.find(b=>b.id===moveId);if(current){rotation=current.rotation;placementVariant=current.variant??0;if(resetCenter){const f=footprint(current);selectionCenter={x:current.x+f.w/2,y:current.y+f.d/2};}}else if(moveId!==null){moveId=null;selected=null;selectionCenter=null;}}
function beginOrbit(e){finishGroundStroke(pointer);roadPreview=null;restorePlacedSelection();pointer={kind:'orbit',lastX:e.clientX,lastY:e.clientY};canvas.setPointerCapture(e.pointerId);draw();}
function lift(b){if(editorLocked())return;closeVariantMenu();moveId=b.id;selected=b.type;rotation=b.rotation;placementVariant=b.variant??0;if(b.type==='castle')castleVariant=placementVariant;if(b.type==='park')parkSize=b.size;tool='move';ghost=null;const f=footprint(b);selectionCenter={x:b.x+f.w/2,y:b.y+f.d/2};sound();speak(byType[b.type].en);updateUI();refreshSelectedThumbnail();draw();}
const touchDrive=installTouchDriving(canvas,()=>mode==='walk'&&!localWon&&!$('#modal').open);
installCameraLook(canvas,renderer,()=>mode==='walk'&&!localWon&&!$('#modal').open&&!$('#game').hidden);
canvas.addEventListener('contextmenu',e=>e.preventDefault());
canvas.addEventListener('pointerdown',e=>{
 if(mode==='walk'){canvas.focus({preventScroll:true});return;}
 if(e.button===2){beginOrbit(e);return;}
 const beginPan=()=>{finishGroundStroke(pointer);restorePlacedSelection();pointer={kind:'pan',x:e.clientX,y:e.clientY,lastX:e.clientX,lastY:e.clientY};follow=false;canvas.setPointerCapture(e.pointerId);canvas.style.cursor='grabbing';};
 if(editorLocked()){beginPan();return;}
 if(space||e.button===1||(e.button===0&&e.ctrlKey)){beginPan();return;}
 if(e.button!==0)return;canvas.focus({preventScroll:true});
 const p=cellAtEvent(e),b=!ghost&&['move','pan'].includes(tool)?picked(e):null;
 if(ghost&&moveId!==null&&buildingAt({buildings:[ghost]},p.x,p.y)){canvas.setPointerCapture(e.pointerId);pointer={kind:'lift',x:e.clientX,y:e.clientY,origin:p,base:{x:ghost.x,y:ghost.y},wasSelected:true,moved:false};return;}
 // Pick the visible model before checking the ground below it: tall roofs can project beyond the board.
 if(b&&tool==='pan'){pointer={kind:'pick-or-pan',buildingId:b.id,x:e.clientX,y:e.clientY,moved:false};canvas.setPointerCapture(e.pointerId);return;}
 if(b){const wasSelected=moveId===b.id;lift(b);canvas.setPointerCapture(e.pointerId);pointer={kind:'lift',x:e.clientX,y:e.clientY,origin:p,base:{x:b.x,y:b.y},wasSelected,moved:false};return;}
 if(tool==='pan'||(tool==='move'&&!selected)){beginPan();updateUI();draw();return;}
 if(!insideBuildArea(p.x,p.y)){if(tool==='building')beginPan();return;}canvas.setPointerCapture(e.pointerId);pointer={x:e.clientX,y:e.clientY,prev:p,origin:p,kind:tool,pointerType:e.pointerType,changed:false,moved:false};
 if(selected){pointer.kind='place';updateGhost(p);return;}
 if(tool==='start'){if(!town.roads.includes(key(p.x,p.y))){sound('error');toast('Place the start flag on a road.');return;}snapshot();town.start=p;sound('drop');changed();return;}
 if(tool==='road'||tool==='rail'){const b=picked(e)||buildingAt(town,p.x,p.y);if(b){speak(byType[b.type].en);pointer=null;return;}previewRoad(p,p);return;}
 if(['river','flowers','pavement','erase'].includes(tool)){pointer.before=JSON.stringify(town);if(tool==='erase'){const target=erasePicked(e);pointer.prev=target.p;pointer.changed=eraseAt(target.p,target.hit,target.layer);}else pointer.changed=tool==='river'?riverPaint(p):tool==='flowers'?buildFlowers(town,p.x,p.y,flowerWidth):paintPavement(town,p.x,p.y);if(pointer.changed){townRevision++;sound(tool==='river'?'water':tool==='flowers'?'drop':'erase');draw();}}
});
canvas.addEventListener('pointermove',e=>{
 const p=cellAtEvent(e);lastCell=p;
 if(mode==='walk')return;
 // A second mouse button does not fire pointerdown while the first is held.
 if(mode==='build'&&(e.buttons&2)&&pointer?.kind!=='orbit'){beginOrbit(e);return;}
 if(pointer?.kind==='orbit'){renderer.orbit(e.clientX-pointer.lastX,e.clientY-pointer.lastY);pointer.lastX=e.clientX;pointer.lastY=e.clientY;draw();return;}
 if(pointer?.kind==='pan'){renderer.panBy(e.clientX-pointer.lastX,e.clientY-pointer.lastY);lastCell=cellAtEvent(e);pointer.lastX=e.clientX;pointer.lastY=e.clientY;draw();return;}
 if(pointer){pointer.moved||=Math.hypot(e.clientX-pointer.x,e.clientY-pointer.y)>5;
 if(pointer.kind==='pick-or-pan'){if(pointer.moved){renderer.panBy(e.clientX-pointer.x,e.clientY-pointer.y);pointer={kind:'pan',lastX:e.clientX,lastY:e.clientY};follow=false;canvas.style.cursor='grabbing';draw();}return;}
 if(pointer.kind==='place'&&pointer.moved&&pointer.pointerType==='touch'){updateGhost(p);return;}
 if(pointer.kind==='place'&&pointer.moved){renderer.panBy(e.clientX-pointer.x,e.clientY-pointer.y);lastCell=cellAtEvent(e);pointer={kind:'pan',lastX:e.clientX,lastY:e.clientY};ghost=null;canvas.style.cursor='grabbing';draw();return;}
 if(pointer.kind==='road'||pointer.kind==='rail'){previewRoad(pointer.origin,p);return;}
 if(['river','flowers','pavement','erase'].includes(pointer.kind)){const target=pointer.kind==='erase'?erasePicked(e):null,end=target?.p||p;if(!insideBuildArea(end.x,end.y))return;if(target?.layer&&!pointer.eraseLayer)pointer.eraseLayer=target.layer;let did=false;if(pointer.kind==='flowers')did=buildFlowerStroke(town,pointer.prev,end,flowerWidth);else if(pointer.kind==='pavement')did=paintPavementStroke(town,pointer.prev,end);else for(const q of roadLine(pointer.prev,end))did=(pointer.kind==='river'?riverPaint(q):eraseAt(q))||did;if(target)did=eraseAt(end,target.hit,target.layer)||did;pointer.prev=end;pointer.changed||=did;if(did){townRevision++;sound(pointer.kind==='river'?'water':pointer.kind==='flowers'?'drop':'erase');draw();}return;}
 if(pointer.kind==='lift'){if(pointer.moved)updateGhost({x:pointer.base.x+p.x-pointer.origin.x,y:pointer.base.y+p.y-pointer.origin.y});return;}}
 if(selected)updateGhost(p);
});
canvas.addEventListener('pointerup',e=>{const op=pointer;pointer=null;setToolCursor();if(!op)return;
 if(op.kind==='pick-or-pan'){if(Math.hypot(e.clientX-op.x,e.clientY-op.y)<=5){const b=town.buildings.find(b=>b.id===op.buildingId);if(b)lift(b);}}
 else if(op.kind==='place')place(cellAtEvent(e),!!e.shiftKey||shiftHeld);else if(op.kind==='lift'&&op.moved&&ghost)place({x:ghost.x,y:ghost.y},!!e.shiftKey||shiftHeld);
 else if(op.kind==='lift'&&!op.moved&&op.wasSelected)place(op.base,!!e.shiftKey||shiftHeld);
 else if(op.kind==='road'||op.kind==='rail'){const candidate=roadCandidate(op.origin,cellAtEvent(e),op.kind);if(!candidate.error){snapshot();town=candidate.town;sound('road');changed();}else{sound('error');toast(candidate.error,4500);}roadPreview=null;draw();}
 else if(['river','flowers','pavement','erase'].includes(op.kind))finishGroundStroke(op);updateUI();});
canvas.addEventListener('pointercancel',()=>{finishGroundStroke(pointer,true);pointer=null;roadPreview=null;restorePlacedSelection();draw();});
canvas.addEventListener('pointerleave',()=>{if(!pointer&&!moveId){ghost=null;draw();}});
canvas.addEventListener('dragover',e=>{e.preventDefault();if(mode==='build'&&selected){e.dataTransfer.dropEffect='copy';updateGhost(cellAtEvent(e));}});
canvas.addEventListener('drop',e=>{e.preventDefault();if(mode==='build'&&selected)place(cellAtEvent(e),!!e.shiftKey||shiftHeld);});
function zoom(delta){if(mode==='walk')return;renderer.zoomBy(delta);updateUI();draw();}
canvas.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1.13:1/1.13);},{passive:false});
function centerAvatar(){renderer.updateCamera(avatar);}
function rotateView(n){renderer.orbit(-n*Math.PI/4/.006,0);sound();draw();}
function rotateBuilding(direction=1){if(editorLocked())return;
 if(mode!=='build'||!selected)return;
 const next=(rotation+direction+8)%8;
 if(moveId!==null){
  const current=town.buildings.find(b=>b.id===moveId);if(!current){selectTool('move');return;}
  const reference=ghost||current,currentBounds=footprint(reference);
  const center=selectionCenter||{x:reference.x+currentBounds.w/2,y:reference.y+currentBounds.d/2};
  const bounds=footprint({...reference,rotation:next}),left=center.x-bounds.w/2,top=center.y-bounds.d/2;
  const candidates=[...new Set([Math.floor(left),Math.ceil(left)])].flatMap(x=>[...new Set([Math.floor(top),Math.ceil(top)])].map(y=>({...current,x,y,rotation:next})));
  candidates.sort((a,b)=>(Math.hypot(a.x+bounds.w/2-center.x,a.y+bounds.d/2-center.y)-Math.hypot(b.x+bounds.w/2-center.x,b.y+bounds.d/2-center.y))||(Math.hypot(a.x-reference.x,a.y-reference.y)-Math.hypot(b.x-reference.x,b.y-reference.y)));
  rotation=next;ghost=candidates.find(b=>editorCanPlace(town,b,moveId))||candidates[0];
  if(pointer?.kind==='lift'){pointer.base={x:ghost.x,y:ghost.y};pointer.origin=lastCell||pointer.origin;}
  draw();
 }else{rotation=next;if(lastCell)updateGhost(lastCell);}
 sound();refreshSelectedThumbnail();toast('Rotated preview · click a clear space to place',1200);
}
function undo(){if(editorLocked())return;
 if(mode!=='build')return;
 if(ghost&&moveId!==null&&!pointer){restorePlacedSelection(true);updateUI();draw();return;}
 if(pointer&&['river','flowers','pavement','erase','road','rail','lift','place'].includes(pointer.kind)){finishGroundStroke(pointer,true);pointer=null;roadPreview=null;restorePlacedSelection();updateUI();draw();return;}
 if(!history.length)return;town=preserveTownProgress(town,JSON.parse(history.pop()));selected=null;moveId=null;selectionCenter=null;ghost=null;sound('erase');changed();
}
function openModal(title,html){if(mode==='walk'){gpsSpeech.cancel();gpsFeedback.reset();}driveControls.clear();closeVariantMenu();keysHeld.clear();engineSound(0);$('#modal').classList.remove('local-route-dialog');$('#modal-title').textContent=title;$('#modal-content').innerHTML=html;if(!$('#modal').open)$('#modal').showModal();sound();}
function closeModal(){if($('#modal').open)$('#modal').close();if(!$('#game').hidden)canvas.focus({preventScroll:true});}
$('#modal-close').onclick=closeModal;$('#modal').addEventListener('click',e=>{if(e.target===$('#modal')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeModal();}});
function openGame(t){stopTaxi();localGps?.stop();localGps=null;localGpsState=null;gpsSpeech.cancel();gpsFeedback.reset();pointEditor?.cancel();localPointGame=emptyPointGame();closeVariantMenu();town=validateTown(t);clearTimeout(draftTimer);pointer=null;touches.clear();gesture=null;touchRestore=null;lastHouseVariant=town.buildings.filter(b=>b.type==='house').at(-1)?.variant??null;townRevision++;selectionCenter=null;mode='build';tool='pan';selected=null;ghost=null;moveId=null;roadPreview=null;history=[];dirty=false;saveCode='';lastSaved='';seen=new Set();avatar=null;driver=null;keysHeld.clear();$('#welcome').hidden=true;$('#game').hidden=false;renderer.setMode('build',null);renderer.resetView('build');updateUI();resize();canvas.focus({preventScroll:true});sound();local.set('aroha-town-draft',JSON.stringify(town));startArtwork();}
function goHome(){stopTaxi();drivingScreen.leave();studentUI?.pauseResume();localGps?.stop();gpsSpeech.cancel();gpsFeedback.reset();void studentUI?.flush()?.catch(()=>{});finishGroundStroke(pointer,true);pointer=null;restorePlacedSelection();engineSound(0);document.exitPointerLock?.();driver=null;keysHeld.clear();local.set('aroha-town-draft',JSON.stringify(town));$('#welcome').hidden=false;$('#game').hidden=true;if('speechSynthesis'in window)speechSynthesis.cancel();resize();sound();}
$('#home').onclick=()=>{openModal('Return to the home screen?','<p>Your town saves automatically. This town is saved only in this browser.</p><div class="modal-buttons"><button id="stay">Stay here</button><button id="go-home" class="primary">Home</button></div>');$('#stay').onclick=closeModal;$('#go-home').onclick=()=>{closeModal();goHome();};};
for(const c of [...CATALOG].sort((a,b)=>Number(!!a.optional)-Number(!!b.optional))){const initialSize=lotSize({type:c.id,size:3,variant:0,plot:newPlot(c.id)}),b=document.createElement('button');b.dataset.type=c.id;b.draggable=true;b.title=c.en+': click to select; Left and Right to rotate';b.innerHTML=`<span class="footprint">${initialSize.w}×${initialSize.d}</span><span class="check"></span><canvas width="160" height="100" aria-hidden="true"></canvas><strong>${c.en}</strong><small>${c.en}${c.optional?' ・ Optional':''}</small>`;if(c.id==='park'||variantCount(c.id)>1){b.setAttribute('aria-haspopup','dialog');b.setAttribute('aria-expanded','false');const badge=document.createElement('span');badge.classList.add('variant-count');badge.textContent=variantChoices(c.id).length+' types';b.append(badge);}$('#catalog').append(b);drawThumbnail(b.querySelector('canvas'),c.id);b.onclick=()=>catalogClick(c.id,b);b.addEventListener('dragstart',e=>{if(optionalLocked(c.id)){e.preventDefault();optionalNotice();return;}if((c.id==='park'||variantCount(c.id)>1)&&selected!==c.id){e.preventDefault();openVariantMenu(c.id,b);return;}const choice=selected===c.id?{variant:placementVariant,size:parkSize}:null;selectBuilding(c.id,choice);e.dataTransfer.setData('text/plain',c.id);e.dataTransfer.effectAllowed='copy';const drag=buildingDragImage(c.id,Math.round(rotation/2),placementVariant,newPlot(c.id),parkSize);drawThumbnail(drag,c.id,parkSize,Math.round(rotation/2),placementVariant,newPlot(c.id));e.dataTransfer.setDragImage(drag,80,100);setTimeout(()=>drag.remove(),0);});b.addEventListener('dragend',()=>{ghost=null;draw();});}
pointEditor=installPointEditor({canvas,renderer,layer:$('#point-markers'),toggle:$('#points-toggle'),tray:$('#points-tray'),getTown:()=>town,isBuild:()=>mode==='build'&&!editorLocked()&&!$('#game').hidden,snapshot,changed,prepare:()=>selectTool('pan'),redraw:draw,toast});
$('#pan-map').onclick=()=>selectTool('pan');$$('[data-river-width]').forEach(b=>b.onclick=()=>{riverWidth=Number(b.dataset.riverWidth);$$('[data-river-width]').forEach(v=>v.classList.toggle('active',v===b));sound();});
$$('[data-flower-width]').forEach(b=>b.onclick=()=>{flowerWidth=Number(b.dataset.flowerWidth);$$('[data-flower-width]').forEach(v=>v.classList.toggle('active',v===b));sound();});
$$('[data-tool]').forEach(b=>b.onclick=()=>selectTool(b.dataset.tool));
$('#cancel-selection').onclick=()=>selectTool('move');$('#rotate-building').onclick=()=>rotateBuilding(1);$('#rotate-building-left').onclick=()=>rotateBuilding(-1);$('#undo').onclick=undo;$('#zoom-in').onclick=()=>zoom(1.25);$('#zoom-out').onclick=()=>zoom(.8);$('#fit-view').onclick=()=>{if(mode==='walk')renderer.toggleFollow();else renderer.resetView(mode);updateUI();draw();};$('#view-left').onclick=()=>rotateView(-1);$('#view-right').onclick=()=>rotateView(1);$('#grid').onclick=()=>{showGrid=!showGrid;$('#grid').setAttribute('aria-pressed',String(showGrid));sound();draw();};$('#sound').onclick=()=>{muted=!muted;local.set('town-muted',muted?'1':'0');if(muted){gpsSpeech.cancel();gpsFeedback.reset();if('speechSynthesis'in window)speechSynthesis.cancel();}else{sound();if(mode==='walk'&&!localWon)gpsSpeech.speak(taxi?.phase==='ride'?taxi.gps.repeat():localGps?.repeat());}updateUI();if(mode==='walk'&&muted)$('#local-gps-status').textContent='Sound is off. Turn it on to hear the directions.';};
function updateDirectionsAccess(){$('#local-tab').classList.toggle('locked',!readiness(town).ready||studentUI?.localDirectionsAllowed()!==true);if(studentUI?.localDirectionsAllowed()!==true&&mode==='walk')buildMode();$('#build-tab').classList.toggle('locked',editorLocked());updateUI();}
function checkTown(target='local'){const roadError=!editorStaff()&&roadRuleMessage(town);if(roadError){openModal('道路を直そう',`<p>${roadError}</p><p>消しゴムで道路を消してから、もう一度試してね。</p><button id="check-close" class="primary">まちづくりに戻る</button>`);$('#check-close').onclick=closeModal;return;}const allowed=target==='local'?studentUI?.localDirectionsAllowed()===true:studentUI?.directionsAllowed()===true,r=readiness(town);blocked=[...r.blocked,...r.railBlocked].map(b=>b.id);draw();if(r.ready&&allowed){if(target==='local')chooseLocalDestination();else startWalk();return;}const missing=r.missing.map(c=>c.en).join('、');const disconnected=[...new Set(r.blocked.map(b=>byType[b.type].en))].join('、');openModal('Get ready to give directions',`${allowed?'':`<p class="directions-notice">${LOCAL_DIRECTIONS_NOTICE_JA}</p>`}<div class="check-list"><div class="check-row ${town.start?'':'bad'}">${town.start?'✓':'○'} Place the start flag on a road</div><div class="check-row ${r.missing.length?'bad':''}">${r.missing.length?'○':'✓'} Place all ${REQUIRED_CATALOG.length} required building types${missing?`<small>Missing: ${missing}</small>`:''}</div><div class="check-row ${r.blocked.length?'bad':''}">${r.blocked.length?'○':'✓'} Connect every entrance to the start by road${disconnected?`<small>Check: ${disconnected}</small>`:''}</div><div class="check-row ${r.railBlocked.length?'bad':''}">${r.railBlocked.length?'○':'✓'} Connect tracks behind the station</div><div class="check-row ${r.transport.valid?'':'bad'}">${r.transport.valid?'✓':'○'} Connect bridges from bank to bank${r.transport.valid?'':`<small>${r.transport.reason}</small>`}</div></div><p>Connect roads near yellow entrances. Buildings set back from roads need a continuous painted pavement path. Roads and tracks are separate. Check the red buildings.</p><button id="check-close" class="primary">Back to building</button>`);$('#check-close').onclick=closeModal;sound('error');}
function startWalk(){chooseLocalDestination();}
function buildMode(){stopTaxi();localGps?.stop();localGps=null;localGpsState=null;gpsSpeech.cancel();gpsFeedback.reset();pointEditor?.cancel();localPointGame=emptyPointGame();document.exitPointerLock?.();mode='build';localDestination=null;localWon=false;avatar=null;driver=null;keysHeld.clear();seen=new Set();selected=null;tool='pan';renderer.setMode('build',null);renderer.resetView('build');sound();updateUI();resize();draw();}
$('#local-tab').onclick=async()=>{try{await studentUI.refreshDirectionsAccess();checkTown('local');}catch(e){toast(e.message,5000);}};$('#build-tab').onclick=()=>{if(mode!=='build')buildMode();};$('#back-build').onclick=buildMode;$('#restart-walk').onclick=()=>{if(localDestination)beginLocalDrive(localDestination);};$('#local-choose').onclick=chooseLocalDestination;
function chooseLocalDestination(){
 if(!studentUI?.localDirectionsAllowed()||!readiness(town).ready){checkTown('local');return;}
 keysHeld.clear();engineSound(0);gpsSpeech.cancel();gpsFeedback.reset();
 openModal('English GPS directions','<p>The computer chooses your destination. Listen to the English directions and drive there. There are no direction arrows.</p><div id="local-vehicle"></div><p id="local-start-error" class="error" role="status"></p><button id="local-go" class="primary">Go!</button>');
 $('#modal').classList.add('local-route-dialog');
 mountVehiclePicker($('#local-vehicle'),value=>{playerVehicle=value;local.set('town-player-vehicle',JSON.stringify(value));},playerVehicle);
 $('#local-go').onclick=()=>{
  if(!gpsSpeech.available()){$('#local-start-error').textContent='This browser cannot read the directions aloud. Try a browser with English speech.';return;}
  closeModal();beginLocalDrive();
 };
}
function applyGpsState(state){
 if(!state)return;localGpsState=state;
 gpsFeedback.apply(state);
}
function paintTaxiHud(){
 if(!taxi)return;
 $('#taxi-status').textContent=taxi.messageUntil>taxi.clock?taxi.message:taxi.phase==='ride'?'目的地で止まって、お客さんを降ろそう':taxi.candidate?'そのまま止まって待とう':'お客さんを探そう';
 $('#taxi-request').textContent=taxi.destination?'Please take me to the '+byType[taxi.destination.type].en+'.':'';
 $('#taxi-clock').hidden=taxi.phase!=='ride';$('#taxi-time').textContent=Math.ceil(taxi.remaining);$('#taxi-time-bar').value=taxi.limit?taxi.remaining/taxi.limit:0;$('#taxi-clock').classList.toggle('urgent',taxi.remaining<=10);
 $('#taxi-score').textContent=taxi.score+' 点';$('#taxi-deliveries').textContent='送迎 '+taxi.deliveries+' 回';
}
function updateTaxi(dt){
 const event=taxi.update(dt,avatar,{canArrive:driver.canArrive});
 if(event?.kind==='pickup'){
  gpsSpeech.cancel();gpsFeedback.reset();applyGpsState({...event.state,spoken:'Please take me to the '+byType[event.destination.type].en+'. '+(event.state.spoken||'')});sound('reveal');
 }else if(event?.kind==='navigation')applyGpsState(event.state);
 else if(event){
  gpsSpeech.cancel();gpsFeedback.reset();localGpsState=null;
  if(event.kind==='delivered'){sound('win');gpsSpeech.speak('Thank you!');}
  else{keysHeld.clear();stopHeld();sound('error');}
 }
 paintTaxiHud();
}
$('#taxi-tab').onclick=()=>{
 
 const r=readiness(town),walk=taxiRequirementsForTown(),roadError=!editorStaff()&&roadRuleMessage(town);
 if(!r.ready||!walk.ready||roadError){
  openModal('タクシーチャレンジの準備',`<p>道路でつながる、お客さんを乗せやすいまちをつくろう。</p><div class="check-list"><div class="check-row ${r.ready?'':'bad'}">${r.ready?'✓':'○'} 道案内の条件を満たす（必要な建物・入り口・スタート・線路）</div><div class="check-row ${walk.footpaths.length>=12?'':'bad'}">道路のすぐ横の歩道：${walk.footpaths.length} / 12 マス</div><div class="check-row ${walk.parks>=1?'':'bad'}">道路につながる公園：${walk.parks} / 1</div><div class="check-row ${walk.grass.length>=6?'':'bad'}">道路のすぐ横の草地：${walk.grass.length} / 6 マス</div></div><p>歩道はスタートから車で行ける道路の横につくろう。降りる場所には歩道は必要ないよ。</p>${roadError?`<p>${roadError}</p>`:''}`);return;
 }
 if(!gpsSpeech.available()){toast('英語の音声を使えるブラウザーで開いてね。',5000);return;}
 finishGroundStroke(pointer,true);pointer=null;roadPreview=null;ghost=null;selected=null;moveId=null;keysHeld.clear();stopHeld();localGps?.stop();localGps=null;localGpsState=null;gpsSpeech.cancel();gpsFeedback.reset();pointEditor?.cancel();
 taxi=new TaxiChallenge(town,{walkability:walk});driver=new Driving(town);mode='walk';localDestination=null;localWon=false;handledArrests=0;lastTaxiFrame=performance.now();avatar={...driver.avatar,vehicle:TAXI_VEHICLE};seen=new Set();blocked=[];
 $('#gps-wrong-road-art').loading='eager';document.body.classList.add('taxi-driving');renderer.setMode('walk',avatar);renderer.resetView('walk');updateUI();paintTaxiHud();drivingScreen.enter();resize();canvas.focus({preventScroll:true});sound();draw();
};
function beginLocalDrive(destination){
 stopTaxi();
 if(!studentUI?.localDirectionsAllowed()){checkTown('local');return;}
 if(!readiness(town).ready){checkTown('local');return;}
 const nextDriver=new Driving(town),nextGps=new SpokenGps(town),next=nextGps.start(nextDriver.avatar,{...(destination?{destinationId:destination}:{}),excludeId:localDestination});
 if(!next){toast('There is no reachable destination. Check the roads and entrances.');return;}
 const b=next.destination;$('#gps-wrong-road-art').loading='eager';
 finishGroundStroke(pointer,true);pointer=null;roadPreview=null;ghost=null;selected=null;moveId=null;keysHeld.clear();localGps?.stop();gpsSpeech.cancel();gpsFeedback.reset();
 if(mode!=='walk')localPointGame=emptyPointGame();mode='walk';handledArrests=0;localDestination=b.id;localWon=false;seen=new Set();driver=nextDriver;localGps=nextGps;avatar={...driver.avatar,vehicle:drivingVehicle()};blocked=[];$('#found-list').replaceChildren();
 $('#local-score').textContent='Total points: '+localPointGame.score;$('#local-target-picture').src=destinationImage(b.type,b.size,b.variant??0);$('#local-target-name').textContent=byType[b.type].en;$('#local-target-ja').textContent=byType[b.type].en;
 renderer.setMode('walk',avatar);renderer.resetView('walk');updateUI();drivingScreen.enter();resize();canvas.focus({preventScroll:true});sound('reveal');applyGpsState({...next,spoken:'Let’s go to the '+byType[b.type].en+'. '+next.spoken});discover();draw();
}
$('#local-repeat').onclick=()=>{if(taxi||!localGps||localWon)return;if(muted){muted=false;local.set('town-muted','0');updateUI();}gpsSpeech.speak(localGps.repeat());canvas.focus({preventScroll:true});};
function discover(){
 if(taxi)return;
 const found=revealAt(town,avatar.x,avatar.y,seen);
 if(found.length){for(const b of found){const el=document.createElement('span');el.textContent=byType[b.type].en;$('#found-list').append(el);}updateUI();}
 const target=town.buildings.find(b=>b.id===localDestination);if(!target||localWon||!driver?.canArrive||!localGpsState?.arrived)return;
 collectDestinationPoints(town,localDestination,localPointGame);$('#local-score').textContent='Total points: '+localPointGame.score;localWon=true;driver.speed=0;driver.turn=0;avatar={...driver.avatar,vehicle:drivingVehicle()};keysHeld.clear();engineSound(0);localGps.stop();
 openModal('You arrived! Well done!','<div class="local-win"><img id="local-win-picture" alt="Destination reached"><h3 id="local-win-name"></h3><p id="local-point-award" class="points-award"></p><p id="local-point-total" class="points-score"></p><p>You followed the English directions! Try a new destination.</p><button id="local-next" class="primary">Try another destination</button><button id="local-finish">Back to building</button></div>');
 $('#local-point-award').textContent='Points earned: '+localPointGame.lastAward;$('#local-point-total').textContent='Total points: '+localPointGame.score;$('#local-win-picture').src=destinationImage(target.type,target.size,target.variant??0);$('#local-win-name').textContent=byType[target.type].en;
 $('#local-next').onclick=()=>{closeModal();beginLocalDrive();};$('#local-finish').onclick=()=>{closeModal();buildMode();};sound('win');gpsSpeech.speak('You have arrived at the '+byType[target.type].en+'. Well done!');
}
const carKey=key=>({ArrowUp:'w',ArrowDown:'s',ArrowLeft:'a',ArrowRight:'d'}[key]||(['w','a','s','d'].includes(key.toLowerCase())?key.toLowerCase():null));
const driveControls=installDrivingControls($('#stick'),$('#knob'),$$('[data-pedal]'),()=>mode==='walk'&&!localWon&&!$('#modal').open&&!$('#game').hidden);
function stopHeld(){driveControls.clear();}
window.addEventListener('keydown',e=>{if(e.key==='Shift')shiftHeld=true;if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)||e.target.isContentEditable||$('#modal').open||$('#game').hidden)return;
 if(mode==='build'&&!editorLocked()&&(e.key==='Delete'||e.key==='Backspace')){if(moveId!==null){e.preventDefault();const id=moveId;if(town.buildings.some(b=>b.id===id)){snapshot();town.buildings=town.buildings.filter(b=>b.id!==id);pointer=null;roadPreview=null;repeatPlacement=false;selectTool('pan');sound('erase');changed();}}return;}
 if(e.code==='Space'){space=true;e.preventDefault();}if(e.key==='Escape'){if(mode==='build')selectTool('pan');return;}
 if(mode==='build'&&(e.key==='ArrowLeft'||e.key==='ArrowRight')){e.preventDefault();rotateBuilding(e.key==='ArrowLeft'?-1:1);return;}
 if(mode==='build'&&e.key.toLowerCase()==='r'){rotateBuilding();return;}
 if((e.ctrlKey||e.metaKey)&&e.key==='z'){e.preventDefault();undo();return;}
 const driveKey=carKey(e.key);if(mode==='walk'&&driveKey){e.preventDefault();keysHeld.add(driveKey);}
});window.addEventListener('keyup',e=>{if(e.key==='Shift'){shiftHeld=false;if(repeatPlacement&&mode==='build'){repeatPlacement=false;selectTool('pan');}}keysHeld.delete(carKey(e.key));if(e.code==='Space')space=false;});window.addEventListener('blur',()=>{engineSound(0);space=false;shiftHeld=false;if(repeatPlacement&&mode==='build')selectTool('pan');repeatPlacement=false;keysHeld.clear();stopHeld();finishGroundStroke(pointer);pointer=null;roadPreview=null;restorePlacedSelection();draw();});
$('#print-map').onclick=()=>{const map=printMapSvg(pointer?.before?validateTown(JSON.parse(pointer.before)):town,{language:interfaceEnglish()?'en':'ja'});$('#print-sheet').innerHTML='<article class="class-print-page"><h1>'+(studentUI?.label()||'Our town')+'</h1>'+map+'<p>White lines: roads / waves: rivers / ladder pattern: tracks / grey: buildings / thick entrance lines: entrances / Flag: Start</p></article>';openModal('Print map','<p>Print a black-and-white map, or save it as a PDF from the print dialog.</p><div class="print-preview">'+map+'</div><button id="print-now" class="primary">Print</button>');$('#modal').classList.add('local-route-dialog');$('#print-now').onclick=()=>window.print();};
$('#help').onclick=()=>openModal('How to play','<ol><li>Drag in a straight line to lay roads or tracks, including diagonally. Cars use roads, not tracks.</li><li>Paint rivers freely. Roads and tracks crossing water form bridges. Bridges must run straight from bank to bank and cannot cross other bridges. To erase a bridge, click its raised deck. To keep the road or tracks, erase the visible water underneath.</li><li>Choose a building picture, then click or tap to place it. In Move map mode, dragging anywhere pans the map; click or tap a building to pick it up, then click elsewhere to put it down. Use the arrow keys or rotation buttons to rotate it by 45 degrees. Press Delete or Backspace to remove the selected building.</li><li>Hold Shift to keep placing. Houses cycle through different models; trees repeat your selected model. Release Shift to return to Move map. Green catalogue buttons show types you have not placed yet.</li><li>Flowers and pavement can cover clear ground. The pavement brush paints one tile at a time. Buildings, roads and rivers replace them. The eraser removes only the first kind of object touched during each stroke.</li><li>Connect roads near the yellow entrances. Buildings set back from a road need a continuous pavement path from their entrance to the road. Red buildings have disconnected entrances. Stations also need tracks at the back.</li><li>Place the start flag on a road and connect the 16 required building types to start giving directions. Optional buildings unlock after the town meets these Directions requirements. Existing optional buildings can still be moved or removed. At 50 buildings and trees in total, the right side unlocks permanently. At 70 buildings and trees, the bottom unlocks too.</li><li>Directions chooses a destination for you. Listen to spoken English directions and drive there without arrows. Press Listen again to repeat an instruction. A longer usable road recalculates the route. A buzzer and a large X mean you need to turn back safely.</li><li>Police cars chase witnessed red-light offences, closed railway crossings and vehicle collisions. If caught, restart at a connected prison or police station. These two buildings cannot be destinations.</li><li>W / Up moves forward, S / Down reverses, A / Left and D / Right turn. Move the mouse to look around independently. W / Up follows the car’s direction, even when looking sideways. Follow car toggles a locked view from behind the car. Wait at red lights and for passing trains and buses. On a touchscreen, steer with the left joystick and hold GO or BACK on the right. Release a pedal to stop. You can also drag on the car.</li><li>Hold Ctrl and drag to move the map with any tool. Right-drag to rotate the map. On touchscreens, drag one finger in Move map mode to pan. Swipe two fingers up or down together to tilt the view, pinch to zoom, and twist to rotate. Swipe two fingers sideways to pan.</li></ol>');
studentUI=installStudentUI({$,local,openModal,closeModal,openGame,goHome,blankTown,getTown:()=>town,toast,onAccessChange:()=>{updateDirectionsAccess();updateUI();draw();},onProgress:progress=>{
 // Replace cached rollback flags too: Undo and cancelled gestures keep their
 // geometry, but cannot restore an unlock the server did not acknowledge.
 const reconcile=snapshot=>{for(const key of ['progressionVersion','optionalUnlocked','expandedUnlocked','expansionStages','fullMapUnlocked'])if(key in progress)snapshot[key]=progress[key];return snapshot;},reconcileJson=json=>JSON.stringify(reconcile(JSON.parse(json)));
 reconcile(town);history=history.map(reconcileJson);
 if(pointer?.before)pointer.before=reconcileJson(pointer.before);
 if(touchRestore?.town)touchRestore.town=reconcileJson(touchRestore.town);
 clearTimeout(draftTimer);draftTimer=0;local.set('aroha-town-draft',JSON.stringify(town));
 townRevision++;
 if(moveId===null&&selected&&optionalLocked(selected)){ghost=null;selected=null;tool='pan';closeVariantMenu();}
 updateUI();draw();
}});updateDirectionsAccess();
// Two-finger touch navigation leaves one-finger building and road painting available.
let touches=new Map(),gesture=null,touchRestore=null;
canvas.addEventListener('pointerdown',e=>{if(e.pointerType!=='touch'||mode==='walk')return;canvas.setPointerCapture(e.pointerId);if(touches.size===0)touchRestore={town:JSON.stringify(town),history:history.length};touches.set(e.pointerId,{x:e.clientX,y:e.clientY});if(touches.size>2){e.preventDefault();e.stopImmediatePropagation();return;}if(touches.size===2){if(touchRestore){town=preserveTownProgress(town,JSON.parse(touchRestore.town));studentUI?.changed(town);townRevision++;history.length=touchRestore.history;}pointer=null;roadPreview=null;restorePlacedSelection(true);updateUI();draw();e.preventDefault();e.stopImmediatePropagation();const [a,b]=[...touches.values()];gesture=beginMapGesture(a,b,renderer.zoom);follow=false;}},true);
canvas.addEventListener('pointermove',e=>{if(!touches.has(e.pointerId))return;touches.set(e.pointerId,{x:e.clientX,y:e.clientY});if(gesture){e.stopImmediatePropagation();if(touches.size!==2)return;const [a,b]=[...touches.values()];const motion=moveMapGesture(gesture,a,b);e.preventDefault();if(mode!=='walk'){renderer.orbit(-motion.turn/.006,motion.tilt);renderer.zoom=Math.max(1,Math.min(12,motion.zoom));renderer.panBy(motion.panX,0);}renderer.fit();draw();}},true);
function endTouch(e){touches.delete(e.pointerId);if(gesture){e.stopImmediatePropagation();pointer=null;if(touches.size===0){gesture=null;touchRestore=null;}}}
canvas.addEventListener('pointerup',endTouch,true);canvas.addEventListener('pointercancel',endTouch,true);
let lastRender=0;
let checkedGhost=null,checkedRevision=-1,checkedMove=null,checkedValidity=true;
function placementValid(){if(ghost!==checkedGhost||checkedRevision!==townRevision||checkedMove!==moveId){checkedGhost=ghost;checkedRevision=townRevision;checkedMove=moveId;checkedValidity=!ghost||editorCanPlace(town,ghost,moveId);}return checkedValidity;}
let lastTaxiFrame=0;
function frame(now){if(document.hidden||$('#modal').open||renderer.graphicsRecovery?.lost)lastTaxiFrame=now;animationId=requestAnimationFrame(frame);if($('#game').hidden||document.hidden||mode!=='walk'||$('#modal').open)policeFeedback.update({},false);const dt=Math.max(0,Math.min(.05,(now-(lastFrame||now-16))/1000));lastFrame=now;if(!$('#game').hidden&&!document.hidden){if(mode==='walk'&&driver&&!localWon&&!$('#modal').open&&!renderer.graphicsRecovery?.lost){const input={...Object.fromEntries([...keysHeld].map(k=>[k,true]))};for(const [key,held]of Object.entries({...touchDrive.input(),...Object.fromEntries(Object.entries(driveControls.input()).filter(([,v])=>v))}))if(held)input[key]=key==='steer'?held:true;if(keysHeld.has('a')||keysHeld.has('d')){delete input.steer;input.a=keysHeld.has('a');input.d=keysHeld.has('d');}if(taxi?.celebrating){keysHeld.clear();stopHeld();}else driver.update(dt,input);avatar={...driver.avatar,vehicle:drivingVehicle()};if(!taxi&&(avatar.police?.arrests||0)!==handledArrests){handledArrests=avatar.police.arrests;keysHeld.clear();stopHeld();gpsSpeech.cancel();gpsFeedback.reset();seen=new Set();$('#found-list').replaceChildren();applyGpsState(localGps?.start(avatar,{destinationId:localDestination}));}if(taxi)updateTaxi(Math.max(0,(now-(lastTaxiFrame||now-16))/1000));else applyGpsState(localGps?.update(avatar,dt,{allowArrival:driver.canArrive}));lastTaxiFrame=now;if(now-lastDiscovery>120){lastDiscovery=now;discover();}}engineSound(mode==='walk'&&!$('#modal').open?(avatar?.speed||0):0);policeFeedback.update(avatar?.police,(mode==='walk'&&!localWon)&&!$('#modal').open&&!document.hidden&&!$('#game').hidden,avatar?.trainTime||0,town);if(needsDraw||now-lastRender>=(mode==='walk'?16:33)){lastRender=now;renderer.draw(town,{buildArea:buildArea(town,editorStaff()),revision:townRevision,mode,seen,avatar,guidance:mode!=='walk',revealAll:mode==='walk',ghost:mode==='build'?ghost:null,valid:placementValid(),grid:showGrid,selected:moveId,destination:null,blocked,tick:now/1000,roadPreview,pointHover:mode==='build'?pointEditor?.hover:null,taxi});pointEditor?.render();needsDraw=false;}}}
animationId=requestAnimationFrame(frame);
function startArtwork(){if(artworkStarted||typeof Image==='undefined')return;artworkStarted=true;void loadArtwork((n,total,id)=>{$('#art-status').textContent=n<total?`建物の画像を読み込み中 ${n} / ${total}`:'';const type=id?.startsWith('tree-')?'tree':id?.startsWith('house-')?'house':id?.startsWith('restaurant-')?'restaurant':id==='castle-japanese'?'castle':id?.startsWith('park-')?'park':id,button=$$('.catalog button').find(b=>b.dataset.type===type);if(button){if(selected===type)refreshSelectedThumbnail();else drawThumbnail(button.querySelector('canvas'),type,parkSize,0,0,2);}if(n===total)requestAnimationFrame(resize);else draw();});}
window.addEventListener('beforeunload',()=>{if(!$('#game').hidden)local.set('aroha-town-draft',pointer?.before||JSON.stringify(town));});
resize();


installInterfaceLanguage();

document.addEventListener('visibilitychange',()=>{lastTaxiFrame=performance.now();if(document.hidden)policeFeedback.update({},false);});window.addEventListener('blur',()=>policeFeedback.update({},false));window.addEventListener('pagehide',()=>policeFeedback.update({},false));
