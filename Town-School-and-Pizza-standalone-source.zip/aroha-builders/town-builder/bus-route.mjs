import {entranceAccess} from './core.mjs';
import {roadGraph} from './network.mjs';
import {validateTransport,transportHeightAt} from './transport.mjs';
const cache=new WeakMap(),SPEED=1.25,DWELL=4;
const distance=(a,b)=>Math.hypot(b.x-a.x,b.y-a.y);
export function buildBusRoutes(t){
 // Every building can obstruct a paved entrance; rail and water edits can
 // break it as well. Retain all access inputs, not just the served stops.
 const graph=roadGraph(t),signature=JSON.stringify([t.buildings,t.pavement,t.rivers,t.rails,t.railEdges]),old=cache.get(t);if(old?.graph===graph&&old.signature===signature)return old.routes;
 const analysis=validateTransport(t),stops=[];
 for(const b of t.buildings){if(!['bus-stop','elementary-school','junior-high-school'].includes(b.type))continue;const p=entranceAccess(t,b);if(!p)continue;let anchor=null;for(const n of graph.nodes.values())if(!anchor||Math.hypot(n.x+.5-p.x,n.y+.5-p.y)<Math.hypot(anchor.x+.5-p.x,anchor.y+.5-p.y))anchor=n;if(anchor)stops.push({id:b.id,type:b.type,node:anchor});}
 const routes=[],handled=new Set();
 for(const first of stops.filter(s=>s.type==='bus-stop')){
  if(handled.has(first.node.id))continue;const connected=new Set([first.node.id]),queue=[first.node];for(let i=0;i<queue.length;i++)for(const id of queue[i].neighbors)if(!connected.has(id)){connected.add(id);queue.push(graph.nodes.get(id));}for(const id of connected)handled.add(id);
  const choices=stops.filter(s=>connected.has(s.node.id));if(!choices.some(s=>s.type!=='bus-stop'))continue;
  let seed=(Number(first.id)||1)*2654435761;const random=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296;};
  const path=(from,to)=>{const q=[from],prev=new Map([[from.id,null]]);for(let i=0;i<q.length&&!prev.has(to.id);i++){const neighbors=[...q[i].neighbors];for(let n=neighbors.length-1;n>0;n--){const j=Math.floor(random()*(n+1));[neighbors[n],neighbors[j]]=[neighbors[j],neighbors[n]];}for(const id of neighbors)if(!prev.has(id)){prev.set(id,q[i].id);q.push(graph.nodes.get(id));}}const out=[];for(let id=to.id;id!=null;id=prev.get(id))out.push(graph.nodes.get(id));return out.reverse();};
  const timeline=[];let current=first,time=0;const dwell=stop=>{timeline.push({start:time,end:time+DWELL,a:stop.node,b:stop.node,stopId:stop.id});time+=DWELL;};dwell(first);
  // Repeatable random itinerary keeps the host, controller and server in sync.
  for(let leg=0;leg<16;leg++){const others=choices.filter(s=>s.id!==current.id),next=leg===15?first:others[Math.floor(random()*others.length)];if(next.id===current.id)continue;const points=path(current.node,next.node);for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],end=time+distance(a,b)/SPEED;timeline.push({start:time,end,a,b});time=end;}dwell(next);current=next;}
  routes.push({id:first.id,timeline,duration:time,analysis,stops:choices.map(s=>s.id)});
 }
 cache.set(t,{graph,signature,routes});return routes;
}
export function busPose(route,time){
 const phase=((time%route.duration)+route.duration)%route.duration,items=route.timeline;let lo=0,hi=items.length-1;while(lo<hi){const mid=(lo+hi)>>1;if(items[mid].end<=phase)lo=mid+1;else hi=mid;}const item=items[lo],u=(phase-item.start)/(item.end-item.start);let x=item.a.x+(item.b.x-item.a.x)*u+.5,y=item.a.y+(item.b.y-item.a.y)*u+.5;
 let heading=0;const facing=i=>Math.atan2(i.b.x-i.a.x,i.b.y-i.a.y);if(!item.stopId){heading=facing(item);const next=items[(lo+1)%items.length];if(!next.stopId&&u>.65){const target=facing(next),delta=Math.atan2(Math.sin(target-heading),Math.cos(target-heading));heading+=delta*(u-.65)/.35*.5;}}
 else{for(let j=1;j<=items.length;j++){const previous=items[(lo-j+items.length)%items.length];if(!previous.stopId){heading=facing(previous);break;}}}
 // Heading is measured from +Z: the driver's left is (+cos, -sin).
 x+=Math.cos(heading)*.21;y-=Math.sin(heading)*.21;
 return {x,y,heading,height:transportHeightAt(route.analysis,x,y,'road'),speed:item.stopId?0:SPEED,stopId:item.stopId??null,halfLength:.51,halfWidth:.20,kind:'bus'};
}
