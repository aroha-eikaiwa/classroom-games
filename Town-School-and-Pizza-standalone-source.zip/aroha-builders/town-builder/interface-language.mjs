import {CATALOG} from './core.mjs';
// Explicit interface copy, shared by the builder and student controller. English
// vocabulary audio remains English; UI labels follow the active user's role.
const copy=`
Loading models…|建物などを読み込んでいます…
Aroha|アロハ
Town Builder|まちづくり
Home|ホーム
① Build town|① まちをつくる
② Directions (room)|② 道案内（友だちと）
③ Directions|③ 道案内（この画面）
④ Taxi Challenge|④ タクシーチャレンジ
Sound: on|音：オン
Sound: off|音：オフ
Open another student town in this class|同じクラスの別の児童のまちを開く
Student towns in this class|このクラスの児童のまち
Help|遊び方
Print map|地図を印刷
Autosave|自動保存
Build your town|まちをつくろう
Move map|地図を動かす
Paint river|川をかく
Paint flowers|花を植える
Draw road|道路をかく
Lay tracks|線路をかく
Start|スタート
Move building|建物を動かす
Erase|消す
River width|川の太さ
Flower width|花の広さ
Narrow|せまい
Medium|ふつう
Wide|広い
Directions · this screen|道案内 · この画面
Explore by car|車で探検しよう
Listen to your partner’s directions in English. Drive past entrances to discover buildings.|友だちの英語の道案内を聞こう。建物の入り口を通ると、建物が見つかるよ。
Destination|目的地
Change destination|目的地を変える
places discovered|か所を見つけたよ
W / Up: forward / S / Down: reverse|W・↑：前に進む ／ S・↓：後ろに進む
A / Left: left / D / Right: right|A・←：左に曲がる ／ D・→：右に曲がる
Touch: drag up/down to drive/reverse; left/right to steer. Release to stop.|タッチ：上下に動かすと前後に進み、左右に動かすと曲がるよ。指をはなすと止まるよ。
Wait for trains at crossings|ふみきりでは電車が通るのを待とう
Stop at red lights|赤信号では止まって待とう
Restart from the start|スタートにもどる
Back to building|まちづくりにもどる
Directions · guide screen|道案内 · 案内する画面
Guide your partner|友だちを案内しよう

Your partner enters this code on the|友だちにこのコードを伝えて、
controller|コントローラー
page.|の画面で入力してもらおう。
Connecting…|接続しています…
Your partner’s destination|友だちの目的地
See every building and your partner’s car. Your partner drives while you use the map to give directions in English.|地図と友だちの車を見ながら、英語で道案内をしよう。

End room and edit|部屋を終えて、まちを直す
Drag to draw a road|動かして道路をかこう
Drag to pan the map|動かして地図を見る
Undo the last change|一つ前にもどす
Undo|もどす
Grid|マス目
Town map. Place buildings and draw roads.|まちの地図。建物を置いたり、道路をかいたりできるよ。
Start by drawing a road.|まずは道路をかこう。
Turn this green field into your town.|この草原に、自分だけのまちをつくろう。
← 45° left|← 左に45度
45° right →|右に45度 →
Cancel selection|選ぶのをやめる
60 × 48 building area|60 × 48 マスのまち
Rotate view left|左から見る
Rotate view right|右から見る
Zoom out|小さく見る
Zoom in|大きく見る
Fit map|地図全体を見る
Follow car|車の後ろに固定
Steering joystick: drag left or right|ハンドル：左右に動かそう
Go forward|前に進む
Go back (reverse)|後ろに進む
Keyboard: WASD or arrow keys|キーボード：WASD・矢印キー
Zoom: wheel / rotate: right-drag / pan: drag / touch: pinch, twist or move two fingers|ホイール：拡大・縮小 ／ 右ドラッグ：回転 ／ ドラッグ：移動 ／ タッチ：2本指で動かそう
Buildings and places|建物・場所
Place 16 building types and the start flag, then connect them with roads.|16種類の必要な建物とスタートの旗を置いて、道路でつなごう。
Check road connections →|道路のつながりを確認 →
Close selection|選ぶ画面を閉じる
Close|閉じる
Printable map|印刷用の地図
Not placed yet|まだ置いていないよ
Not placed|まだだよ
Optional|自由に追加
Drag to move the map; click a building to pick it up|ドラッグで地図を動かそう。建物を押すと動かせるよ。
Drag to paint a river|ドラッグで川をかこう
Paint flowers on grass; buildings, roads and rivers replace them|草原に花を植えよう。建物・道路・川を置くと、その場所の花は消えるよ。
Drag and release to build a straight or diagonal road|ドラッグして指をはなすと、まっすぐ・ななめの道路ができるよ
Drag to lay tracks; connect behind the station|ドラッグで線路をかこう。駅の後ろにつなげてね。
Click a road to place the start flag|道路を押してスタートの旗を置こう
Tap to place / touch-drag to move / Left and Right: rotate|押すと置けるよ ／ タッチして動かすと移動 ／ ←・→で回転
Click a building to select it / drag empty space to pan|建物を押して選ぼう。何もない所をドラッグすると地図が動くよ。
Drag to erase only the first object type touched|ドラッグで消そう。最初にさわったものと同じ種類だけ消えるよ。
Click to place / hold Shift to repeat / Left and Right: rotate|押して置こう ／ Shiftを押しながら続けて置けるよ ／ ←・→で回転
Steer on the left · Hold GO or BACK on the right · Wait at red lights and crossings|左でハンドル操作 · 右で前進・後退 · 赤信号とふみきりで待とう
Ready! Give directions in a room or on this screen.|準備できたよ！友だちと、またはこの画面で道案内をしよう。
Connect every entrance to a road|すべての入り口を道路につなごう

Watch your partner drive and give directions in English|友だちの車を見ながら、英語で道案内をしよう
Follow the road from just behind the car|車の後ろから道路を見て進もう
Oak|カシの木
Cedar|スギ
Cherry blossom|サクラ
Palm|ヤシの木
Maple|カエデ
Variegated tree|色とりどりの木
Wind-swept tree|風にゆれる木
Flower cottage|花のある家
Japanese house|日本の家
Modern house|モダンな家
Townhouse|まちなかの家
Bungalow|平屋の家
Villa|大きな家
Restaurant|レストラン
Burger restaurant|ハンバーガー屋
Ramen shop|ラーメン屋
Sushi restaurant|すし屋
Pizza restaurant|ピザ屋
Original grey|もとのグレー
Light cream|明るいクリーム色
European castle|ヨーロッパのお城
Japanese castle|日本のお城
Small flower garden|小さな花の公園
Medium fountain park|ふん水のある公園
Large pond garden|大きな池の公園
Woodland pond park|森と池の公園
Japanese garden|日本庭園
Original temple|もとのお寺
Pagoda|五重塔のお寺
Choose the first model. Hold Shift while placing to cycle through the other houses.|最初の家を選ぼう。Shiftを押しながら置くと、いろいろな家を続けて置けるよ。
Choose a clear space to place this building.|何もない場所に建物を置こう。
You can place up to 192 buildings.|建物は192こまで置けるよ。
Connect a road to the entrance. Red buildings are not connected yet.|入り口に道路をつなごう。赤い建物は、まだつながっていないよ。
Keep roads and tracks clear of buildings.|道路や線路は建物と重ならないようにしよう。
Place the start flag on a road.|道路にスタートの旗を置こう。
Rotated preview · click a clear space to place|向きを変えたよ。何もない場所を押して置こう。
Return to the home screen?|最初の画面にもどる？

Stay here|この画面で続ける
Get ready to give directions|道案内の準備をしよう
Place the start flag on a road|道路にスタートの旗を置く
Place all 16 required building types|16種類の必要な建物をすべて置く
Connect every entrance to the start by road|すべての入り口を、道路でスタートにつなぐ
Connect tracks behind the station|駅の後ろに線路をつなぐ
Connect bridges from bank to bank|橋を川の両岸につなぐ
Connect roads near yellow entrances. Buildings set back from roads need a continuous painted pavement path. Roads and tracks are separate. Check the red buildings.|黄色い入り口の近くに道路をつなごう。道路からはなれた建物は、入り口から道路まで歩道をとぎれずにつなげてね。道路と線路は別だよ。赤い建物を確認してね。
Creating a room…|部屋をつくっています…


Reconnecting… the car is stopped|接続し直しています… 車は止まっています
Waiting for a driver|運転する友だちを待っています
Your partner is choosing a destination|友だちが目的地を選んでいます
Arrived! Choose another destination|到着！新しい目的地を選ぼう
Your partner is driving. Give directions in English|友だちが運転中です。英語で道案内をしよう。




Choose a destination|目的地を選ぼう
Drive on this screen. Choose a picture, then press Go!|この画面で運転するよ。写真を選んで「出発！」を押そう。
No destination selected|目的地を選んでね
Go!|出発！
You arrived! Well done!|到着！よくできたね！
Destination reached|到着した建物
You reached your destination! Swap roles with your partner and try again.|目的地に着いたね！友だちと役を交代して、もう一度やってみよう。
Choose another destination|新しい目的地を選ぶ
Our town|わたしたちのまち
Print a black-and-white map, or save it as a PDF from the print dialog.|白黒の地図を印刷できるよ。印刷の画面でPDFにも保存できるよ。
Print|印刷する
How to play|遊び方
Waiting to save online…|オンラインに保存するのを待っています…
Saving online…|オンラインに保存しています…
Saved online|オンラインに保存できたよ
Only saved on this browser|このブラウザーだけに保存されています
Sign in to save online|サインインしてオンラインに保存
Could not save online|オンラインに保存できませんでした
Check your save|保存したまちを確認してね
Set student details|自分の情報を選ぼう
Set school, class and student number|学校・クラス・出席番号を選ぼう
Your sign-in expired. Your changes are safe on this browser. Click Sign in to save online.|サインインが切れました。このブラウザーにまちは残っているよ。「サインインしてオンラインに保存」を押してね。
No other browser copies are available on this device.|この端末に、ほかのまちのコピーはありません。
Recover a browser copy|このブラウザーのコピーを開く
Recovered town saved online.|コピーのまちをオンラインに保存したよ。
Check the save in the other window before switching towns.|まちを変える前に、別の画面で保存されたまちを確認してね。
Opened the unsent changes from this device.|この端末に残っていた、まだ送っていないまちを開いたよ。
Your town saves automatically.|まちは自動保存されるよ。
Your saved town is open!|保存したまちを開いたよ！
Could not continue|続きを開けませんでした

Choose which town to keep|保存するまちを選ぼう
Both copies will be kept in this browser's recovery history. Saving this browser's town will replace the online copy.|両方のまちを、このブラウザーにコピーして残すよ。この画面のまちを保存すると、オンラインのまちが置きかわるよ。
Save this browser's town online|この画面のまちをオンラインに保存
Open the online town|オンラインのまちを開く
This browser’s town is now saved online.|この画面のまちをオンラインに保存したよ。
Changes save automatically.|変更は自動で保存されるよ。

Checking your save…|保存を確認しています…
All changes saved online.|すべてオンラインに保存できたよ。
Recover a copy from this browser|このブラウザーのコピーからもどす
A copy is also stored on this device.|この端末にもコピーが残っているよ。
Choose a copy to restore and save online. The current online town will also be kept here as a backup.|もどして保存するコピーを選ぼう。今のオンラインのまちも、このブラウザーに残すよ。

Could not connect. Please try again.|接続できませんでした。もう一度試してね。
Connection error.|接続できませんでした。
Bridges overlap. Choose a different crossing.|橋が重なっているよ。別の場所に橋をかけよう。
Draw bridges straight across the river without bends.|橋は曲げずに、まっすぐ川をわたるようにかこう。
Extend bridges to dry land on both banks.|橋をのばして、川の両側の陸地につなごう。
Roads and tracks cannot branch on bridges.|橋の上で道路や線路を分かれさせることはできないよ。
Roads and tracks cannot run along the same line.|道路と線路は重ねずに、交わるようにつくろう。
Choose a destination.|目的地を選んでね。
Choose a destination first.|先に目的地を選んでね。
Waiting for the guide screen to connect.|案内する画面の接続を待っています。
Reach the current destination before choosing another.|今の目的地に着いてから、次の目的地を選ぼう。
Synchronising driving.|車の位置を合わせています…
This room has ended. Join with a new code.|この部屋は終わりました。新しいコードで入ってね。
This action is not available.|この操作は使えません。
Invalid driving data.|車の情報を確認できませんでした。入り直してね。
Move the mouse to look around. W / Up follows the car’s direction. A / D or Left / Right steers. Follow car toggles a locked view from behind the car.|マウスでまわりを見よう。W・↑は車が向いている方へ進むよ。A・D・←・→で曲がるよ。「車の後ろに固定」を押すと、固定と自由な視点を切りかえられるよ。
`;

export const JAPANESE_COPY=new Map(copy.trim().split('\n').map(line=>line.split('|')));
for(const c of CATALOG)JAPANESE_COPY.set(c.en,c.ja);
for(const [en,ja] of [["Drag in a straight line to lay roads or tracks, including diagonally. Cars use roads, not tracks.", "まっすぐ・ななめにドラッグすると、道路や線路をかけるよ。車は道路を走るよ。"], ["Paint rivers freely. Roads and tracks crossing water form bridges. Bridges must run straight from bank to bank and cannot cross other bridges. To erase a bridge, click its raised deck. To keep the road or tracks, erase the visible water underneath.", "川を自由にかこう。道路や線路が川をわたると橋になるよ。橋はまっすぐ、両岸につなげよう。橋どうしを重ねることはできないよ。橋を消すときは、浮いている橋を押そう。下に見える水を消すと、道路や線路が残るよ。"], ["Choose a building picture, then click or tap to place it. In Move map mode, dragging anywhere pans the map; click or tap a building to pick it up, then click elsewhere to put it down. Use the arrow keys or rotation buttons to rotate it by 45 degrees. Press Delete or Backspace to remove the selected building.", "建物の写真を選んで、置きたい場所を押そう。「地図を動かす」では、ドラッグで地図を動かし、建物を押すと持ち上げられるよ。矢印キーや回転ボタンで45度ずつ向きを変えられるよ。選んだ建物はDelete・Backspaceキーで消せるよ。"], ["Hold Shift to keep placing. Houses cycle through different models; trees repeat your selected model. Release Shift to return to Move map. Green catalogue buttons show types you have not placed yet.", "Shiftを押しながら置くと、続けて置けるよ。家は種類が変わり、木は選んだ種類のまま置けるよ。Shiftをはなすと地図を動かせるよ。緑の建物ボタンは、まだ置いていない種類だよ。"], ["Flowers can only cover clear grass. Buildings, roads and rivers replace flower paint. The eraser removes only the first kind of object touched during each stroke.", "花は草原にだけ植えられるよ。建物・道路・川を置くと、その場所の花は消えるよ。消しゴムは、最初にさわったものと同じ種類だけを消すよ。"], ["Connect roads near the yellow entrances. Nearby entrances can share clear access to the road. Red buildings have disconnected entrances. Stations also need tracks at the back.", "黄色い入り口の近くに道路をつなごう。道路からはなれた建物は、入り口から道路まで歩道をとぎれずにつなげてね。赤い建物は、まだつながっていないよ。駅には後ろの線路も必要だよ。"], ["Place the start flag on a road and connect all 16 required building types to start giving directions. Trees, game centres and shopping malls are optional.", "道路にスタートの旗を置き、16種類の必要な建物をすべて道路でつなぐと、道案内を始められるよ。木や映画館などは、自由に追加できるよ。"], ["Directions lets you choose a destination and drive on the same device. Reach its entrance to win.", "「道案内（この画面）」では、この端末で目的地を選んで運転できるよ。目的地の入り口を目指そう。"], ["W / Up moves forward, S / Down reverses, A / Left and D / Right turn. Move the mouse to look around independently. W / Up follows the car’s direction, even when looking sideways. Follow car toggles a locked view from behind the car. Wait at red lights and for passing trains and buses. On a touchscreen, steer with the left joystick and hold GO or BACK on the right. Release a pedal to stop. You can also drag on the car.", "W・↑で前進、S・↓で後退、A・←で左、D・→で右に曲がるよ。マウスでまわりを見ても、車の向きは変わらないよ。「車の後ろに固定」で、固定と自由な視点を切りかえられるよ。赤信号では止まって待とう。電車や前の車が通るのも待とう。タッチでは左のハンドルと右の前進・後退ボタンを使い、指をはなすと止まるよ。車の上をドラッグしても運転できるよ。"], ["Hold Ctrl and drag to move the map with any tool. Right-drag to rotate the map. On touchscreens, drag one finger in Move map mode to pan. Swipe two fingers up or down together to tilt the view, pinch to zoom, and twist to rotate. Swipe two fingers sideways to pan.", "コントロールキーを押しながらドラッグすると、どの道具でも地図を動かせるよ。右ドラッグで地図が回転するよ。タッチでは1本指で地図を動かそう。2本指を上下に動かすと見下ろす角度が変わり、指を広げたり近づけたりすると拡大・縮小できるよ。2本指をひねると回転、横に動かすと移動できるよ。"], ["Please save from this site.", "このゲームの画面から保存してね。"], ["Invalid data format.", "データを確認できませんでした。もう一度開いてね。"], ["There is no town yet. Choose Create new to start.", "まだまちがないよ。「新しくつくる」から始めよう。"], ["Invalid town data.", "まちのデータを確認できませんでした。"], ["Too many attempts. Please ask your teacher or try again later.", "何度も入力されたので、少し待ってね。先生にも相談してね。"], ["Check the save status and reopen the town.", "保存の状態を確認して、まちを開き直してね。"], ["This town changed in another window. Open the latest save.", "別の画面でまちが保存されたよ。保存ボタンから、残したいまちを選んでね。"], ["Connection failed. Your town is still stored on this device. Please try again.", "接続できませんでした。まちはこの端末に残っているよ。もう一度試してね。"], ["Could not connect to the room.", "部屋に接続できませんでした。もう一度試してね。"], ["White lines: roads / waves: rivers / ladder pattern: tracks / grey: buildings / thick entrance lines: entrances / Flag: Start", "白い線：道路 ／ 波：川 ／ はしごの模様：線路 ／ グレー：建物 ／ 太い線：入り口 ／ 旗：スタート"], ["Drag to move the map; click a building to pick it up", "ドラッグで地図を動かそう。建物を押すと動かせるよ。"], ["Roads and tracks must cross at an angle.", "道路と線路は重ねずに、交わるようにつくろう。"]])JAPANESE_COPY.set(en,ja);
JAPANESE_COPY.set('Cross roads and tracks; do not run them along the same space.','道路と線路は重ねずに、交わるようにつくろう。');
for(const [en,ja]of [
 ['Hide points','ポイントをかくす'],['Hidden points','かくしたポイント'],
 ['Drag a point onto a building. Houses and trees cannot hold points. One token per building. Drag it back here to return it.','ポイントを建物にドラッグしよう。家と木には置けないよ。建物1つに1こずつ置こう。ここにもどすと取り消せるよ。'],
 ['Choose a building without another point token. Houses and trees cannot hold points.','まだポイントがない建物を選ぼう。家と木には置けないよ。'],
 ['Invalid hidden points.','かくしたポイントのデータを確認してね。']
])JAPANESE_COPY.set(en,ja);
const phrases=[...JAPANESE_COPY].sort((a,b)=>b[0].length-a[0].length);
export function japanese(text){
 const leading=text.match(/^\s*/)[0],trailing=text.match(/\s*$/)[0],s=text.trim();if(!s)return text;
 if(JAPANESE_COPY.has(s))return leading+JAPANESE_COPY.get(s)+trailing;
 let out=s;
 const patterns=[
  [/^Total points: (\d+)$/,(_,n)=>`合計：${n}点`],
  [/^Points earned: (\d+)$/,(_,n)=>`${n}点ゲット！`],
  [/^(\d+) point token$/,(_,n)=>`${n}点のポイント`],
  [/^(.+) Class 5-(\d+), No. (\d+)$/,(_,name,c,n)=>`${japanese(name)} 5年${c}組 ${n}番`],
  [/^(\d+) \/ (\d+) types placed ・ Start(set|not set) ・ (.+)$/,(_,n,total,start,tail)=>`${n} / ${total} 種類を置いたよ ・ スタート：${start==='set'?'あり':'まだ'} ・ ${japanese(tail)}`],
  [/^Entrance roads: (\d+) \/ station tracks: (\d+) to check$/,(_,a,b)=>`入り口の道路：${a}か所 ／ 駅の線路：${b}か所を確認`],
  [/^(\d+) \/ (\d+) types$/,(_,n,total)=>`${n} / ${total} 種類`],
  [/^(\d+) × (\d+)\s+tiles \/ (\d+) places$/,(_,w,h,n)=>`${w} × ${h} マス ／ 建物 ${n}こ`],
  [/^(\d+) types$/,(_,n)=>`${n}種類`],
  [/^(.+) models$/,(_,name)=>`${japanese(name)}の種類`],
  [/^(.+): click to select; Left and Right to rotate$/,(_,name)=>`${japanese(name)}：押して選ぶ ／ ←・→で回転`],
  [/^(.+)・(\d+) placed$/,(_,name,n)=>`${japanese(name)}・${n}こ置いたよ`],
  [/^(.+)・Not placed yet$/,(_,name)=>`${japanese(name)}・まだ置いていないよ`],
  [/^(.+) discovered!$/,(_,names)=>`${japanese(names)}を見つけたよ！`],
  [/^Destination：(.+)$/,(_,name)=>`目的地：${japanese(name)}`],
  [/^(?:This browser:|Online:|Online now:) (\d+) buildings(?: and|,) (\d+) road cells(.*)$/,(_,a,b,tail)=>`${s.startsWith('This browser')?'この画面':'オンライン'}：建物 ${a}こ、道路 ${b}マス${tail}`],
  [/^Save this copy online: (\d+) buildings, (\d+) road cells(.*)$/,(_,a,b,tail)=>`このコピーを保存：建物 ${a}こ、道路 ${b}マス${tail}`],
  [/^(.+): (\d+) \/ station tracks: (\d+) to check$/,(_,name,a,b)=>`入り口の道路：${a}か所 ／ 駅の線路：${b}か所を確認`],
 ];
 for(const [re,replace]of patterns)if(re.test(s))return leading+s.replace(re,replace)+trailing;
 // Curated fragments handle counts, lists and sentences split by inline markup.
 for(const [en,ja]of phrases){if(!out.includes(en))continue;out=out.replace(new RegExp('(?<![A-Za-z])'+en.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'(?![A-Za-z])','g'),ja);}
 out=out.replace(/Missing: /g,'まだない建物：').replace(/Check: /g,'確認：').replace(/Check bridges: /g,'橋を確認：').replace(/(\d+) \/ (\d+) types placed/g,'$1 / $2 種類を置いたよ').replace(/Startnot set/g,'スタート：まだ').replace(/Startset/g,'スタート：あり').replace(/スタートnot set/g,'スタート：まだ').replace(/スタートset/g,'スタート：あり');
 return leading+out+trailing;
}
const languageKey=Symbol.for('aroha-town.interface-language');
const languageState=globalThis[languageKey]??={teacher:false,refresh(){}};
export function setTeacherInterface(value){languageState.teacher=!!value;languageState.refresh();}
export const interfaceEnglish=()=>languageState.teacher;
export function installInterfaceLanguage(root=document.body){
 if(typeof MutationObserver==='undefined')return {refresh(){},disconnect(){}};
 if(root[languageKey]){languageState.refresh=root[languageKey].refresh;languageState.refresh();return root[languageKey];}
 const originals=new WeakMap(),attributes=new WeakMap();let observer;
 const english=node=>node.parentElement?.closest('[data-interface="teacher"]')||(!node.parentElement?.closest('#welcome')&&languageState.teacher);
 function text(node){const old=originals.get(node),current=node.nodeValue;const source=old&&current===old.translated?old.source:current,translated=english(node)?source:japanese(source);originals.set(node,{source,translated});if(current!==translated)node.nodeValue=translated;}
 function element(el){if(/^(SCRIPT|STYLE|INPUT|TEXTAREA)$/.test(el.tagName))return;
  let saved=attributes.get(el);if(!saved){saved=new Map();attributes.set(el,saved);}
  for(const key of ['aria-label','title','alt','placeholder'])if(el.hasAttribute(key)){const old=saved.get(key),current=el.getAttribute(key),source=old&&current===old.translated?old.source:current,translated=english({parentElement:el})?source:japanese(source);saved.set(key,{source,translated});if(current!==translated)el.setAttribute(key,translated);}
  for(const child of el.childNodes){if(child.nodeType===3)text(child);else if(child.nodeType===1)element(child);}
 }
 function apply(nodes){observer?.disconnect();for(const node of nodes){if(node.nodeType===3)text(node);else if(node.nodeType===1)element(node);}observer?.observe(root,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['aria-label','title','alt','placeholder']});}
 const refresh=()=>{document.documentElement.lang=languageState.teacher?'en':'ja';const game=document.getElementById('game');if(game)game.lang=languageState.teacher?'en':'ja';apply([root]);};
 observer=new MutationObserver(records=>{const nodes=new Set();for(const r of records){if(r.type==='childList'){for(const n of r.addedNodes)nodes.add(n);}else nodes.add(r.target);}apply(nodes);});
 languageState.refresh=refresh;refresh();const control={refresh,disconnect:()=>observer.disconnect()};root[languageKey]=control;return control;
}

for(const [en,ja] of [...JAPANESE_COPY])if(en.includes('Follow car toggles a locked view from behind the car.'))JAPANESE_COPY.set(en.replace('Follow car toggles a locked view from behind the car.','Follow car resets the view.'),ja);

JAPANESE_COPY.set('Paint pavement','歩道をぬる');
JAPANESE_COPY.set('Paint pavement one tile at a time; drag to make a path','1マスずつ歩道をぬろう。ドラッグすると道をつくれるよ');
JAPANESE_COPY.set('Flowers and pavement can cover clear ground. The pavement brush paints one tile at a time. Buildings, roads and rivers replace them. The eraser removes only the first kind of object touched during each stroke.','花や歩道は、何もない地面にかけるよ。歩道は1マスずつぬれるよ。建物・道路・川を置くと、その場所の花や歩道は消えるよ。消しゴムは、最初にさわったものと同じ種類だけを消すよ。');
JAPANESE_COPY.set('Place the start flag on a road and connect the 16 required building types to start giving directions. Other buildings are optional.','道路にスタートの旗を置き、16種類の必要な建物を道路でつなぐと、道案内を始められるよ。ほかの建物は、好きなものを追加できるよ。');

for(const [en,ja] of [['Choose your car and colour','車と色を選ぼう'],['Car model','車の種類'],['Car colour','車の色'],['Your car','きみの車'],['Skyline','スカイライン'],['Porsche 911','ポルシェ 911'],['Compact','コンパクトカー'],['Coupe','クーペ'],['Hatchback','ハッチバック'],['Minivan','ミニバン'],['Off-road','オフロードカー'],['Pickup','ピックアップ'],['Sedan','セダン'],['Sports car','スポーツカー'],['SUV','エスユーブイ'],['Wagon','ワゴン'],['Red','赤'],['Blue','青'],['Yellow','黄色'],['Green','緑'],['White','白'],['Black','黒'],['Silver','銀色'],['Purple','紫'],['Orange','オレンジ'],['Pink','ピンク'],['Choose a valid car and colour.','車の種類と色を選び直してね。']])JAPANESE_COPY.set(en,ja);

for(const [en,ja]of [['City hotel','街のホテル'],['Skyscraper hotel','高層ホテル'],['Brick factory','れんがの工場'],['Restored factory','改修した工場']])JAPANESE_COPY.set(en,ja);

for(const [en,ja]of [
 ['② Directions','② 道案内'],['③ Create room','③ 部屋をつくる'],['Directions · English GPS','道案内・英語を聞こう'],['Listen and drive','聞いて、運転しよう'],['Listen to the English directions. Find the destination without direction arrows.','英語の道案内を聞いて運転しよう。矢印なしで目的地を見つけてね。'],['Listen again','もう一度聞く'],['New destination','新しい目的地'],['English GPS directions','英語を聞いて道案内'],['The computer chooses your destination. Listen to the English directions and drive there. There are no direction arrows.','コンピューターが目的地を選ぶよ。英語の道案内を聞いて運転しよう。道を教える矢印は出ないよ。'],['Listen to the English directions.','英語の道案内を聞こう。'],['Follow the English directions. Press Listen again whenever you need.','英語を聞いて進もう。わからないときは「もう一度聞く」を押してね。'],['Sound is off. Turn it on to hear the directions.','音がオフになっているよ。「音：オン」か「もう一度聞く」を押してね。'],['The voice could not play. Press Listen again.','音声を再生できませんでした。「もう一度聞く」を押してね。'],['Wrong way. Listen to the new directions.','ちがう道に進んだよ。新しい道案内を聞こう。'],['This browser cannot read the directions aloud. Try a browser with English speech.','このブラウザーでは音声を再生できません。英語の音声を使えるブラウザーで開いてね。'],['There is no reachable destination. Check the roads and entrances.','行ける目的地がないよ。道路と入り口を確認してね。'],['You followed the English directions! Try a new destination.','英語の道案内を聞いて到着できたね！次の目的地に挑戦しよう。'],['Try another destination','次の目的地に挑戦'],['Directions chooses a destination for you. Listen to spoken English directions and drive there without arrows. Press Listen again to repeat an instruction. A longer usable road recalculates the route. A buzzer and a large X mean you need to turn back safely.','「道案内」では、コンピューターが目的地を選ぶよ。英語を聞き、矢印なしで運転しよう。「もう一度聞く」で繰り返せるよ。遠回りでも行ける道なら、新しいルートを案内するよ。引き返す必要がある道では、ブザーと大きな×が出るよ。']
])JAPANESE_COPY.set(en,ja);

JAPANESE_COPY.set('Place the start flag on a road and connect the 16 required building types to start giving directions. Optional buildings unlock after the town meets these Directions requirements. Existing optional buildings can still be moved or removed. At 50 buildings and trees in total, the right side unlocks permanently. At 70 buildings and trees, the bottom unlocks too.','道路にスタートの旗を置き、16種類の必要な建物を道路でつなぎ、駅の後ろに線路をつなぐと、道案内で遊べるよ。条件を満たすと、追加の建物も使えるよ。すでに置いた追加の建物は、動かしたり消したりできるよ。建物と木を合わせて50こになると右側、70こになると下側もずっと使えるようになるよ。');
JAPANESE_COPY.set('Invalid progression: optional buildings unlock when your town meets the Directions requirements. Refresh the game; your local changes are retained.','追加の建物は、道案内の条件を満たすと使えるよ。まちはこの端末に残っているよ。ゲームを開き直してね。');
JAPANESE_COPY.set('Invalid progression: the larger map unlocks at 70 buildings. Refresh the game; your local changes are retained.','広い地図は、木を除く建物が70こになると使えるよ。まちはこの端末に残っているよ。ゲームを開き直してね。');

JAPANESE_COPY.set('Invalid progression: the right side unlocks at 50 buildings and the bottom at 70. Refresh the game; your local changes are retained.','建物と木を合わせて50こで右側、70こで下側が使えるよ。まちはこの端末に残っているよ。ゲームを開き直してね。');

JAPANESE_COPY.set('Police cars chase witnessed red-light offences, closed railway crossings and vehicle collisions. If caught, restart at a connected prison or police station. These two buildings cannot be destinations.','信号無視、閉まっている踏切への進入、車との衝突を見られると、警察が追いかけてくるよ。つかまったら、道路につながっている刑務所か警察署からやり直し。この2つの建物は目的地にはならないよ。');

JAPANESE_COPY.set('Original station','もとの駅');
JAPANESE_COPY.set('Japanese local station','小さな日本の駅');

JAPANESE_COPY.set('Connect roads near the yellow entrances. Buildings set back from a road need a continuous pavement path from their entrance to the road. Red buildings have disconnected entrances. Stations also need tracks at the back.','黄色い入り口の近くに道路をつなごう。道路からはなれた建物は、入り口から道路まで歩道をとぎれずにつなげてね。赤い建物は、まだつながっていないよ。駅には後ろの線路も必要だよ。');
