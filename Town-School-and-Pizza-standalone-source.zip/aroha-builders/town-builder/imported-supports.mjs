import * as THREE from './vendor/three.module.js';

// These two supplied assets contain raised open-bottom ground sheets. Close
// only their existing perimeter; do not move the originals or cover a whole lot.
const EPS=1e-8,BOTTOM=-.012;
const stadiumMaterial=new THREE.MeshStandardMaterial({color:'#85877d',roughness:.96,side:THREE.DoubleSide});stadiumMaterial.userData.shared=true;
const bakeryMaterial=new THREE.MeshStandardMaterial({color:'#b9b4a6',roughness:.96,side:THREE.DoubleSide});bakeryMaterial.userData.shared=true;
function triangles(parts,visit){
 for(const part of parts){
  const geometry=part.geometry,p=geometry?.attributes?.position,uv=geometry?.attributes?.uv,index=geometry?.index;if(!p)continue;
  const count=index?index.count:p.count;
  for(let i=0;i<count;i+=3){
   const ids=[0,1,2].map(j=>index?index.getX(i+j):i+j),v=ids.map(id=>({x:p.getX(id),y:p.getY(id),z:p.getZ(id),u:uv?.getX(id)??0,v:uv?.getY(id)??0}));visit(v,part);
  }
 }
}
const cross=(a,b,c)=>(b.x-a.x)*(c.z-a.z)-(b.z-a.z)*(c.x-a.x);
function supportPart(name,edges,material){
 if(!edges.length)return null;const positions=[],uv=[];
 const groups=new Map();
 for(const [a,b]of edges){const axis=Math.abs(a.x-b.x)<EPS?'z':'x',fixed=axis==='z'?a.x:a.z,sign=Math.sign(b[axis]-a[axis]),key=axis+':'+Math.round(fixed*1e6)+':'+sign+':'+Math.round(a.y*1000);if(!groups.has(key))groups.set(key,{axis,sign,edges:[]});groups.get(key).edges.push([a,b]);}
 const merged=[];
 for(const {axis,sign,edges:list}of groups.values()){
  list.sort((a,b)=>(a[0][axis]-b[0][axis])*sign);let current=null;
  for(const edge of list){if(current&&Math.hypot(current[1].x-edge[0].x,current[1].z-edge[0].z)<1e-6&&Math.abs(current[1].y-edge[0].y)<.0011)current[1]=edge[1];else{if(current)merged.push(current);current=[...edge];}}
  if(current)merged.push(current);
 }
 for(const [a,b]of merged){
  // Only a vertical skirt is added; no top sheet can obscure source artwork.
  for(const p of [{...a,y:BOTTOM},{...b,y:BOTTOM},b,{...a,y:BOTTOM},b,a]){positions.push(p.x,p.y,p.z);uv.push(p.u||0,p.v||0);}
 }
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.computeVertexNormals();geometry.computeBoundingBox();geometry.computeBoundingSphere();
 return {name,geometry,material,shadowCaster:false,groundSupport:true};
}
function bakerySupport(parts){
 const planes=new Map();
 triangles(parts,v=>{
  const min=Math.min(...v.map(p=>p.y)),max=Math.max(...v.map(p=>p.y)),area=Math.abs(cross(...v))/2;
  if(min<.02||max>.15||max-min>.0002||area<1e-6)return;
  const key=Math.round((min+max)/2*1000),plane=planes.get(key)||{area:0,triangles:[]};plane.area+=area;plane.triangles.push(v);planes.set(key,plane);
 });
 const plane=[...planes.values()].sort((a,b)=>b.area-a.area)[0];if(!plane||plane.area<.5)return null;
 return surfacePerimeterSupport(plane.triangles,{cell:.02,minSupport:.02,overlap:.004,name:'bakery-platform-ground-contact',material:bakeryMaterial});
}
function stadiumSupport(parts){
 const low=[];
 triangles(parts,v=>{
  if(Math.max(...v.map(p=>p.y))>.62||Math.abs(cross(...v))<1e-7)return;
  low.push(v);
 });
 return surfacePerimeterSupport(low,{cell:.06,minSupport:.035,overlap:.012,name:'stadium-outer-ground-contact',material:stadiumMaterial});
}
function surfacePerimeterSupport(low,{cell,minSupport,overlap,name,material}){
 if(!low.length)return null;
 let minX=Infinity,maxX=-Infinity,minZ=Infinity,maxZ=-Infinity;
 for(const v of low)for(const p of v){minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minZ=Math.min(minZ,p.z);maxZ=Math.max(maxZ,p.z);}
 const w=Math.ceil((maxX-minX)/cell)+2,d=Math.ceil((maxZ-minZ)/cell)+2,originX=minX-cell/2,originZ=minZ-cell/2;
 if(w*d>100000)return null;
 const heights=new Float32Array(w*d).fill(Infinity),key=(x,z)=>z*w+x;
 // Resolve the union across every split part/material first. This prevents
 // support curtains on texture seams or inside a continuous floor.
 for(const v of low){
  const [a,b,c]=v,den=cross(a,b,c),x0=Math.max(0,Math.floor((Math.min(...v.map(p=>p.x))-originX)/cell)),x1=Math.min(w-1,Math.floor((Math.max(...v.map(p=>p.x))-originX)/cell)),z0=Math.max(0,Math.floor((Math.min(...v.map(p=>p.z))-originZ)/cell)),z1=Math.min(d-1,Math.floor((Math.max(...v.map(p=>p.z))-originZ)/cell));
  for(let z=z0;z<=z1;z++)for(let x=x0;x<=x1;x++){
   const q={x:originX+(x+.5)*cell,z:originZ+(z+.5)*cell},wa=cross(q,b,c)/den,wb=cross(a,q,c)/den,wc=1-wa-wb;
   if(wa< -EPS||wb< -EPS||wc< -EPS)continue;const y=wa*a.y+wb*b.y+wc*c.y;heights[key(x,z)]=Math.min(heights[key(x,z)],y);
  }
 }
 const outside=new Uint8Array(w*d),queue=[];
 const seed=(x,z)=>{const k=key(x,z);if(!Number.isFinite(heights[k])&&!outside[k]){outside[k]=1;queue.push(k);}};
 for(let x=0;x<w;x++){seed(x,0);seed(x,d-1);}for(let z=0;z<d;z++){seed(0,z);seed(w-1,z);}
 for(let i=0;i<queue.length;i++){const k=queue[i],x=k%w,z=Math.floor(k/w);if(x)seed(x-1,z);if(x+1<w)seed(x+1,z);if(z)seed(x,z-1);if(z+1<d)seed(x,z+1);}
 const edges=[],point=(x,z,y)=>({x:originX+x*cell,y,z:originZ+z*cell,u:0,v:0});
 for(let z=0;z<d;z++)for(let x=0;x<w;x++){
  const y=heights[key(x,z)];if(!Number.isFinite(y)||y<minSupport)continue;
  // A small vertical overlap tucks the support behind the ragged scan edge.
  const h=y+overlap;
  if(x===0||outside[key(x-1,z)])edges.push([point(x,z+1,h),point(x,z,h)]);
  if(x===w-1||outside[key(x+1,z)])edges.push([point(x+1,z,h),point(x+1,z+1,h)]);
  if(z===0||outside[key(x,z-1)])edges.push([point(x,z,h),point(x+1,z,h)]);
  if(z===d-1||outside[key(x,z+1)])edges.push([point(x+1,z+1,h),point(x,z+1,h)]);
 }
 return supportPart(name,edges,material);
}
export function appendImportedGroundSupports(name,parts){
 if(parts.some(p=>p.groundSupport))return parts;
 const support=name==='bakery'?bakerySupport(parts):name==='stadium'?stadiumSupport(parts):null;
 return support?[...parts,support]:parts;
}
