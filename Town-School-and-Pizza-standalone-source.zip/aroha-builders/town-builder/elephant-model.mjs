import * as THREE from './vendor/three.module.js';
import {cherryGeometry} from './cherry-tree.mjs';
let parts=null,pending=null,revision=0;
const clock={value:0};
export const elephantRevision=()=>revision;
function animateSkin(material){
 // Bend only the hanging trunk; the four feet, face, eyes and tusks stay planted.
 material.onBeforeCompile=shader=>{
  shader.uniforms.elephantTime=clock;
  shader.vertexShader='uniform float elephantTime;\n'+shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
   float trunkWeight=smoothstep(0.38,0.52,position.z)*(1.0-smoothstep(0.36,0.57,position.y))*(1.0-smoothstep(0.07,0.13,abs(position.x)));
   transformed.x+=sin(elephantTime*1.25+position.y*3.0)*0.022*trunkWeight;
   transformed.z+=sin(elephantTime*1.25+0.8)*0.012*trunkWeight;`);
 };
 material.customProgramCacheKey=()=> 'elephant-trunk-v1';
}
export async function loadElephant(){return Promise.resolve(false);}
export function createElephant(scale=1,variant='normal'){
 if(!parts)return null;
 const group=new THREE.Group();group.scale.setScalar(1.15*scale);group.position.y=.09;group.rotation.y=-Math.PI/2;group.userData.importedAnimal=true;
 for(const p of parts){
  let material=p.material;
  if(variant.startsWith('ghost')){material=material.clone();material.userData.shared=false;material.transparent=true;material.opacity=.66;if(variant==='ghost-invalid')material.color.set('#ef7575');if(p.kind==='skin')animateSkin(material);}
  const mesh=new THREE.Mesh(p.geometry,material);mesh.name=p.name;mesh.userData.sharedGeometry=true;mesh.userData.shadowCaster=false;group.add(mesh);
 }
 group.userData.animate=t=>{clock.value=t;};
 return group;
}
