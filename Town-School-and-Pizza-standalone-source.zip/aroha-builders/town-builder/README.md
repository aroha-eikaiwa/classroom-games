# Aroha Eikaiwa Town Builder — standalone

Build a town, drive through it with spoken English directions, or complete the Taxi Challenge. This edition uses the November 24 Town Builder game code with browser-local saving. The map editor, progression, road/rail logic, GPS, traffic and taxi gameplay run on the device. For Directions, place the start flag and connect the 16 required building types. The Taxi Challenge also requires connected pedestrian facilities; its checklist explains what to add.

To play, serve this folder as a static site and open `index.html` through that server. For example, in this folder run `python3 -m http.server 8080` and open `http://localhost:8080`. JavaScript modules generally do not run when the page is opened as a file. English speech uses the browser’s speech feature when a compatible voice is available.

## What is different in this edition?

- There are no accounts, class selectors or online room codes. Multiplayer controller handoff and teacher/class-wide controls are not included.
- The game saves only to browser storage. **Start fresh** replaces the local town after confirmation. Print Map remains available.
- Imported models, sprites, textures and fonts with unverified redistribution rights are not included. The game uses built-in shapes, original replacement artwork and system fonts.
- This distribution is a standalone adaptation, not a backup of the original production system. It makes no API calls. Three.js is included under the license in `vendor/THREE-LICENSE.txt`. That notice applies to the vendor library, not the game code.
