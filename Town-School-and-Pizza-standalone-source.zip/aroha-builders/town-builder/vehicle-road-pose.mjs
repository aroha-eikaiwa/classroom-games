import {transportHeightAt} from './transport.mjs';

// Sample axle contact points in world coordinates. This also eases the body
// across ramp crests and feet as one axle reaches the next surface first.
export function vehicleRoadPose(analysis,x,y,heading,wheelbase=.60){
 const half=wheelbase/2,dx=Math.sin(heading)*half,dy=Math.cos(heading)*half;
 const front=transportHeightAt(analysis,x+dx,y+dy,'road'),rear=transportHeightAt(analysis,x-dx,y-dy,'road');
 return {height:(front+rear)/2,pitch:Math.atan2(front-rear,wheelbase)};
}

// Imported cars face -Z; the school bus faces +Z. YXZ keeps pitch and the
// existing cornering lean local to the vehicle for every compass heading.
export function applyVehicleRoadPose(group,analysis,pose,{wheelbase=.60,offset=0,front= -1,roll=0}={}){
 const road=vehicleRoadPose(analysis,pose.x,pose.y,pose.heading,wheelbase);
 group.position.set(pose.x,road.height+offset,pose.y);
 group.rotation.set(-front*road.pitch,pose.heading+(front<0?Math.PI:0),roll,'YXZ');
 return road;
}
