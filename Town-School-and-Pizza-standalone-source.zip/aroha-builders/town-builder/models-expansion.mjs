/** New toy-town architecture. All entrances face +localY; lots stay normalized. */
import {MALL_PARKED_CARS} from './mall-parking.mjs';
import {M,P,shade} from './model-kit.mjs';

// Dedicated image-generated v8 atlas. Kept separate from the original atlas so
// legacy surfaces and the animal/grass materials retain their existing mapping.
export const EXPANSION_M=Object.freeze({ceramic:21,timber:22,shingle:23,arcade:24,mall:25,bark:26,foliage:27});
const E=EXPANSION_M;

export function buildExpansion(type,k,w,d,variant=0){
 if(type==='restaurant'&&variant>=1&&variant<=4){[null,burgerRestaurant,ramenRestaurant,sushiRestaurant,pizzaRestaurant][variant](k);return true;}
 if(type==='house'&&variant>=3&&variant<=5){[townhouse,bungalow,villa][variant-3](k);return true;}
 if(type==='arcade'){arcade(k);return true;}
 if(type==='shopping-mall'){shoppingMall(k,w,d);return true;}
 if(type==='tree'){if(variant)variantTree(k,variant);else standaloneTree(k);return true;}
 return false;
}

function frontPath(k,from=.80){k.path(.445,from,.11,.995-from);}
function lot(k,{garden=false}={}){if(garden)k.grass();else k.rounded(.025,.035,.005,.95,.93,.022,'#ddd5c7',M.paving,.04);}
function frontWindows(k,y,z,xs,a,h,opts={}){for(const x of xs)k.wallWindow(0,x,y,z,a,h,{arched:false,frame:P.ivory,mullions:false,...opts});}
function sideWindows(k,x,y,zs,{width=.10,height=.21,frame=P.ivory}={}){
 for(const side of [1,3])for(const yy of y)for(const z of zs)k.wallWindow(side,side===1?x[1]:x[0],yy,z,width,height,{arched:false,frame,glass:'#81aab0'});
}
function railing(k,x,y,z,a,b,h=.20,c=P.ivory){
 for(const [p,q]of[[[x,y],[x+a,y]],[[x+a,y],[x+a,y+b]],[[x,y+b],[x+a,y+b]]]){
  k.beam([...p,z+h],[...q,z+h],.004,c,M.metal,6);
  const n=Math.max(2,Math.ceil(Math.hypot(q[0]-p[0],q[1]-p[1])/.045));
  for(let i=0;i<=n;i++){const t=i/n,xx=p[0]+(q[0]-p[0])*t,yy=p[1]+(q[1]-p[1])*t;k.beam([xx,yy,z],[xx,yy,z+h],.003,c,M.metal,5);}
 }
}
function terraceTable(k,x,y,{r=.042,c=P.red}={}){
 k.cyl(x,y,.025,.009,.009,.14,P.dark,M.metal,8);k.cyl(x,y,.165,r,r,.022,P.ivory,M.marble,20);
 for(const dx of [-r*1.55,r*1.55]){k.rounded(x+dx-.020,y-.022,.09,.04,.044,.020,c,null,.008);k.rounded(x+dx-.020,y-.027,.105,.04,.010,.092,c,null,.005);for(const q of [-.012,.012])k.beam([x+dx+q,y-.012,.025],[x+dx+q,y-.012,.09],.003,P.dark,M.metal,5);}
}
// Small readable geometric signs avoid a texture-resolution dependency and
// remain part of the building's one batched mesh.
const GLYPH={
 A:[[[0,0],[.5,1],[1,0]],[[.23,.43],[.77,.43]]],B:[[[0,0],[0,1],[.65,1],[1,.8],[.65,.53],[0,.53]],[[.65,.53],[1,.3],[.8,0],[0,0]]],
 C:[[[1,.9],[.75,1],[.2,1],[0,.8],[0,.2],[.2,0],[.8,0],[1,.1]]],D:[[[0,0],[0,1],[.6,1],[1,.75],[1,.25],[.6,0],[0,0]]],E:[[[1,1],[0,1],[0,0],[1,0]],[[0,.5],[.8,.5]]],
 G:[[[1,.85],[.8,1],[.2,1],[0,.8],[0,.2],[.2,0],[1,0],[1,.5],[.5,.5]]],I:[[[.5,0],[.5,1]],[[.05,1],[.95,1]],[[.05,0],[.95,0]]],L:[[[0,1],[0,0],[1,0]]],M:[[[0,0],[0,1],[.5,.45],[1,1],[1,0]]],
 N:[[[0,0],[0,1],[1,0],[1,1]]],P:[[[0,0],[0,1],[.8,1],[1,.75],[.8,.5],[0,.5]]],R:[[[0,0],[0,1],[.8,1],[1,.75],[.8,.5],[0,.5]],[[.45,.5],[1,0]]],
 S:[[[1,.9],[.8,1],[.2,1],[0,.8],[.2,.55],[.8,.45],[1,.2],[.8,0],[.2,0],[0,.1]]],U:[[[0,1],[0,.2],[.2,0],[.8,0],[1,.2],[1,1]]],Z:[[[0,1],[1,1],[0,0],[1,0]]],H:[[[0,0],[0,1]],[[1,0],[1,1]],[[0,.5],[1,.5]]]
};
function sign(k,text,x,y,z,width,height,color=P.ivory){
 const gap=width/(text.length*1.4),a=gap*.90;
 for(let i=0;i<text.length;i++)for(const stroke of GLYPH[text[i]]||[])k.tube(stroke.map(([u,v])=>[x+i*gap*1.4+u*a,y,z+v*height]),Math.min(.0035,height*.045),color,null,5);
}
function menuBoard(k,x,y,c=P.wood){
 k.softBox(x,y,.035,.075,.018,.18,c,E.timber,.006);k.pane(x+.008,y+.020,.065,.059,.135,'#30383b',null);
 for(let i=0;i<4;i++)k.box(x+.017,y+.022,.083+i*.028,.040,.003,.005,i%2?P.gold:P.ivory);
 k.beam([x+.008,y+.01,.05],[x+.008,y+.05,.025],.004,c,E.timber,6);k.beam([x+.067,y+.01,.05],[x+.067,y+.05,.025],.004,c,E.timber,6);
}
function burger(k,x,y,z,s=1){
 k.cyl(x,y,z,.072*s,.058*s,.035*s,'#c78439',M.stucco,24);
 k.cyl(x,y,z+.035*s,.078*s,.064*s,.012*s,'#628d40',M.leaf,24);
 k.cyl(x,y,z+.049*s,.073*s,.060*s,.025*s,'#6e3d2a',null,24);
 k.rounded(x-.072*s,y-.056*s,z+.077*s,.144*s,.112*s,.012*s,'#f4bf43',null,.008*s);
 k.cyl(x,y,z+.092*s,.071*s,.059*s,.018*s,'#cc4f3c',null,24);
 k.dome(x,y,z+.110*s,.077*s,.063*s,.065*s,'#d7a454',M.stucco,28,8);
 for(const [dx,dy]of[[-.035,0],[.015,-.023],[.038,.009],[-.005,.026],[.001,0]])k.sphere(x+dx*s,y+dy*s,z+(.159-Math.hypot(dx,dy)*.25)*s,.008*s,.003*s,.003*s,P.ivory,null,6,3);
}
function burgerRestaurant(k){
 lot(k);const red='#bd483d',cream='#f5dfb7',chrome='#a8b5b3';
 k.rounded(.14,.19,.03,.71,.54,.66,cream,E.ceramic,.045);
 k.rounded(.11,.16,.69,.77,.60,.075,red,E.ceramic,.060);
 k.rounded(.145,.19,.765,.70,.53,.025,chrome,M.metal,.035);
 k.rounded(.13,.18,.060,.73,.56,.055,red,E.ceramic,.035);
 for(const x of [.245,.755]){k.wallWindow(0,x,.737,.16,.165,.30,{arched:false,frame:chrome,glass:'#92bcbf'});for(const xx of [x-.05,x+.05]){k.cyl(xx,.705,.04,.016,.016,.14,red,null,12);k.cyl(xx,.705,.18,.022,.022,.018,red,null,16);}}
 sideWindows(k,[.135,.855],[.30,.57],[.17],{width:.14,height:.29,frame:chrome});
 k.door(.5,.738,.04,.15,.40,{arched:false,color:chrome,glass:true,frame:chrome});k.rounded(.36,.74,.46,.28,.11,.034,red,E.ceramic,.018);
 k.rounded(.305,.23,.80,.39,.25,.045,cream,E.ceramic,.025);burger(k,.50,.36,.845,1.55);
 k.softBox(.27,.749,.56,.46,.017,.095,red,E.ceramic,.008);sign(k,'BURGER',.294,.772,.581,.42,.050,P.ivory);
 terraceTable(k,.18,.87,{r:.035,c:red});terraceTable(k,.82,.87,{r:.035,c:red});menuBoard(k,.63,.84,red);frontPath(k,.84);
 for(const x of [.105,.86])k.planter(x,.07,.065,.08,P.ivory);k.hvac(.73,.24,.80,.075);
}
function ramenRestaurant(k){
 lot(k);const timber='#694732',red='#bd5142',plaster='#d7bd8e';
 k.softBox(.18,.22,.185,.64,.51,.54,plaster,E.ceramic,.014);k.softBox(.18,.22,.035,.64,.51,.15,timber,E.timber,.009);
 k.hip(.12,.16,.76,.76,.63,.19,'#424b4b',E.shingle,.14);
 for(const x of [.19,.34,.66,.80])k.softBox(x,.73,.12,.017,.035,.59,timber,E.timber,.004);
 k.softBox(.17,.731,.60,.66,.035,.12,timber,E.timber,.008);sign(k,'RAMEN',.337,.774,.628,.33,.064,P.ivory);
 k.door(.5,.738,.045,.18,.43,{arched:false,color:timber,glass:true,frame:timber});
 for(const x of [.27,.73])k.wallWindow(0,x,.739,.16,.12,.32,{arched:false,frame:timber,glass:'#c89a58'});
 for(let i=0;i<7;i++)k.softBox(.375+i*.036,.795,.43,.033,.011,.125,red,M.stucco,.003);
 k.softBox(.365,.79,.557,.27,.018,.018,timber,E.timber,.003);
 for(const x of [.125,.875]){k.cyl(x,.78,.31,.029,.026,.20,red,M.stucco,24);k.dome(x,.78,.51,.029,.026,.025,red,M.stucco,24,5);k.cyl(x,.78,.29,.020,.020,.023,timber,M.metal,12);for(let j=0;j<5;j++)k.ring(x,.78,.325+j*.038,.030,.027,.0018,.003,P.gold,null,24);k.beam([x,.78,.535],[x,.78,.62],.003,P.dark,M.metal,6);}
 // A ceramic ramen bowl with visible broth, noodles and chopsticks.
 k.frustum(.5,.40,.96,.047,.04,.090,.089,.071,P.ivory,null,28);k.ring(.5,.40,1.037,.089,.071,.004,.012,'#bd5142',null,28);k.cyl(.5,.40,1.05,.084,.066,.006,'#c38b47',null,28);
 for(let i=0;i<4;i++)k.tube(Array.from({length:11},(_,j)=>[.449+j*.010,.38+i*.012+Math.sin(j*.8+i)*.006,1.058]),.003,'#edcb7e',null,6);
 k.sphere(.53,.39,1.06,.022,.018,.010,P.ivory,null,14,6);k.sphere(.53,.39,1.068,.009,.009,.004,P.gold,null,10,4);
 for(const yy of [.43,.445])k.beam([.43,yy,1.066],[.61,yy-.065,1.105],.0034,P.honey,E.timber,8);
 sideWindows(k,[.175,.825],[.36,.60],[.20],{width:.11,height:.23,frame:timber});k.wallWindow(2,.5,.217,.23,.27,.23,{arched:false,frame:timber});
 menuBoard(k,.23,.84);frontPath(k,.84);k.planter(.72,.85,.13,.065,P.ivory);k.hvac(.69,.25,.925,.08);
}
function sushiRestaurant(k){
 lot(k,{garden:true});const timber='#534632',cream='#e3d4b2',blue='#305b73';
 k.path(.12,.78,.76,.17);k.softBox(.17,.24,.17,.66,.50,.525,cream,E.ceramic,.016);
 k.softBox(.17,.24,.04,.66,.50,.13,timber,E.timber,.007);k.hip(.10,.17,.73,.80,.64,.23,'#48575b',E.shingle,.16);
 k.softBox(.16,.743,.57,.68,.018,.13,timber,E.timber,.006);sign(k,'SUSHI',.345,.766,.602,.31,.065,P.ivory);
 k.door(.50,.748,.05,.15,.41,{arched:false,color:timber,glass:true,frame:timber});
 for(const x of [.28,.72]){k.wallWindow(0,x,.748,.15,.15,.30,{arched:false,frame:timber,glass:'#cba765'});for(let i=0;i<5;i++)k.box(x-.06+i*.03,.779,.15,.005,.007,.30,timber,E.timber);}
 k.softBox(.37,.787,.49,.26,.016,.022,timber,E.timber,.004);for(let i=0;i<5;i++)k.softBox(.375+i*.050,.791,.36,.046,.01,.125,blue,M.stucco,.003);
 // Nigiri roof emblem: rounded rice with flat salmon markings, not spot meshes.
 k.rounded(.385,.355,.985,.23,.12,.075,P.ivory,M.stucco,.035);k.rounded(.374,.348,1.052,.252,.134,.055,'#cf7e62',null,.032);
 for(let i=0;i<5;i++)k.tube([[.40+i*.045,.351,1.079],[.417+i*.04,.385,1.11],[.431+i*.037,.473,1.086]],.0025,'#f2c3a2',null,5);
 sideWindows(k,[.165,.835],[.37,.62],[.20],{width:.12,height:.25,frame:timber});k.wallWindow(2,.50,.237,.20,.30,.25,{arched:false,frame:timber});
 for(const x of [.11,.88]){k.cyl(x,.79,.03,.025,.026,.11,P.stone,M.stone,16);k.cyl(x,.79,.14,.009,.009,.27,P.wood,E.timber,10);k.sphere(x,.79,.44,.047,.045,.09,'#779051',E.foliage,18,9);}
 menuBoard(k,.24,.85,timber);frontPath(k,.95);k.bench(.65,.86,.16);
}
function pizzaRestaurant(k){
 lot(k);const brick='#c2764f',green='#49754e',cream='#f1d3a2';
 k.softBox(.18,.23,.035,.64,.50,.71,brick,M.brick,.014);k.cornice(.17,.22,.71,.66,.52,cream);k.roof(.13,.17,.80,.74,.62,.27,'#b65b3d',M.terracotta);
 k.softBox(.68,.26,.94,.075,.10,.25,cream,E.ceramic,.010);k.softBox(.67,.25,1.18,.095,.12,.026,P.terra,M.terracotta,.007);
 for(const x of [.29,.71])k.wallWindow(0,x,.737,.13,.17,.35,{arched:true,frame:cream,glass:'#d3a55f'});
 k.door(.50,.74,.045,.15,.43,{color:green,glass:true,frame:cream});
 k.awning(.17,.75,.56,.66,.12,green,P.ivory,12);for(let i=0;i<4;i++)k.softBox(.17+i*.165,.873,.463,.055,.008,.021,'#bb5144',null,.002);
 k.softBox(.33,.742,.64,.34,.017,.10,cream,E.ceramic,.006);sign(k,'PIZZA',.348,.764,.665,.31,.058,green);
 // Actual round pizza crest with a gently raised crust and toppings.
 k.disk(.5,.636,1.095,.107,.155,'#cd9346',M.stucco,40);k.disk(.5,.640,1.095,.093,.134,'#d15835',null,36);k.disk(.5,.644,1.095,.087,.126,'#e8bc61',null,36);
 for(let i=0;i<36;i++){const a=i/36*Math.PI*2,b=(i+1)/36*Math.PI*2;k.beam([.5+Math.cos(a)*.100,.645,1.095+Math.sin(a)*.145],[.5+Math.cos(b)*.100,.645,1.095+Math.sin(b)*.145],.005,'#cd9346',M.stucco,6);}
 for(const [x,z]of[[-.045,-.02],[.035,-.065],[.044,.05],[-.025,.07],[0,0]])k.disk(.5+x,.651,1.095+z,.014,.020,'#b34c36',null,16);
 sideWindows(k,[.175,.825],[.35,.60],[.18],{width:.12,height:.30,frame:cream});k.wallWindow(2,.50,.227,.25,.22,.25,{arched:true,frame:cream});
 terraceTable(k,.19,.87,{r:.039,c:green});terraceTable(k,.81,.87,{r:.039,c:green});menuBoard(k,.62,.86,green);frontPath(k,.88);
}

function houseGarden(k){lot(k,{garden:true});frontPath(k,.82);for(const x of [.13,.82])k.planter(x,.84,.07,.07,P.ivory);}
function townhouse(k){
 houseGarden(k);const brick='#c38a70',slate='#4a6474',cream='#eee2c8';
 k.softBox(.23,.23,.045,.54,.51,1.14,brick,M.brick,.016);k.softBox(.22,.22,.045,.56,.53,.075,P.stone,M.stone,.01);
 for(const z of [.40,.79,1.16])k.cornice(.23,.23,z,.54,.51,cream);k.roof(.18,.18,1.22,.64,.61,.30,slate,E.shingle);
 k.softBox(.39,.62,1.30,.22,.13,.18,cream,E.ceramic,.010);k.roof(.37,.61,1.48,.26,.15,.13,slate,E.shingle);k.wallWindow(0,.5,.754,1.33,.12,.14,{arched:false,frame:cream});
 for(const z of [.51,.90])frontWindows(k,.746,z,[.34,.66],.125,.22,{frame:cream,flowers:z<.6});
 k.door(.5,.75,.05,.14,.34,{arched:true,color:'#456c78',frame:cream});for(const x of [.32,.68])k.wallWindow(0,x,.746,.13,.09,.21,{arched:true,frame:cream});
 sideWindows(k,[.225,.775],[.36,.61],[.16,.53,.92],{width:.10,height:.19,frame:cream});for(const z of [.18,.56,.95])k.wallWindow(2,.5,.225,z,.20,.18,{arched:false,frame:cream});
 k.softBox(.59,.28,1.44,.07,.09,.26,cream,E.ceramic,.01);k.softBox(.58,.27,1.69,.09,.11,.025,slate,E.shingle,.008);k.steps(.5,.81,.065,.24,3,.023,.02);
 k.tree(.12,.66,.56);k.bench(.72,.81,.13);k.lamp(.37,.88,.55);
}
function bungalow(k){
 houseGarden(k);const timber='#c6a578',blue='#536f7b',cream='#f1e7d1';
 k.softBox(.15,.28,.045,.70,.44,.53,timber,E.timber,.018);k.softBox(.14,.27,.035,.72,.46,.065,P.stone,M.stone,.012);
 k.hip(.08,.20,.64,.84,.60,.29,blue,E.shingle,.20);k.beam([.31,.50,.935],[.69,.50,.935],.009,blue,E.shingle,10);
 k.softBox(.38,.67,.04,.24,.17,.065,P.ivory,M.paving,.012);k.door(.5,.727,.065,.15,.36,{arched:false,color:blue,glass:true,frame:cream});
 frontWindows(k,.726,.17,[.27,.73],.16,.23,{frame:cream,flowers:true});sideWindows(k,[.145,.855],[.40,.61],[.17],{width:.12,height:.22,frame:cream});
 for(const x of [.31,.69])k.wallWindow(2,x,.275,.19,.16,.22,{arched:false,frame:cream});
 for(const x of [.34,.66]){k.cyl(x,.80,.045,.012,.012,.50,P.ivory,E.ceramic,14);k.softBox(x-.02,.78,.045,.04,.04,.09,P.stone,M.stone,.005);}
 k.hip(.29,.68,.55,.42,.20,.13,blue,E.shingle,.08);k.steps(.5,.84,.065,.26,2,.027,.025);
 k.softBox(.66,.32,.80,.07,.09,.23,P.stone,M.stone,.010);k.softBox(.65,.31,1.02,.09,.11,.025,cream,E.ceramic,.006);
 k.tree(.12,.80,.54);k.bench(.72,.84,.14);for(const x of [.10,.88])k.shrub(x,.23,.03,.055);
}
function villa(k){
 houseGarden(k);const plaster='#eed5ac',roof='#b9724c',green='#638477';
 k.softBox(.16,.25,.04,.68,.47,.61,plaster,E.ceramic,.025);k.softBox(.23,.28,.67,.40,.39,.49,plaster,E.ceramic,.018);
 k.hip(.11,.20,.68,.78,.57,.24,roof,M.terracotta,.18);k.hip(.18,.23,1.20,.50,.49,.22,roof,M.terracotta,.13);
 k.softBox(.26,.66,.65,.33,.16,.037,P.ivory,M.stone,.010);railing(k,.27,.68,.69,.31,.12,.18,green);
 for(const x of [.31,.55])k.wallWindow(0,x,.676,.86,.12,.26,{arched:true,frame:P.ivory,glass:'#80a3a2'});
 k.door(.50,.728,.05,.15,.41,{color:green,frame:P.ivory});for(const x of [.28,.72])k.wallWindow(0,x,.728,.16,.14,.27,{arched:true,frame:P.ivory});
 for(const x of [.30,.68])k.cyl(x,.80,.045,.015,.015,.48,P.ivory,E.ceramic,16);k.hip(.27,.70,.53,.44,.17,.11,roof,M.terracotta,.06);
 sideWindows(k,[.155,.845],[.37,.61],[.19],{width:.11,height:.26});k.wallWindow(2,.43,.275,.83,.22,.25,{arched:true,frame:P.ivory});
 // Distinct open pergola terrace and low fountain garden.
 for(const x of [.69,.81])for(const y of [.28,.63])k.softBox(x,y,.84,.012,.012,.24,P.honey,E.timber,.003);
 for(let i=0;i<6;i++)k.softBox(.67,.27+i*.067,1.08,.16,.016,.018,P.honey,E.timber,.003);
 k.ring(.84,.85,.025,.07,.06,.012,.035,P.ivory,M.stone,24);k.cyl(.84,.85,.027,.055,.045,.014,'#8ab5bd',M.glass,20);k.cyl(.84,.85,.04,.009,.008,.08,P.ivory,M.stone,12);
 k.tree(.12,.73,.60);k.steps(.5,.84,.065,.26,2,.024,.025);
}

function gameCabinet(k,x,y,z,c){
 k.softBox(x,y,z,.058,.053,.25,'#353f54',E.arcade,.006);
 k.softBox(x-.004,y+.028,z+.20,.066,.031,.061,c,E.arcade,.006);k.pane(x+.006,y+.060,z+.213,.046,.032,'#d7d9ba',null);
 k.pane(x+.006,y+.055,z+.10,.046,.086,'#93c9d4',M.glass);k.softBox(x+.002,y+.053,z+.075,.054,.032,.018,c,E.arcade,.004);
 k.beam([x+.019,y+.072,z+.092],[x+.019,y+.072,z+.113],.002,P.dark,M.metal,6);k.sphere(x+.019,y+.072,z+.117,.005,.005,.005,P.red,null,8,4);
 for(const xx of [.035,.045])k.sphere(x+xx,y+.073,z+.096,.003,.004,.002,P.gold,null,6,3);
 for(const [dx,dz]of[[.008,.012],[.02,.028],[.032,.013]])k.box(x+dx,y+.057,z+.13+dz,.006,.002,.006,P.ivory);
}
function arcade(k){
 lot(k);const navy='#245cb4',purple='#a84de0',cyan='#15e8e2',pink='#ff4b9b';
 k.rounded(.15,.20,.035,.70,.52,1.10,navy,E.arcade,.035);
 k.rounded(.12,.17,1.135,.76,.58,.065,purple,E.arcade,.035);k.rounded(.15,.20,1.20,.70,.52,.025,navy,E.arcade,.025);
 k.softBox(.18,.724,.09,.64,.012,.45,'#1d2c3b',M.glass,.008);
 for(const x of [.21,.29,.65,.73])gameCabinet(k,x,.743,.055,x<.4?purple:'#548a99');
 for(const x of [.16,.82]){k.softBox(x,.729,.12,.025,.021,.86,cyan,null,.007);k.softBox(x+.006,.754,.15,.013,.006,.80,'#b6e7de',null,.004);}
 k.door(.5,.752,.04,.16,.42,{arched:false,color:cyan,glass:true,frame:purple});
 k.rounded(.35,.77,.47,.30,.13,.065,purple,E.arcade,.022);k.softBox(.36,.891,.48,.28,.007,.018,cyan,null,.003);
 k.rounded(.24,.73,.65,.52,.038,.22,purple,E.arcade,.022);sign(k,'ARCADE',.275,.777,.713,.46,.094,P.ivory);
 // Large controller emblem creates a recognizable silhouette even at distance.
 k.rounded(.37,.57,1.27,.26,.12,.12,purple,E.arcade,.04);for(const x of [.39,.59])k.sphere(x,.62,1.285,.065,.072,.075,purple,E.arcade,20,10);
 k.box(.402,.695,1.29,.045,.008,.012,cyan);k.box(.419,.695,1.271,.012,.008,.050,cyan);
 for(const [x,z]of[[.565,1.283],[.590,1.307]])k.disk(x,.698,z,.009,.013,pink,null,14);
 for(const side of [1,3]){const xx=side===1?.855:.145;k.at(xx,.47,.69,-side*Math.PI/2,()=>{k.rounded(-.13,0,0,.26,.015,.27,purple,E.arcade,.018);for(const [x,z]of[[-.075,.06],[-.025,.15],[.025,.06],[.075,.15]]){k.disk(x,.020,z,.020,.030,cyan,null,16);}});}
 for(const x of [.29,.71])k.wallWindow(2,x,.195,.57,.18,.30,{arched:false,frame:purple,glass:'#72aab9'});
 for(let band=0;band<3;band++)k.rounded(.13,.18,.93+band*.065,.74,.56,.025,['#ffcb32','#ff4b9b','#15e8e2'][band],null,.025);
 for(let row=0;row<2;row++)for(let phase=0;phase<3;phase++)k.mark('arcade-light',[.5,.78,.7],{phase:phase*2+row},()=>{for(let i=phase;i<15;i+=3)k.sphere(.245+i*.036,.785,.65+row*.22,.009,.009,.012,['#ffe645','#ff66cb','#38ffff'][phase],null,6,4);});
 for(let phase=0;phase<3;phase++)k.mark('arcade-light',[.5,.75,.5],{phase:phase*2},()=>{for(const x of [.17,.83])for(let i=phase;i<15;i+=3)k.softBox(x,.76,.16+i*.047,.02,.008,.029,['#ffff75','#f65dfa','#69faff'][phase],null,.004);});
 k.hvac(.20,.28,1.23,.105);k.hvac(.68,.27,1.23,.105);k.planter(.14,.85,.15,.075,navy);k.planter(.72,.85,.15,.075,navy);frontPath(k,.90);
}
function shoppingMall(k,w,d){
 const first=k.faces.length;
 lot(k);const stone='#d5cbb6',white='#efeadb',blue='#6796aa',frame='#b1baba',teal='#47798a';
 // Three wings, a taller glazed central atrium and two stepped roof terraces.
 k.rounded(.07,.17,.03,.86,.55,.78,stone,E.mall,.025);
 for(const x of [.065,.63]){k.rounded(x,.21,.815,.305,.47,.63,white,E.mall,.020);k.rounded(x-.007,.20,1.445,.319,.49,.055,teal,M.metal,.014);}
 k.rounded(.37,.15,.04,.26,.59,1.43,frame,E.mall,.025);
 for(const z of [.13,.61,1.04]){
  for(const x of [.40,.455,.51,.565])k.wallWindow(0,x+.015,.746,z,.043,.32,{arched:false,frame:frame,glass:blue,mullions:false});
  for(const x of [.09,.155,.22,.285,.655,.72,.785,.85])k.wallWindow(0,x+.022,.724,z,.051,.27,{arched:false,frame:white,glass:blue,mullions:false});
 }
 for(const z of [.48,.95,1.405])k.softBox(.07,.719,z,.86,.018,.045,white,E.mall,.006);
 // Barrel-vaulted glass skylight: smooth normals and visible structural ribs.
 const n=22;for(let i=0;i<n;i++){
  const a=Math.PI*i/n,b=Math.PI*(i+1)/n,pt=(t,y)=>[.50+Math.cos(t)*.15,y,1.50+Math.sin(t)*.20];
  k.face([pt(a,.68),pt(b,.68),pt(b,.18),pt(a,.18)],'#87b5bd',M.glass,'mall-atrium');
 }
 for(const y of [.18,.28,.38,.48,.58,.68])k.tube(Array.from({length:n+1},(_,i)=>{const a=Math.PI*i/n;return[.50+Math.cos(a)*.151,y,1.50+Math.sin(a)*.202];}),.003,frame,M.metal,6);
 for(const side of [1,3])for(const y of [.25,.36,.47,.58,.67])for(const z of [.19,.64,1.10])k.wallWindow(side,side===1?.935:.065,y,z,.061,.25,{arched:false,frame:white,glass:blue,mullions:false});
 for(const x of [.15,.28,.43,.57,.72,.85])for(const z of [.20,.64,1.10])k.wallWindow(2,x,.165,z,.065,.25,{arched:false,frame:white,glass:blue,mullions:false});
 // Entrance canopy, paired glazed doors and plaza remain centred on road access.
 k.rounded(.365,.72,.06,.27,.13,.50,frame,E.mall,.018);k.door(.5,.852,.04,.10,.39,{arched:false,color:frame,glass:true,frame:frame});
 for(const x of [.405,.595])k.wallWindow(0,x,.854,.13,.065,.29,{arched:false,frame:white,glass:blue,mullions:false});
 k.rounded(.335,.715,.56,.33,.20,.055,teal,M.metal,.025);k.rounded(.35,.725,.617,.30,.17,.015,'#abcbd0',M.glass,.02);
 k.softBox(.397,.746,1.31,.206,.020,.125,teal,E.mall,.008);sign(k,'MALL',.418,.770,1.342,.18,.069,P.ivory);
 for(const [x,y]of[[.12,.25],[.25,.25],[.68,.25],[.81,.25]])k.hvac(x,y,1.505,.065);
 for(const x of [.16,.75]){k.rounded(x,.48,1.505,.09,.12,.012,P.ivory,M.paving,.01);k.planter(x,.50,.09,.055,P.ivory,false);}
 // Courtyard planting and seating give the mall a generous, believable footprint.
 for(const x of [.12,.82]){k.tree(x,.83,.68);k.bench(x-.04,.91,.08);k.planter(x-.045,.74,.09,.055,P.ivory);}
 for(const x of [.30,.70])k.lamp(x,.88,.90);k.path(.37,.88,.26,.11);frontPath(k,.88);
 for(const x of [.27,.67])k.rounded(x,.83,.025,.06,.085,.025,white,E.mall,.015);
 // Retain the original 8x5 mall behind the new front car park.
 const animations=new Set();
 for(const face of k.faces.slice(first)){
  for(const p of face.points){p[0]=w*.1+p[0]*.8;p[1]*=.625;}
  if(face.animation&&!animations.has(face.animation)){animations.add(face.animation);face.animation.center[0]=w*.1+face.animation.center[0]*.8;face.animation.center[1]*=.625;}
 }
 k.rounded(.055,.64,.014,.89,.33,.012,'#727a7c',M.asphalt,.02);
 for(const base of [.08,.56]){
  for(let i=0;i<=4;i++)k.box(base+i*.09,.65,.028,.002,.17,.002,P.white);
  k.box(base,.65,.028,.362,.002,.002,P.white);
 }
 k.path(.46,.62,.08,.375);
 // Marked spaces, two empty bays, and a clear centre pedestrian route.
 for(const car of MALL_PARKED_CARS){const y=.735,center=[car.x,y,.028];k.mark('parked-passenger',center,{model:car.model,color:car.color,length:.9*Math.min(w/10,d/8)},()=>{k.box(car.x-.018,y-.05625,.08,.036,.1125,.08,car.color);k.box(car.x-.015,y-.025,.16,.03,.048,.05,P.glass);});}
 for(const x of [.12,.88])k.lamp(x,.93,.55);

}
function standaloneTree(k){
 // Sculpted branching trunk and overlapping rounded crowns, with dedicated bark
 // and foliage textures; no square lawn tile, so it blends with flowers/terrain.
 k.cyl(.5,.5,.012,.075,.063,.055,'#8c6b45',E.bark,22);
 k.frustum(.5,.5,.03,.050,.046,.66,.028,.026,'#8c6b45',E.bark,22);
 for(const [a,z,len]of[[.2,.45,.23],[2.2,.54,.23],[4.15,.62,.20]]){
  const x=.5+Math.cos(a)*len,y=.5+Math.sin(a)*len;k.beam([.5,.5,z],[x,y,z+.31],.022,'#8c6b45',E.bark,12);
  k.beam([x,y,z+.23],[x+Math.cos(a+.5)*.05,y+Math.sin(a+.5)*.05,z+.47],.011,'#8c6b45',E.bark,10);
 }
 const crowns=[[.48,.47,1.18,.28,.25,.40,'#91ad65'],[.28,.51,1.04,.23,.24,.30,'#809f58'],[.69,.44,1.09,.23,.24,.32,'#759c53'],[.50,.69,1.04,.25,.22,.32,'#89a85e'],[.49,.29,1.08,.22,.23,.30,'#91ad65']];
 for(const [x,y,z,rx,ry,rz,c]of crowns)k.sphere(x,y,z,rx,ry,rz,c,E.foliage,22,12);
 for(let i=0;i<5;i++){const a=i/5*Math.PI*2;k.beam([.5,.5,.06],[.5+Math.cos(a)*.13,.5+Math.sin(a)*.13,.015],.012,'#8c6b45',E.bark,10);}
}

function variantTree(k,v){
 const bark=E.bark,leaf=27+v;
 k.frustum(.5,.5,.01,.065,.06,v===3?1.17:.80,.026,.025,'#8c6b45',bark,24);
 for(let i=0;i<5;i++){const a=i*Math.PI*2/5;k.beam([.5,.5,.06],[.5+Math.cos(a)*.14,.5+Math.sin(a)*.14,.015],.012,'#8c6b45',bark,10);}
 if(v===1){
  // Cedar: six soft conical whorls with individual drooping boughs.
  for(let i=0;i<6;i++){const z=.38+i*.20,r=.40-i*.054;k.frustum(.5,.5,z,r,r,.49,.012,.012,'#397548',leaf,32);for(let j=0;j<7;j++){const a=j*Math.PI*2/7+i*.3;k.sphere(.5+Math.cos(a)*r*.64,.5+Math.sin(a)*r*.64,z+.11,r*.36,r*.36,.15,'#4b8851',leaf,16,8);}}
 }else if(v===3){
  // Palm: curved ringed trunk, long arched fronds, paired narrow leaflets.
  for(let j=0;j<12;j++)k.cyl(.5,.5,.15+j*.077,.049-j*.0014,.048-j*.0014,.018,'#aa8965',bark,22);
  for(let i=0;i<9;i++){const a=i*Math.PI*2/9,ux=Math.cos(a),uy=Math.sin(a),nx=-uy,ny=ux,pts=[];for(let j=0;j<10;j++){const u=j/9;pts.push([.5+ux*u*.46,.5+uy*u*.46,1.11+.27*Math.sin(u*Math.PI)-.12*u]);}k.tube(pts,.009,'#658348',leaf,8);
   for(let j=1;j<9;j++){const u=j/9,q=pts[j],len=.13*Math.sin(u*Math.PI);for(const sign of [-1,1]){const tip=[q[0]+ux*.08+nx*len*sign,q[1]+uy*.08+ny*len*sign,q[2]-.06],base=[q[0]-ux*.025,q[1]-uy*.025,q[2]];k.face([base,[q[0]+nx*.018*sign,q[1]+ny*.018*sign,q[2]+.008],tip],'#52934d',leaf);}}
  }for(const a of [0,2,4])k.sphere(.5+Math.cos(a)*.055,.5+Math.sin(a)*.055,1.10,.035,.035,.045,'#92724b',bark,14,8);
 }else{
  const pink=v===2,c=pink?'#f5bacc':'#e8bd42';
  for(let i=0;i<7;i++){const a=i*Math.PI*2/7,r=.23,x=.5+Math.cos(a)*r,y=.5+Math.sin(a)*r,z=.72+(i%3)*.10;k.beam([.5,.5,.40],[x,y,z+.28],.022,'#907050',bark,14);k.sphere(x,y,z+.29,pink?.25:.21,pink?.25:.21,pink?.25:.36,c,leaf,24,14);}
  k.sphere(.5,.5,pink?1.15:1.30,.27,.25,pink?.30:.39,c,leaf,26,14);
  if(pink)for(let i=0;i<16;i++){const a=i*2.4,r=.11+(i%4)*.045;k.sphere(.5+Math.cos(a)*r,.5+Math.sin(a)*r,.025,.012,.009,.004,'#f3c5d2',null,8,4);}
 }
}
