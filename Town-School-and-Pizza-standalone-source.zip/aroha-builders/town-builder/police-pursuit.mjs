import {entranceAccess,entranceTarget,segmentHitsLot} from './core.mjs';
import {redSignalAhead} from './traffic-signals.mjs';
import {crossingClosed,trainBodies,carHitsTrain} from './train-traffic.mjs';
import {transportHeightAt} from './transport.mjs';
import {vehicleAhead} from './road-traffic.mjs';
import {patrolPose} from './patrol-route.mjs';

const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const heading=(a,b)=>Math.atan2(b.x-a.x,b.y-a.y);
const world=n=>({x:n.x+.5,y:n.y+.5});
const sameEdge=(a,b)=>a.a.id===b.a.id&&a.b.id===b.b.id||a.a.id===b.b.id&&a.b.id===b.a.id;
function project(graph,p){
 let best=null;
 for(const {a,b}of graph.links){const ax=a.x+.5,ay=a.y+.5,dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy,u=l?Math.max(0,Math.min(1,((p.x-ax)*dx+(p.y-ay)*dy)/l)):0,q={x:ax+u*dx,y:ay+u*dy};const d=distance(q,p);if(!best||d<best.d)best={...q,a,b,d};}
 return best;
}
class Queue{
 constructor(){this.items=[];}
 push(v){let i=this.items.length;this.items.push(v);while(i){const p=(i-1)>>1;if(this.items[p].cost<=v.cost)break;this.items[i]=this.items[p];i=p;}this.items[i]=v;}
 pop(){const first=this.items[0],last=this.items.pop();if(this.items.length){let i=0;while(i*2+1<this.items.length){let j=i*2+1;if(j+1<this.items.length&&this.items[j+1].cost<this.items[j].cost)j++;if(this.items[j].cost>=last.cost)break;this.items[i]=this.items[j];i=j;}this.items[i]=last;}return first;}
}
// Both ends attach to their actual road segment; no straight shortcuts across
// lots, rivers or disconnected roads. All pursuit coordinates are world-space.
export function policeRoadPath(graph,from,to){
 const start=project(graph,from),goal=project(graph,to);if(!start||!goal||start.d>.8||goal.d>.8)return null;
 if(sameEdge(start,goal)){const out=[];for(const p of [from,start,goal])if(!out.length||distance(out.at(-1),p)>1e-7)out.push({x:p.x,y:p.y});return out;}
 const costs=new Map(),prev=new Map(),queue=new Queue();let best=Infinity,end=null;
 for(const n of [start.a,start.b]){const cost=distance(start,world(n));if(cost<(costs.get(n.id)??Infinity)){costs.set(n.id,cost);prev.set(n.id,null);queue.push({id:n.id,cost});}}
 while(queue.items.length){const item=queue.pop();if(item.cost>(costs.get(item.id)??Infinity)+1e-8||item.cost>best)continue;const n=graph.nodes.get(item.id);
  if(n.id===goal.a.id||n.id===goal.b.id){const total=item.cost+distance(world(n),goal);if(total<best){best=total;end=n.id;}}
  for(const id of [...n.neighbors].sort()){const q=graph.nodes.get(id),cost=item.cost+distance(n,q);if(cost<(costs.get(id)??Infinity)-1e-8){costs.set(id,cost);prev.set(id,n.id);queue.push({id,cost});}}
 }
 let points;if(sameEdge(start,goal)&&distance(start,goal)<=best){points=[from,start,goal];}else{
  if(end===null)return null;const nodes=[];for(let id=end;id!==null;id=prev.get(id))nodes.push(world(graph.nodes.get(id)));points=[from,start,...nodes.reverse(),goal];
 }
 const clean=[];for(const p of points)if(!clean.length||distance(clean.at(-1),p)>1e-7)clean.push({x:p.x,y:p.y});return clean;
}
export function policeCanSee(town,police,player,range=9){
 if(!police||!player||Math.abs((police.height||0)-(player.height||0))>.55)return false;
 const d=distance(police,player);if(d>range)return false;
 if(d>2.2&&((player.x-police.x)*Math.sin(police.heading)+(player.y-police.y)*Math.cos(police.heading))/d<-.18)return false;
 const a={x:police.x-.5,y:police.y-.5},b={x:player.x-.5,y:player.y-.5};
 return !town.buildings.some(lot=>segmentHitsLot(a,b,lot,0));
}
export function drivingOffence(traffic,before,after,time,collision=false){
 if(redSignalAhead(traffic.junctions,before,after,time))return 'red-light';
 for(const c of traffic.analysis.crossings||[]){const p={x:c.x+.5,y:c.y+.5};if(Math.abs(after.height||0)<.55&&distance(before,p)>=1.28&&distance(after,p)<1.28&&crossingClosed(traffic,c,time))return 'railway-crossing';}
 return collision?'collision':null;
}
// Plan once on return. Offset the road-centre route into the same left lane
// as ordinary traffic so opposing vehicles do not form a permanent queue.
function returnPath(graph,from,home,route){
 const start=project(graph,from),points=start&&policeRoadPath(graph,start,world(home));if(!points)return [];
 const spawn=patrolPose(route,0),normal=(a,b)=>{const d=distance(a,b);return d>1e-8?{x:(b.y-a.y)/d,y:-(b.x-a.x)/d}:null;};
 const lane=points.map((p,i)=>{const a=i?normal(points[i-1],p):null,b=i+1<points.length?normal(p,points[i+1]):null,n=a&&b?{x:(a.x+b.x)/2,y:(a.y+b.y)/2}:a||b||{x:Math.cos(spawn.heading),y:-Math.sin(spawn.heading)};return {x:p.x+n.x*.21,y:p.y+n.y*.21};});
 const out=[{x:from.x,y:from.y}];for(const p of [...lane,{x:spawn.x,y:spawn.y}])if(distance(out.at(-1),p)>1e-7)out.push(p);return out.slice(1);
}
const fresh=()=>({returnLaneVersion:0,phase:null,routeIndex:-1,x:0,y:0,heading:0,speed:0,path:[],repath:0,lost:0,capture:0,cooldown:0,hold:0,arrests:0,restartBuilding:null,offence:null,travel:2});
export class PolicePursuit{
 constructor(town,graph,traffic){this.town=town;this.graph=graph;this.traffic=traffic;this.state=fresh();}
 snapshot(){return {...this.state,path:this.state.path.map(p=>({...p}))};}
 restore(raw){this.state={...fresh(),...raw,path:(raw?.path||[]).map(p=>({...p}))};return this;}
 get active(){return this.state.phase==='chasing';}
 get canArrive(){return !this.active&&this.state.hold<=0&&this.state.travel>=1.5;}
 get record(){const s=this.state;return s.phase?{index:s.routeIndex,pose:{x:s.x,y:s.y,heading:s.heading,speed:s.speed,height:transportHeightAt(this.traffic.analysis,s.x,s.y,'road'),kind:'police',halfLength:.45,halfWidth:.19,pursuit:true,chasing:this.active}}:null;}
 player(driver){return {x:driver.x+.5,y:driver.y+.5,heading:driver.heading,height:transportHeightAt(this.traffic.analysis,driver.x+.5,driver.y+.5,'road')};}
 begin(index,pose,player,offence){const route=policeRoadPath(this.graph,pose,player);if(!route)return false;Object.assign(this.state,{phase:'chasing',routeIndex:index,x:pose.x,y:pose.y,heading:pose.heading,speed:0,path:route.slice(1),repath:.45,lost:0,capture:0,offence,cooldown:1});return true;}
 returnHome(roadTraffic){
  const s=this.state,route=roadTraffic.routes[s.routeIndex],home=this.graph.nodes.get(route?.home),path=home&&returnPath(this.graph,s,home,route);
  s.capture=0;s.speed=0;s.phase='returning';s.path=path||[];s.repath=0;s.returnLaneVersion=1;
 }
 restart(driver,roadTraffic){
  const s=this.state,origin=this.player(driver),options=this.town.buildings.filter(b=>['prison','police-station'].includes(b.type)&&entranceAccess(this.town,b,{connected:true})).map(b=>({b,p:entranceTarget(this.town,b)})).filter(x=>x.p);
  options.sort((a,b)=>Number(a.b.type!=='prison')-Number(b.b.type!=='prison')||distance(a.p,origin)-distance(b.p,origin)||a.b.id-b.b.id);
  const chosen=options.find(x=>policeRoadPath(this.graph,origin,x.p));
  const target=chosen?.p||{x:this.town.start.x+.5,y:this.town.start.y+.5},road=project(this.graph,target);
  const candidates=road?[{x:road.x,y:road.y},world(road.a),world(road.b)]:[target],seen=new Set(road?[road.a.id,road.b.id]:[]);
  if(road)for(const n of [road.a,road.b])for(const id of n.neighbors)if(!seen.has(id)){seen.add(id);const p=world(this.graph.nodes.get(id));if(distance(p,target)<=2.5)candidates.push(p);}
  const bodies=[...trainBodies(this.traffic,driver.trainTime),...roadTraffic.poses().filter((_,i)=>i!==s.routeIndex)],safe=candidates.find(p=>!carHitsTrain(this.traffic,bodies,p.x-.5,p.y-.5,.08))||candidates[0];
  driver.x=safe.x-.5;driver.y=safe.y-.5;driver.speed=0;driver.turn=0;driver.reverse=false;
  const start={x:driver.x+.5,y:driver.y+.5},ends=road?[road.a,road.b].map(world).filter(p=>distance(start,p)>.1):[];
  if(ends.length)driver.heading=driver.targetHeading=heading(start,ends[0]);driver.trackRoad(driver.roadAt(driver.x,driver.y));
  s.arrests++;s.restartBuilding=chosen?.b.id??null;s.hold=2.5;s.travel=0;s.cooldown=5;this.returnHome(roadTraffic);
 }
 update(dt,driver,before,collision=false){
  const s=this.state,roadTraffic=driver.roadTraffic;if(s.phase==='returning'&&s.returnLaneVersion!==1)this.returnHome(roadTraffic);s.hold=Math.max(0,s.hold-dt);s.cooldown=Math.max(0,s.cooldown-dt);
  const player=this.player(driver);s.travel=Math.min(2,s.travel+distance(before,player));
  const offence=!s.phase&&s.cooldown<=0&&drivingOffence(this.traffic,before,player,driver.trainTime,collision);
  if(offence){const poses=roadTraffic.poses();for(let i=0;i<poses.length;i++)if(roadTraffic.routes[i].kind==='police'&&policeCanSee(this.town,poses[i],player)&&this.begin(i,poses[i],player,offence))break;}
  if(!s.phase){roadTraffic.police=null;return;}
  if(this.active){
   const visible=policeCanSee(this.town,this.record.pose,player,14);s.lost=visible?0:s.lost+dt;s.repath-=dt;
   if(s.lost>=8){this.returnHome(roadTraffic);}else if(s.repath<=0){const path=policeRoadPath(this.graph,s,player);if(!path)this.returnHome(roadTraffic);else{s.path=path.slice(1);s.repath=.45;}}
  }
  let remaining=dt*2.9;s.speed=0;
  const others=roadTraffic.poses().filter((_,i)=>i!==s.routeIndex);
  while(remaining>1e-8&&s.path.length){
   const goal=s.path[0],d=distance(s,goal);if(d<1e-7){s.path.shift();continue;}
   const step=Math.min(d,remaining),next={x:s.x+(goal.x-s.x)*step/d,y:s.y+(goal.y-s.y)*step/d},angle=heading(s,next),current={...this.record.pose,heading:angle};
   const closed=(this.traffic.analysis.crossings||[]).some(c=>{const p={x:c.x+.5,y:c.y+.5};return distance(s,p)>=1.18&&distance(next,p)<1.30&&distance(next,p)<distance(s,p)&&crossingClosed(this.traffic,c,driver.trainTime);});
   if(closed||vehicleAhead(current,others,.12))break;
   s.heading=angle;s.x=next.x;s.y=next.y;s.speed=2.9;remaining-=step;if(step>=d-1e-8)s.path.shift();
  }
  if(this.active){
   s.capture=distance(s,player)<.96&&policeCanSee(this.town,this.record.pose,player,1)?s.capture+dt:0;
   if(s.capture>=.30)this.restart(driver,roadTraffic);
  }else if(!s.path.length){
   if(roadTraffic.states[s.routeIndex])Object.assign(roadTraffic.states[s.routeIndex],{clock:0,waiting:false,train:false,light:false,jam:0,clearance:0});
   s.phase=null;s.routeIndex=-1;s.speed=0;s.cooldown=Math.max(s.cooldown,1);
  }
  roadTraffic.police=this.record;
 }
}
