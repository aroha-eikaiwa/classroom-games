import {POINT_TOKENS,pointEligible} from './core.mjs';
export const emptyPointGame=()=>({claimed:[],score:0,lastAward:0});
export function restorePointGame(raw){const claimed=[...new Set((Array.isArray(raw?.claimed)?raw.claimed:[]).filter(n=>Number.isInteger(n)&&n>=0&&n<POINT_TOKENS.length))];return {claimed,score:claimed.reduce((sum,n)=>sum+POINT_TOKENS[n],0),lastAward:[0,1,2,3,5].includes(raw?.lastAward)?raw.lastAward:0};}
// Called only after the chosen destination's arrival check. Passing other
// entrances and choosing a destination never award points on their own.
export function collectDestinationPoints(town,destination,game){
 game.lastAward=0;if(!pointEligible(town.buildings.find(b=>b.id===destination)))return 0;
 const point=(town.points||[]).find(p=>p.building===destination);if(!point||game.claimed.includes(point.token))return 0;
 game.claimed.push(point.token);game.lastAward=POINT_TOKENS[point.token];game.score+=game.lastAward;return game.lastAward;
}
