import * as T from './vendor/three.module.js';
import {pedestrianPlan,pedestrianPose} from './pedestrian-plan.mjs';
export class Pedestrians{
 constructor(scene){this.root=new T.Group();scene.add(this.root);this.plan=[];this.signature=null;this.geos=[new T.CapsuleGeometry(.095,.24,2,6),new T.SphereGeometry(.075,8,6)];this.mats=[new T.MeshLambertMaterial({color:0x5593ad}),new T.MeshLambertMaterial({color:0xd6aa85})];}
 clear(){this.root.clear();}
 sync(t,area,sig,plan){if(this.signature===sig)return;this.signature=sig;this.plan=plan??pedestrianPlan(t,area);this.clear();for(let i=0;i<this.plan.length;i++){const g=new T.Group();for(let j=0;j<2;j++){const m=new T.Mesh(this.geos[j],this.mats[j]);m.userData.sharedGeometry=true;m.userData.shared=true;m.position.y=j?.36:.18;g.add(m);}this.root.add(g);}}
 pose(p,t){return pedestrianPose(p,t);}
 tick(t){this.plan.forEach((p,i)=>{const q=this.pose(p,t),g=this.root.children[i];if(g&&q){g.position.set(q.x,.025+Math.sin(t*12+i)*.018,q.z);g.rotation.y=q.heading||0;}});}
}