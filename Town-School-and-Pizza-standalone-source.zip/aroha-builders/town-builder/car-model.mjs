import {DEFAULT_VEHICLE,renderVehicle} from './vehicle-choice.mjs';
import {loadPassengerModel,passengerRevision,createPassengerCar} from './passenger-models.mjs';
import * as THREE from './vendor/three.module.js';
import {loadImportedModel,createImportedModel,importedModelRevision} from './imported-models.mjs';
export const carModelRevision=(model='skyline')=>model.startsWith('car-')?passengerRevision():importedModelRevision(model);
const paints=new WeakMap();
function paintCar(group,color){group.traverse(mesh=>{if(!mesh.isMesh)return;const recolor=base=>{if(!['car-paint','red paint'].includes(base.name))return base;let variants=paints.get(base);if(!variants){variants=new Map();paints.set(base,variants);}if(!variants.has(color)){const clone=base.clone();clone.color.set(color);clone.userData.shared=true;variants.set(color,clone);}return variants.get(color);};mesh.material=Array.isArray(mesh.material)?mesh.material.map(recolor):recolor(mesh.material);});return group;}

// The car is a real mesh: every view shares the same body, windows and wheels.
// Generated art supplies surface materials only, never a picture of a whole car.
const PAINT=0,ROOF=1,GLASS=2,RUBBER=3,CHROME=4,PLASTIC=5,LAMP=6,TAIL=7,GRILLE=8;
const definitions=[
  ['#dc302b',.34,.12],['#fff0cb',.36,.04],['#315c78',.19,.2],
  ['#253138',.95,0],['#c6d5d7',.27,.55],['#29383e',.82,0],
  ['#fff0ba',.24,.05],['#dc302b',.3,.04],['#202b31',.7,.12],
];
const materials=definitions.map(([color,roughness,metalness],i)=>new THREE.MeshStandardMaterial({
  color,roughness,metalness,side:THREE.DoubleSide,
  ...(i===LAMP?{emissive:'#f7cd72',emissiveIntensity:.13}:{}),
  ...(i===TAIL?{emissive:'#9e110c',emissiveIntensity:.08}:{}),
}));
materials.forEach((material,i)=>{material.userData.shared=true;material.userData.carTile=i;material.name=['red paint','ivory roof','blue glass','tire rubber','silver metal','graphite plastic','headlamp lens','red tail lamp lens','grille'][i];});
let texturePromise,bodyTemplate,wheelTemplate;

export function loadCarTextures(model='skyline'){
  if(model.startsWith('car-'))return loadPassengerModel(model);
  return loadImportedModel(model).then(ok=>ok||loadFallbackCarTextures());
}

function loadFallbackCarTextures(){return Promise.resolve(false);}

function accumulator(){return Array.from({length:materials.length},()=>[]);}
function add(list,geometry,mat,position=[0,0,0],rotation=[0,0,0],scale=[1,1,1]){
  const mesh=new THREE.Mesh(geometry);mesh.position.fromArray(position);mesh.rotation.set(...rotation);mesh.scale.fromArray(scale);mesh.updateMatrix();
  const g=(geometry.index?geometry.toNonIndexed():geometry.clone());g.applyMatrix4(mesh.matrix);
  list[mat].push(g);geometry.dispose();
}
function merge(list){
  const group=new THREE.Group();
  for(let m=0;m<list.length;m++){
    const parts=list[m];if(!parts.length)continue;
    const count=parts.reduce((n,g)=>n+g.attributes.position.count,0),positions=new Float32Array(count*3),normals=new Float32Array(count*3),uvs=new Float32Array(count*2);
    let at=0;for(const g of parts){positions.set(g.attributes.position.array,at*3);normals.set(g.attributes.normal.array,at*3);if(g.attributes.uv)uvs.set(g.attributes.uv.array,at*2);at+=g.attributes.position.count;g.dispose();}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(positions,3));g.setAttribute('normal',new THREE.BufferAttribute(normals,3));g.setAttribute('uv',new THREE.BufferAttribute(uvs,2));g.computeBoundingSphere();
    const mesh=new THREE.Mesh(g,materials[m]);mesh.userData.sharedGeometry=true;mesh.userData.sharedMaterial=true;group.add(mesh);
  }
  return group;
}
function roundRect(w,h,r){
  const s=new THREE.Shape(),x=-w/2,y=-h/2;s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s;
}
function roundedBox(w,h,d,r=.03){const bevel=Math.min(r/3,d/4),g=new THREE.ExtrudeGeometry(roundRect(w-2*bevel,h-2*bevel,r),{depth:d-2*bevel,bevelEnabled:true,bevelSize:bevel,bevelThickness:bevel,bevelSegments:2,curveSegments:5,steps:1});g.translate(0,0,-d/2+bevel);const p=g.attributes.position,u=g.attributes.uv;for(let i=0;i<p.count;i++)u.setXY(i,p.getX(i)/w+.5,p.getY(i)/h+.5);return g;}
function roofDome(){
  const positions=[0,.021,0],uvs=[.5,.5],indices=[],segments=48,rings=6;
  for(let ring=1;ring<=rings;ring++)for(let i=0;i<segments;i++){
    const r=ring/rings,a=i/segments*Math.PI*2,c=Math.cos(a),s=Math.sin(a),x=.2855*Math.sign(c)*Math.sqrt(Math.abs(c))*r,z=.2575*Math.sign(s)*Math.sqrt(Math.abs(s))*r;
    positions.push(x,.003+.018*(1-r*r),z);uvs.push(x/.571+.5,z/.515+.5);
  }
  for(let i=0;i<segments;i++)indices.push(0,1+(i+1)%segments,1+i);
  for(let ring=1;ring<rings;ring++)for(let i=0;i<segments;i++){
    const a=1+(ring-1)*segments+i,b=1+(ring-1)*segments+(i+1)%segments,c=1+ring*segments+i,d=1+ring*segments+(i+1)%segments;indices.push(a,b,c,b,d,c);
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));g.setIndex(indices);g.computeVertexNormals();return g;
}
function quad(list,points,mat){
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(points.flat(),3));g.setAttribute('uv',new THREE.Float32BufferAttribute([0,0,1,0,1,1,0,1],2));g.setIndex([0,1,2,0,2,3]);g.computeVertexNormals();add(list,g,mat);
}
function pane(list,points,normal){
  const center=points.reduce((p,q)=>p.map((v,i)=>v+q[i]/4),[0,0,0]);
  quad(list,points.map(p=>p.map((v,i)=>v+normal[i]*.003)),PLASTIC);
  quad(list,points.map(p=>p.map((v,i)=>center[i]+(v-center[i])*.87+normal[i]*.005)),GLASS);
}
function tube(list,points,radius,mat,segments=16){const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));add(list,new THREE.TubeGeometry(curve,segments,radius,4,false),mat);}
function sph(list,x,y,z,sx,sy,sz,mat,segments=16){add(list,new THREE.SphereGeometry(1,segments,segments>12?8:6),mat,[x,y,z],[0,0,0],[sx,sy,sz]);}
function body(){
  const list=accumulator(),shape=new THREE.Shape();
  const p=(z,y,start=false)=>start?shape.moveTo(-z,y):shape.lineTo(-z,y);
  p(-.56,.19,true);p(-.525,.18);
  // Open wheel arches are cut into the body, rather than painted over a box.
  for(const center of [-.345,.345]){
    p(center-.172,.18);
    for(let i=0;i<=18;i++){const a=Math.PI-i/18*Math.PI;p(center+.172*Math.cos(a),.18+.172*Math.sin(a));}
  }
  p(.55,.18);p(.572,.24);p(.55,.39);p(.49,.435);p(.35,.445);p(-.265,.445);p(-.47,.421);p(-.555,.37);p(-.58,.285);shape.closePath();
  const shell=new THREE.ExtrudeGeometry(shape,{depth:.59,bevelEnabled:true,bevelSize:.027,bevelThickness:.027,bevelSegments:3,curveSegments:8,steps:1});shell.rotateY(Math.PI/2);shell.translate(-.295,0,0);add(list,shell,PAINT);
  add(list,roundedBox(.57,.09,.73,.035),PLASTIC,[0,.19,0]);
  // The sloping cabin is painted metal between the actual glass panels.
  const A=[-.316,.438,-.28],B=[.316,.438,-.28],C=[.271,.645,-.128],D=[-.271,.645,-.128];
  const E=[-.316,.438,.505],F=[.316,.438,.505],G=[.271,.645,.36],H=[-.271,.645,.36];
  quad(list,[A,B,C,D],PAINT);quad(list,[F,E,H,G],PAINT);quad(list,[B,F,G,C],PAINT);quad(list,[E,A,D,H],PAINT);quad(list,[D,C,G,H],ROOF);
  pane(list,[[-.283,.454,-.276],[.283,.454,-.276],[.251,.625,-.142],[-.251,.625,-.142]],[0,.46,-.89]);
  pane(list,[[.284,.46,.496],[-.284,.46,.496],[-.251,.622,.371],[.251,.622,.371]],[0,.45,.89]);
  for(const sign of [-1,1]){
    const x=(y)=>sign*(.316-(y-.438)/(.645-.438)*.045+.003);
    const side=(coords)=>coords.map(([z,y])=>[x(y),y,z]);
    pane(list,side([[-.243,.46],[.077,.46],[.077,.626],[-.115,.626]]),[sign,0,0]);
    pane(list,side([[.105,.46],[.465,.46],[.345,.626],[.105,.626]]),[sign,0,0]);
    // Door shut line, silver handle, rounded mirror with its black stalk.
    tube(list,[[sign*.326,.439,-.228],[sign*.326,.275,-.198],[sign*.326,.223,-.12],[sign*.326,.223,.13],[sign*.326,.28,.185],[sign*.326,.439,.185]],.0038,PLASTIC,23);
    add(list,roundedBox(.012,.017,.071,.008),CHROME,[sign*.331,.407,.121]);
    tube(list,[[sign*.299,.482,-.20],[sign*.355,.476,-.215],[sign*.36,.51,-.21]],.012,PLASTIC,6);
    sph(list,sign*.36,.524,-.205,.05,.037,.05,PAINT,12);
    sph(list,sign*.36,.523,-.163,.04,.027,.006,CHROME,12);
    for(const z of [-.345,.345]){
      const points=[];for(let i=0;i<=18;i++){const a=i/18*Math.PI;points.push([sign*.327,.18+.176*Math.sin(a),z+.176*Math.cos(a)]);}
      tube(list,points,.014,PLASTIC,20);
    }
    tube(list,[[sign*.324,.2,-.17],[sign*.324,.2,.17]],.014,PLASTIC,2);
  }
  // Rounded cream roof follows the cabin footprint and has a narrow black seal.
  add(list,roundedBox(.565,.51,.025,.075),PLASTIC,[0,.646,.114],[-Math.PI/2,0,0]);
  add(list,roundedBox(.571,.515,.022,.085),ROOF,[0,.662,.114],[-Math.PI/2,0,0]);
  add(list,roofDome(),ROOF,[0,.670,.114]);
  // Hood and hatch seams give the body separate panels without baked shadows.
  tube(list,[[-.235,.435,-.438],[-.255,.453,-.32],[-.24,.454,-.267],[.24,.454,-.267],[.255,.453,-.32],[.235,.435,-.438]],.0032,PAINT,24);
  tube(list,[[-.22,.435,.50],[-.222,.29,.574],[.222,.29,.574],[.22,.435,.50]],.003,PLASTIC,18);
  add(list,roundedBox(.6,.081,.08,.032),PLASTIC,[0,.205,-.556]);
  add(list,roundedBox(.6,.079,.076,.032),PLASTIC,[0,.205,.548]);
  // Oval grille, separate chrome surround, circular headlamps and fog lamps.
  add(list,roundedBox(.339,.105,.018,.048),CHROME,[0,.305,-.581]);
  add(list,roundedBox(.319,.085,.022,.039),GRILLE,[0,.305,-.589]);
  add(list,roundedBox(.27,.035,.013,.014),GRILLE,[0,.203,-.6]);
  for(const x of [-.226,.226]){
    add(list,new THREE.TorusGeometry(.06,.008,6,24),CHROME,[x,.375,-.612],[.13,0,0]);
    sph(list,x,.375,-.615,.054,.057,.02,LAMP,20);
    add(list,new THREE.TorusGeometry(.024,.004,5,16),CHROME,[x,.263,-.617]);
    sph(list,x,.263,-.619,.021,.021,.01,LAMP,12);
    sph(list,x,.364,.585,.054,.083,.017,PLASTIC,16);
    sph(list,x,.364,.597,.045,.073,.014,TAIL,16);
    sph(list,x,.209,.59,.043,.015,.009,TAIL,12);
  }
  add(list,roundedBox(.118,.037,.014,.01),PLASTIC,[0,.245,.596]);
  add(list,roundedBox(.079,.021,.015,.01),PAINT,[0,.389,.564]);
  // Proper wipers follow the sloped windshield; rear glass has a single wiper.
  for(const x of [-.125,.125])tube(list,[[x-.057,.467,-.279],[x,.488,-.27],[x+.071,.49,-.27]],.005,PLASTIC,6);
  tube(list,[[-.08,.474,.493],[.015,.482,.486],[.10,.48,.487]],.005,PLASTIC,7);
  return merge(list);
}
function wheel(){
  const list=accumulator();
  add(list,new THREE.CylinderGeometry(.148,.148,.09,24,1),RUBBER,[0,0,0],[0,0,Math.PI/2]);
  for(const sign of [-1,1]){
    add(list,new THREE.TorusGeometry(.113,.032,7,24),RUBBER,[sign*.035,0,0],[0,Math.PI/2,0]);
    add(list,new THREE.CylinderGeometry(.091,.091,.006,24),CHROME,[sign*.058,0,0],[0,0,Math.PI/2]);
    for(let k=0;k<7;k++){const a=k*Math.PI*2/7;add(list,new THREE.CircleGeometry(.014,10),PLASTIC,[sign*.063,Math.sin(a)*.066,Math.cos(a)*.066],[0,sign*Math.PI/2,0],[1,1.1,1]);}
    sph(list,sign*.064,0,0,.008,.043,.043,CHROME,12);
  }
  return merge(list);
}

export function createCar(value=DEFAULT_VEHICLE){
  const choice=renderVehicle(value);
  const imported=choice.model.startsWith('car-')?createPassengerCar(choice.model,choice.color):createImportedModel(choice.model);if(imported){imported.userData.applyArt=()=>{};imported.traverse(mesh=>{if(mesh.isMesh)mesh.castShadow=false;});return paintCar(imported,choice.color);}
  bodyTemplate??=body();wheelTemplate??=wheel();
  const group=new THREE.Group();group.name='red-compact-car';group.scale.setScalar(.55);group.add(bodyTemplate.clone());
  const wheels=[];
  for(const x of [-.30,.30])for(const z of [-.345,.345]){
    const pivot=new THREE.Group(),spin=wheelTemplate.clone();pivot.position.set(x,.15,z);pivot.add(spin);group.add(pivot);wheels.push({pivot,spin,front:z<0});
  }
  group.userData.wheels=wheels;group.userData.front='-Z';
  group.userData.applyArt=()=>{}; // Compatibility with the renderer while assets load.
  group.userData.update=(dt,speed=0,turn=0)=>{
    const delta=Math.min(.08,Math.max(0,dt||0)),steer=THREE.MathUtils.clamp(turn,-1,1)*.24;
    for(const {pivot,spin,front}of wheels){spin.rotation.x-=speed*delta/.148;if(front)pivot.rotation.y=THREE.MathUtils.lerp(pivot.rotation.y,steer,Math.min(1,delta*12));}
  };
  return paintCar(group,choice.color);
}
