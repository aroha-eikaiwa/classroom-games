import {vehicleRoadPose} from './vehicle-road-pose.mjs';
import * as THREE from './vendor/three.module.js';
import {packedGeometry} from './imported-models.mjs';
import {PASSENGER_MODELS} from './civilian-route.mjs';
const models=new Map(),pending=new Map();let version=0,materialsPromise;
const shared=material=>{material.userData.shared=true;return material;};
export const passengerRevision=()=>version;
export const passengerModelRevision=name=>models.has(name)?1:0;
async function loadMaterials(){return Promise.resolve(false);}
export function loadPassengerModel(name){return Promise.resolve(false);}
const fallback=[
 {geometry:new THREE.BoxGeometry(.36,.17,.8).translate(0,.15,0),material:shared(new THREE.MeshStandardMaterial({color:'#ffffff',roughness:.5})),paint:true},
 {geometry:new THREE.BoxGeometry(.30,.12,.36).translate(0,.285,.04),material:shared(new THREE.MeshStandardMaterial({color:'#273e4b',roughness:.4}))},
 ...[-.18,.18].flatMap(x=>[-.27,.27].map(z=>({geometry:new THREE.CylinderGeometry(.07,.07,.045,8).rotateZ(Math.PI/2).translate(x,.075,z),material:null})))
];
const rubber=shared(new THREE.MeshStandardMaterial({color:'#20282c',roughness:.95}));for(const part of fallback)part.material??=rubber;
// Instance colours affect only body paint. Glass, lamps and tyres keep their
// own colours; all civilian cars share GPU buffers and two texture atlases.
export function createPassengerFleet(routes){
 const group=new THREE.Group(),batches=[],matrix=new THREE.Matrix4(),position=new THREE.Vector3(),rotation=new THREE.Quaternion(),scale=new THREE.Vector3(1,1,1),euler=new THREE.Euler(0,0,0,'YXZ');
 for(const name of new Set(routes.map(r=>r.model))){
  const members=routes.filter(r=>r.model===name),parts=models.get(name)||fallback;
  for(const part of parts){
   const mesh=new THREE.InstancedMesh(part.geometry,part.material,members.length);mesh.userData.sharedGeometry=true;mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);mesh.castShadow=false;mesh.receiveShadow=true;mesh.frustumCulled=false;
   if(part.paint)members.forEach((r,i)=>mesh.setColorAt(i,new THREE.Color(r.paint)));group.add(mesh);batches.push({mesh,members});
  }
 }
 group.userData.update=(poses,analysis)=>{const roads=new Map(routes.map(route=>{const p=poses.get(route);return [route,p?vehicleRoadPose(analysis,p.x,p.y,p.heading):null];}));for(const {mesh,members}of batches){members.forEach((route,i)=>{const p=poses.get(route);if(!p)return;const road=roads.get(route);position.set(p.x,(analysis?road.height:p.height)+.03,p.y);rotation.setFromEuler(euler.set(road.pitch,p.heading+Math.PI,0,'YXZ'));matrix.compose(position,rotation,scale);mesh.setMatrixAt(i,matrix);});mesh.instanceMatrix.needsUpdate=true;}};
 group.userData.vehicleCount=routes.length;group.userData.batchCount=batches.length;return group;
}

const playerPaints=new WeakMap();
export function createPassengerCar(name,color){
 const parts=models.get(name);if(!parts)return null;const group=new THREE.Group();group.userData.importedModel=name;
 for(const part of parts){let material=part.material;if(part.paint){let variants=playerPaints.get(material);if(!variants){variants=new Map();playerPaints.set(material,variants);}if(!variants.has(color)){const clone=material.clone();clone.color.set(color);clone.userData.shared=true;variants.set(color,clone);}material=variants.get(color);}const mesh=new THREE.Mesh(part.geometry,material);mesh.userData.sharedGeometry=true;mesh.castShadow=false;group.add(mesh);}return group;
}
