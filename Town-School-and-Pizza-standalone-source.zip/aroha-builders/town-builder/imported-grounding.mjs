import {M} from './model-kit.mjs';

// Source kit faces use X/Y for the lot and Z for height. The old lawn slabs
// concealed the open bottoms of low plinths. Extend only existing straight
// support skirts; never lower a model or add a rectangular lawn/foundation.
const EPS=1e-8;
const supportMaterials=new Set([M.stucco,M.brick,M.stone,M.siding,M.wood,M.paving,M.asphalt,M.turf,M.metal,M.marble,M.redwood]);
const sameXY=(a,b)=>Math.abs(a[0]-b[0])<=EPS&&Math.abs(a[1]-b[1])<=EPS;

export function groundStaticBaseFaces(faces,{maxBase=.055,ground=0}={}){
 return faces.map(face=>{
  if(face.animation||!supportMaterials.has(face.material)||face.points.length<4)return face;
  const points=face.points,min=Math.min(...points.map(p=>p[2])),max=Math.max(...points.map(p=>p[2]));
  if(min<=ground+EPS||min>maxBase+EPS||max-min<=EPS)return face;
  // Only two-level vertical side quads qualify. This excludes caps, sloping
  // roofs/ramps, curved ornaments, arch silhouettes and upper-storey details.
  if(points.some(p=>Math.abs(p[2]-min)>EPS&&Math.abs(p[2]-max)>EPS))return face;
  const bottom=points.filter(p=>Math.abs(p[2]-min)<=EPS),top=points.filter(p=>Math.abs(p[2]-max)<=EPS);
  if(bottom.length!==2||top.length!==2||sameXY(bottom[0],bottom[1])||!bottom.every(p=>top.some(q=>sameXY(p,q))))return face;
  return {...face,points:points.map(p=>Math.abs(p[2]-min)<=EPS?[p[0],p[1],ground]:p)};
 });
}
