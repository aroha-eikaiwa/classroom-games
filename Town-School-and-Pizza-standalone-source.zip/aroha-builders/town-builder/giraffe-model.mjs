import * as THREE from './vendor/three.module.js';
import {cherryGeometry} from './cherry-tree.mjs';
let parts=null,pending=null,revision=0,duration=4;
export const giraffeRevision=()=>revision;
export async function loadGiraffe(){return Promise.resolve(false);}
export function createGiraffe(scale=1,variant='normal'){
 if(!parts)return null;const group=new THREE.Group();group.scale.setScalar(scale);group.position.y=.09;group.rotation.y=-Math.PI/2;group.userData.importedAnimal=true;
 for(const p of parts){let mat=p.material;if(variant.startsWith('ghost')){mat=mat.clone();mat.userData.shared=false;mat.transparent=true;mat.opacity=.66;if(variant==='ghost-invalid')mat.color.set('#ef7575');}const mesh=new THREE.Mesh(p.geometry,mat);mesh.userData.sharedGeometry=true;mesh.userData.shadowCaster=false;group.add(mesh);}
 group.userData.animate=t=>{for(const mesh of group.children){const weights=mesh.morphTargetInfluences,count=weights.length,frame=((t%duration)+duration)%duration/duration*count,i=Math.floor(frame);weights.fill(0);weights[i]=1-(frame-i);weights[(i+1)%count]=frame-i;}};return group;
}
