import {validateTransport,bridgeDeckHeightAt} from './transport.mjs';
import {WIDTH,HEIGHT,xy,key} from './core.mjs';
import {signalAspect} from './traffic-signals.mjs';
import {roadGraph,trafficLightPlacements} from './network.mjs';
import {artwork} from './art.mjs';
import {paintRoadMap} from './terrain-map.mjs';
export function worldContext(r,fn,z=0){const c=r.ctx,p=r.project(0,0,z),ex=r.project(1,0,z),ey=r.project(0,1,z);c.save();c.transform(ex[0]-p[0],ex[1]-p[1],ey[0]-p[0],ey[1]-p[1],p[0],p[1]);fn(c);c.restore();}
function waterPath(c,rivers){c.beginPath();for(const k of rivers){const{x,y}=xy(k);c.rect(x,y,1,1);}}
export function drawGrass(r){if(!artwork.grass)return;worldContext(r,c=>{const tile=8;for(let y=0;y<HEIGHT;y+=tile)for(let x=0;x<WIDTH;x+=tile)c.drawImage(artwork.grass,0,0,artwork.grass.width,artwork.grass.height,x,y,Math.min(tile,WIDTH-x),Math.min(tile,HEIGHT-y));c.fillStyle='rgba(234,241,193,.10)';c.fillRect(0,0,WIDTH,HEIGHT);});}
export function drawWater(r,t,time){const rivers=t.rivers||[];if(!rivers.length)return;const set=new Set(rivers);worldContext(r,c=>{
 waterPath(c,rivers);c.fillStyle='#3685ad';c.fill();c.strokeStyle='#799d63';c.lineWidth=.12;c.stroke();c.save();waterPath(c,rivers);c.clip();const grad=c.createLinearGradient(0,0,WIDTH,HEIGHT);grad.addColorStop(0,'#42b4dc');grad.addColorStop(.5,'#258ac7');grad.addColorStop(1,'#61c5df');c.fillStyle=grad;c.fillRect(0,0,WIDTH,HEIGHT);
 // Flowing ribbons move independently of camera position, with no repeating hard tile edge.
 c.lineCap='round';for(const k of rivers){const{x,y}=xy(k);for(let n=0;n<2;n++){const phase=time*.42+(x*.271+y*.173+n*.44),offset=phase-Math.floor(phase),yy=y+.12+offset*.8;c.beginPath();c.moveTo(x+.08,yy);c.bezierCurveTo(x+.28,yy-.08,x+.44,yy+.09,x+.68,yy-.025);c.strokeStyle=n?'rgba(209,255,245,.36)':'rgba(180,244,247,.24)';c.lineWidth=.035;c.stroke();}c.fillStyle='rgba(191,255,247,.12)';c.beginPath();c.ellipse(x+.36+Math.sin(time*.6+y)*.08,y+.46,.22,.09,0,0,Math.PI*2);c.fill();}
 c.restore();c.lineWidth=.07;c.strokeStyle='#d2e5b5';c.beginPath();for(const k of rivers){const{x,y}=xy(k);if(!set.has(key(x,y-1))){c.moveTo(x,y+.04);c.lineTo(x+1,y+.04);}if(!set.has(key(x,y+1))){c.moveTo(x,y+.96);c.lineTo(x+1,y+.96);}if(x===0||!set.has(key(x-1,y))){c.moveTo(x+.04,y);c.lineTo(x+.04,y+1);}if(x===WIDTH-1||!set.has(key(x+1,y))){c.moveTo(x+.96,y);c.lineTo(x+.96,y+1);}}c.stroke();
 },.005);}
export function drawRoads(r,t,preview=null){const g=roadGraph(t);worldContext(r,c=>{paintRoadMap(c,t,1,null,false);
 if(preview?.line?.length){c.beginPath();preview.line.forEach((p,i)=>i?c.lineTo(p.x+.5,p.y+.5):c.moveTo(p.x+.5,p.y+.5));if(preview.line.length===1){const p=preview.line[0];c.lineTo(p.x+.501,p.y+.5);}c.strokeStyle=preview.valid?'rgba(255,220,120,.9)':'rgba(224,103,83,.9)';c.lineWidth=.86;c.stroke();c.strokeStyle=preview.valid?'#fff5d4':'#ffc8b6';c.lineWidth=.06;c.setLineDash([.18,.13]);c.stroke();c.setLineDash([]);}
 },.025);return g;}
const ribbon=(a,b,width,z,color)=>{const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy)||1,nx=-dy/len*width/2,ny=dx/len*width/2;return {points:[[a.x+nx+.5,a.y+ny+.5,z],[b.x+nx+.5,b.y+ny+.5,z],[b.x-nx+.5,b.y-ny+.5,z],[a.x-nx+.5,a.y-ny+.5,z]],color};};
export function bridgeObjects(t){
 const out=[];
 for(const bridge of validateTransport(t).bridges){
  const dx=(bridge.b.x-bridge.a.x)/bridge.length,dy=(bridge.b.y-bridge.a.y)/bridge.length,nx=-dy*bridge.width/2,ny=dx*bridge.width/2;
  const stops=[0,bridge.rampLength,bridge.length-bridge.rampLength,bridge.length];
  for(let i=1;i<stops.length;i++){
   const u=stops[i-1],v=stops[i];if(v-u<1e-7)continue;const a={x:bridge.a.x+.5+dx*u,y:bridge.a.y+.5+dy*u},b={x:bridge.a.x+.5+dx*v,y:bridge.a.y+.5+dy*v},za=bridgeDeckHeightAt(bridge,u),zb=bridgeDeckHeightAt(bridge,v);
   const face=(width,z0,z1,color)=>({points:[[a.x+nx*width,a.y+ny*width,z0],[b.x+nx*width,b.y+ny*width,z1],[b.x-nx*width,b.y-ny*width,z1],[a.x-nx*width,a.y-ny*width,z0]],color});
   const faces=[face(1,za,zb,'#b9a58a'),face(.79,za+.006,zb+.006,bridge.kind==='rail'?'#897f6c':'#727a7a')];
   for(const sign of [-1,1]){
    const x0=a.x+nx*sign,y0=a.y+ny*sign,x1=b.x+nx*sign,y1=b.y+ny*sign;
    faces.push({points:[[x0,y0,za-.065],[x1,y1,zb-.065],[x1,y1,zb],[x0,y0,za]],color:'#aa9b82'});
    const rail=bridge.barriers.find(r=>r.side===sign),lo=Math.max(u,rail?.start??Infinity),hi=Math.min(v,rail?.end??-Infinity);
    if(hi>lo){const z0=bridgeDeckHeightAt(bridge,lo),z1=bridgeDeckHeightAt(bridge,hi),point=(along,z)=>[bridge.a.x+.5+dx*along-dy*rail.offset*sign,bridge.a.y+.5+dy*along+dx*rail.offset*sign,z];faces.push({points:[point(lo,z0+.23),point(hi,z1+.23),point(hi,z1+.29),point(lo,z0+.29)],color:'#e0d5b8'});}
   }
   out.push({x:(a.x+b.x)/2,y:(a.y+b.y)/2,bridge,faces});
  }
 }
 return out;
}
export function trafficLightObjects(t,time,cube){const out=[];for(const {x,y,phase:side,phaseCount} of trafficLightPlacements(t)){const faces=[...cube(x-.035,y-.035,.02,.07,.07,.67,'#465c51'),...cube(x-.10,y-.08,.62,.20,.16,.40,'#344b42')];for(let j=0;j<3;j++){const active=j===(signalAspect(side,time,phaseCount)==='green'?2:0),color=active?(j===0?'#fb6052':'#92e990'):'#536451';faces.push(...cube(x-.07,y+.085,.91-j*.105,.14,.025,.073,color));}out.push({x,y,faces});}
 return out;}
