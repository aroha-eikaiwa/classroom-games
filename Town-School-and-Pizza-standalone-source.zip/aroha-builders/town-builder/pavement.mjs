import {WIDTH,HEIGHT,key,inside,cells,roadLine} from './core.mjs';
import {transportGroundCells} from './ground-clearance.mjs';
function occupied(t){const out=new Set([...transportGroundCells(t),...(t.rivers||[])]);for(const b of t.buildings||[])for(const k of cells(b))out.add(k);return out;}
// Fixed one-cell brush. Interpolation fills skipped pointer samples, never widens it.
export function paintPavement(t,x,y){
 if(!inside(x,y))return false;const k=key(x,y);if(occupied(t).has(k)||(t.pavement||[]).includes(k))return false;
 t.pavement=[...(t.pavement||[]),k];t.flowers=(t.flowers||[]).filter(v=>v!==k);return true;
}
export function paintPavementStroke(t,from,to){
 if(![from?.x,from?.y,to?.x,to?.y].every(Number.isFinite))return false;
 const clamp=p=>({x:Math.max(0,Math.min(WIDTH-1,Math.floor(p.x))),y:Math.max(0,Math.min(HEIGHT-1,Math.floor(p.y)))}),blocked=occupied(t),values=new Set(t.pavement||[]);let changed=false;
 let previous=null;
 const add=p=>{const k=key(p.x,p.y);if(!blocked.has(k)&&!values.has(k)){values.add(k);changed=true;}};
 for(const p of roadLine(clamp(from),clamp(to))){
  if(previous&&p.x!==previous.x&&p.y!==previous.y){const connectors=[{x:p.x,y:previous.y},{x:previous.x,y:p.y}],bridge=connectors.find(q=>!blocked.has(key(q.x,q.y)));if(bridge)add(bridge);}
  add(p);previous=p;
 }
 if(changed){t.pavement=[...values];t.flowers=(t.flowers||[]).filter(k=>!values.has(k));}return changed;
}
export function erasePavement(t,x,y){const k=key(x,y),old=t.pavement||[];if(!old.includes(k))return false;t.pavement=old.filter(v=>v!==k);return true;}
export function prunePavement(t){const blocked=occupied(t),old=t.pavement||[],next=[...new Set(old)].filter(k=>Number.isInteger(k)&&k>=0&&k<WIDTH*HEIGHT&&!blocked.has(k));if(next.length===old.length)return false;t.pavement=next;return true;}
