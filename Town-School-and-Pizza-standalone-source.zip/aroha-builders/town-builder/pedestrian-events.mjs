// Small, purely cosmetic pedestrian event. No towns, traffic, or saves are changed.
// A 4x4 uninterrupted paved square is the minimum footprint for a dance circle.
export const BREAKDANCE_MIN_PAVEMENT = 4;
export const BREAKDANCE_CYCLE_SECONDS = 185;
export const BREAKDANCE_DURATION_SECONDS = 34;
export const BREAKDANCE_MIN_RESIDENTS = 4;

const positiveMod = (value, period) => ((value % period) + period) % period;
const hash = value => {
  let h = (value | 0) ^ 0x9e3779b9;
  h = Math.imul(h ^ (h >>> 16), 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  return (h ^ (h >>> 16)) >>> 0;
};
export const ease = value => {
  const t = Math.min(1, Math.max(0, value));
  return t * t * (3 - 2 * t);
};

/**
 * paths are already checked against land, buildings, rivers, railways, roads,
 * and unlocked map bounds. Require every tile of a candidate plaza to be paved.
 * Prefer 5x5 to 4x4; use stable hashing to avoid every town using the same spot.
 */
export function findBreakdancePlaza(paths, seed = 0) {
  if (!paths || paths.length < BREAKDANCE_MIN_PAVEMENT ** 2) return null;
  const tiles = new Set(paths.map(p => `${Math.floor(p.x)},${Math.floor(p.z)}`));
  let best = null;
  for (const size of [5, BREAKDANCE_MIN_PAVEMENT]) {
    for (const p of paths) {
      const x = Math.floor(p.x), z = Math.floor(p.z);
      let open = true;
      for (let dz = 0; dz < size && open; dz++)
        for (let dx = 0; dx < size; dx++)
          if (!tiles.has(`${x + dx},${z + dz}`)) { open = false; break; }
      if (!open) continue;
      const score = hash(seed ^ Math.imul(x + 1, 92821) ^ Math.imul(z + 1, 68917));
      if (!best || score > best.score) best = { x, z, size, cx: x + size / 2, cz: z + size / 2, seed: score, score };
    }
    if (best) break;
  }
  if (!best) return null;
  const { score, ...plaza } = best;
  return plaza;
}

/** No real-time randomness, timers, network traffic, or changes to saved towns. */
export function breakdanceState(seconds, seed) {
  const t = Number.isFinite(seconds) ? seconds : 0;
  const phase = positiveMod(t + hash(seed) % BREAKDANCE_CYCLE_SECONDS, BREAKDANCE_CYCLE_SECONDS);
  if (phase >= BREAKDANCE_DURATION_SECONDS) return { active: false, stage: 'idle', phase, gathering: 0 };
  const gathering = ease(phase / 4) * (1 - ease((phase - 30) / 4));
  return {
    active: true,
    stage: phase < 4 ? 'gather' : phase < 27 ? 'dance' : phase < 30 ? 'cheer' : 'depart',
    phase,
    gathering,
    // Dance stage changes visibly every few seconds, not every single frame.
    move: phase < 4 ? 'wait' : phase < 27 ? (phase - 4) % 13 < 4 ? 'toprock' : (phase - 4) % 13 < 7 ? 'sixstep' : (phase - 4) % 13 < 11 ? 'backspin' : 'freeze' : 'celebrate'
  };
}

/** Return the same number of residents as before, with no extra dancers. */
export function breakdanceCast(plaza, count, seed) {
  if (!plaza || count < BREAKDANCE_MIN_RESIDENTS) return [];
  const n = Math.min(6, count);
  const r = plaza.size >= 5 ? 1.72 : 1.29;
  const outer = plaza.size >= 5 ? 2.03 : 1.60;
  const members = [{ role: 'dancer', x: plaza.cx + .41, z: plaza.cz + .24, tx: plaza.cx, tz: plaza.cz, heading: .4, index: 0 }];
  for (let i = 1; i < n; i++) {
    const a = 2 * Math.PI * (i - 1) / (n - 1) + .28 + (seed % 5) * .04;
    const dx = Math.sin(a), dz = Math.cos(a);
    members.push({ role: 'spectator', index: i, x: plaza.cx + dx * outer, z: plaza.cz + dz * outer, tx: plaza.cx + dx * r, tz: plaza.cz + dz * r, heading: Math.atan2(-dx, -dz) });
  }
  return members;
}

/** Smoothly transition between four recognisable breakdance moves. */
export function breakdancePose(time, phase) {
  const neutral = {tiltX: 0, tiltZ: 0, drop: 0, yaw: 0, leftArm: 0, rightArm: 0, leftLeg: 0, rightLeg: 0};
  if (phase < 4 || phase >= 27) return neutral;
  const beat = time * 7;
  const moves = [
    () => ({
      tiltX: 0, tiltZ: Math.sin(beat) * .13, drop: -Math.abs(Math.sin(beat * .5)) * .12,
      yaw: Math.sin(time * 2) * .24,
      leftArm: Math.sin(beat) * 1.05 - .3, rightArm: -Math.sin(beat) * 1.05 - .3,
      leftLeg: Math.sin(beat) * .55, rightLeg: -Math.sin(beat) * .55
    }),
    () => ({
      tiltX: .53, tiltZ: Math.sin(time * 4) * .25, drop: -.46, yaw: time * 2.1,
      leftArm: -.92, rightArm: -.75,
      leftLeg: Math.sin(time * 7) * 1.12, rightLeg: -Math.sin(time * 7 + .8) * 1.14
    }),
    () => ({
      tiltX: .18, tiltZ: 1.43, drop: -.45, yaw: time * 9,
      leftArm: -1.05, rightArm: 1.05,
      leftLeg: -1.06 + Math.sin(time * 10) * .20,
      rightLeg: 1.06 - Math.sin(time * 10) * .20
    }),
    () => ({
      tiltX: .15, tiltZ: 2.22, drop: -.12, yaw: 0,
      leftArm: -1.1, rightArm: 1.38, leftLeg: -.75, rightLeg: .95
    })
  ];
  const segmentEnds = [4, 7, 11, 13], u = positiveMod(phase - 4, 13);
  const current = segmentEnds.findIndex(end => u < end);
  let pose = moves[current]();
  const remaining = segmentEnds[current] - u;
  const mix = (a, b, w) => {
    const merged = {};
    for (const key of Object.keys(a)) {
      // Quaternion-like shortest-path interpolation for the dancer's yaw.
      const delta = key === 'yaw' ? Math.atan2(Math.sin(b[key] - a[key]), Math.cos(b[key] - a[key])) : b[key] - a[key];
      merged[key] = a[key] + delta * w;
    }
    return merged;
  };
  if (remaining < .65) pose = mix(pose, moves[(current + 1) % 4](), ease(1 - remaining / .65));
  // Finish upright before the applause rather than teleporting out of a spin.
  if (phase > 26.2) pose = mix(pose, neutral, ease((phase - 26.2) / .8));
  return pose;
}
