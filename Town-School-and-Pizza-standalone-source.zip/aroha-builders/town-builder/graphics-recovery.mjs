// The browser owns context restoration. Keep game state in memory while Three.js
// recreates GPU resources; never reload or replace the student's town.
export function graphicsPixelRatio(width,height,{reduced=false,ratio=globalThis.devicePixelRatio||1}={}){
 return Math.min(ratio,reduced?1:1.35,Math.sqrt((reduced?1000000:2000000)/Math.max(1,width*height)));
}
export function watchGraphicsContext(canvas, renderer, timers=globalThis,{onUnavailable,onRestored,onLost=()=>{},delay=4000}={}){
 const state={lost:false,restoring:false,active:true},doc=canvas.ownerDocument;
 let status,timeout;
 function message(text){
  if(!status && doc && canvas.parentElement){status=doc.createElement('div');status.className='graphics-recovery';status.setAttribute('role','status');status.setAttribute('aria-live','polite');canvas.parentElement.append(status);}
  if(status){status.textContent=text;status.hidden=!text;}
 }
 const lost=event=>{
  event?.preventDefault?.();if(!state.active||state.lost)return;
  state.lost=true;state.restoring=false;
  onLost();
  message('画面を復旧しています。少しお待ちください…');
  timers.clearTimeout(timeout);
  timeout=timers.setTimeout(()=>{if(state.lost){if(onUnavailable)onUnavailable();else message('画面を復旧できません。先生に知らせてください。');}},delay);
 };
 const restored=()=>{
  if(!state.active)return;
  timers.clearTimeout(timeout);state.lost=false;state.restoring=true;
  // Reduce framebuffer memory after a graphics reset and redraw the shadow map.
  renderer.shadowMap.needsUpdate=true;
  if(onRestored)onRestored();else renderer.setPixelRatio(Math.min(globalThis.devicePixelRatio||1,1));
  message('画面を復旧しています。少しお待ちください…');
 };
 canvas.addEventListener('webglcontextlost',lost);
 canvas.addEventListener('webglcontextrestored',restored);
 state.lostNow=lost;
 state.useFallback=()=>{state.active=false;state.lost=false;state.restoring=false;timers.clearTimeout(timeout);canvas.removeEventListener?.('webglcontextlost',lost);canvas.removeEventListener?.('webglcontextrestored',restored);message('3D表示を休んで、軽い地図表示に切り替えました。そのまま続けられます。');if(status)status.className='graphics-recovery graphics-recovered';};
 state.rendered=()=>{if(state.restoring){state.restoring=false;message('');}};
 return state;
}
