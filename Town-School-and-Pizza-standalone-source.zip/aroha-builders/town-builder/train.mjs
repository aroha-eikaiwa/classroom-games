import * as THREE from './vendor/three.module.js';

// Shared batched carriage geometry: curved body, inset passenger doors, bogies,
// air-conditioning units, pantograph and fitted generated surface artwork.
const STEEL=0,ROOF=1,SIDE=2,FRONT=3,SOLID=4;
const materials=[
 new THREE.MeshStandardMaterial({color:'#d8e0df',metalness:.48,roughness:.45}),
 new THREE.MeshStandardMaterial({color:'#a6afb0',metalness:.32,roughness:.6}),
 new THREE.MeshStandardMaterial({color:'#d4dcda',metalness:.35,roughness:.48}),
 new THREE.MeshStandardMaterial({color:'#bed5d1',metalness:.18,roughness:.42}),
 new THREE.MeshStandardMaterial({vertexColors:true,metalness:.22,roughness:.48}),
];
materials.forEach(m=>{m.userData.shared=true;m.side=THREE.DoubleSide;});
let template,promise;
export function loadTrainTextures(){return Promise.resolve(false);}
function roundedShape(w,h,r){const x=-w/2,y=-h/2,s=new THREE.Shape();s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s;}
function roundBox(w,h,d,r=.035){if(r<.015||Math.min(w,h,d)<.025)return new THREE.BoxGeometry(w,h,d);const detailed=r>=.04;const bevel=Math.min(.008,d*.15),g=new THREE.ExtrudeGeometry(roundedShape(w-2*bevel,h-2*bevel,r),{depth:d-2*bevel,steps:1,curveSegments:detailed?7:3,bevelEnabled:true,bevelSegments:detailed?3:1,bevelSize:bevel,bevelThickness:bevel});g.translate(0,0,-d/2+bevel);const p=g.attributes.position,u=g.attributes.uv,n=g.attributes.normal;for(let i=0;i<p.count;i++){const nx=Math.abs(n.getX(i)),ny=Math.abs(n.getY(i)),nz=Math.abs(n.getZ(i));if(ny>=nx&&ny>=nz)u.setXY(i,p.getX(i)/w+.5,p.getZ(i)/d+.5);else if(nx>=nz)u.setXY(i,p.getZ(i)/d+.5,p.getY(i)/h+.5);else u.setXY(i,p.getX(i)/w+.5,p.getY(i)/h+.5);}return g;}
function carriage(){
 const lists=Array.from({length:materials.length},()=>[]);
 function add(geometry,mat=SOLID,color='#ffffff',position=[0,0,0],rotation=[0,0,0]){
  const mesh=new THREE.Mesh(geometry);mesh.position.fromArray(position);mesh.rotation.set(...rotation);mesh.updateMatrix();const g=geometry.index?geometry.toNonIndexed():geometry.clone();g.applyMatrix4(mesh.matrix);geometry.dispose();const c=new THREE.Color(color),colors=new Float32Array(g.attributes.position.count*3);for(let i=0;i<colors.length;i+=3){colors[i]=c.r;colors[i+1]=c.g;colors[i+2]=c.b;}g.setAttribute('color',new THREE.BufferAttribute(colors,3));lists[mat].push(g);
 }
 const box=(w,h,d,x,y,z,color,mat=SOLID,r=.012)=>add(roundBox(w,h,d,r),mat,color,[x,y,z]);
 const beam=(a,b,r,color)=>{const av=new THREE.Vector3(...a),bv=new THREE.Vector3(...b),v=bv.clone().sub(av),g=new THREE.CylinderGeometry(r,r,v.length(),10);const q=new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),v.normalize());g.applyQuaternion(q);g.translate(...av.add(bv).multiplyScalar(.5).toArray());add(g,SOLID,color);};
 // Rounded stainless shell and full-width lower skirt. The train's front is +Z.
 box(.58,.57,1.46,0,.46,0,'#ffffff',STEEL,.09);
 box(.555,.16,1.42,0,.15,0,'#36434a',SOLID,.04);
 box(.57,.11,1.40,0,.77,0,'#ffffff',ROOF,.045);
 // The side elevations are fitted only to the straight wall panels. Curved
 // corners, roof, cab and undercarriage retain their own UVs/materials.
 for(const side of [-1,1]){
  add(new THREE.PlaneGeometry(1.31,.46),SIDE,'#ffffff',[side*.291,.475,0],[0,side*Math.PI/2,0]);
  box(.015,.066,1.32,side*.301,.345,0,'#319c8e',SOLID,.004);
  box(.015,.013,1.32,side*.303,.303,0,'#d7b655',SOLID,.003);
  // Three pairs of recessed sliding doors and clean individual window frames.
  for(const z of [-.44,0,.44]){
   box(.018,.42,.17,side*.303,.468,z,'#a9b7b6',SOLID,.007);
   box(.022,.198,.12,side*.314,.55,z,'#214753',SOLID,.012);
   box(.024,.32,.008,side*.317,.432,z,'#586c70',SOLID,.002);
   for(const dz of [-.031,.031])box(.026,.028,.008,side*.318,.411,z+dz,'#e6e9dc',SOLID,.003);
   box(.031,.018,.176,side*.316,.257,z,'#d1d9ce',SOLID,.003);
  }
  for(const z of [-.22,.22]){
   box(.018,.205,.21,side*.307,.55,z,'#53686b',SOLID,.015);
   box(.024,.178,.187,side*.315,.55,z,'#254a58',SOLID,.016);
   box(.026,.008,.174,side*.317,.598,z,'#6a979c',SOLID,.002);
  }
 }
 for(const end of [-1,1]){
  // Cab glazing, destination panel, paired lamps and working coupler detail.
  add(new THREE.PlaneGeometry(.48,.42),FRONT,'#ffffff',[0,.495,end*.739],[0,end>0?0:Math.PI,0]);
  box(.49,.234,.018,0,.556,end*.754,'#294c57',SOLID,.041);
  box(.4,.011,.021,0,.61,end*.766,'#628b91',SOLID,.003);
  box(.014,.211,.024,0,.555,end*.768,'#aebeb9',SOLID,.004);
  box(.232,.052,.026,0,.709,end*.735,'#183d3a',SOLID,.009);
  for(let i=-2;i<=2;i++)box(.019,.019,.029,i*.032,.709,end*.738,'#a3e4b7',SOLID,.002);
  box(.48,.065,.026,0,.367,end*.754,'#2f9d8e',SOLID,.011);
  for(const x of [-.202,.202]){
   box(.085,.05,.029,x,.409,end*.759,'#304749',SOLID,.015);
   box(.062,.031,.032,x,.409,end*.766,end>0?'#fff3bd':'#f07a64',SOLID,.012);
   beam([x-.024,.472,end*.774],[x+.032,.495,end*.774],.0045,'#172d32');
  }
  box(.45,.068,.06,0,.222,end*.724,'#788784',SOLID,.022);
  box(.115,.06,.15,0,.155,end*.78,'#344449',SOLID,.01);
 }
 // Air conditioning equipment, cooling fins and a delicate single pantograph.
 for(const z of [-.40,.25]){
  box(.39,.075,.32,0,.861,z,'#c4cdcb',SOLID,.025);
  for(let i=-3;i<=3;i++)box(.28,.008,.014,0,.903,z+i*.033,'#697c7b',SOLID,.002);
 }
 box(.28,.026,.20,0,.852,.55,'#697a78',SOLID,.009);
 for(const x of [-.08,.08]){beam([x,.87,.48],[x,.99,.60],.008,'#4c5c5d');beam([x,.99,.60],[x,1.08,.46],.008,'#4c5c5d');}
 beam([-.19,1.08,.46],[.19,1.08,.46],.012,'#3c4c4f');
 // Two bogies, four axles and visible flanged steel wheels. Their cylinders are
 // smooth but kept in the carriage batch: tiny wheel spins add no useful pixels.
 for(const z of [-.47,.47]){
  box(.44,.11,.36,0,.117,z,'#35464b',SOLID,.023);
  for(const offset of [-.105,.105]){
   const at=z+offset;beam([-.28,.104,at],[.28,.104,at],.022,'#61706e');
   for(const side of [-1,1]){
    add(new THREE.CylinderGeometry(.09,.09,.058,20),SOLID,'#354348',[side*.223,.103,at],[0,0,Math.PI/2]);
    add(new THREE.CylinderGeometry(.061,.061,.061,20),SOLID,'#8c9b96',[side*.225,.103,at],[0,0,Math.PI/2]);
   }
  }
 }
 const group=new THREE.Group();
 for(let mat=0;mat<lists.length;mat++){
  const parts=lists[mat];if(!parts.length)continue;const count=parts.reduce((n,g)=>n+g.attributes.position.count,0),p=new Float32Array(count*3),n=new Float32Array(count*3),uv=new Float32Array(count*2),color=new Float32Array(count*3);let at=0;
  for(const g of parts){p.set(g.attributes.position.array,at*3);n.set(g.attributes.normal.array,at*3);uv.set(g.attributes.uv.array,at*2);color.set(g.attributes.color.array,at*3);at+=g.attributes.position.count;g.dispose();}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));g.setAttribute('normal',new THREE.BufferAttribute(n,3));g.setAttribute('uv',new THREE.BufferAttribute(uv,2));g.setAttribute('color',new THREE.BufferAttribute(color,3));g.computeBoundingSphere();const mesh=new THREE.Mesh(g,materials[mat]);mesh.userData.sharedGeometry=true;mesh.castShadow=false;mesh.receiveShadow=true;group.add(mesh);
 }
 return group;
}
export function createTrain({carCount=2}={}){
 template??=carriage();const group=new THREE.Group(),cars=Array.from({length:carCount},()=>template.clone());for(const car of cars)group.add(car);
 group.userData.cars=cars;group.userData.update=motion=>{
  for(let i=0;i<cars.length;i++){const p=motion.pose(-i*1.68);cars[i].position.set(p.x,p.height+.025+.027*Math.min(1,p.height/.05),p.y);cars[i].rotation.set(-(p.pitch||0),p.heading,0,'YXZ');}
 };return group;
}
