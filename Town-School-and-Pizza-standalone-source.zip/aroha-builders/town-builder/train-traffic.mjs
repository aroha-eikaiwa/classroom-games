import {roadGraph,trafficLightPlacements} from './network.mjs';
import {signalJunctions,redSignalAhead} from './traffic-signals.mjs';
import {buildCivilianRoutes} from './civilian-route.mjs';
import {buildPatrolRoutes,patrolPose} from './patrol-route.mjs';
import {buildBusRoutes,busPose} from './bus-route.mjs';
import {buildTrainRoutes,buildParkedTrains,TrainMotion} from './train-route.mjs';
import {validateTransport,transportHeightAt} from './transport.mjs';
const cache=new WeakMap();
export function trainTraffic(t){
 // Entrance access depends on pavement too: a new path can enable patrols
 // without changing either the building or the road network.
 const signature=JSON.stringify([t.roads,t.roadEdges,t.rails,t.railEdges,t.rivers,t.buildings,t.pavement]);let data=cache.get(t);if(data?.signature===signature)return data;
 const analysis=validateTransport(t),routes=buildTrainRoutes(t,analysis),roadJunctions=signalJunctions(roadGraph(t)),signalIds=new Set(trafficLightPlacements(t).map(p=>p.junction));
 // Signal fixtures depend on the same immutable layout. Compute them once,
 // rather than repeating the whole placement pass for every junction.
 data={signature,analysis,routes,roadJunctions,junctions:roadJunctions.filter(j=>signalIds.has(j.id)),buses:buildBusRoutes(t),patrols:buildPatrolRoutes(t),parked:buildParkedTrains(t,routes,analysis)};data.cars=buildCivilianRoutes(t,[...data.buses,...data.patrols]);cache.set(t,data);return data;
}
// Share a lightweight room view; never mutate the cached solo traffic plan.
const quietRoadTraffic=new WeakMap();
export function roomTraffic(t){const base=trainTraffic(t);let data=quietRoadTraffic.get(base);if(!data){data={...base,buses:[],patrols:[],cars:[]};quietRoadTraffic.set(base,data);}return data;}
const bodyFrames=new WeakMap();
export function trainBodies(traffic,time){
 let frames=bodyFrames.get(traffic);if(!frames){frames=new Map();bodyFrames.set(traffic,frames);}if(frames.has(time))return frames.get(time);
 const bodies=traffic.parked.map(p=>p.pose);
 for(const route of traffic.routes){const motion=new TrainMotion(route).update(time);bodies.push(motion.pose(),motion.pose(-1.68));}if(frames.size>=128)frames.delete(frames.keys().next().value);frames.set(time,bodies);return bodies;
}
export function carHitsTrain(traffic,bodies,x,y,pad=.02){
 const wx=x+.5,wy=y+.5,height=transportHeightAt(traffic.analysis,wx,wy,'road');
 return bodies.some(p=>{if(p.clearingJam||Math.abs(p.height-height)>.55)return false;const dx=wx-p.x,dy=wy-p.y,s=Math.sin(p.heading),c=Math.cos(p.heading),along=dx*s+dy*c,across=dx*c-dy*s;
 // Capsule approximation includes the car's half width and a small stop gap.
 return Math.hypot(Math.max(0,Math.abs(along)-(p.halfLength??.77)),Math.max(0,Math.abs(across)-(p.halfWidth??.30)))<(['bus','police','ambulance','civilian'].includes(p.kind)?.17:.22)+pad;
 });
}
// Move a struck car only along connected road segments. Search forward/backward
// from its current segment, never jump to a nearby disconnected road.
export function bumpFromTrain(driver,bodies){
 const {graph,traffic}=driver,origin={x:driver.x,y:driver.y},queue=[],visited=new Map(),candidates=[];
 const seed=(node,d)=>{if(d<(visited.get(node.id)??Infinity)){visited.set(node.id,d);queue.push({node,d});}};
 if(driver.to){const len=Math.hypot(driver.to.x-driver.node.x,driver.to.y-driver.node.y);seed(driver.node,driver.progress);seed(driver.to,len-driver.progress);}else seed(driver.node,0);
 const sample=(a,b,startDistance,startT=0,endT=1)=>{const len=Math.hypot(b.x-a.x,b.y-a.y);for(let i=0;i<=Math.ceil(len/.08);i++){const u=startT+(endT-startT)*i/Math.ceil(len/.08),x=a.x+(b.x-a.x)*u,y=a.y+(b.y-a.y)*u,d=startDistance+Math.abs(u-startT)*len;if(d>2.4||carHitsTrain(traffic,bodies,x,y,.08))continue;candidates.push({a,b,u,x,y,d});}};
 if(driver.to){const len=Math.hypot(driver.to.x-driver.node.x,driver.to.y-driver.node.y),u=driver.progress/len;sample(driver.node,driver.to,0,u,0);sample(driver.node,driver.to,0,u,1);}
 for(let i=0;i<queue.length&&i<100;i++){const {node,d}=queue[i];if(d>2.4)continue;for(const id of node.neighbors){const next=graph.nodes.get(id),len=Math.hypot(next.x-node.x,next.y-node.y);sample(node,next,d);seed(next,d+len);}}
 candidates.sort((a,b)=>a.d-b.d||Math.hypot(a.x-origin.x,a.y-origin.y)-Math.hypot(b.x-origin.x,b.y-origin.y));const p=candidates[0];if(!p)return false;
 driver.node=p.a;driver.to=p.b;driver.from=null;driver.progress=Math.hypot(p.b.x-p.a.x,p.b.y-p.a.y)*p.u;driver.x=p.x;driver.y=p.y;driver.speed=0;driver.turn=0;
 // Preserve car facing, while orienting the road edge for that same direction.
 const edgeHeading=Math.atan2(p.b.x-p.a.x,p.b.y-p.a.y),facing=Math.cos(edgeHeading-driver.heading);if(facing<0){driver.node=p.b;driver.to=p.a;driver.progress=Math.hypot(p.b.x-p.a.x,p.b.y-p.a.y)*(1-p.u);}driver.reverse=false;driver.targetHeading=driver.heading;return true;
}

export function trafficBodies(traffic,time){return [...trainBodies(traffic,time),...(traffic.buses||[]).map(route=>busTrafficPose(traffic,route,time)),...(traffic.patrols||[]).map(route=>busTrafficPose(traffic,route,time)),...(traffic.cars||[]).map(route=>busTrafficPose(traffic,route,time))];}

// Check a short look-ahead as well as the full train now. A tail carriage keeps
// the barriers closed after the leading cab has cleared the road.
export function crossingClosed(traffic,crossing,time){for(const ahead of [0,.6,1.2,1.8])for(const p of trainBodies(traffic,time+ahead)){if(Math.abs(p.height)>.55)continue;const dx=crossing.x+.5-p.x,dy=crossing.y+.5-p.y,along=dx*Math.sin(p.heading)+dy*Math.cos(p.heading),across=dx*Math.cos(p.heading)-dy*Math.sin(p.heading);if(Math.abs(along)<1.25&&Math.abs(across)<.55)return true;}return false;}

// Fixed simulation steps keep buses identical in the renderer and car collisions,
// including when a controller joins late or requests an earlier timestamp.
const busClocks=new WeakMap(),BUS_STEP=.1;
export function busTrafficPose(traffic,route,time){
 const poseAt=route.kind?patrolPose:busPose,crossings=traffic.analysis.crossings||[];if(!crossings.length&&!traffic.junctions?.length)return poseAt(route,time);
 let clocks=busClocks.get(traffic);if(!clocks){clocks=new Map();busClocks.set(traffic,clocks);}let history=clocks.get(route);const CAPACITY=6002;
 if(!history){history={tick:0,values:new Float64Array(CAPACITY)};clocks.set(route,history);}
 time=Math.max(0,time);const tick=Math.floor(time/BUS_STEP);
 const advance=(clock,now,dt)=>{const current=poseAt(route,clock),next=poseAt(route,clock+dt);if(redSignalAhead(traffic.junctions,current,next,now))return clock;if(current.speed||next.speed)for(const c of crossings){const before=Math.hypot(current.x-c.x-.5,current.y-c.y-.5),after=Math.hypot(next.x-c.x-.5,next.y-c.y-.5);if(before>=1.18&&after<1.30&&after<before&&(crossingClosed(traffic,c,now)||crossingClosed(traffic,c,now+1.2)))return clock;}return clock+dt;};
 if(tick<Math.max(0,history.tick-CAPACITY+1)){history.tick=0;history.values[0]=0;}
 while(history.tick<tick+1){const i=history.tick,clock=history.values[i%CAPACITY];history.values[(i+1)%CAPACITY]=advance(clock,i*BUS_STEP,BUS_STEP);history.tick++;}
 const before=history.values[tick%CAPACITY],after=history.values[(tick+1)%CAPACITY],clock=before+(after-before)*(time/BUS_STEP-tick),pose=poseAt(route,clock);if(after===before){pose.speed=0;pose.waitingForLight=!!redSignalAhead(traffic.junctions,pose,poseAt(route,clock+BUS_STEP),time);pose.waitingForTrain=!pose.waitingForLight;}return pose;
}
