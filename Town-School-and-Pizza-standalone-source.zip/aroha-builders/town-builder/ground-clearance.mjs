import {W,H,migrateRoadEdges,segmentTouchesBox} from './network.mjs';
// Only the eight adjacent grid directions and two fixed widths occur. Reuse
// their translation-invariant footprints, rather than clipping every edge
// against nine fresh rectangles on every save or paint operation.
const edgeFootprints=new Map();
function edgeFootprint(dx,dy,pad){
 const id=`${dx},${dy},${pad}`;if(edgeFootprints.has(id))return edgeFootprints.get(id);
 const out=[];for(let y=Math.min(0,dy)-1;y<=Math.max(0,dy)+1;y++)for(let x=Math.min(0,dx)-1;x<=Math.max(0,dx)+1;x++)if(segmentTouchesBox({x:0,y:0},{x:dx,y:dy},{x,y,w:1,d:1},pad))out.push([x,y]);
 // Cache adjacent geometry only; arbitrary caller data cannot grow the cache.
 if(Math.max(Math.abs(dx),Math.abs(dy))===1)edgeFootprints.set(id,out);return out;
}
export function transportGroundCells(t){
 const out=new Set([...(t.roads||[]),...(t.rails||[])]);
 for(const [nodes,edges,pad] of [[t.roads||[],t.roadEdges,.43],[t.rails||[],t.railEdges,.38]])for(const [a,b] of edges??migrateRoadEdges(nodes)){
  const p={x:a%W,y:Math.floor(a/W)},q={x:b%W,y:Math.floor(b/W)};
  for(const [dx,dy]of edgeFootprint(q.x-p.x,q.y-p.y,pad)){const x=p.x+dx,y=p.y+dy;if(x>=0&&x<W&&y>=0&&y<H)out.add(y*W+x);}
 }
 return out;
}
