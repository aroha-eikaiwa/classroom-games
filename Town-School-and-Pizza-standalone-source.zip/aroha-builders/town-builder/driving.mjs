import {RoadTraffic,vehicleAhead} from './road-traffic.mjs';
import {transportHeightAt} from './transport.mjs';
import {trainTraffic,roomTraffic,trainBodies,carHitsTrain,bumpFromTrain} from './train-traffic.mjs';
import {roadGraph,nodeKey} from './network.mjs';
import {PolicePursuit} from './police-pursuit.mjs';
// Optional third movement value retains proportional joystick input end to end.
export function keysFromBits(bits,steer){return {w:!!(bits&1),s:!!(bits&2),a:!!(bits&4),d:!!(bits&8),...(Number.isFinite(steer)?{steer}: {})};}
export const angleDelta=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
// The compact car can move across the tarmac, without crossing the kerb.
export const ROAD_CLEARANCE=.20;
const indexes=new WeakMap();
function roadIndex(graph){let index=indexes.get(graph);if(index)return index;index=new Map();for(const link of graph.links){for(let y=Math.floor(Math.min(link.a.y,link.b.y)-1);y<=Math.floor(Math.max(link.a.y,link.b.y)+1);y++)for(let x=Math.floor(Math.min(link.a.x,link.b.x)-1);x<=Math.floor(Math.max(link.a.x,link.b.x)+1);x++){const key=nodeKey(x,y);if(!index.has(key))index.set(key,[]);index.get(key).push(link);}}indexes.set(graph,index);return index;}
const cornerIndexes=new WeakMap();
function cornerGeometry(graph){
 let cached=cornerIndexes.get(graph);if(cached)return cached;
 const corners=[...graph.nodes.values()].filter(n=>{const neighbors=[...n.neighbors].map(id=>graph.nodes.get(id));return neighbors.length>2||neighbors.length===2&&Math.abs((neighbors[0].x-n.x)*(neighbors[1].y-n.y)-(neighbors[0].y-n.y)*(neighbors[1].x-n.x))>1e-6;}),index=new Map();
 for(const n of corners){const key=nodeKey(Math.floor(n.x),Math.floor(n.y));let bucket=index.get(key);if(!bucket){bucket=[];index.set(key,bucket);}bucket.push(n);}
 cached={corners,index};cornerIndexes.set(graph,cached);return cached;
}
export class Driving{
 constructor(t,{roadTraffic=true}={}){this.town=t;this.roadTrafficEnabled=roadTraffic;this.traffic=roadTraffic?trainTraffic(t):roomTraffic(t);this.trainTime=0;this.roadTraffic=new RoadTraffic(this.traffic);this.graph=roadGraph(t);this.index=roadIndex(this.graph);const geometry=cornerGeometry(this.graph);this.corners=geometry.corners;this.cornerIndex=geometry.index;this.node=this.graph.nodes.get(nodeKey(t.start.x,t.start.y));this.from=null;this.to=null;this.progress=0;this.speed=0;this.x=this.node.x;this.y=this.node.y;this.heading=0;this.targetHeading=0;this.reverse=false;this.turn=0;const first=[...this.node.neighbors].map(id=>this.graph.nodes.get(id))[0];if(first)this.heading=this.targetHeading=Math.atan2(first.x-this.x,first.y-this.y);}
 // Room maps are immutable after creation. Fork only the mutable driving
 // state; sharing these layout indexes keeps transactional commands cheap.
 fork(snapshot=this.snapshot()){
  const next=Object.create(Driving.prototype);
  for(const key of ['town','traffic','roadTrafficEnabled','graph','index','corners','cornerIndex'])next[key]=this[key];
  next.roadTraffic=new RoadTraffic(this.traffic);next.police=new PolicePursuit(this.town,this.graph,this.traffic);return next.restore(snapshot);
 }
 roadAt(x,y){let best=null;for(const {a,b}of this.index.get(nodeKey(Math.floor(x),Math.floor(y)))||[]){const dx=b.x-a.x,dy=b.y-a.y,length=Math.hypot(dx,dy),u=Math.max(0,Math.min(1,((x-a.x)*dx+(y-a.y)*dy)/(length*length))),px=a.x+u*dx,py=a.y+u*dy,d=Math.hypot(x-px,y-py);if(!best||d<best.d)best={a,b,u,length,d,x:px,y:py};}return best;}
 onRoad(x,y,p=this.roadAt(x,y)){
  if(!p)return false;if(p.d<=ROAD_CLEARANCE+1e-9)return true;
  // The original .62 corner radius reaches at most one neighbouring unit bin,
  // including fractional nodes at diagonal X crossings. Keep the exact final
  // distance predicate; this index only removes impossible distant candidates.
  const gx=Math.floor(x),gy=Math.floor(y);
  for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
   const bucket=this.cornerIndex.get(nodeKey(gx+dx,gy+dy));if(!bucket)continue;
   for(const n of bucket)if(Math.hypot(x-n.x,y-n.y)<=.62)return true;
  }
  return false;
 }
 trackRoad(p){if(!p)return;this.node=p.a;this.to=p.b;this.progress=p.u*p.length;this.from=null;}
 update(dt,input){
  this.police??=new PolicePursuit(this.town,this.graph,this.traffic);
  const before=this.police.player(this);
  dt=Math.max(0,Math.min(dt,.05));if(this.traffic.routes.length||this.traffic.buses.length||this.traffic.patrols?.length||this.traffic.cars?.length||this.traffic.junctions?.length)this.trainTime+=dt;const trains=trainBodies(this.traffic,this.trainTime);this.roadTraffic.update(dt,{x:this.x+.5,y:this.y+.5,heading:this.heading,speed:this.speed,halfLength:.45,halfWidth:.17,height:transportHeightAt(this.traffic.analysis,this.x+.5,this.y+.5,'road')},this.trainTime);const roadBodies=this.roadTraffic.poses(),bodies=[...trains,...roadBodies];
  if(this.police.state.hold>0){this.speed=0;this.turn=0;this.police.update(dt,this,before);return true;}
  if(carHitsTrain(this.traffic,trains,this.x,this.y)){bumpFromTrain(this,trains);this.speed=0;this.police.update(dt,this,before);return true;}
  let collision=false;
  const oldX=this.x,oldY=this.y,oldHeading=this.heading;
  const throttle=Number(!!input.w)-Number(!!input.s),analog=Number.isFinite(input.steer);this.turn=analog?Math.max(-1,Math.min(1,input.steer)):Number(!!input.d)-Number(!!input.a);
  // Left/right always turn the nose in that direction, even when stationary.
  // Slower cornering and reverse give children time to line up the next street.
  this.heading-=this.turn*(analog?1.55:2.65)*dt;this.heading=Math.atan2(Math.sin(this.heading),Math.cos(this.heading));this.targetHeading=this.heading;
  const straightSpeed=throttle<0?1.35:2.2;let wanted=throttle*(analog?straightSpeed-(straightSpeed-1.05)*Math.abs(this.turn):this.turn?1.05:straightSpeed);
  const leader=throttle>0?vehicleAhead({x:this.x+.5,y:this.y+.5,heading:this.heading,halfLength:.45,halfWidth:.17,height:transportHeightAt(this.traffic.analysis,this.x+.5,this.y+.5,'road')},roadBodies,Math.max(.08,Math.abs(this.speed)*.15)):null;
  if(leader){wanted=0;this.speed=0;}
  // Opposite throttle cancels old momentum immediately: W cannot keep reversing.
  if(throttle&&this.speed*throttle<0)this.speed=0;
  const rate=throttle?4.8:8,change=rate*dt;this.speed+=Math.max(-change,Math.min(change,wanted-this.speed));if(Math.abs(this.speed)<.001)this.speed=0;
  this.reverse=this.speed<0;
  const dx=Math.sin(this.heading)*this.speed*dt,dy=Math.cos(this.heading)*this.speed*dt;
  if(dx||dy){
   let x=this.x+dx,y=this.y+dy,next=this.roadAt(x,y);
   if(next&&!this.onRoad(x,y,next)){
    // Slide along the kerb in the closest nose direction, never reflect it.
    // Junctions and bends have a small forgiving area for cutting the corner.
    let tx=(next.b.x-next.a.x)/next.length,ty=(next.b.y-next.a.y)/next.length;
    const facing=tx*Math.sin(this.heading)+ty*Math.cos(this.heading);
    if(facing<0){tx=-tx;ty=-ty;}
    this.heading=Math.atan2(tx,ty);this.targetHeading=this.heading;
    x=this.x+tx*this.speed*dt;y=this.y+ty*this.speed*dt;next=this.roadAt(x,y);
    if(next&&!this.onRoad(x,y,next)){
     // Keep the car just inside the edge while preserving its along-road motion.
     const inset=(ROAD_CLEARANCE-.001)/next.d;
     x=next.x+(x-next.x)*inset;y=next.y+(y-next.y)*inset;next=this.roadAt(x,y);
    }
    // A true dead end still stops the car, without turning it around.
    const along=(x-this.x)*tx+(y-this.y)*ty;
    if(along*Math.sign(this.speed)<=1e-6){x=this.x;y=this.y;next=this.roadAt(x,y);this.speed=0;}
   }
   if(this.onRoad(x,y,next)&&!carHitsTrain(this.traffic,bodies,x,y)){this.x=x;this.y=y;this.trackRoad(next);}else{collision=Math.abs(this.speed)>.7&&carHitsTrain(this.traffic,roadBodies.filter(p=>!p.pursuit),x,y);this.speed=0;}
  }
  this.police.update(dt,this,before,collision);
  return this.x!==oldX||this.y!==oldY||this.heading!==oldHeading;
 }
 get canArrive(){return this.police?.canArrive??true;}
 get avatar(){const {path,...police}=this.police?.snapshot()||{};return{roadTrafficEnabled:this.roadTrafficEnabled,x:this.x,y:this.y,heading:this.heading,speed:this.speed,turn:this.turn,trainTime:this.trainTime,roadTraffic:this.roadTraffic.snapshot(),police};}
 snapshot(){return {roadTrafficEnabled:this.roadTrafficEnabled,trainTime:this.trainTime,roadTraffic:this.roadTraffic.snapshot(),police:this.police?.snapshot()||new PolicePursuit(this.town,this.graph,this.traffic).snapshot(),node:this.node.id,from:this.from?.id??null,to:this.to?.id??null,progress:this.progress,speed:this.speed,x:this.x,y:this.y,heading:this.heading,targetHeading:this.targetHeading,reverse:this.reverse,turn:this.turn};}
 restore(s){if(s.roadTrafficEnabled===false&&this.roadTrafficEnabled){this.roadTrafficEnabled=false;this.traffic=roomTraffic(this.town);this.roadTraffic=new RoadTraffic(this.traffic);this.police=new PolicePursuit(this.town,this.graph,this.traffic);}this.trainTime=Number.isFinite(s.trainTime)?s.trainTime:0;this.roadTraffic.restore(s.roadTraffic,this.trainTime);this.node=this.graph.nodes.get(s.node);this.from=s.from?this.graph.nodes.get(s.from):null;this.to=s.to?this.graph.nodes.get(s.to):null;for(const k of ['progress','speed','x','y','heading','targetHeading','reverse','turn'])this[k]=s[k];this.police??=new PolicePursuit(this.town,this.graph,this.traffic);this.police.restore(this.roadTrafficEnabled?s.police:undefined);this.roadTraffic.police=this.police.record;return this;}
}
