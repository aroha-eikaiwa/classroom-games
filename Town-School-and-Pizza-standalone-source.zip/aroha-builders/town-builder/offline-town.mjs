import {validateTown} from './core.mjs';
export function installStudentUI({$,local,getTown,openGame,openModal,closeModal,blankTown,toast}) {
 const key='aroha-town-draft';
 const load=()=>{let saved;try{saved=JSON.parse(local.get(key)||'null');if(saved)validateTown(saved);}catch{saved=null;}openGame(saved||blankTown());};
 $('#open-town').onclick=load;
 const save=()=>local.set(key,JSON.stringify(getTown()));
 $('#save').onclick=()=>{save();toast('Saved on this device / この端末に保存しました');};
 const reset=document.createElement('button');reset.id='reset-town-local';reset.textContent='Start fresh / はじめから';$('#save').after(reset);
 reset.onclick=()=>{
  openModal('Start a new town? / はじめから？','<p>This replaces the town saved in this browser only.</p><button id="cancel-local-reset">Cancel</button> <button id="confirm-local-reset" class="primary">Delete and start fresh</button>');
  $('#cancel-local-reset').onclick=closeModal;
  $('#confirm-local-reset').onclick=()=>{const fresh=blankTown();local.set(key,JSON.stringify(fresh));closeModal();openGame(fresh);toast('New town / 新しいまち');};
 };
 return {editingAllowed:()=>true,progressionBypassAllowed:()=>false,localDirectionsAllowed:()=>true,directionsAllowed:()=>false,
 refreshDirectionsAccess:async()=>false,label:()=> 'Our town',changed(){},pauseResume(){},async flush(){save();}};
}