# Pizza Builder · standalone edition

This is an offline adaptation of the current Pizza Builder guest workshop source from 24 November 2026. It preserves the actual pizza editor and local ingredient-shopping practice, including the current peach/pepperoni sizing and the matching ingredient drag preview. Keep this directory intact; it contains the source, not just a link to a hosted build.

## Run

From this folder, run `python3 -m http.server --bind 127.0.0.1 8080`, then open `http://127.0.0.1:8080/`. It can also run from a standalone static hosting directory. There are no dependencies or service credentials required to play. A browser must support local storage and current JavaScript modules.

- Use the ingredient shop to get toppings, then arrange and rotate them and add sauce.
- The offline shopping practice uses an imaginary ¥1,000 wallet. No real money is processed.
- Classic, thin and thick bases cook in the oven. Dessert bases chill in the refrigerator; fruit and mascarpone stay fresh. Pineapple works on both.
- **Reset** starts an entirely new local draft. All other workshop progress is saved on this browser only.
- The app includes PNG export, though file-download behavior was not exercised by automated checks.

This edition omits classroom accounts, school/player data, class shopkeeping, cross-device QR checkout and all connected services. The original production artwork and bundled font/QR implementations are not redistributed. The included WebP artwork is recreated by the original script in `make-art.py` (Pillow is only needed if regenerating images). No application-wide redistribution licence is supplied.

## Verification

`node test-offline.cjs` exercises the actual frontend script in a local DOM/storage harness. It verifies boot, both shop modes, ingredient quantities, drag width, placement and reload, oven and fridge locking/completion, and absence of live endpoints. Full browser rendering was not verified in the execution environment.
