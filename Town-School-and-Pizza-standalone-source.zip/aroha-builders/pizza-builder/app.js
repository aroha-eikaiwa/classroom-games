function $3(e, a, t, r) {
  let o = Math.max(1, Math.min(3, a));
  return {
    scale: o,
    x: t.x - r.x - ((t.x - r.x - e.x) * o) / e.scale,
    y: t.y - r.y - ((t.y - r.y - e.y) * o) / e.scale,
  };
}
function Q2(e, a, t) {
  let r = Math.max(1, Math.min(3, e.scale)),
    o = Math.max(0, (t.width * r - a.width) / 2),
    i = Math.max(0, (t.height * r - a.height) / 2);
  return {
    scale: r,
    x: Math.max(-o, Math.min(o, e.x)),
    y: Math.max(-i, Math.min(i, e.y)),
  };
}
function Z2({
  canvas: e,
  scene: a,
  view: t,
  onGesture: r = () => {},
  onChange: o = () => {},
  listenResize: i = !0,
}) {
  let c = new Map(),
    s = [],
    l = null,
    w = !1,
    B = () => {
      let h = e.getBoundingClientRect();
      return { x: h.left + h.width / 2, y: h.top + h.height / 2 };
    },
    u = () => {
      (Object.assign(
        t,
        Q2(t, e.getBoundingClientRect(), {
          width: a.offsetWidth,
          height: a.offsetHeight,
        }),
      ),
        (a.style.transform = `translate(${t.x}px,${t.y}px) scale(${t.scale})`),
        o(t));
    },
    m = (h, f) => {
      (e.addEventListener(h, f, { passive: !1 }), s.push([h, f]));
    },
    b = () => {
      r();
      let h = [...c.values()];
      if (h.length >= 2) {
        let [f, d] = h;
        l = {
          kind: "pinch",
          distance: Math.hypot(d.x - f.x, d.y - f.y) || 1,
          point: { x: (f.x + d.x) / 2, y: (f.y + d.y) / 2 },
          view: { ...t },
        };
      } else h.length && (l = { kind: "pan", point: h[0], view: { ...t } });
    },
    g = (h) => {
      (h.preventDefault(), h.stopPropagation());
    };
  (m("pointerdown", (h) => {
    h.pointerType === "touch" &&
      (c.set(h.pointerId, { x: h.clientX, y: h.clientY }),
      (c.size >= 2 ||
        (t.scale > 1 && !h.target.closest("[data-piece],[data-rotate]"))) &&
        (b(), e.setPointerCapture?.(h.pointerId), g(h)));
  }),
    m("pointermove", (h) => {
      if (
        !c.has(h.pointerId) ||
        (c.set(h.pointerId, { x: h.clientX, y: h.clientY }), !l)
      )
        return;
      g(h);
      let f = [...c.values()];
      if (l.kind === "pinch" && f.length >= 2) {
        let [d, k] = f,
          v = { x: (d.x + k.x) / 2, y: (d.y + k.y) / 2 },
          p = (l.view.scale * Math.hypot(k.x - d.x, k.y - d.y)) / l.distance,
          y = $3(l.view, p, l.point, B());
        ((y.x += v.x - l.point.x),
          (y.y += v.y - l.point.y),
          Object.assign(t, y));
      } else
        f.length &&
          ((t.x = l.view.x + f[0].x - l.point.x),
          (t.y = l.view.y + f[0].y - l.point.y));
      u();
    }));
  let z = (h) => {
    c.has(h.pointerId) &&
      (c.delete(h.pointerId), l && (g(h), r(), c.size ? b() : (l = null)));
  };
  (m("pointerup", z),
    m("pointercancel", z),
    m("wheel", (h) => {
      h.ctrlKey
        ? (g(h),
          r(),
          Object.assign(
            t,
            $3(
              t,
              t.scale * Math.exp(-h.deltaY * 0.012),
              { x: h.clientX, y: h.clientY },
              B(),
            ),
          ),
          u())
        : t.scale > 1 && (g(h), r(), (t.x -= h.deltaX), (t.y -= h.deltaY), u());
    }));
  let M = null;
  (m("gesturestart", (h) => {
    (g(h),
      r(),
      (M = {
        view: { ...t },
        point: {
          x: Number.isFinite(h.clientX) ? h.clientX : B().x,
          y: Number.isFinite(h.clientY) ? h.clientY : B().y,
        },
      }));
  }),
    m("gesturechange", (h) => {
      M &&
        (g(h),
        Object.assign(t, $3(M.view, M.view.scale * h.scale, M.point, B())),
        u());
    }),
    m("gestureend", (h) => {
      M && (g(h), r(), (M = null));
    }));
  let C = () => {
    w || u();
  };
  return (
    i && typeof window < "u" && window.addEventListener("resize", C),
    u(),
    {
      get gesturing() {
        return !!(l || M);
      },
      zoomBy(h, f = B()) {
        (Object.assign(t, $3(t, t.scale * h, f, B())), u());
      },
      reset() {
        (c.clear(),
          (l = M = null),
          Object.assign(t, { scale: 1, x: 0, y: 0 }),
          u());
      },
      destroy() {
        w = !0;
        for (let [h, f] of s) e.removeEventListener(h, f);
        i && typeof window < "u" && window.removeEventListener("resize", C);
      },
    }
  );
}
var e3 = [
    ["cheese", "Cheese", "\u30C1\u30FC\u30BA", 250, 1, 0],
    ["pepperoni", "Pepperoni", "\u30DA\u30D1\u30ED\u30CB", 30, 1, 13.2],
    ["ham", "Ham", "\u30CF\u30E0", 25, 1, 11],
    ["bacon", "Bacon", "\u30D9\u30FC\u30B3\u30F3", 30, 1, 15],
    ["sausage", "Sausage", "\u30BD\u30FC\u30BB\u30FC\u30B8", 25, 1, 12],
    ["chicken", "Chicken", "\u30C1\u30AD\u30F3", 30, 1, 10.5],
    ["shrimp", "Shrimp", "\u30A8\u30D3", 40, 1, 12],
    ["tuna", "Tuna", "\u30C4\u30CA", 30, 1, 9],
    [
      "mushroom",
      "Mushrooms",
      "\u30DE\u30C3\u30B7\u30E5\u30EB\u30FC\u30E0",
      20,
      1,
      11.5,
    ],
    ["corn", "Corn", "\u30B3\u30FC\u30F3", 5, 1, 3.2],
    ["green-pepper", "Green peppers", "\u30D4\u30FC\u30DE\u30F3", 20, 1, 14],
    ["red-pepper", "Red peppers", "\u8D64\u30D1\u30D7\u30EA\u30AB", 20, 1, 12.5],
    ["onion", "Onions", "\u7389\u306D\u304E", 10, 1, 13],
    ["tomato", "Tomatoes", "\u30C8\u30DE\u30C8", 20, 1, 12],
    ["olive", "Olives", "\u30AA\u30EA\u30FC\u30D6", 10, 1, 5.25],
    [
      "pineapple",
      "Pineapple",
      "\u30D1\u30A4\u30CA\u30C3\u30D7\u30EB",
      20,
      1,
      10.5,
    ],
    ["basil", "Basil", "\u30D0\u30B8\u30EB", 10, 1, 9],
    ["broccoli", "Broccoli", "\u30D6\u30ED\u30C3\u30B3\u30EA\u30FC", 20, 1, 10],
    ["peach", "Peaches", "\u3082\u3082", 25, 1, 16.5],
    ["strawberry", "Strawberries", "\u3044\u3061\u3054", 25, 1, 14],
    ["banana", "Bananas", "\u30D0\u30CA\u30CA", 15, 1, 12.8],
    [
      "blueberry",
      "Blueberries",
      "\u30D6\u30EB\u30FC\u30D9\u30EA\u30FC",
      10,
      1,
      5.75,
    ],
    ["kiwi", "Kiwi fruit", "\u30AD\u30A6\u30A4", 20, 1, 14.7],
    ["mango", "Mango", "\u30DE\u30F3\u30B4\u30FC", 25, 1, 13.5],
    [
      "mascarpone",
      "Mascarpone",
      "\u30DE\u30B9\u30AB\u30EB\u30DD\u30FC\u30CD",
      250,
      1,
      0,
    ],
  ].map(([e, a, t, r, o, i]) => ({
    id: e,
    name: a,
    ja: t,
    price: r,
    pieces: o,
    size: i,
    image: `./assets/kitchen-v2/raw-${e}.webp?v=toppings-2`,
  })),
  I3 = [
    ["classic","Classic dough","手のばし生地"], ["thin","Thin crust","うすい生地"],
    ["thick","Thick crust","ふっくら生地"], ["dessert","Sweet base","デザート台"]
  ].map(([id,name,ja])=>({id,name,ja,image:`./assets/kitchen-v2/${id==="dessert"?"baked":"dough"}-${id}.webp`})),
  _ = Object.fromEntries(e3.map((e) => [e.id, e])),
  X3 = [];
function J3(e, a = e3.map((t) => t.id)) {
  let t = 2166136261;
  for (let o of e) t = Math.imul(t ^ o.charCodeAt(0), 16777619);
  let r = a.slice();
  for (let o = r.length - 1; o > 0; o--) {
    ((t ^= t << 13), (t ^= t >>> 17), (t ^= t << 5));
    let i = (t >>> 0) % (o + 1);
    [r[o], r[i]] = [r[i], r[o]];
  }
  return r;
}
var f3 = ["cheese", "mascarpone"];
function n2(e, a) {
  let t = J3(e + ":shops", [...new Set(a)]),
    r = Object.fromEntries(t.map((o) => [o, []]));
  return (t.length && J3(e).forEach((o, i) => r[t[i % t.length]].push(o)), r);
}
var O = (e, a = document) => a.querySelector(e),
  V2 = O("#app"),
  g3 = O("#modal-root"),
  Z = (e) =>
    String(e ?? "").replace(
      /[&<>"']/g,
      (a) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[a],
    ),
  x3 = (e) =>
    [
      "",
      "One",
      "Two",
      "Three",
      "Four",
      "Five",
      "Six",
      "Seven",
      "Eight",
      "Nine",
      "Ten",
    ][e] || String(e),
  t3 = (e) => "\xA5" + Number(e).toLocaleString("en-US"),
  r3 = (e, a = "") =>
    `<img class="${a}" src="${e.image}" alt="${Z(e.name)}" draggable="false">`,
  F3 = (e) => JSON.parse(JSON.stringify(e)),
  n = {
    session: null,
    data: null,
    page: "builder",
    demo: !1,
    teacher: null,
    classId: "",
    teacherTab: "roster",
    viewId: null,
    selectedTopping: null,
    selectedPiece: null,
    quantity: 1,
    orderTopping: null,
    filter: "",
    dirty: !1,
    saving: !1,
    saveTimer: null,
    editGeneration: 0,
    savePromise: null,
    undo: [],
    modal: null,
    returnFocus: null,
    selectedKeepers: [],
    keeperClass: null,
    keeperVersion: null,
  },
  B3 = null,
  U3 = null,
  W2 = { scale: 1, x: 0, y: 0 },
  M3 = 0,
  c3 = null,
  Q3 = null,
  j3 = null,
  N3 = 0;
function L3(e, a = !1) {
  ((n.scanMessage = e), (n.scanBad = a));
  let t = O("#scan-status");
  t && ((t.textContent = e), (t.className = a ? "error" : "muted"));
}
// No QR encoder, camera, or scanner ships in this standalone build.
const w3 = { start() {}, stop() {} };
const a2 = {default:{async toDataURL(){throw new Error('QR is not available in the offline edition.')}}};
function G(e, a = !1) {
  let t = O("#toast");
  ((t.textContent = e),
    (t.className = "show" + (a ? " bad" : "")),
    clearTimeout(Q3),
    (Q3 = setTimeout(() => (t.className = ""), 4500)));
}
async function Q() { throw new Error('This edition runs offline.'); }
function G2() {
  return '<a class="brand" href="./" aria-label="Pizza Builder home"><img src="./assets/base-classic.webp" alt=""><span>PIZZA BUILDER<small>AROHA EIKAIWA \xB7 PIZZA LAB</small></span></a>';
}
const teacherRoute = false;
function demoButton(css) {
 return '<button type="button" class="'+css+'" data-act="demo">Try the demo / デモを試す</button>';
}
function e5() {
  return '<header class="session-actions"><span class="account-name">Pizza Maker · Offline</span></header>';
}
function t5() {
  if (n.session) return "";
  return '<footer class="footer"><span>AROHA EIKAIWA \xB7 Made for little pizza makers.</span><span>SHOP. SPEAK. CREATE.</span></footer>';
}
function H() {
  clearTimeout(bakeTimer);
  cancelSauceEffect?.();
  (B3?.destroy(), (B3 = null));
  let e = !!(n.session && n.session.enabled !== false && n.data && n.page === "builder");
  document.body.classList.toggle("maker-shop", !!(n.data && (n.page === "shop" || (n.demo && n.page === "demo-geordie"))));
  document.body.classList.toggle("signed-in", !!n.session);
  document.body.classList.toggle(
    "teacher-shop",
    !!(
      n.session?.kind === "teacher" &&
      !n.viewId &&
      n.teacherTab === "geordie-shop"
    ),
  );
  if (
    (document.body.classList.toggle("editing-pizza", e),
    (V2.innerHTML = `${n.demo ? '<div class="demo-strip"><b>OFFLINE KITCHEN</b><span>Saved on this device / この端末に保存されます</span><div class="demo-controls"><button data-act="demo-geordie">Geordie’s Shop</button><button data-act="demo-shopping">\u304A\u5BA2\u3055\u3093\u306E\u7DF4\u7FD2</button><button data-act="demo-builder">\u30D4\u30B6\u4F5C\u308A\u306B\u623B\u308B</button><button data-act="reset-demo">\u3084\u308A\u76F4\u3059</button></div></div>' : ""}<div class="shell">${e5()}${n.session ? (n.session.kind === "teacher" && !n.viewId ? (teacherRoute ? i5() : o5(true)) : r5()) : o5()}${t5()}</div>`),
    n.session?.enabled !== false && n.page === "builder" && n.data && !n.data.pizza.bake)
  ) {
    (l5(), T3());
    let a = O(".pizza-canvas"),
      t = O(".pizza-scene");
    B3 = Z2({
      canvas: a,
      scene: t,
      view: W2,
      onGesture: () => {
        (U3?.(), (N3 = Date.now() + 450));
      },
      onChange: (r) => {
        let o = O("[data-act=reset-zoom]");
        o &&
          ((o.hidden = r.scale <= 1.01),
          (o.textContent = Math.round(r.scale * 100) + "% \xB7 Fit"));
      },
    });
  }
  if ((n.session?.enabled !== false && n.page === "shopping" && n.data && w3.start(), !n.session)) {

  }
}
function o5() { return '<main class="empty card"><h1>Offline Pizza Workshop</h1></main>'; }
function r5() {
  if(n.session?.enabled===false)return waitingRoom();
  let e = n.data;
  if (!e) return '<div class="loading">Opening your kitchen\u2026</div>';
  if (n.demo && n.page === "demo-geordie") return g5(true);
  let a = e.settings;
  return `${n.viewId ? '<div class="teacher-view-bar"><span>Viewing a student pizza as a teacher</span><button data-act="back-teacher">← Back to class list</button></div>' : ""}${(n.page === "builder" && !a.building && !e.pizza.bake) || (n.page === "shop" && !a.selling) || (n.page === "shopping" && !a.shopping) ? '<div class="notice">\u5148\u751F\u304C\u3053\u306E\u30E2\u30FC\u30C9\u3092\u304A\u4F11\u307F\u306B\u3057\u3066\u3044\u307E\u3059\u3002\u518D\u958B\u3059\u308B\u307E\u3067\u5F85\u3063\u3066\u306D\u3002</div>' : ""}${n.page === "shop" ? a5() : n.page === "shopping" ? n5() : s5()}`;
}
function i2() {
  return typeof n.data.student.shop == "string"
    ? JSON.parse(n.data.student.shop)
    : n.data.student.shop;
}
function a5() {
  const toppings = i2(),
    cols = Math.min(5, Math.ceil(Math.sqrt(toppings.length))),
    rows = Math.ceil(toppings.length / cols);
  if (!toppings.length)
    return '<div class="empty card">\u4ECA\u56DE\u306F\u62C5\u5F53\u3059\u308B\u6750\u6599\u304C\u3042\u308A\u307E\u305B\u3093\u3002\u5148\u751F\u306B\u77E5\u3089\u305B\u3066\u306D\u3002</div>';
  return `<main class="teacher-shop-main maker-counter"><div class="maker-title"><h1>${Z(n.data.student.nickname)}’s shop</h1></div>
 <section class="shop-front card" aria-label="Toppings"><div class="products" style="grid-template:repeat(${rows},minmax(0,1fr)) / repeat(${cols},minmax(0,1fr))">
 ${toppings
   .map((id) => {
     const t = _[id];
     return `<button type="button" class="product product-order" data-act="order-topping" data-id="${id}" ${n.data.settings.selling ? "" : "disabled"} aria-label="Order ${t.name}">
 <img src="./assets/shop-counter-v1/${id}.webp" alt=""><span class="tray-tag">${t.name} <b>${t3(t.price)}</b></span></button>`;
   })
   .join("")}</div></section></main>`;
}
function n5() {
  let e = n.data,
    a = e.shops.filter(
      (t) =>
        t.role === "shopkeeper" &&
        t.id !== e.student.id &&
        (!n.filter || t.shop.includes(n.filter)),
    );
  return `<main><div class="shopping-top"><section class="wallet card"><div><div class="section-label">YOUR PIZZA BUDGET</div><div class="amount">${t3(e.balance)}</div></div><div><b style="font-size:12px">\u304A\u3055\u3044\u3075</b><p class="muted">\u6700\u521D\u306E\u304A\u91D1\uFF1A1,000\u5186<br>\u8CB7\u3063\u305F\u6750\u6599\u306F\u30D4\u30B6\u4F5C\u308A\u3067\u4F7F\u3048\u308B\u3088\u3002</p></div></section><section class="scan-card card"><h2>Practice shopping</h2><p class="muted">Choose an ingredient from a practice shop below. Your wallet and purchases stay on this device.</p></section></div><section class="shop-directory"><div class="directory-header"><div><span class="section-label">PRACTICE SHOPS</span><h2>Find your toppings <small class="muted">\xB7 ${a.length} shops</small></h2></div><select id="shop-filter" aria-label="\u30C8\u30C3\u30D4\u30F3\u30B0\u3067\u304A\u5E97\u3092\u63A2\u3059"><option value="">All toppings \xB7 \u3059\u3079\u3066</option>${e3.map((t) => `<option value="${t.id}" ${n.filter === t.id ? "selected" : ""}>${t.name} \xB7 ${t.ja}</option>`).join("")}</select></div><div class="shop-grid">${
    a
      .map(
        (t) =>
          `<article class="mini-shop card"><div class="row between"><h3>${Z(t.nickname)}\u2019s shop</h3>${t.attendance ? `<span class="tag">NO. ${t.attendance}</span>` : ""}</div><div class="mini-menu">${t.shop
            .map((r) => {
              let o = _[r];
              return `<div class="row">${r3(o)}<span class="name">${o.name}<small>${o.ja} \xB7 ${f3.includes(o.id) ? "\u30D4\u30B6\uFF11\u679A\u5206" : "\uFF11\u500B\u3042\u305F\u308A"}</small></span><span class="price">${t3(o.price)}</span>${n.demo ? `<button class="btn subtle small" data-act="demo-buy" data-id="${r}" ${e.balance < o.price ? "disabled" : ""}>\u8CB7\u3046</button>` : ""}</div>`;
            })
            .join("")}</div></article>`,
      )
      .join("") ||
    '<div class="empty card"><p>\u307E\u3060\u304A\u5E97\u304C\u3042\u308A\u307E\u305B\u3093\u3002</p><p class="muted">\u5148\u751F\u304C\u304A\u5E97\u306E\u4EBA\u3092\u9078\u3076\u3068\u3001\u304A\u5E97\u304C\u898B\u3048\u308B\u3088\u3002</p></div>'
  }</div></section>${
    e.history.length
      ? `<section class="history card"><h2>Your shopping bag</h2><p class="muted">\u304A\u8CB7\u3044\u7269\u304C\u7D42\u308F\u3063\u305F\u3089\u3001\u5148\u751F\u304C\u30D4\u30B6\u4F5C\u308A\u306E\u753B\u9762\u306B\u5207\u308A\u66FF\u3048\u308B\u3088\u3002</p>${e.history
          .slice(0, 12)
          .map(
            (t) =>
              `<div class="history-row">${r3(_[t.topping])}<div><b>${_[t.topping].name} \xD7 ${t.quantity}</b><p class="muted">${Z(t.seller_name)}\u2019s shop</p></div><b>${t3(t.total)}</b></div>`,
          )
          .join("")}</section>`
      : ""
  }</main>`;
}
const kitchenArt = name => './assets/kitchen-v2/' + name + '.webp';
const pizzaSauces = {
  tomato:{name:'Tomato sauce',ja:'トマト',color:'#c73917'},
  pesto:{name:'Pesto',ja:'バジル',color:'#638121'},
  white:{name:'White sauce',ja:'ホワイト',color:'#fff1ce'},
  ketchup:{name:'Ketchup',ja:'ケチャップ',color:'#b92617'}
};

function finishedRecipe(pizza) {
  return !!pizza.bake && pizza.bake.readyAt <= ovenNow();
}

function isColdPizza(pizza) {
  return pizza.base==='dessert' && (!pizza.bake || pizza.bake.method==='chill');
}
const dessertOnlyToppings=new Set(['peach','strawberry','banana','blueberry','kiwi','mango','mascarpone']);
function toppingAllowedForBase(base,id) {
  return id==='pineapple'||(base==='dessert'?dessertOnlyToppings.has(id):!dessertOnlyToppings.has(id));
}
function normalizeForBase(pizza) {
  if (!pizza || pizza.bake || !Array.isArray(pizza.pieces)) return 0;
  const kept=pizza.pieces.filter(piece=>toppingAllowedForBase(pizza.base,piece.topping));
  let changed=pizza.pieces.length-kept.length;
  pizza.pieces=kept;
  if(pizza.base==='dessert'){
    if(pizza.cheese){pizza.cheese=false;changed++;}
    if(pizza.sauce!==null){pizza.sauce=null;changed++;}
  } else if(pizza.mascarpone){pizza.mascarpone=false;changed++;}
  return changed;
}
function finishLabel(pizza){return isColdPizza(pizza)?'Chill / 冷やす':'Cook / 焼く';}
function recipeLayers(pizza,cooked) {
  const cold=isColdPizza(pizza);
  if(cold)cooked=false;
  // The previous edition baked sauce into the base image on its finished pizzas.
  const legacy = !!pizza.bake && !Object.hasOwn(pizza,'sauce');
  const baseImage = legacy ? './assets/base-'+pizza.base+'.webp' :
    kitchenArt((cold||cooked?'baked-':'dough-')+pizza.base);
  const layers = [{id:'base',src:baseImage,inset:2,alt:I3.find(b=>b.id===pizza.base)?.name||'Pizza base'}];
  if (pizza.sauce && pizzaSauces[pizza.sauce])
    layers.push({id:'sauce',src:kitchenArt('sauce-'+pizza.sauce),inset:10,alt:pizzaSauces[pizza.sauce].name});
  if (pizza.cheese)
    layers.push({id:'cheese',src:cooked||legacy?'./assets/melted-cheese.webp':kitchenArt('scatter-cheese'),inset:11,alt:cooked?'Melted cheese':'Scattered shredded cheese'});
  if (pizza.mascarpone)
    layers.push({id:'mascarpone',src:cold||cooked||legacy?'./assets/spread-mascarpone.webp':kitchenArt('scatter-mascarpone'),inset:11,alt:'Mascarpone'});
  return layers;
}

function layerMarkup(pizza,cooked) {
  return recipeLayers(pizza,cooked).map(layerImageMarkup).join('');
}
function layerImageMarkup(layer) {
    const type = layer.id==='mascarpone'?'cheese-layer mascarpone-layer':layer.id+'-layer';
    return `<img class="pizza-layer ${type}" data-layer="${layer.id}" src="${layer.src}" alt="${Z(layer.alt)}" draggable="false" style="left:${layer.inset}%;top:${layer.inset}%;width:${100-layer.inset*2}%;height:${100-layer.inset*2}%">`;
}
function foundationKey(pizza) {
  return [pizza.base,pizza.sauce||'',Number(pizza.cheese),Number(!!pizza.mascarpone)].join('|');
}
function l2(pizza,preview=false,cooked=finishedRecipe(pizza)) {
  return `<div class="pizza-stage${cooked?' baked':''}" ${preview?'':'id="pizza-stage" role="group" aria-label="Pizza" tabindex="0"'}><div class="board"></div><div class="pizza-foundation" data-recipe="${Z(foundationKey(pizza))}">${layerMarkup(pizza,cooked)}</div>${pizza.pieces.map(piece=>c2(piece,preview,cooked,pizza)).join('')}</div>`;
}
function toppingImage(id,cooked,pizza) {
  if(pizza && isColdPizza(pizza)) cooked=['chicken','shrimp','bacon','sausage','tuna'].includes(id);
  return cooked ? './assets/'+id+'.webp?v=toppings-2' : _[id].image;
}
function condimentRack() {
  return `<section class="condiments" aria-label="Sauces"><div class="condiment-heading"><h2>ソース</h2><button type="button" class="sauce-clear" data-act="no-sauce" ${n.data.pizza.sauce&&canEditPizza()?'':'disabled'}>なし</button></div><div class="sauce-bottles">${Object.entries(pizzaSauces).map(([id,sauce])=>`<button type="button" class="sauce-choice" data-sauce="${id}" aria-label="${sauce.name} / ${sauce.ja}" aria-pressed="${n.data.pizza.sauce===id}" ${canEditPizza()&&n.data.pizza.base!=='dessert'?'':'disabled'}><img src="${kitchenArt('bottle-'+id)}" alt="" draggable="false"><span>${sauce.ja}</span></button>`).join('')}</div></section>`;
}

function applySauce(id) {
  if (!canEditPizza() || n.modal || (id!==null&&(n.data.pizza.base==='dessert'||!Object.hasOwn(pizzaSauces,id)))) return;
  if(n.data.pizza.sauce!==id) {
    p3();
    n.data.pizza.sauce=id;
    a3();
  }
  n.selectedTopping=n.selectedPiece=null;
  o3();
  if(id) squirtSauce(id);
}

let cancelSauceEffect;
function squirtSauce(id) {
  cancelSauceEffect?.();
  const stage=O('#pizza-stage');
  const sauce=stage?.querySelector('[data-layer=sauce]');
  if(!sauce || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
  const mask=document.createElement('canvas');
  mask.width=mask.height=384;
  const ctx=mask.getContext('2d');
  if(!ctx)return;
  mask.className='sauce-trail';
  sauce.after(mask);
  const dispenser=document.createElement('div');
  dispenser.className='sauce-dispenser';
  dispenser.setAttribute('aria-hidden','true');
  dispenser.style.setProperty('--sauce-color',pizzaSauces[id].color);
  dispenser.innerHTML=`<img src="${kitchenArt('bottle-'+id)}" alt="" draggable="false"><i></i>`;
  stage.append(dispenser);
  sauce.style.visibility='hidden';
  let frame;
  const stop=()=>{
    cancelAnimationFrame(frame);
    mask.remove();dispenser.remove();sauce.style.visibility='';sauce.style.opacity='';
    if(cancelSauceEffect===stop)cancelSauceEffect=null;
  };
  cancelSauceEffect=stop;
  const started=performance.now();
  const point=t=>{
    const angle=t*Math.PI*5.7-Math.PI/2,r=t*168;
    return [192+Math.cos(angle)*r,192+Math.sin(angle)*r];
  };
  function animate(now) {
    if(!sauce.isConnected){stop();return;}
    const progress=Math.min(1,(now-started)/1050);
    const t=Math.min(1,progress/.87),steps=Math.ceil(t*100);
    ctx.clearRect(0,0,384,384);
    ctx.lineWidth=68;ctx.lineCap='round';ctx.lineJoin='round';
    ctx.strokeStyle=pizzaSauces[id].color;ctx.beginPath();ctx.moveTo(192,192);
    for(let i=1;i<=steps;i++)ctx.lineTo(...point(t*i/steps));
    ctx.stroke();
    if(sauce.complete&&sauce.naturalWidth) {
      ctx.globalCompositeOperation='source-in';ctx.drawImage(sauce,0,0,384,384);
      ctx.globalCompositeOperation='source-over';
    }
    const [x,y]=point(t);
    dispenser.style.left=(10+80*x/384)+'%';dispenser.style.top=(10+80*y/384)+'%';
    if(progress>.87){
      const blend=(progress-.87)/.13;
      sauce.style.visibility='';sauce.style.opacity=String(blend);
      dispenser.style.opacity=String(1-blend);
    }
    if(progress<1)frame=requestAnimationFrame(animate);
    else {sauce.style.opacity='';stop();}
  }
  frame=requestAnimationFrame(animate);
}

function A3(e) {
  return `left:${e.x}%;top:${e.y}%;width:${_[e.topping].size * (e.scale ?? 1)}%;transform:translate(-50%,-50%) rotate(${e.rotation}deg)`;
}
function c2(e, a = !1, cooked=false,pizza=n.data?.pizza) {
  let t = _[e.topping];
  return `<${a ? "span" : "button"} class="placed${!a && n.selectedPiece === e.id ? " selected" : ""}" ${a ? "" : `data-piece="${Z(e.id)}" aria-label="${t.name}\u3002\u77E2\u5370\u30AD\u30FC\u3067\u79FB\u52D5\u3002R\u3067\u56DE\u8EE2\u3002Delete\u3067\u623B\u3059\u3002"`} style="${A3(e)}"><img src="${toppingImage(t.id,cooked,pizza)}" alt="" draggable="false"></${a ? "span" : "button"}>`;
}
function d2(e) {
  let a = n.data.pizza;
  return f3.includes(e)
    ? (n.data.inventory[e] || 0) - (a[e] ? 1 : 0)
    : (n.data.inventory[e] || 0) -
        a.pieces.filter((t) => t.topping === e).length;
}
let bakeClockOffset = 0;
let bakeTimer;
const finishImages=new Map();
let startingBake = false;

function ovenNow() {
  return Date.now() + (n.demo ? 0 : bakeClockOffset);
}

function canEditPizza() {
  return !!n.data?.settings.building && !n.data.pizza.bake && !startingBake;
}

function acceptSealedPizza(pizza) {
  clearTimeout(n.saveTimer);
  n.dirty = false;
  n.undo = [];
  n.selectedTopping = n.selectedPiece = null;
  n.data.pizza = pizza;
}

function finishImage(pizza) {
  const src=isColdPizza(pizza)?kitchenArt('fridge'):'./assets/wood-fired-oven.webp';
  if(!finishImages.has(src)){
    const image=new Image();image.src=src;
    finishImages.set(src,image.decode().catch(()=>{finishImages.delete(src);throw new Error('画像を読み込めませんでした。もう一度試してね。');}));
  }
  return finishImages.get(src);
}

function askToCook() {
  if (!canEditPizza()) return;
  const pizza=n.data.pizza, cold=isColdPizza(pizza);
  finishImage(pizza).catch(()=>{});
  m3(`<h2>${cold?'Chill your dessert pizza?':'Cook your pizza?'}</h2><p>${cold?'冷蔵庫':'窯'}に入れたら、ピザの名前やトッピングは変えられないよ。</p><div class="bake-choices"><button class="btn light" data-act="close-modal">Keep making / まだ作る</button><button class="btn" data-act="confirm-cook">${finishLabel(pizza)}</button></div><p class="error" id="bake-error" role="alert"></p>`);
}

async function startBaking() {
  if (!canEditPizza()) return;
  U3?.();
  startingBake = true;
  const actor = n.data.student.id, round = n.data.settings.round;
  const samePizza = () => n.data?.student.id === actor && n.data.settings.round === round;
  const dialog = g3.querySelector('.modal');
  dialog?.setAttribute('aria-busy', 'true');
  V2.inert = true;
  try {
    await finishImage(n.data.pizza);
    clearTimeout(n.saveTimer);
    await l3();
    if (!samePizza() || n.data.pizza.bake) return;
    const draft = F3(n.data.pizza);
    let pizza;
    if (n.demo) {
      const startedAt = Date.now();
      pizza = {...draft, revision:draft.revision+1, bake:{method:draft.base==="dessert"?"chill":"bake",startedAt, readyAt:startedAt+6800}};
      localStorage.setItem(pizzaDemoKey(), JSON.stringify({...n.data, pizza}));
    } else {
      ({pizza} = await Q('offline-disabled:pizza', {action:'bake', pizza:draft, round}));
    }
    if (!samePizza()) return;
    acceptSealedPizza(pizza);
    W();
    H();
  } catch (error) {
    const message = O('#bake-error');
    if (message) message.textContent = error.message;
    else G(error.message, true);
  } finally {
    startingBake = false;
    V2.inert = false;
    dialog?.removeAttribute('aria-busy');
  }
}

function ovenView(pizza) {
  const {startedAt, readyAt} = pizza.bake;
  const remaining = readyAt - ovenNow();
  if (remaining <= 0) {
    return `<main class="baked-pizza-view"><h1>${Z(pizza.name)}</h1><p role="status">${isColdPizza(pizza)?'Chilled and ready! / ひんやりデザートのできあがり！':'Fresh from the oven! / 焼き上がり！'}</p><div class="baked-pizza-art">${l2(pizza,true)}</div><button class="btn light" data-act="download">↓ Picture / 画像を保存</button></main>`;
  }
  const duration = readyAt - startedAt;
  const elapsed = Math.max(0, duration - remaining);
  bakeTimer = setTimeout(() => {
    if (n.page === 'builder' && n.data?.pizza.bake?.readyAt === readyAt) H();
  }, remaining + 20);
  if(isColdPizza(pizza))return `<main class="oven-view"><h1 role="status">Chilling your dessert pizza / 冷蔵庫で冷やしているよ</h1><div class="oven-frame"><div class="oven-scene fridge-scene" style="--bake-time:${duration}ms;--bake-delay:-${elapsed}ms"><img class="oven-stone" src="${kitchenArt('fridge')}" alt="冷蔵庫の棚"><div class="fridge-tray">${l2(pizza,true,false)}</div><div class="fridge-door" aria-hidden="true"><i></i></div></div></div></main>`;
  return `<main class="oven-view"><h1 role="status">Baking your pizza / ピザを焼いているよ</h1><div class="oven-frame"><div class="oven-scene" style="--bake-time:${duration}ms;--bake-delay:-${elapsed}ms"><img class="oven-stone" src="./assets/wood-fired-oven.webp" alt="薪の火が燃えるレンガのピザ窯"><div class="oven-firelight"></div><div class="oven-carriage"><div class="oven-plane"><div class="oven-peel"></div><div class="oven-raw-phase">${l2(pizza,true,false)}</div><div class="oven-cooked-phase" aria-hidden="true">${l2(pizza,true,true)}</div></div></div></div></div></main>`;
}

function s5() {
  if (n.data.pizza.bake) return ovenView(n.data.pizza);
  if(n.data.settings.building && normalizeForBase(n.data.pizza)) a3();
  let e = n.data,
    a = e.pizza,
    t = e3.filter((r) => e.inventory[r.id] > 0);
  return `<main class="builder-layout" aria-label="Pizza builder"><aside class="bases-panel card" aria-label="Pizza bases"><h2 class="editor-panel-title">Bases</h2><div class="base-list">${I3.map((r) => `<button class="base-choice ${a.base === r.id ? "active" : ""}" data-act="base" data-id="${r.id}" aria-label="${r.name}" title="${r.ja}" ${e.settings.building ? "" : "disabled"}>${r3(r)}<span><b>${r.name}</b><small>${r.ja}</small></span></button>`).join("")}</div></aside><section class="workbench"><div class="workbench-bar"><input id="pizza-name" value="${Z(a.name)}" maxlength="40" aria-label="\u30D4\u30B6\u306E\u540D\u524D" ${e.settings.building ? "" : "disabled"}><button class="zoom-fit" data-act="reset-zoom" aria-label="Fit pizza" hidden>Fit</button><span class="save-state" id="save-state" role="status">${n.dirty ? "\u4FDD\u5B58\u5F85\u3061\u2026" : "\u2713 Saved"}</span></div><div class="pizza-canvas"><div class="pizza-scene">${l2(a)}</div></div><div class="tool-bar"><button class="btn light" data-act="undo" ${!n.undo.length || !e.settings.building ? "disabled" : ""} title="\u5143\u306B\u623B\u3059">\u21B6 Undo</button><button class="btn light" data-act="clear-pizza" ${e.settings.building ? "" : "disabled"} title="\u6750\u6599\u3092\u30C8\u30EC\u30FC\u306B\u623B\u3059">Clear</button><button class="btn light" data-act="download" title="\u753B\u50CF\u3092\u4FDD\u5B58">\u2193 Picture</button><button class="btn oven-trigger" data-act="cook" ${e.settings.building ? "" : "disabled"}>${finishLabel(a)}</button></div></section><aside class="ingredients-panel card" aria-label="Bought toppings"><h2 class="editor-panel-title">Toppings</h2><div class="ingredient-list" id="ingredient-list">${t.map((r) => u2(r)).join("") || '<div class="empty"><h3>No toppings yet.</h3></div>'}</div>${condimentRack()}</aside></main>`;
}
function u2(e) {
  let a=d2(e.id);
  const compatible=toppingAllowedForBase(n.data.pizza.base,e.id);
  const hint=compatible?'':n.data.pizza.base==='dessert'?'Fruit or mascarpone only / フルーツとマスカルポーネだけ':'Sweet pizza only / デザートピザ用';
  return `<button class="ingredient ${n.selectedTopping===e.id?'active':''} ${compatible?'':'incompatible'}" data-ingredient="${e.id}" title="${hint}" ${a<=0||!n.data.settings.building||!compatible?'disabled':''} aria-label="${e.name}, ${a} ${f3.includes(e.id)?'pizza layers':'pieces'} available${compatible?'':', '+hint}"><span class="ingredient-thumb">${r3({...e,image:toppingImage(e.id,false,n.data.pizza)})}</span><span><b>${e.name}</b>${compatible?'':`<small>${n.data.pizza.base==='dessert'?'Not for sweet base':'Sweet base only'}</small>`}</span><span class="count">${f3.includes(e.id)?(n.data.pizza[e.id]?'\u2713':a+'\u679A'):a}</span></button>`;
}
function i5() {
  const e = n.teacher;
  if(e&&!e.settings)return emptyClassroom();
  if (e && n.teacherTab === "geordie-shop") return g5();
  if (!e) return '<div class="loading">Loading your class…</div>';
  const a = e.settings,
    online = e.students.filter((s) => s.online),
    keepers = n.selectedKeepers.filter((id) => online.some((s) => s.id === id)),
    count = keepers.length,
    valid = count > 0 && count < online.length;
  return `${s2("THE TEACHER'S TABLE", "Plan your pizza party.", "Choose online shopkeepers, then start shopping. Everyone else's tablet opens their wallet.", "ROUND " + a.round)}
 <main><div class="teacher-toolbar"><select id="teacher-class" aria-label="Class">${X3.map((s) => `<option value="${s}" ${n.classId === s ? "selected" : ""}>${Z(classLabel(s))}</option>`).join("")}</select>
 <button class="btn light small" data-act="pizza-pdf">Save pizzas as PDF</button><button class="btn subtle small" data-act="refresh-teacher">Refresh</button><button class="btn green small" data-act="geordie-shop">Geordie's shop</button><button class="btn light small" data-act="new-round">Reset activity</button></div>
 <section class="role-control card"><div class="row between"><p>Student game access / 生徒のアクセス</p><button class="toggle ${e.enabled ? "on" : ""}" data-act="shared-access">${e.enabled ? "OPEN / 利用可能" : "CLOSED / お休み"}</button></div><div class="row between"><div><span class="section-label">TEACHER-CONTROLLED ACTIVITY</span><h2>${a.activity ? "Shopping is open" : "Choose your shopkeepers"}</h2></div><span class="tag">${online.length} ONLINE</span></div>
 <div class="role-actions"><button class="btn light" data-act="random-half" ${online.length > 1 ? "" : "disabled"}>Random half</button><button class="btn" data-act="start-activity" ${valid ? "" : "disabled"}>${a.activity ? "Apply selected roles" : "Start shopping"}</button><button class="btn green" data-act="switch-roles" ${a.activity ? "" : "disabled"}>Switch roles</button><button class="btn light" data-act="end-activity" ${a.activity ? "" : "disabled"}>Finish shopping → Pizza builder</button></div>
 <p class="selection-summary" role="status">${count} shopkeepers · ${online.length - count} customers</p><details class="activity-help"><summary>How it works</summary><p class="muted">Checked online students become shopkeepers. The others become customers. Ingredients are assigned randomly and as evenly as possible. Random half selects the closest possible split.</p><p class="muted">Tablets change automatically while this game is open. Switching roles keeps purchased ingredients, pizzas and remaining money. Reset starts a new round with ¥1,000 each.</p></details>
 <div class="role-actions small-actions"><button class="toggle ${a.building ? "on" : ""}" data-act="teacher-toggle" data-id="building">Pizza building ${a.building ? "ON" : "OFF"}</button></div></section>
 <div class="row between" style="margin-bottom:18px"><div class="tabs-inline" style="margin:0"><button class="btn light small" data-act="teacher-tab" data-tab="roster">Class list</button><button class="btn light small" data-act="teacher-tab" data-tab="gallery">Pizza gallery</button></div><span class="muted">${e.students.length} accounts · ${online.length} online</span></div>
 ${n.teacherTab === "roster" ? `<div class="card table-wrap"><table class="teacher-table"><thead><tr><th>SHOPKEEPER</th><th>NO.</th><th>STUDENT</th><th>STATUS / ROLE / INGREDIENTS</th><th>WALLET</th><th>SALES</th><th>WORK</th></tr></thead><tbody>${e.students.map((s) => `<tr><td><input class="keeper-checkbox" type="checkbox" data-keeper="${Z(s.id)}" aria-label="Select ${Z(s.nickname)} as shopkeeper" ${keepers.includes(s.id) ? "checked" : ""} ${s.online ? "" : "disabled"}></td><td>${s.attendance || "—"}</td><td><b>${Z(s.nickname)}</b></td><td><small>${s.online ? "Online" : "Offline"} · ${a.activity ? (s.role === "shopkeeper" ? "Shopkeeper" : "Customer") : "Pizza builder"}</small><div>${a.activity ? s.shop.map((id) => `<img class="tiny" src="${_[id].image}" alt="${_[id].name}" title="${_[id].name}">`).join("") : ""}</div></td><td>${t3(s.balance ?? 1000)}</td><td>${t3(s.revenue)}</td><td><button class="btn subtle small" data-act="view-student" data-id="${s.id}">Open →</button></td></tr>`).join("")}</tbody></table>${e.students.length ? "" : '<div class="empty">No accounts are registered in this class.</div>'}</div>` : `<div class="teacher-grid">${e.students.map((s) => `<article class="gallery-card card">${l2(s.pizza || { base: "classic", cheese: false, pieces: [] }, true)}<h3>${Z(s.pizza?.name || "No toppings yet.")}</h3><p class="muted">${s.attendance || ""} · ${Z(s.nickname)}</p><button class="text-btn" data-act="view-student" data-id="${s.id}">Open pizza →</button></article>`).join("")}</div>`}</main>`;
}
function m3(e, a = !1) {
  (W(),
    (n.returnFocus = document.activeElement),
    (g3.innerHTML = `<div class="overlay"><section class="modal${a ? " wide" : ""}" role="dialog" aria-modal="true" aria-label="Pizza Builder dialog"><button class="close-modal" data-act="close-modal" aria-label="\u9589\u3058\u308B">\xD7</button>${e}</section></div>`),
    (n.modal = !0),
    O(".close-modal", g3)?.focus());
}
function p2() {
  w3.stop();
}
function W() {
  (p2(),
    M3++,
    (n.creatingOrder = 0),
    clearInterval(c3),
    (c3 = null),
    (g3.innerHTML = ""),
    (n.modal = null),
    n.returnFocus?.focus?.(),
    queueMicrotask(() => w3.start()));
}
function p3() {
  (n.undo.push(F3(n.data.pizza)), n.undo.length > 30 && n.undo.shift());
}
function a3() {
  ((n.dirty = !0),
    n.editGeneration++,
    clearTimeout(n.saveTimer),
    (n.saveTimer = setTimeout(() => l3().catch((a) => G(a.message, !0)), 900)));
  let e = O("#save-state");
  (e && (e.textContent = "\u4FDD\u5B58\u5F85\u3061\u2026"),
    n.demo && localStorage.setItem(pizzaDemoKey(), JSON.stringify(n.data)));
}
async function l3() {
  if (!n.data || !n.dirty) return;
  if (n.savePromise) return (await n.savePromise, n.dirty ? l3() : void 0);
  let e = n.editGeneration,
    a = F3(n.data.pizza),
    t = n.data.settings.round,
    r = O("#save-state");
  (r && (r.textContent = "\u4FDD\u5B58\u4E2D\u2026"),
    (n.savePromise = (async () => {
      await Promise.resolve();
      try {
        let o = n.demo
          ? { revision: a.revision + 1 }
          : await Q("offline-disabled:pizza", { pizza: a, round: t });
        if (!n.data || n.data.settings.round !== t) return;
        ((n.data.pizza.revision = o.revision),
          (n.dirty = n.editGeneration !== e),
          n.demo &&
            localStorage.setItem(pizzaDemoKey(), JSON.stringify(n.data)));
        let i = O("#save-state");
        i &&
          (i.textContent = n.dirty
            ? "\u4FDD\u5B58\u5F85\u3061\u2026"
            : "\u2713 Saved");
      } catch (o) {
        let i = O("#save-state");
        throw (
          i &&
            (i.textContent =
              "\u26A0 \u4FDD\u5B58\u3067\u304D\u307E\u305B\u3093"),
          o
        );
      } finally {
        n.savePromise = null;
      }
    })()),
    await n.savePromise,
    n.dirty &&
      (clearTimeout(n.saveTimer),
      (n.saveTimer = setTimeout(
        () => l3().catch((o) => G(o.message, !0)),
        900,
      ))));
}
function o3(e = null) {
  let a = O("#pizza-stage");
  if (!a) return;
  const t=n.data.pizza;
  const foundation=O('.pizza-foundation',a);
  const key=foundationKey(t);
  if(foundation.dataset.recipe!==key){
    cancelSauceEffect?.();
    foundation.innerHTML=layerMarkup(t,false);
    foundation.dataset.recipe=key;
    if(e && f3.includes(e)) foundation.querySelector('[data-layer="'+e+'"]')?.classList.add('spreading');
  }
  for(const bottle of document.querySelectorAll('[data-sauce]')) {
    bottle.setAttribute('aria-pressed',String(bottle.dataset.sauce===t.sauce));
    bottle.disabled=!canEditPizza()||t.base==='dessert';
  }
  const clear=O('[data-act=no-sauce]');
  if(clear)clear.disabled=!t.sauce||!canEditPizza();
  let o = new Map(
    [...a.querySelectorAll("[data-piece]")].map((s) => [s.dataset.piece, s]),
  );
  for (let s of t.pieces) {
    let l = o.get(s.id);
    (l || (a.insertAdjacentHTML("beforeend", c2(s)), (l = a.lastElementChild)),
      o.delete(s.id),
      (l.style.cssText = A3(s)),
      l.classList.toggle("selected", n.selectedPiece === s.id));
    const img=l.querySelector("img"),src=toppingImage(s.topping,false,t);
    if(img.getAttribute("src")!==src)img.src=src;
  }
  for (let s of o.values()) s.remove();
  const finish=O('[data-act=cook]');if(finish)finish.textContent=finishLabel(t);
  for (let s of document.querySelectorAll('[data-act="base"]'))
    s.classList.toggle("active", s.dataset.id === t.base);
  let i = O("[data-act=undo]");
  i && (i.disabled = !n.undo.length || !n.data.settings.building);
  let c = O("#ingredient-list");
  if (c && e3.some((s) => n.data.inventory[s.id] > 0)) {
    let s = c.scrollTop;
    ((c.innerHTML = e3
      .filter((l) => n.data.inventory[l.id] > 0)
      .map(u2)
      .join("")),
      (c.scrollTop = s));
  }
  T3();
}
function T3() {
  let e = O("#pizza-stage");
  if (!e) return;
  let a = n.data.pizza.pieces.find((o) => o.id === n.selectedPiece),
    t = O(".piece-controls", e);
  if (!a || !n.data.settings.building) {
    t?.remove();
    return;
  }
  ((!t || t.dataset.controls !== a.id) &&
    (t?.remove(),
    e.insertAdjacentHTML(
      "beforeend",
      `<div class="piece-controls" data-controls="${Z(a.id)}"><span class="rotation-line" aria-hidden="true"></span><span class="rotate-handle" data-rotate="${Z(a.id)}" role="slider" tabindex="0" aria-label="Rotate ${_[a.topping].name}" aria-valuemin="0" aria-valuemax="359"><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M20 7v5h-5M19 12a7 7 0 1 0-2 5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span><button class="remove-handle" data-act="remove-piece" aria-label="Return topping to tray" title="\u5177\u3092\u623B\u3059">\xD7</button></div>`,
    ),
    (t = e.lastElementChild)),
    (t.style.cssText = A3(a)));
  let r = O("[data-rotate]", t);
  (r.setAttribute("aria-valuenow", Math.round(a.rotation) % 360),
    r.setAttribute("aria-valuetext", (Math.round(a.rotation) % 360) + "\xB0"));
}
function q3(e) {
  let a = O("#pizza-stage")?.getBoundingClientRect();
  if (!a) return null;
  let t = {
    x: ((e.clientX - a.left) / a.width) * 100,
    y: ((e.clientY - a.top) / a.height) * 100,
  };
  return Math.hypot(t.x - 50, t.y - 50) <= 39 ? t : null;
}
function Y3(e, a, dragRotation) {
  if (!canEditPizza() || d2(e) <= 0 || !toppingAllowedForBase(n.data.pizza.base,e)) return;
  if (f3.includes(e)) {
    (p3(),
      (n.data.pizza[e] = !0),
      (n.selectedTopping = null),
      a3(),
      o3(dragRotation === undefined ? e : undefined),
      G(_[e].ja + "\u304C\u5E83\u304C\u3063\u305F\u3088\uFF01"));
    return;
  }
  if (!a) return;
  p3();
  let t = {
    id: crypto.randomUUID(),
    topping: e,
    ...a,
    rotation: dragRotation ?? Math.floor(Math.random() * 360),
    scale: 1,
  };
  (n.data.pizza.pieces.push(t), (n.selectedPiece = t.id), a3(), o3());
}
function l5() {
  let e = O("#pizza-stage");
  e &&
    e.addEventListener("click", (a) => {
      if (Date.now() < N3 || a.target.closest(".piece-controls")) return;
      let t = a.target.closest("[data-piece]");
      if (t) {
        ((n.selectedPiece = t.dataset.piece), (n.selectedTopping = null), o3());
        return;
      }
      n.selectedTopping
        ? Y3(n.selectedTopping, q3(a))
        : ((n.selectedPiece = null), o3());
    });
}
function inventoryDragPreview(ingredient, bottle, rotation, stage) {
  if (bottle) {
    const image = document.createElement("img");
    image.className = "drag-ghost";
    image.src = kitchenArt("bottle-" + bottle);
    image.alt = "";
    return image;
  }

  // Match the stage coordinate system, including its zoom and minimum piece width.
  const preview = document.createElement("div");
  preview.className = "ingredient-drag-preview";
  preview.setAttribute("aria-hidden", "true");
  const stageWidth = parseFloat(getComputedStyle(stage).width);
  preview.style.width = stageWidth + "px";
  preview.style.transform = `translate(-50%, -50%) scale(${stage.getBoundingClientRect().width / stageWidth})`;

  if (f3.includes(ingredient)) {
    const layers = recipeLayers({...n.data.pizza, [ingredient]:true}, false);
    preview.innerHTML = layerImageMarkup(layers.find(layer => layer.id === ingredient));
  } else {
    const piece = {topping:ingredient, x:50, y:50, rotation, scale:1};
    preview.innerHTML = c2(piece, true);
  }
  return preview;
}

document.addEventListener("pointerdown", (e) => {
  if (B3?.gesturing || (e.pointerType === "touch" && e.isPrimary === !1))
    return;
  let a = e.target.closest("[data-rotate]"),
    t = e.target.closest("[data-ingredient],[data-sauce]"),
    r = e.target.closest("[data-piece]");
  if (
    (!a && !t && !r) ||
    !canEditPizza() || n.modal ||
    e.button !== 0 ||
    t?.disabled
  )
    return;
  let o = { x: e.clientX, y: e.clientY },
    i = t?.dataset.ingredient,
    bottle = t?.dataset.sauce,
    c =
      a || r
        ? n.data.pizza.pieces.find(
            (h) => h.id === (a?.dataset.rotate || r.dataset.piece),
          )
        : null,
    s = !1,
    l = null,
    w = null,
    B = O("#pizza-stage").getBoundingClientRect(),
    u = c
      ? { x: B.left + (c.x / 100) * B.width, y: B.top + (c.y / 100) * B.height }
      : null,
    m = c ? Math.atan2(e.clientY - u.y, e.clientX - u.x) : 0,
    b = c?.rotation;
  const dragRotation = i ? Math.floor(Math.random() * 360) : undefined;
  if (c) {
    ((n.selectedPiece = c.id),
      (n.selectedTopping = null),
      (w = F3(n.data.pizza)));
    for (let h of document.querySelectorAll("[data-piece]"))
      h.classList.toggle("selected", h.dataset.piece === c.id);
    T3();
  }
  a && e.preventDefault();
  let g = () => {
      ((U3 = null),
        document.removeEventListener("pointermove", z),
        document.removeEventListener("pointerup", M),
        document.removeEventListener("pointercancel", C),
        l?.remove());
    },
    z = (h) => {
      if (
        h.pointerId === e.pointerId &&
        (!s &&
          Math.hypot(h.clientX - o.x, h.clientY - o.y) > 3 &&
          ((s = !0),
          (i||bottle) &&
            ((l = inventoryDragPreview(i, bottle, dragRotation, O("#pizza-stage"))),
            document.body.append(l))),
        !!s &&
          (h.preventDefault(),
          l &&
            ((l.style.left = h.clientX + "px"),
            (l.style.top = h.clientY + "px")),
          c))
      ) {
        if (a) {
          let d = Math.atan2(h.clientY - u.y, h.clientX - u.x),
            k = b + ((d - m) * 180) / Math.PI;
          (h.shiftKey && (k = Math.round(k / 15) * 15),
            (c.rotation = ((k % 360) + 360) % 360));
        } else {
          let d = q3(h);
          d && ((c.x = d.x), (c.y = d.y));
        }
        let f = [...document.querySelectorAll("[data-piece]")].find(
          (d) => d.dataset.piece === c.id,
        );
        (f && (f.style.cssText = A3(c)), T3());
      }
    },
    M = (h) => {
      if (h.pointerId === e.pointerId && (g(), s))
        if (((N3 = Date.now() + 350), i||bottle)) {
          let f = q3(h);
          if(f) { if(bottle)applySauce(bottle); else Y3(i,f,dragRotation); }
        } else
          (n.undo.push(w), n.undo.length > 30 && n.undo.shift(), a3(), o3());
    },
    C = () => {
      (g(), c && w && ((n.data.pizza = w), o3()));
    };
  ((U3 = C),
    document.addEventListener("pointermove", z, { passive: !1 }),
    document.addEventListener("pointerup", M),
    document.addEventListener("pointercancel", C));
});
async function R3() {
  n.demo ||
    (n.dirty && (await l3()),
    (n.data = await Q("offline-disabled:state")),
    (n.page = K3(n.data)),
    (n.dirty = !1),
    (n.undo = []));
}
let teacherRefreshId = 0;
async function u3(){
 const classId=n.classId,requestId=++teacherRefreshId;
 const next=await Q('offline-disabled:teacher'+(classId?'?classId='+encodeURIComponent(classId):''));
 if(classId!==n.classId||requestId!==teacherRefreshId||n.session?.kind!=='teacher'||n.viewId)return;
 n.teacher=next;X3.splice(0,X3.length,...next.classes);n.classId=next.settings?.id||'';
 if(!next.settings){n.selectedKeepers=[];H();return;}
 if(n.keeperClass!==n.classId||n.keeperVersion!==next.settings.role_version){n.selectedKeepers=next.students.filter(e=>e.online&&e.role==='shopkeeper').map(e=>e.id);n.keeperClass=n.classId;n.keeperVersion=next.settings.role_version;}
 n.selectedKeepers=n.selectedKeepers.filter(id=>next.students.some(s=>s.id===id&&s.online));H();
}
function Z3() {
  let e = ["Mia", "Haru", "Yui", "Leo", "Sora", "Kai"],
    a = n2("pizza-demo", e);
  return {
    student: {
      id: "demo",
      nickname: "Pizza Maker",
      attendance: 7,
      shop: "[]",
      role: "customer",
    },
    settings: {
      id: "demo",
      round: 1,
      shopping: 0,
      selling: 0,
      building: 1,
      activity: 0,
      role_version: 0,
    },
    balance: 1e3,
    inventory: {},
    pizza: {
      base: "classic",
      sauce: null,
      cheese: !1,
      mascarpone: !1,
      pieces: [],
      name: "My pizza",
      revision: 0,
    },
    shops: e.map((t, r) => ({
      id: "demo-shop-" + r,
      nickname: t,
      attendance: r + 1,
      role: "shopkeeper",
      shop: a[t],
    })),
    history: [],
    revenue: 0,
    catalog: e3,
    bases: I3,
  };
}
function pizzaDemoKey(){return 'aroha-pizza-offline-v1';}
function V3(e = !1) {
  if(n.session?.role!=='local')throw new Error('Offline session not initialized.');
  let a = !e && localStorage.getItem(pizzaDemoKey());
  try {
    n.data = a ? JSON.parse(a) : Z3();
  } catch {
    n.data = Z3();
  }
  const draft=n.data.pizza;
  if(draft&&!draft.bake&&!Object.hasOwn(draft,'sauce')){
    draft.sauce=({classic:'tomato',thin:'tomato',thick:'tomato',pesto:'pesto',white:'white'})[draft.base]||null;
    if(['white','pesto'].includes(draft.base))draft.base='classic';
  }
  let t = n.data.history.reduce((r, o) => r + o.total, 0);
  ((n.data.balance = Math.max(0, 1e3 - t)),
    (n.demo = !0),
    (n.session = { ...n.session,kind: "student" }),
    (n.page = "builder"),
    (n.selectedTopping = null),
    (n.selectedPiece = null),
    (n.undo = []),
    (n.dirty = !1),
    H());
}
async function c5() {
  if(n.dirty) await l3();
  W();
  n.page = 'builder';
  H();
}
function d5(e) {
  if (!n.data.settings.selling || !i2().includes(e)) return;
  n.orderTopping = e;
  if (f3.includes(e)) {
    n.quantity = 1;
    H();
    m3('<p role="status">Creating QR code…</p>');
    return u5();
  }
  H();
  let a = _[e];
  m3(
    `<div class="eyebrow" style="justify-content:center">TAKE AN ORDER</div><h2>How many?</h2><div class="checkout-item">${r3(a)}<div><b>${a.name}</b><p class="muted">${t3(a.price)} each</p></div></div><p class="muted">\u6CE8\u6587\u306E\u6570\u3092\u9078\u3093\u3067\u306D\u3002\u3059\u3050\u306BQR\u30B3\u30FC\u30C9\u304C\u51FA\u308B\u3088\u3002</p><div class="order-quantities">${Array.from(
      { length: 10 },
      (t, r) => r + 1,
    )
      .map(
        (t) =>
          `<button data-act="order-quantity" data-quantity="${t}" aria-label="${x3(t)} ${t === 1 ? "piece" : "pieces"}"><strong>${t}</strong><small>${x3(t)}</small><span>${t3(a.price * t)}</span></button>`,
      )
      .join("")}</div><p class="muted" id="order-creating" role="status"></p>`,
  );
}
async function u5() {
  if (n.creatingOrder) return;
  let e = ++M3;
  n.creatingOrder = e;
  let a = [...g3.querySelectorAll('[data-act="order-quantity"]')];
  a.forEach((r) => (r.disabled = !0));
  let t = O("#order-creating");
  t &&
    (t.textContent =
      "QR\u30B3\u30FC\u30C9\u3092\u4F5C\u3063\u3066\u3044\u307E\u3059\u2026");
  try {
    let r = _[n.orderTopping],
      o = n.demo
        ? await Q("offline-disabled:practice-order", {
            action: "create",
            device: practiceDevice(),
            topping: r.id,
            quantity: f3.includes(r.id) ? 1 : n.quantity,
          })
        : await Q("offline-disabled:checkout", { topping: r.id, quantity: n.quantity }),
      i = new URL(location.origin);
    i.searchParams.set(n.demo ? "practice" : "buy", n.demo ? o.id : o.code);
    let c = await a2.default.toDataURL(i.href, {
      width: 360,
      margin: 2,
      errorCorrectionLevel: "M",
    });
    if (M3 !== e || !n.modal || n.page !== "shop") return;
    (m3(
      `<div class="eyebrow" style="justify-content:center">YOUR ORDER IS READY</div><h2>Here you are!</h2><p class="muted">\u304A\u5BA2\u3055\u3093\u306BQR\u30B3\u30FC\u30C9\u3092\u898B\u305B\u3066\u306D\u3002</p><img class="qr" src="${c}" alt="\u304A\u4F1A\u8A08\u306EQR\u30B3\u30FC\u30C9"><div class="checkout-item">${r3(r)}<div><b>${r.name} \xD7 ${o.quantity}</b><p class="muted">${t3(o.total)}</p></div></div><p class="muted" id="order-status">\u652F\u6255\u3044\u3092\u5F85\u3063\u3066\u3044\u307E\u3059 \xB7 10\u5206\u9593\u6709\u52B9</p>${n.demo ? '<p class="muted">\u30C7\u30E2\u7528\u306EQR\u30B3\u30FC\u30C9\u3067\u3059\u3002</p>' : ""}`,
    ),
      (c3 = setInterval(async () => {
        try {
          let s = await Q(
              n.demo
                ? "offline-disabled:practice-order?action=status&device=" +
                    practiceDevice() +
                    "&code=" +
                    o.id
                : "offline-disabled:order?code=" + o.code,
            ),
            l = O("#order-status");
          if (!l) return;
          s.status === "paid"
            ? ((l.className = "status-paid"),
              (l.textContent =
                "\u2713 Thank you! \u304A\u652F\u6255\u3044\u5B8C\u4E86"),
              clearInterval(c3),
              n.demo || (n.data = await Q("offline-disabled:state")),
              H())
            : s.status === "cancelled"
              ? ((l.textContent =
                  "役割が変わったよ。このQRコードは使えません。"),
                clearInterval(c3))
              : s.expires < Date.now() / 1e3 &&
                ((l.textContent =
                  "\u6642\u9593\u5207\u308C\u3067\u3059\u3002\u65B0\u3057\u3044QR\u30B3\u30FC\u30C9\u3092\u51FA\u3057\u3066\u306D\u3002"),
                clearInterval(c3));
        } catch (s) {
          clearInterval(c3);
          let l = O("#order-status");
          l && (l.textContent = s.message);
        }
      }, 6e3)));
  } finally {
    n.creatingOrder === e &&
      ((n.creatingOrder = 0),
      a.forEach((r) => {
        r.isConnected && (r.disabled = !1);
      }),
      t?.isConnected &&
        (t.textContent =
          "\u6570\u3092\u9078\u3093\u3067\u3001\u3082\u3046\u4E00\u5EA6\u305F\u3081\u3057\u3066\u306D\u3002"));
  }
}
function practiceDevice() {
  let key = sessionStorage.getItem("pizza-practice-device");
  if (!key) {
    key = crypto.randomUUID();
    sessionStorage.setItem("pizza-practice-device", key);
  }
  return key;
}
function p5(raw) {
  try {
    const url = new URL(raw);
    if (url.origin !== location.origin) return "";
    return url.searchParams.has("practice")
      ? "demo:" + url.searchParams.get("practice")
      : url.searchParams.get("buy") || "";
  } catch {
    return "";
  }
}
async function f2(code) {
  n.checkingPurchase = true;
  W();
  try {
    if (code.startsWith("demo:") !== !!n.demo)
      throw Error(
        n.demo
          ? "デモ用のQRコードを使ってね。"
          : "このQRコードはデモ専用です。",
      );
    if (n.demo) {
      const order = await Q(
        "offline-disabled:practice-order?action=preview&device=" +
          practiceDevice() +
          "&code=" +
          encodeURIComponent(code.slice(5)),
      );
      H3({
        ...order,
        topping: order.item.id,
        item: _[order.item.id],
        practice: true,
      });
      return;
    }
    if (!/^\d{6}$/.test(code)) throw Error("お店のQRコードを読み直してね。");
    H3(await Q("offline-disabled:checkout?code=" + code));
  } finally {
    n.checkingPurchase = false;
  }
}
function H3(e) {
  n.pendingPurchase = e;
  let a = e.item || _[e.topping],
    t = n.data.balance >= e.total;
  m3(
    `<div class="eyebrow" style="justify-content:center">CHECK YOUR ORDER</div><h2>Looks delicious.</h2><p class="muted">${Z(e.seller_name || "Demo")}\u2019s shop</p><div class="checkout-item">${r3(a)}<div><b>${a.name} \xD7 ${e.quantity}</b><p class="muted">${a.ja} \xB7 ${e.quantity}${f3.includes(a.id) ? "\u679A\u5206" : " pieces"}</p></div></div>${n.demo && !e.practice && !f3.includes(a.id) ? `<label style="margin-top:16px">How many? \xB7 \u500B\u6570</label><div class="quantity" style="justify-content:center"><button data-act="demo-quantity" data-delta="-1" aria-label="One less" ${e.quantity <= 1 ? "disabled" : ""}>\u2212</button><output>${e.quantity}</output><button data-act="demo-quantity" data-delta="1" aria-label="One more" ${e.quantity >= 10 ? "disabled" : ""}>+</button></div>` : ""}<div class="checkout-total">${t3(e.total)}</div><p class="muted">${t3(n.data.balance)} \u2192 ${t3(n.data.balance - e.total)}</p>${t ? "" : '<p class="error" style="margin-top:12px">\u304A\u91D1\u304C\u8DB3\u308A\u306A\u3044\u3088\u3002</p>'}<button class="btn full" data-act="pay" ${t ? "" : "disabled"}>Pay \xB7 \u304A\u652F\u6255\u3044</button><button class="text-btn" data-act="close-modal">\u3084\u3081\u308B</button>`,
  );
}
async function f5() {
  let e = n.pendingPurchase;
  if (e) {
    if (n.demo) {
      if (n.data.balance < e.total)
        throw new Error(
          "\u304A\u91D1\u304C\u8DB3\u308A\u306A\u3044\u3088\u3002",
        );
      if (e.practice) {
        await Q("offline-disabled:practice-order", {
          action: "pay",
          device: practiceDevice(),
          code: e.id,
        });
        if (n.data.history.some((row) => row.id === e.id)) return;
      }
      ((n.data.balance -= e.total),
        (n.data.inventory[e.topping] =
          (n.data.inventory[e.topping] || 0) + e.quantity),
        n.data.history.unshift({ ...e, seller_name: e.seller_name || "Demo" }),
        localStorage.setItem(pizzaDemoKey(), JSON.stringify(n.data)));
    } else {
      let a = await Q("offline-disabled:pay", { code: e.code });
      n.data = a.state;
    }
    ((n.pendingPurchase = null),
      m3(
        `<div class="eyebrow" style="justify-content:center">A GOOD CHOICE</div><h2>Thank you!</h2><div class="checkout-item">${r3(_[e.topping])}</div><p class="muted">${_[e.topping].name}\u304C\u6750\u6599\u306B\u52A0\u308F\u3063\u305F\u3088\u3002</p><button class="btn full" data-act="close-modal">Keep shopping \xB7 \u304A\u8CB7\u3044\u7269\u3092\u7D9A\u3051\u308B</button>`,
      ),
      H());
  }
}
async function m5() {
  (w3.stop({ reset: !0 }), await w3.start({ retry: !0 }));
}
async function pizzaArtwork(e) {
  let a = document.createElement("canvas");
  ((a.width = 1200), (a.height = 1380));
  let t = a.getContext("2d");
  ((t.fillStyle = "#faf7ed"),
    t.fillRect(0, 0, a.width, a.height),
    (t.fillStyle = "#29392f"),
    (t.font = "46px system-ui"),
    (t.textAlign = "center"),
    t.fillText(e.name, 600, 84));
  async function r(o, i, c, s, l, w = 0) {
    let B = new Image();
    B.src = o;
    await B.decode();
    const fit = Math.min(s / B.naturalWidth, l / B.naturalHeight);
    const width = B.naturalWidth * fit, height = B.naturalHeight * fit;
    t.save();
    t.translate(i + s / 2, c + l / 2);
    t.rotate((w * Math.PI) / 180);
    t.drawImage(B, -width / 2, -height / 2, width, height);
    t.restore();
  }
  await r('./assets/board-oak-v1.webp',0,130,1200,1200);
  const cooked=finishedRecipe(e);
  for(const layer of recipeLayers(e,cooked)){
    const offset=layer.inset*12,side=1200-2*offset;
    t.filter=cooked&&layer.id==='base'&&!Object.hasOwn(e,'sauce')?'saturate(1.18) brightness(.90)':'none';
    await r(layer.src,offset,130+offset,side,side);
  }
  t.filter='none';
  for (let o of e.pieces) {
    let i = _[o.topping].size * (o.scale ?? 1) * 12;
    await r(
      toppingImage(o.topping,cooked,e),
      o.x * 12 - i / 2,
      130 + o.y * 12 - i / 2,
      i,
      i,
      o.rotation,
    );
  }
  return a;
}
async function h5() {
  (await l3(), await document.fonts.load("46px system-ui"));
  let a = await pizzaArtwork(n.data.pizza),
    t = a.getContext("2d");
  ((t.font = "17px system-ui"),
    (t.fillStyle = "#778074"),
    t.fillText("PIZZA BUILDER \xB7 AROHA EIKAIWA", 600, 1355),
    a.toBlob((o) => {
      let i = URL.createObjectURL(o),
        c = document.createElement("a");
      ((c.href = i),
        (c.download = "My_Pizza.png"),
        c.click(),
        setTimeout(() => URL.revokeObjectURL(i), 1e3));
    }, "image/png"));
}
async function k5(e) {
  (n.dirty && (await l3()),
    W(),
    w3.stop({ reset: !0 }),
    (n.scanMessage = ""),
    (n.scanBad = !1),
    (n.page = e),
    (n.selectedPiece = null),
    (n.selectedTopping = null),
    n.demo || (await R3()),
    H(),
    window.scrollTo({ top: 0 }));
}
document.addEventListener("click", async (e) => {
  if (Date.now() < N3 || startingBake) return;
  const bottle=e.target.closest("[data-sauce]");
  if(bottle){if(!bottle.disabled)applySauce(bottle.dataset.sauce);return;}
  let a = e.target.closest("[data-ingredient]");
  if (a && !a.disabled) {
    let o = a.dataset.ingredient;
    f3.includes(o)
      ? Y3(o, null)
      : ((n.selectedTopping = n.selectedTopping === o ? null : o),
        (n.selectedPiece = null),
        o3());
    return;
  }
  let t = e.target.closest("[data-act]");
  if (!t || t.disabled) return;
  let r = t.dataset.act;
  if (['base','undo','clear-pizza','confirm-clear','remove-piece'].includes(r) && !canEditPizza()) return;
  t.disabled = !0;
  try {
    switch (r) {
      case "geordie-shop":
        ((n.teacherTab = "geordie-shop"), H());
        break;
      case "geordie-back":
        (W(), (n.teacherTab = "roster"), H());
        break;
      case "geordie-topping":
        await w5(t.dataset.id);
        break;
      case "geordie-quantity":
        await v5(t.dataset.id, Number(t.dataset.quantity));
        break;
      case "demo":
        V3();
        break;
      case "demo-geordie":
        if (n.demo) {
          W();
          n.page = "demo-geordie";
          H();
        }
        break;
      case "demo-shopping":
        (W(),
          (n.data.settings.activity = 1),
          (n.data.settings.shopping = 1),
          (n.data.settings.selling = 1),
          (n.data.student.role = "customer"),
          (n.page = "shopping"),
          H());
        break;
      case "demo-switch":
        (W(),
          (n.data.settings.activity = 1),
          (n.data.settings.selling = 1),
          (n.data.student.role = "shopkeeper"),
          (n.data.student.shop = JSON.stringify(
            Object.values(n2("demo-seller", ["demo"]))[0],
          )),
          (n.page = "shop"),
          H());
        break;
      case "demo-builder":
        (W(), (n.data.settings.activity = 0), (n.page = "builder"), H());
        break;
      case "random-half": {
        const online = n.teacher.students
          .filter((s) => s.online)
          .map((s) => s.id);
        for (let i = online.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [online[i], online[j]] = [online[j], online[i]];
        }
        n.selectedKeepers = online.slice(0, Math.round(online.length / 2));
        H();
        break;
      }
      case "start-activity":
        await S3("start-activity", { shopkeeperIds: n.selectedKeepers });
        break;
      case "switch-roles":
        await S3("switch-roles");
        break;
      case "end-activity":
        await S3("end-activity");
        break;
      case "reset-demo":
        (W(), localStorage.removeItem(pizzaDemoKey()), V3(!0));
        break;
      case "account-password":
        await showAccountPassword();break;
      case "shared-access":
        await Q("offline-disabled:teacher/access",{classId:n.classId,enabled:!n.teacher.enabled});await u3();break;
      case "logout":
        await c5();
        break;
      case "nav":
        await k5(t.dataset.page);
        break;
      case "order-topping":
        await d5(t.dataset.id);
        break;
      case "order-quantity":
        ((n.quantity = Number(t.dataset.quantity)), H(), await u5());
        break;
      case "close-modal":
        W();
        break;
      case "scan":
        await m5();
        break;
      case "pay":
        await f5();
        break;
      case "demo-quantity": {
        let o = n.pendingPurchase;
        if (n.demo && o) {
          let i = Math.max(
            1,
            Math.min(10, o.quantity + Number(t.dataset.delta)),
          );
          H3({ ...o, quantity: i, total: _[o.topping].price * i });
        }
        break;
      }
      case "demo-buy": {
        let o = _[t.dataset.id];
        H3({
          topping: o.id,
          item: o,
          quantity: 1,
          total: o.price,
          seller_name: "Demo",
        });
        break;
      }
      case "reset-zoom":
        B3?.reset();
        break;
      case "no-sauce":
        applySauce(null); break;
      case "cook":
        askToCook(); break;
      case "confirm-cook":
        await startBaking(); break;
      case "base": {
        const nextBase=t.dataset.id;
        if(!I3.some(base=>base.id===nextBase)||n.data.pizza.base===nextBase) break;
        p3();
        n.data.pizza.base=nextBase;
        const returned=normalizeForBase(n.data.pizza);
        n.selectedPiece=n.selectedTopping=null;
        a3();
        o3();
        if(returned)G('Ingredients for the other pizza type were returned to your tray. / 合わない材料はトレーに戻したよ。');
        break;
      }
      case "save-pizza":
        (await l3(),
          G(
            n.demo
              ? "\u30C7\u30E2\u3092\u4FDD\u5B58\u3057\u305F\u3088\u3002"
              : "\u30D4\u30B6\u3092\u4FDD\u5B58\u3057\u305F\u3088\u3002",
          ));
        break;
      case "undo": {
        let o = n.undo.pop();
        o &&
          ((o.revision = n.data.pizza.revision),
          (n.data.pizza = o),
          (n.selectedPiece = null),
          a3(),
          o3());
        break;
      }
      case "clear-pizza":
        m3(
          '<h2>A fresh canvas?</h2><p class="muted">\u30D4\u30B6\u306E\u5177\u3092\u3059\u3079\u3066\u30C8\u30EC\u30FC\u306B\u623B\u3057\u307E\u3059\u3002\u8CB7\u3063\u305F\u6750\u6599\u306F\u306A\u304F\u306A\u308A\u307E\u305B\u3093\u3002</p><button class="btn full" data-act="confirm-clear">\u5177\u3092\u623B\u3059</button><button class="text-btn" data-act="close-modal">\u3084\u3081\u308B</button>',
        );
        break;
      case "confirm-clear":
        (p3(),
          (n.data.pizza.sauce = null),
          (n.data.pizza.pieces = []),
          (n.data.pizza.cheese = !1),
          (n.data.pizza.mascarpone = !1),
          (n.selectedPiece = null),
          a3(),
          W(),
          H());
        break;
      case "remove-piece":
        m2();
        break;
      case "download":
        (await h5(),
          G(
            "\u30D4\u30B6\u306E\u753B\u50CF\u3092\u4FDD\u5B58\u3057\u305F\u3088\u3002",
          ));
        break;
      case "pizza-pdf":
        await pizzaClassPDF(t);
        break;
      case "refresh-teacher":
        await u3();
        break;
      case "teacher-toggle":
        (await Q("offline-disabled:teacher/action", {
          classId: n.classId,
          action: t.dataset.id,
          enabled: !n.teacher.settings[t.dataset.id],
        }),
          await u3());
        break;
      case "new-round":
        m3(
          '<h2>A new pizza party?</h2><p class="muted">Students receive ¥1,000 and start with empty ingredients and pizzas. Choose roles again. Previous records are retained.</p><button class="btn full" data-act="confirm-round">Start new round</button><button class="text-btn" data-act="close-modal">Cancel</button>',
        );
        break;
      case "confirm-round":
        (await Q("offline-disabled:teacher/action", {
          classId: n.classId,
          action: "new-round",
          roleVersion: n.teacher.settings.role_version,
        }),
          W(),
          await u3(),
          G("Started a new round."));
        break;
      case "teacher-tab":
        ((n.teacherTab = t.dataset.tab), H());
        break;
      case "view-student":
        ((n.viewId = t.dataset.id), (n.page = "builder"), await R3(), H());
        break;
      case "back-teacher":
        (n.dirty && (await l3()),
          (n.viewId = null),
          (n.data = null),
          await u3());
        break;
    }
  } catch (o) {
    G(o.message, !0);
  } finally {
    t.isConnected && (t.disabled = !1);
  }
});
function m2() {
  if (!canEditPizza()) return;
  let e = n.data.pizza.pieces.findIndex((a) => a.id === n.selectedPiece);
  e >= 0 &&
    (p3(),
    n.data.pizza.pieces.splice(e, 1),
    (n.selectedPiece = null),
    a3(),
    o3());
}

document.addEventListener("change", async (e) => {
  try {
    if (e.target.dataset.keeper) {
      let a = e.target.dataset.keeper;
      ((n.selectedKeepers = e.target.checked
        ? [...new Set([...n.selectedKeepers, a])]
        : n.selectedKeepers.filter((t) => t !== a)),
        H());
    }
    (e.target.id === "shop-filter" && ((n.filter = e.target.value), H()),
      e.target.id === "teacher-class" &&
        ((n.classId = e.target.value), await u3()));
  } catch (a) {
    G(a.message, !0);
  }
});
document.addEventListener("input", (e) => {
  e.target.id === "pizza-name" &&
    canEditPizza() &&
    ((n.data.pizza.name = e.target.value), a3());
});
document.addEventListener("keydown", (e) => {
  if (startingBake) { e.preventDefault(); return; }
  if (n.modal) {
    if (e.key === "Escape") {
      W();
      return;
    }
    if (e.key === "Tab") {
      let t = [
        ...g3.querySelectorAll("button:not(:disabled),input,a[href],select"),
      ];
      if (!t.length) return;
      let r = t[0],
        o = t.at(-1);
      e.shiftKey && document.activeElement === r
        ? (e.preventDefault(), o.focus())
        : !e.shiftKey &&
          document.activeElement === o &&
          (e.preventDefault(), r.focus());
    }
    return;
  }
  if (
    ["INPUT", "SELECT", "TEXTAREA"].includes(e.target.tagName) ||
    !canEditPizza() ||
    n.page !== "builder"
  )
    return;
  if (
    e.target.closest(".pizza-canvas") &&
    ["+", "=", "-", "0"].includes(e.key)
  ) {
    (e.preventDefault(),
      e.key === "0" ? B3?.reset() : B3?.zoomBy(e.key === "-" ? 1 / 1.2 : 1.2));
    return;
  }
  let a = n.data.pizza.pieces.find((t) => t.id === n.selectedPiece);
  if (a) {
    if (
      e.target.closest("[data-rotate]") &&
      [
        "ArrowLeft",
        "ArrowRight",
        "ArrowUp",
        "ArrowDown",
        "Home",
        "End",
      ].includes(e.key)
    ) {
      (e.preventDefault(),
        p3(),
        (a.rotation =
          e.key === "Home"
            ? 0
            : e.key === "End"
              ? 359
              : (a.rotation +
                  (["ArrowLeft", "ArrowDown"].includes(e.key) ? -1 : 1) *
                    (e.shiftKey ? 15 : 1) +
                  360) %
                360),
        a3(),
        o3());
      return;
    }
    if (e.key === "Delete" || e.key === "Backspace") (e.preventDefault(), m2());
    else if (e.key.toLowerCase() === "r")
      (p3(), (a.rotation = (a.rotation + 30) % 360), a3(), o3());
    else if (
      ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)
    ) {
      e.preventDefault();
      let t =
          a.x + (e.key === "ArrowLeft" ? -1 : e.key === "ArrowRight" ? 1 : 0),
        r = a.y + (e.key === "ArrowUp" ? -1 : e.key === "ArrowDown" ? 1 : 0);
      Math.hypot(t - 50, r - 50) <= 39 &&
        (p3(), (a.x = t), (a.y = r), a3(), o3());
    }
  }
});
window.addEventListener("beforeunload", (e) => {
  (p2(), n.dirty && !n.demo && (e.preventDefault(), (e.returnValue = "")));
});
async function h2() {
  let e = new URL(location.href),
    a = e.searchParams.get("buy");
  if (a && n.session?.kind === "student") {
    if (
      (e.searchParams.delete("buy"),
      history.replaceState({}, "", e),
      (n.page = K3(n.data)),
      H(),
      n.page !== "shopping")
    )
      return;
    await f2(a).catch((t) => G(t.message, !0));
  }
}
async function S3(e, a = {}) {
  if (n.keeperClass !== n.classId) return;
  (await Q("offline-disabled:teacher/action", {
    classId: n.classId,
    action: e,
    roleVersion: n.teacher.settings.role_version,
    ...a,
  }),
    await u3(),
    G(
      e === "switch-roles"
        ? "Roles switched."
        : e === "end-activity"
          ? "Everyone returned to pizza building."
          : "Shopping started.",
    ));
}
var O3 = !1;
async function k2() {
  if (
    !(
      O3 ||
      !n.session ||
      n.demo ||
      n.session.kind === "teacher" ||
      document.hidden ||
      n.viewId ||
      !n.data
    )
  ) {
    O3 = !0;
    try {
      let e = await Q("offline-disabled:state");
      if (!n.data || startingBake || n.data.student.id !== e.student.id) return;
      if (e.pizza.bake && !n.data.pizza.bake && e.settings.round === n.data.settings.round) {
        U3?.();
        acceptSealedPizza(e.pizza);
        W();
        H();
      }
      let a = e.settings.round !== n.data.settings.round,
        t =
          e.settings.role_version !== n.data.settings.role_version ||
          e.student.role !== n.data.student.role,
        r = ["shopping", "selling", "building", "activity"].some(
          (o) => e.settings[o] !== n.data.settings[o],
        );
      if (a || t || r)
        (n.dirty && !a && e.settings.building && (await l3()),
          clearTimeout(n.saveTimer),
          W(),
          w3.stop({ reset: !0 }),
          (n.pendingPurchase = null),
          (n.filter = ""),
          (n.selectedPiece = null),
          (n.selectedTopping = null),
          (n.undo = []),
          (n.dirty = !1),
          (n.data = { ...e, pizza: a ? e.pizza : n.data.pizza }),
          (n.page = K3(n.data)),
          H(),
          G(
            a
              ? "\u65B0\u3057\u3044\u30E9\u30A6\u30F3\u30C9\u304C\u59CB\u307E\u3063\u305F\u3088\u3002"
              : t
                ? "\u5148\u751F\u304C\u5F79\u5272\u3092\u5909\u3048\u305F\u3088\u3002"
                : "\u5148\u751F\u304C\u8A2D\u5B9A\u3092\u5909\u3048\u305F\u3088\u3002",
          ));
      else if (!n.dirty && !n.savePromise) {
        let o =
          JSON.stringify(e.inventory) !== JSON.stringify(n.data.inventory) ||
          e.balance !== n.data.balance ||
          e.revenue !== n.data.revenue;
        ((n.data = { ...e, pizza: n.data.pizza }), o && !n.modal && H());
      }
    } catch (e) {
      G(e.message, !0);
    } finally {
      O3 = !1;
    }
  }
}
function B2() {
  (clearInterval(j3), (j3 = setInterval(pizzaRoleTick, 1500)));
}
document.addEventListener("visibilitychange", () => {
  document.hidden || k2();
});
function B5() {
  n.session={role:'local',kind:'student',profile:{id:'workshop'},enabled:true};
  V3();
}
B5();
function g5(forDemo = false) {
  return `<main class="teacher-shop-main">
    <div class="teacher-shop-toolbar">
      <button class="btn light small shop-back" data-act="${forDemo ? 'demo-builder' : 'geordie-back'}">${forDemo ? 'Back to pizza' : '← Teacher menu'}</button>
      <h1><img src="./assets/shop-counter-v1/sign.webp" alt="Geordie’s Shop"></h1>
      ${forDemo ? '' : `<div class="shop-tools"><select id="teacher-class" aria-label="Class">${X3.map((t) => `<option value="${t}" ${n.classId === t ? "selected" : ""}>${Z(classLabel(t))}</option>`).join("")}</select>
        <button class="text-btn" data-act="logout">Sign out</button>
      </div>`}
    </div>
    <section class="shop-front card" aria-label="Ingredients">
      <div class="products">${e3
        .map(
          (t) => `
        <button type="button" class="product product-order" data-act="geordie-topping" data-id="${t.id}" aria-label="${forDemo ? 'Add' : 'Order'} ${t.name}">
          <img src="./assets/shop-counter-v1/${t.id}.webp" alt="" draggable="false">
          <span class="tray-tag">${t.name}</span>
        </button>`,
        )
        .join("")}
      </div>
    </section>
  </main>`;
}
function w5(e) {
  if (!_[e]) return;
  if (f3.includes(e)) {
    if (!n.demo) m3('<p role="status">Creating QR code…</p>');
    return v5(e, 1);
  }
  let a = _[e];
  m3(
    `<h2>How many?</h2><div class="checkout-item">${r3(a)}<b>${a.name}</b></div><div class="order-quantities">${Array.from(
      { length: 10 },
      (t, r) => r + 1,
    )
      .map(
        (t) =>
          `<button data-act="geordie-quantity" data-id="${e}" data-quantity="${t}"><strong>${t}</strong><small>${x3(t)}</small></button>`,
      )
      .join("")}</div>`,
  );
}
async function v5(e, a) {
  if (n.demo) {
    if (n.page !== "demo-geordie" || !_[e] || !Number.isInteger(a) ||
        a < 1 || a > 10 || (f3.includes(e) && a !== 1)) return;
    n.data.inventory[e] = (n.data.inventory[e] || 0) + a;
    localStorage.setItem(pizzaDemoKey(), JSON.stringify(n.data));
    W();
    G(_[e].name + " × " + a + " added to your ingredients.");
    return;
  }
  if (n.creatingOrder) return;
  let t = n.classId,
    r = ++M3;
  ((n.creatingOrder = r),
    g3
      .querySelectorAll('button[data-act="geordie-quantity"]')
      .forEach((o) => (o.disabled = !0)));
  try {
    let o = await Q("offline-disabled:teacher/shop/checkout", {
        classId: t,
        topping: e,
        quantity: a,
      }),
      i = new URL(location.origin);
    i.searchParams.set(
      o.testMode ? "practice" : "buy",
      o.testMode ? o.id : o.code,
    );
    let c = await a2.default.toDataURL(i.href, {
      width: 360,
      margin: 2,
      errorCorrectionLevel: "M",
    });
    if (
      M3 !== r ||
      !n.modal ||
      n.classId !== t ||
      n.teacherTab !== "geordie-shop"
    )
      return;
    (m3(
      `<h2>Here you are!</h2><img class="qr" src="${c}" alt="Free topping QR code"><div class="checkout-item">${r3(_[e])}<b>${_[e].name} \xD7 ${o.quantity}</b><span class="price">\xA50</span></div><p id="order-status" class="muted" role="status">${o.testMode ? "Demo QR · Scan in customer practice." : "Waiting for the customer…"}</p>`,
    ),
      (c3 = setInterval(async () => {
        try {
          let s = await Q(
              o.testMode
                ? "offline-disabled:practice-order?action=status&device=" +
                    practiceDevice() +
                    "&code=" +
                    o.id
                : "offline-disabled:teacher/shop/order?classId=" +
                    encodeURIComponent(t) +
                    "&code=" +
                    o.code,
            ),
            l = O("#order-status");
          if (!l) return;
          (s.status === "paid" ||
            s.status === "cancelled" ||
            s.expires < Date.now() / 1e3) &&
            ((l.textContent =
              s.status === "paid"
                ? "\u2713 Thank you!"
                : s.status === "cancelled"
                  ? "Order cancelled."
                  : "This QR code has expired."),
            clearInterval(c3));
        } catch (s) {
          clearInterval(c3);
          let l = O("#order-status");
          l && (l.textContent = s.message);
        }
      }, 3e3)));
  } finally {
    (n.creatingOrder === r && (n.creatingOrder = 0),
      g3
        .querySelectorAll('button[data-act="geordie-quantity"]')
        .forEach((o) => (o.disabled = !1)));
  }
}

// Each browser-rendered sheet becomes an A4 PDF page with a JPEG image.
async function classPDF(
  students,
  render,
  landscape,
  filename,
  className,
  progress,
) {
  if (!students.length)
    throw Error("There are no pizzas to print in this class.");
  const encoder = new TextEncoder(),
    chunks = [],
    offsets = [0];
  let size = 0;
  function put(value) {
    const bytes = typeof value === "string" ? encoder.encode(value) : value;
    chunks.push(bytes);
    size += bytes.length;
  }
  function object(id, body) {
    offsets[id] = size;
    put(id + " 0 obj\n");
    put(body);
    put("\nendobj\n");
  }
  put("%PDF-1.4\n");
  object(1, "<< /Type /Catalog /Pages 2 0 R >>");
  object(
    2,
    "<< /Type /Pages /Count " +
      students.length +
      " /Kids [" +
      students.map((_, i) => 3 + i * 3 + " 0 R").join(" ") +
      "] >>",
  );
  const pw = landscape ? 841.89 : 595.28,
    ph = landscape ? 595.28 : 841.89;
  for (const [i, student] of students.entries()) {
    progress?.(i + 1, students.length);
    const canvas = document.createElement("canvas");
    canvas.width = landscape ? 1754 : 1240;
    canvas.height = landscape ? 1240 : 1754;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await render(canvas, student);
    const w = 455,
      h = 128,
      x = canvas.width - w - 18,
      y = canvas.height - h - 18;
    ctx.save();
    ctx.fillStyle = "white";
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = "#697568";
    ctx.strokeRect(x, y, w, h);
    ctx.fillStyle = "#20372c";
    ctx.textAlign = "left";
    ctx.font = "bold 21px sans-serif";
    ctx.fillText(className + "  No. " + student.number, x + 14, y + 26);
    ctx.font = "16px sans-serif";
    ctx.fillText("Name", x + 14, y + 83);
    for (let line = 0; line < 4; line++) {
      ctx.strokeStyle = line === 2 ? "#af5454" : "#859484";
      ctx.lineWidth = line === 2 ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(x + 70, y + 44 + line * 21);
      ctx.lineTo(x + w - 14, y + 44 + line * 21);
      ctx.stroke();
    }
    ctx.restore();
    const blob = await new Promise((resolve, reject) =>
      canvas.toBlob(
        (b) =>
          b ? resolve(b) : reject(Error("Could not create the PDF page.")),
        "image/jpeg",
        0.9,
      ),
    );
    const bytes = new Uint8Array(await blob.arrayBuffer()),
      page = 3 + i * 3,
      img = page + 1,
      content = page + 2;
    object(
      page,
      "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " +
        pw +
        " " +
        ph +
        "] /Resources << /XObject << /Sheet " +
        img +
        " 0 R >> >> /Contents " +
        content +
        " 0 R >>",
    );
    offsets[img] = size;
    put(
      img +
        " 0 obj\n<< /Type /XObject /Subtype /Image /Width " +
        canvas.width +
        " /Height " +
        canvas.height +
        " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " +
        bytes.length +
        " >>\nstream\n",
    );
    put(bytes);
    put("\nendstream\nendobj\n");
    const op = "q " + pw + " 0 0 " + ph + " 0 0 cm /Sheet Do Q\n";
    object(
      content,
      "<< /Length " + op.length + " >>\nstream\n" + op + "endstream",
    );
    canvas.width = canvas.height = 1;
  }
  const xref = size;
  put("xref\n0 " + offsets.length + "\n0000000000 65535 f \n");
  for (const offset of offsets.slice(1))
    put(String(offset).padStart(10, "0") + " 00000 n \n");
  put(
    "trailer\n<< /Size " +
      offsets.length +
      " /Root 1 0 R >>\nstartxref\n" +
      xref +
      "\n%%EOF\n",
  );
  const pdf = new Blob(chunks, { type: "application/pdf" }),
    url = URL.createObjectURL(pdf),
    link = document.createElement("a");
  link.href = url;
  link.download = filename + ".pdf";
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return pdf;
}

async function pizzaClassPDF(button) {
  const id = n.classId,
    classLabel =
      classLabel(id);
  const data = await Q("offline-disabled:teacher?classId=" + encodeURIComponent(id));
  const rows = data.students
    .filter((s) => s.pizza)
    .map((s) => ({ pizza: s.pizza, number: s.attendance }))
    .sort((a, b) => a.number - b.number);
  await document.fonts.load("46px system-ui");
  try {
    await classPDF(
      rows,
      async (canvas, student) => {
        const pizza = await pizzaArtwork(student.pizza),
          ctx = canvas.getContext("2d");
        ctx.drawImage(pizza, 20, 72, 1200, 1380);
        pizza.width = pizza.height = 1;
      },
      false,
      "Class_Pizzas_" + id.replace(":", "-"),
      classLabel,
      (i, total) => (button.textContent = i + " / " + total),
    );
  } finally {
    button.textContent = "Save pizzas as PDF";
  }
}

var pizzaTeacherBusy = false,
  pizzaTeacherTime = 0;
async function pizzaRoleTick(){
 if(!n.session||n.demo||document.hidden||n.modal||pizzaTeacherBusy)return;
 if(n.session.enabled===false){
  if(Date.now()-pizzaTeacherTime<2900)return;
  pizzaTeacherBusy=true;pizzaTeacherTime=Date.now();
  try{const session=await Q('offline-disabled:session');n.session=session;if(session.enabled){await R3();H();await h2();}}catch(e){if(e.status!==401)G(e.message,true);}finally{pizzaTeacherBusy=false;}
 }else if(n.session.kind==='teacher'){
  if(teacherRoute&&!n.viewId&&Date.now()-pizzaTeacherTime>2900){pizzaTeacherBusy=true;try{await u3();pizzaTeacherTime=Date.now();}catch(e){G(e.message,true);}finally{pizzaTeacherBusy=false;}}
 }else await k2();
}

async function accountSession(){throw new Error('Accounts are unavailable offline.');}
function classLabel(){return 'Offline';}
function emptyClassroom(){return o5();}
function waitingRoom(){return o5();}
async function showAccountPassword(){throw new Error('No account is needed.');}
