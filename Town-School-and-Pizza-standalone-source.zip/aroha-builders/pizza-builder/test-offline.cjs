const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),{randomUUID}=require('node:crypto');
const appJs=fs.readFileSync(__dirname+'/app.js','utf8');
const store=new Map(), byID=new Map(), handlers=new Map();
let tm=0,clock=1000000; const timers=[];
class TestDate extends Date { static now(){return clock} }
class LocalImage { constructor(){this.naturalWidth=256;this.naturalHeight=256;} async decode(){assert.ok(require("node:fs").existsSync(require("node:path").join(__dirname,this.src)));} }
class Element {
  constructor(sel){this.sel=sel;this.dataset={};this.style={setProperty(){},cssText:''};this.classList={toggle(){},add(){},remove(){}};this.children=[]; }
  querySelector(s){return s.includes('[data-layer=')?null:get(s);}
  querySelectorAll(){return []}
  setAttribute(){} getAttribute(){return '';}
  addEventListener(){} removeEventListener(){} focus(){} remove(){}
  getBoundingClientRect(){return {x:0,y:0,left:0,top:0,width:500,height:500,right:500,bottom:500};}
  insertAdjacentHTML(_dest,s){this.lastElementChild=new Element('component');this.lastElementChild.html=s;}
  after(){} append(){} replaceChildren(){} removeAttribute(){} getContext(){return null;}
}
const get=s=> (byID.has(s)||byID.set(s,new Element(s)),byID.get(s));
const document={
 querySelector:get,querySelectorAll:()=>[],activeElement:null,body:get('body'),
 addEventListener:(type,fn)=>(handlers.has(type)||handlers.set(type,[]),handlers.get(type).push(fn)),
 hidden:false,createElement:s=>new Element(s)
};
const c=vm.createContext({document,console,window:{addEventListener(){},removeEventListener(){},scrollTo(){},matchMedia(){return {matches:true}}},localStorage:{
 getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k)
},location:new URL('http://localhost/'),crypto:{randomUUID},Date:TestDate,Image:LocalImage,URL,URLSearchParams,setTimeout(fn,ms){timers.push([fn,ms]);return ++tm},clearTimeout(){},clearInterval(){},setInterval(){return ++tm;},queueMicrotask(){},performance:{now(){return 0;}},getComputedStyle(){return {width:'250'}}});
vm.runInContext(appJs, c, {filename:'Offline Pizza app.js'});
const exec=s=>vm.runInContext(s,c);
const click=async (act,dataset={})=>{
 const elt=new Element(act); elt.dataset={act,...dataset};
 const target={closest(sel){return sel==='[data-act]'?elt:null}};
 for(const f of handlers.get('click')||[]) await f({target,preventDefault(){}});
};
(async()=>{
 assert.match(get('#app').innerHTML,/OFFLINE KITCHEN/);
 assert.match(get('#app').innerHTML,/pizza-stage/);
 assert.equal(exec('n.demo'),true);
 assert.equal(exec('n.data.balance'),1000);
 await click('demo-shopping'); assert.equal(exec('n.page'),'shopping');
 assert.match(get('#app').innerHTML,/PRACTICE SHOPS/);
 assert.doesNotMatch(get('#app').innerHTML,/qr-video|data-act="scan"/);
 await click('demo-buy',{id:'basil'}); assert.equal(exec('n.pendingPurchase.quantity'),1);
 await click('demo-quantity',{delta:'1'}); assert.equal(exec('n.pendingPurchase.quantity'),2);
 await click('pay');
 assert.equal(exec('n.data.balance'),980);
 assert.equal(exec('n.data.inventory.basil'),2);
 await click('demo-geordie'); assert.equal(exec('n.page'),'demo-geordie');
 await click('geordie-topping',{id:'pepperoni'}); assert.match(get('#modal-root').innerHTML,/How many/);
 await click('geordie-quantity',{id:'pepperoni',quantity:'2'});
 await click('geordie-topping',{id:'peach'});
 await click('geordie-quantity',{id:'peach',quantity:'2'});
 assert.equal(exec('n.data.inventory.pepperoni'),2);
 assert.equal(exec('n.data.inventory.peach'),2);
 await click('demo-builder'); assert.equal(exec('n.page'),'builder');
 assert.equal(exec('d2("pepperoni")'),2);
 exec('Y3("pepperoni",{x:50,y:51},17)'); assert.equal(exec('n.data.pizza.pieces[0].rotation'),17);
 assert.match(exec('inventoryDragPreview("pepperoni", null, 17, document.querySelector("#pizza-stage")).innerHTML'),/13\.2%/);
 assert.match(exec('c2(n.data.pizza.pieces[0],true)'),/13\.2%/);
 assert.equal(exec('toppingAllowedForBase("classic","peach")'),false);
 assert.equal(exec('toppingAllowedForBase("dessert","pepperoni")'),false);
 assert.equal(exec('toppingAllowedForBase("dessert","pineapple")'),true);
 assert.equal(exec('isColdPizza({base:"dessert"})'),true);
 assert.match(exec('recipeLayers({base:"dessert",sauce:null,cheese:false,mascarpone:false},true)[0].src'),/baked-dessert/);
 assert.match(exec('toppingImage("peach",true,{base:"dessert"})'),/raw-peach\.webp/);
 assert.match(exec('toppingImage("pepperoni",true,{base:"classic"})'),/assets\/pepperoni\.webp/);
 const saved=JSON.parse(store.get('aroha-pizza-offline-v1'));
 assert.equal(saved.pizza.pieces[0].topping,'pepperoni');
 exec('V3()'); assert.equal(exec('n.data.pizza.pieces[0].rotation'),17);
 await click('cook'); assert.match(get('#modal-root').innerHTML,/Cook your pizza/);
 await click('confirm-cook');
 assert.equal(exec('n.data.pizza.bake.method'),'bake');
 assert.equal(exec('n.data.pizza.bake.readyAt')-clock,6800);
 assert.equal(exec('canEditPizza()'),false);
 assert.match(get('#app').innerHTML,/Baking your pizza/);
 exec('V3()'); assert.equal(exec('n.data.pizza.bake.method'),'bake');
 clock+=7000;exec('H()');assert.match(get('#app').innerHTML,/Fresh from the oven/);
 await click('reset-demo'); assert.equal(exec('n.data.pizza.bake'),undefined);
 await click('base',{id:'dessert'}); assert.equal(exec('n.data.pizza.base'),'dessert');
 await click('cook'); assert.match(get('#modal-root').innerHTML,/Chill your dessert pizza/);
 await click('confirm-cook'); assert.equal(exec('n.data.pizza.bake.method'),'chill');
 clock+=7000;exec('H()');assert.match(get('#app').innerHTML,/Chilled and ready/);
 await assert.rejects(exec('Q("anything")'),/runs offline/);
 assert.doesNotMatch(appJs,/aroha-eikaiwa\.com|\/api\/|\bfetch\(|\bWebSocket\b|\bgetUserMedia\b|hokuyo|asahi|北陽|朝日/i);
 console.log('PASS: real frontend boot, local shopping, placement, matched drag/canvas piece width, local reload, dessert/cooked logic, no live endpoints');
})().catch(e=>{console.error(e);process.exitCode=1});
