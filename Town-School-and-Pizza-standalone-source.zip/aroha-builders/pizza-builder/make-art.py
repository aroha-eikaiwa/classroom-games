"""Generate the offline pack's original, redistribution-safe placeholder artwork."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math, random
ROOT=Path(__file__).parent
COLORS={
'cheese':'#ffe4a1','pepperoni':'#ad3826','ham':'#e79794','bacon':'#a8524b','sausage':'#996441','chicken':'#e3b882','shrimp':'#ed906d','tuna':'#b96967','mushroom':'#a87b62','corn':'#f1c12e','green-pepper':'#41945d','red-pepper':'#d84b36','onion':'#c48cc4','tomato':'#d34332','olive':'#554269','pineapple':'#eec453','basil':'#2f874f','broccoli':'#557742','peach':'#f7ab70','strawberry':'#e64752','banana':'#f3cf7a','blueberry':'#5667ad','kiwi':'#89b54a','mango':'#f0a64a','mascarpone':'#fff5dc'}
SAUCES={'tomato':'#bf3525','pesto':'#6d8d3c','white':'#fff1cb','ketchup':'#a92826'}
def shape(img,size=256):
 d=ImageDraw.Draw(img)
 return d
def dark(h, factor=.72):
 v=bytes.fromhex(h.lstrip('#'));return tuple(max(0,min(255,int(x*factor))) for x in v)
def put(path,img):
 p=ROOT/'assets'/path;p.parent.mkdir(parents=True,exist_ok=True);img.save(p,'WEBP',quality=86,method=6)
def art(kind,base='classic',heated=False):
 img=Image.new('RGBA',(256,256)); d=shape(img); rng=random.Random(kind+base+str(heated))
 if kind=='base':
  col='#f2d5a1' if not heated else '#dca15d'; inner='#f8dfb4' if not heated else '#efba77'
  if base=='dessert': col,inner='#eaa46d','#f8d791'
  if base=='thin': col,inner=('#f5d9ae','#fae5bf') if not heated else ('#c88a4c','#e6b776')
  d.ellipse((3,3,253,253),fill=col,outline=dark(col),width=3); d.ellipse((22,22,234,234),fill=inner)
  for _ in range(115):
   x,y=rng.randrange(10,247),rng.randrange(10,247)
   if (x-128)**2+(y-128)**2<116**2:d.ellipse((x,y,x+2,y+2),fill=dark(col,.88))
 elif kind in ('sauce','spread'):
  col=SAUCES.get(base, COLORS.get(base,'#ffd263'))
  d.ellipse((6,6,250,250),fill=col); 
  for _ in range(80):
   x,y=rng.randrange(20,237),rng.randrange(20,237)
   if (x-128)**2+(y-128)**2<109**2:d.ellipse((x,y,x+2,y+2),fill=dark(col,.86))
 elif kind=='scatter':
  col=COLORS[base]
  for _ in range(130):
   x,y=rng.randrange(18,239),rng.randrange(18,239)
   if (x-128)**2+(y-128)**2<111**2:d.line([(x,y),(x+5,y-3)],fill=col,width=4)
 elif kind=='bottle':
  col=SAUCES[base];d.rounded_rectangle((65,63,191,240),radius=22,fill=col,outline=dark(col),width=5)
  d.polygon([(91,74),(108,16),(148,16),(165,74)],fill='#f8e5d1');d.rounded_rectangle((82,119,174,184),radius=8,fill='#fff5df')
  d.text((128,151),base.title(),fill='#63432d',anchor='mm',font=ImageFont.load_default(size=16))
 elif kind=='ingredient':
  col=COLORS[base]; col=('#%02x%02x%02x'%dark(col,.83)) if heated else col; border=dark(col,.71)
  if base in ('pepperoni','olive','blueberry','kiwi','tomato'):
   d.ellipse((8,12,248,244),fill=col,outline=border,width=10)
   if base=='olive':d.ellipse((72,68,184,188),fill='#705b81',outline=border,width=9)
   if base=='kiwi':d.ellipse((68,65,190,190),fill='#b9d27f')
   if base in ('pepperoni','kiwi','tomato'):
    for _ in range(20):
     x,y=rng.randrange(40,213),rng.randrange(41,212)
     if (x-128)**2+(y-129)**2<89**2:d.ellipse((x,y,x+8,y+7),fill=dark(col,.63) if base=='kiwi' else '#f0af81')
  elif base in ('peach','pineapple','banana','mango','onion','red-pepper','green-pepper'):
   d.pieslice((7,5,249,249),166,359,fill=border);d.pieslice((18,7,239,230),170,356,fill=col)
   d.arc((41,38,222,199),190,340,fill=dark(col,1.22),width=8)
  elif base=='strawberry':
   d.polygon([(50,50),(106,33),(154,36),(206,56),(212,111),(187,173),(128,242),(67,180),(42,112)],fill=col)
   for _ in range(22):
    x,y=rng.randrange(68,181),rng.randrange(60,174);d.ellipse((x,y,x+5,y+9),fill='#f8d889')
   d.polygon([(75,36),(108,50),(128,15),(148,50),(184,32),(153,69),(103,70)],fill='#498949')
  elif base in ('basil','broccoli'):
   for x,y in [(77,101),(128,64),(182,114),(136,147)]:d.ellipse((x-45,y-47,x+45,y+47),fill=col,outline=border,width=7)
   d.line([(86,221),(127,130)],fill=border,width=16)
  else:
   d.rounded_rectangle((14,44,242,210),radius=45,fill=col,outline=border,width=9)
   for _ in range(26):
    x,y=rng.randrange(42,215),rng.randrange(59,192);d.ellipse((x,y,x+4,y+4),fill=dark(col,.83))
 return img
for name in COLORS:
 put(f'kitchen-v2/raw-{name}.webp',art('ingredient',name)); cooked=art('ingredient',name,True);put(f'{name}.webp',cooked);put(f'shop-counter-v1/{name}.webp',art('ingredient',name))
for name in ('classic','thick','thin','dessert','white','pesto'):
 put(f'kitchen-v2/dough-{name}.webp',art('base',name)); cooked=art('base',name,True);put(f'kitchen-v2/baked-{name}.webp',cooked);put(f'base-{name}.webp',cooked)
for name in SAUCES:
 put(f'kitchen-v2/sauce-{name}.webp',art('sauce',name));put(f'kitchen-v2/bottle-{name}.webp',art('bottle',name))
for name in ('cheese','mascarpone'):put(f'kitchen-v2/scatter-{name}.webp',art('scatter',name))
put('melted-cheese.webp',art('spread','cheese'));put('spread-mascarpone.webp',art('spread','mascarpone'))
board=Image.new('RGBA',(512,512)); d=ImageDraw.Draw(board); d.rounded_rectangle((7,7,505,505),radius=80,fill='#b87e42',outline='#754c2b',width=8)
for y in range(53,470,35):d.arc((16,y-25,496,y+35),0,180,fill='#a66c37',width=2)
put('board-oak-v1.webp',board)
for name,color,text in [('kitchen-v2/fridge.webp','#b2d6df','FRIDGE'),('wood-fired-oven.webp','#a65f45','OVEN')]:
 im=Image.new('RGB',(640,420),color);dd=ImageDraw.Draw(im); dd.rounded_rectangle((127,62,513,358),radius=45,fill='#262224',outline='#fff2d5',width=8);dd.text((320,31),text,fill='#fff1d5',anchor='mm',font=ImageFont.load_default(size=26));put(name,im)
for name in ('sign','maker-sign'):
 im=Image.new('RGBA',(480,130));dd=ImageDraw.Draw(im);dd.rounded_rectangle((8,8,472,122),radius=26,fill='#714d30',outline='#e8bb71',width=9);dd.text((240,65),'Pizza Ingredient Shop',fill='#fff4d5',anchor='mm',font=ImageFont.load_default(size=31));put(f'shop-counter-v1/{name}.webp',im)
