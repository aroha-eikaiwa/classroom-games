import * as THREE from './vendor/three.module.js';

// Generated illustration sheet: four columns, two rows. Text is rendered here
// so every subject label stays accurate and legible at classroom scale.
import {POSTERS} from './poster-catalog.mjs';
export {POSTERS} from './poster-catalog.mjs';
const pictures = new Map();
let atlas;
if (typeof document !== 'undefined') {
 atlas = new Image(); atlas.decoding='async';
 atlas.onload=()=>{for(const p of pictures.values()){p.draw(p.context);p.texture.needsUpdate=true;}};
 atlas.src = new URL('./assets/interiors/school-poster-atlas.webp',import.meta.url).href;
 document.fonts?.load('42px "NH Handwriting"').then(()=>{for(const p of pictures.values()){p.draw(p.context);p.texture.needsUpdate=true;}}).catch(()=>{});
}
export function artworkMaterial(key,w,h,draw) {
 if(pictures.has(key))return pictures.get(key).material;
 if(typeof document==='undefined')return new THREE.MeshBasicMaterial({color:0xf2e9d9});
 const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
 const context=canvas.getContext('2d');draw(context);
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
 const material=new THREE.MeshLambertMaterial({map:texture,side:THREE.FrontSide});
 pictures.set(key,{draw,context,texture,material});return material;
}
// Canvas-drawn symbols keep these school rules exact and clear at small sizes.
function drawSafetyIcon(c,kind,accent){
 c.save();c.translate(256,320);c.fillStyle='#eef1e7';c.beginPath();c.arc(0,0,175,0,Math.PI*2);c.fill();
 const running=kind==='no-running';c.strokeStyle='#284b54';c.fillStyle='#284b54';c.lineWidth=25;c.lineCap='round';c.lineJoin='round';
 c.beginPath();c.arc(running?25:0,-102,25,0,Math.PI*2);c.fill();
 const paths=running?[[[8,-58],[-26,3],[27,38],[81,13]],[[-26,3],[-59,63],[-115,77]],[[2,-47],[49,-27],[92,-58]],[[0,-44],[-57,-56],[-84,-27]]]:[[[0,-55],[-13,21],[33,109]],[[-13,21],[-61,105]],[[0,-40],[48,6],[75,10]],[[0,-38],[-47,-6],[-67,32]]];
 for(const points of paths){c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.stroke();}
 if(running){c.strokeStyle=accent;c.lineWidth=21;c.beginPath();c.arc(0,0,174,0,Math.PI*2);c.stroke();c.beginPath();c.moveTo(-122,-122);c.lineTo(122,122);c.stroke();}
 else{c.strokeStyle=accent;c.lineWidth=9;c.beginPath();c.moveTo(-107,135);c.lineTo(107,135);c.stroke();}
 c.restore();
}
export function drawPoster(c,index,x=0,y=0,w=512,h=640) {
 const [title,subtitle,panel,accent,safety]=POSTERS[((index%POSTERS.length)+POSTERS.length)%POSTERS.length];
 c.save();c.translate(x,y);c.scale(w/512,h/640);
 c.fillStyle='#fcf8ed';c.fillRect(0,0,512,640);
 c.strokeStyle=accent;c.lineWidth=10;c.strokeRect(7,7,498,626);
 c.fillStyle=accent;c.textAlign='center';c.textBaseline='middle';c.font=safety?'bold 50px "Noto Sans JP", "Yu Gothic", sans-serif':'bold 33px Arial';c.fillText(title,256,53,466);
 if(safety)drawSafetyIcon(c,safety,accent);
 else if(atlas?.complete&&atlas.naturalWidth){
  const s=atlas.naturalWidth/4,t=atlas.naturalHeight/2;
  c.drawImage(atlas,(panel%4)*s,Math.floor(panel/4)*t,s,t,24,100,464,464);
 }
 c.fillStyle=accent;c.font='22px Arial';c.fillText(subtitle,256,600,466);c.restore();
}
export function posterMaterial(variant){return artworkMaterial('school-poster-'+variant,512,640,c=>drawPoster(c,variant));}

export const BOARD_CONTENT={
 classroom:['Today’s English','What do you like?','I like music.  I like art.'],
 science:['Plants need…','sunlight + water + air','seed → sprout → plant'],
 music:['Let’s make music','do   re   mi   fa   sol   la   ti   do','Listen. Keep the beat.'],
 art:['Warm & cool colours','red  orange  yellow','blue  green  purple'],
 cooking:['Let’s cook!','1. Wash    2. Cut    3. Mix','What ingredients do you need?'],
 teachers:['Today at school','8:30 Morning meeting','9:00 Lessons    12:00 Lunch']
};
const subjectPosters={classroom:[11,5],science:[1,9],music:[0,8],art:[2,10],cooking:[3,11],library:[4,12],gym:[7,5],restroom:[5,3],nurse:[3,5],entrance:[5,6],teachers:[6,13],principal:[4,5]};
function blackboardMaterial(type){
 return artworkMaterial('chalk-'+type,1536,320,c=>{
  c.fillStyle='#285e50';c.fillRect(0,0,1536,320);
  const rows=BOARD_CONTENT[type]||BOARD_CONTENT.classroom;
  c.textAlign='left';c.textBaseline='middle';c.fillStyle='#f4edd2';c.font='54px "NH Handwriting", cursive';c.fillText(rows[0],60,64,1400);
  c.fillStyle='#e4eddf';c.font='42px "NH Handwriting", cursive';c.fillText(rows[1],60,151,1390);c.fillText(rows[2],60,239,1390);
  if(type==='music'){
   c.fillStyle='#285e50';c.fillRect(700,195,785,95);c.strokeStyle='#dce9da';c.lineWidth=2;
   for(let i=0;i<5;i++){c.beginPath();c.moveTo(740,211+i*15);c.lineTo(1440,211+i*15);c.stroke();}
   for(let i=0;i<8;i++){const x=780+i*82,y=271-i*7.5;c.fillStyle='#f1e7c4';c.beginPath();c.ellipse(x,y,13,8,-.3,0,Math.PI*2);c.fill();c.fillRect(x+10,y-49,3,49);}
  }
 });
}
export function createClassroomArt(layout,type){
 const g=new THREE.Group();g.name='classroom-art';g.userData.softwareRoomInterior=true;
 if(typeof document==='undefined')return g;
 const variants=subjectPosters[type]||[5,6];
 for(const [i,p] of (layout.posters||[]).entries()){
  const plane=new THREE.Mesh(new THREE.PlaneGeometry(Math.min(p.width,p.height*.8),p.height),posterMaterial(variants[i%variants.length]));
  plane.geometry.userData.owned=true;plane.position.set(p.x,p.y,p.z);plane.rotation.y=p.rotation;plane.name='subject-poster';plane.userData.wallSide=p.side;g.add(plane);
 }
 if(layout.board&&BOARD_CONTENT[type]){
  const b=layout.board,plane=new THREE.Mesh(new THREE.PlaneGeometry(b.width-.06,b.height-.035),blackboardMaterial(type));
  plane.geometry.userData.owned=true;plane.position.set(b.x,b.y,b.z+.003);plane.name='blackboard-writing';plane.userData.wallSide='north';g.add(plane);
 }
 return g;
}
