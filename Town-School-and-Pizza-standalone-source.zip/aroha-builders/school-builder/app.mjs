import {ROOMS,BY_TYPE,DECORATIONS,W,H,createSchool,createDemoSchool,normalizeSchool,canPlaceRoom,canPlaceDecoration,addRoom,moveRoom,addDecoration,roomAt,roomDoor,drawCorridor,canDrawCorridor,deleteAt,validateSchool} from './core.mjs';
import {SchoolScene} from './scene.mjs';
import {SchoolWalk,joystickAxes} from './simulation.mjs';
import {beginBuildGesture,moveBuildGesture} from './view-input.mjs';
import {createSchoolNavigationGuide} from './navigation-guide.mjs';
import {interfaceLanguage,showLanguageSwitch,roomLabelText,roomLabelHtml} from './ui-language.mjs';
import {createSchoolVoice} from './school-voice.mjs';
import {createSchoolTeacherSpeech} from './teacher-speech.mjs';
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state={school:createDemoSchool(),mode:'build',tool:'hand',selected:null,moving:null,ground:false,grid:true,demo:true,session:null,studentId:null,revision:0,dirty:false,saving:false,saveBlocked:false,undo:[],redo:[],lang:localStorage.getItem('school-language')||'en',room:null,walk:null};
let scene,toastTimer,drag=null,ghost=null,frameAt=0,networkClock=0,raf;
const keys=new Set(),touches=new Map();
const movementStick={pointer:null,x:0,y:0};
const t=(en,ja)=>interfaceLanguage(state)==='ja'?ja:en;
const name=roomLabelText;
const roomLabelHTML=roomLabelHtml;
const studentPreferenceKey = 'school-student-avatar';
let soloStudentVariant = localStorage.getItem(studentPreferenceKey) === 'girl' ? 1 : 0;

function chooseStudent(onChoose){
 const choices=[['boy','男の子'],['girl','女の子']];
 showModal('キャラクターを選ぼう',
  '<div class="avatar-options">'+choices.map(([id,label])=>
   `<button type="button" data-avatar="${id}"><span class="avatar-illustration" aria-hidden="true">${id==='boy'?'👦':'👧'}</span><span>${label}</span></button>`).join('')+'</div>');
 for(const button of $('modal-body').querySelectorAll('[data-avatar]')){
  button.onclick=()=>{
   soloStudentVariant=button.dataset.avatar==='girl'?1:0;
   try{localStorage.setItem(studentPreferenceKey,button.dataset.avatar);}catch{}
   closeModal();
   schoolVoice.unlock();onChoose(soloStudentVariant);
  };
 }
}
function updateStudentCharacter(){
 if(state.room)scene.setStudentVariant(state.room.avatar??Number(state.room.code)%2);
 else if(state.mode==='walk')scene.setStudentVariant(soloStudentVariant);
}
let voiceMuted=localStorage.getItem('school-voice-muted')==='true';
let wrongWayTimer,teacherWarningUntil=0;
const schoolVoice=createSchoolVoice({muted:voiceMuted,onState:status=>{const canvas=$('scene');if(canvas)canvas.dataset.speechState=status;}});
const teacherSpeech=createSchoolTeacherSpeech({voice:schoolVoice});
const navigationGuide=createSchoolNavigationGuide({speech:schoolVoice.channel('navigation'),muted:voiceMuted,onWrongWay:show=>{
 const cross=$('wrong-way');clearTimeout(wrongWayTimer);cross.hidden=!show;
 if(show)wrongWayTimer=setTimeout(()=>{cross.hidden=true;},1700);
},onInstruction:text=>{
 const caption=$('navigation-instruction');if(caption)caption.textContent=text||'';
}});
function updateTeacherWarning(now,walking){
 const warning=$('teacher-warning'),bubble=$('teacher-bubble');
 warning.hidden=!walking||now>=teacherWarningUntil;
 const anchor=!warning.hidden&&state.walk?.scoldTime>0?scene.scoldingTeacherAnchor():null;
 bubble.hidden=!anchor;
 if(anchor){
  bubble.style.setProperty('--teacher-x',anchor.x+'%');
  bubble.style.setProperty('--teacher-y',anchor.y+'%');
 }
}
function onRoomSelected(def){if(!def||!BY_TYPE[def.type]||state.mode!=='build')return;schoolVoice.unlock();schoolVoice.resume();schoolVoice.room(def.en);}
function navigationContext(){return {school:state.school,player:state.walk?.player,targetId:state.walk?.targetId,arrived:state.walk?.arrived,mode:state.mode,localDirections:permitted('localDirections'),paired:!!state.room,paused:document.hidden||!document.hasFocus()||$('modal').open||$('start-dialog').open||!!state.walk?.pendingArrival||state.mode==='controller'&&!state.room?.peerConnected};}
function refreshCameraControls(){
 const walking=['walk','controller'].includes(state.mode),free=scene.cameraMode==='free';
 $('free-camera').hidden=!walking;$('follow-camera').hidden=!walking;
 $('free-camera').textContent=t('Free camera','自由カメラ');
 $('free-camera').classList.toggle('active',free);$('free-camera').setAttribute('aria-pressed',String(free));
 $('follow-camera').textContent=t('Behind player','固定カメラ');
 $('follow-camera').title=t('Keep the camera behind your character','プレイヤーの後ろにカメラを固定');
 $('follow-camera').classList.toggle('active',!free);$('follow-camera').setAttribute('aria-pressed',String(!free));
 if(!walking)$('scene').releaseFreeLook?.();
 const solo=state.mode==='walk'&&!state.room;
 $('voice-directions').hidden=!['build','walk','controller'].includes(state.mode);$('navigation-instruction').hidden=!solo;
 const soundLabel=voiceMuted?t('English audio off','英語の音声：オフ'):t('English audio on','英語の音声：オン');
 $('voice-directions').setAttribute('aria-label',soundLabel);$('voice-directions').title=soundLabel;$('voice-directions').classList.toggle('muted',voiceMuted);
 $('voice-directions').setAttribute('aria-pressed',String(!voiceMuted));
}

function toast(message,time=3200){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,time);}
function error(e){toast(e?.message||String(e),6000);console.error(e);}
function showModal(title,html){schoolVoice.pause();navigationGuide.pause();clearKeys();$('modal-title').textContent=title;$('modal-body').innerHTML=html;if(!$('modal').open)$('modal').showModal();}
function closeModal(){$('modal').close();clearKeys();}
function remember(){state.undo.push(JSON.stringify(state.school));if(state.undo.length>60)state.undo.shift();state.redo=[];}
function draftKey(){return 'aroha-school-standalone-v1';}
function localWrite(){try{localStorage.setItem(draftKey(),JSON.stringify({school:state.school,revision:state.revision,dirty:state.dirty,savedAt:Date.now()}));return true;}catch{toast(t('This device cannot keep a local copy.','この端末には保存できません。'));return false;}}
function changed(){state.dirty=true;scene.setSchool(state.school);updatePalette();refresh();if(localWrite())$('save-status').textContent=t('Saved on this device','この端末に保存済み');}
function permitted(cap){return cap!=='roomDirections';}
function roomSvg(def){const c=def.color||'#9fc5c4';return `<svg viewBox="0 0 76 56" aria-hidden="true"><path d="M8 23 38 9 68 23 38 39Z" fill="${c}"/><path d="M8 23v14l30 15V39Z" fill="#8ba6a7"/><path d="M38 39v13l30-15V23Z" fill="#c4d4cf"/><path d="M8 23V9l30 14v16M38 23 68 9v14" fill="none" stroke="#f8fbf9" stroke-width="5"/><path d="M22 26 30 22 38 26 30 30Zm17 8 8-4 8 4-8 4" fill="#fff8dd"/><path d="M38 39v-9" stroke="#075a82" stroke-width="3"/></svg>`;}
function updatePalette(){
 const list=state.ground?DECORATIONS:ROOMS,groundsReady=validateSchool(state.school).ready;
 if(!groundsReady&&DECORATIONS.some(def=>def.type===state.selected)){state.selected=null;state.tool='hand';state.moving=null;updateTools();}
 $('room-catalog').innerHTML=list.map(def=>{
  const count=state.school.rooms.filter(r=>r.type===def.type).length,disabled=state.ground?!groundsReady:!def.unlimited&&count;
  const size=state.ground?'':def.w+' × '+def.d,amount=count?' · '+(def.unlimited?count:'✓'):'';
  return `<button class="room-card ${state.selected===def.type?'selected':''}" data-room="${def.type}" ${disabled?'disabled':''} title="${esc(name(def))}" aria-label="${esc(name(def))}"><span class="room-thumb">${def.preview?'<img src="'+esc(def.preview)+'" alt="" loading="lazy">':roomSvg(def)}</span><span class="room-card-text">${roomLabelHTML(def)}${size||amount?'<span class="room-size">'+size+amount+'</span>':''}</span></button>`;
 }).join('');
 for(const b of $('room-catalog').querySelectorAll('[data-room]'))b.onclick=()=>{
  if(!permitted('builder'))return toast(t('Your teacher has locked building.','先生が編集をロックしています。'));
  state.selected=b.dataset.room;state.tool='place';state.moving=null;
  const def=BY_TYPE[state.selected];if(def)onRoomSelected(def);
  updateTools();updatePalette();
 };
}
function updateTools(){$('scene')?.cancelGesture?.();document.querySelectorAll('[data-tool]').forEach(b=>{b.classList.toggle('active',state.tool===b.dataset.tool);b.setAttribute('aria-pressed',String(state.tool===b.dataset.tool));});$('scene').style.cursor=state.tool==='hand'?'grab':'crosshair';scene.setGhost(null);ghost=null;}
function refresh(){applyControlLabels();updateStudentCharacter();refreshCameraControls();const v=validateSchool(state.school);$('reset-school').disabled=state.mode!=='build'||!permitted('builder');$('reset-school').textContent=t('Delete and start fresh','消して最初から');$('readiness').textContent=t('Ready ','完成 ')+ROOMS.filter(r=>state.school.rooms.some(x=>x.type===r.type)).length+'/'+ROOMS.length;$('readiness').classList.toggle('complete',v.ready);$('walk-mode').disabled=!v.ready||!permitted('localDirections');$('empty-state').hidden=state.school.rooms.length>0||state.mode!=='build';$('build-panel').hidden=state.mode!=='build';$('walk-hud').hidden=!['walk','controller'].includes(state.mode);$('host-hud').hidden=state.mode!=='host';$('follow-camera').hidden=!['walk','controller'].includes(state.mode);document.querySelectorAll('.build-view-control').forEach(e=>e.hidden=['walk','controller'].includes(state.mode));$('touch-controls').hidden=!['walk','controller'].includes(state.mode);$('build-mode').classList.toggle('active',state.mode==='build');$('walk-mode').classList.toggle('active',state.mode==='walk');$('activity-label').textContent=state.mode==='host'?t('Guide your partner','ペアに道案内'):['walk','controller'].includes(state.mode)?t('Find the room','部屋を見つけよう'):t('Your school','自分の学校');for(const id of ['build-mode','walk-mode'])$(id).hidden=state.mode==='controller';$('back-build').textContent=state.mode==='controller'?t('Leave room','退出する'):t('Build','つくる');$('restart-walk').hidden=state.mode==='controller';$('grid').hidden=state.mode!=='build';for(const id of ['build-mode','walk-mode','grid'])$(id).setAttribute('aria-pressed',String($(id).classList.contains('active')));$('next-destination').hidden=!state.walk?.arrived;$('target-name').innerHTML=state.walk?.targetId?roomLabelHTML(BY_TYPE[state.school.rooms.find(r=>r.id===state.walk.targetId)?.type]):'';$('run-status').hidden=!state.walk?.runLocked;$('run-status').textContent=state.walk?.runLocked?t('Walk until you arrive','目的地まで歩こう'):'';}
function loadSchool(s,{demo=true,resetHistory=true}={}){endRoom(false);state.school=normalizeSchool(s);state.suspendedWalk=null;state.demo=demo;state.dirty=false;state.saveBlocked=false;if(resetHistory){state.undo=[];state.redo=[];}state.selected=null;state.moving=null;state.tool='hand';state.walk=null;state.mode='build';scene.setMode('build');scene.setClassroomSession(null);scene.setSchool(state.school);scene.setPlayer(null);scene.setTeachers([]);scene.setTarget(null);scene.fit();$('start-dialog').close();$('save-status').textContent=demo?t('On this device','この端末に保存'):t('Saved','保存済み');updateTools();updatePalette();refresh();}
function showChecklist(){const v=validateSchool(state.school);showModal(t('School checklist','学校のチェック'),`<div class="checklist">${ROOMS.map(r=>`<div class="check-row"><span class="check ${v.missing.includes(r.type)?'missing':''}">${v.missing.includes(r.type)?'○':'✓'}</span><span>${esc(name(r))}</span><small>${r.unlimited?t('1 or more','1つ以上'):t('1 room','1つ')}</small></div>`).join('')}</div><p class="notice ${v.ready?'success':''}">${v.ready?t('Ready for directions.','道案内で遊べます。'):v.disconnected.length||v.disconnectedRooms?.length?t('Connect every corridor and doorway to the entrance.','すべての廊下と入口を玄関につなごう。'):t('Place the remaining rooms.','残りの部屋を置こう。')}</p>`);}
function enterWalk(){if(!validateSchool(state.school).ready)return showChecklist();if(!permitted('localDirections'))return toast(t('Your teacher has not opened directions.','先生が道案内をオンにすると遊べます。'));endRoom(false);state.mode='walk';state.walk=state.suspendedWalk?.signature===JSON.stringify(state.school)?state.suspendedWalk.walk:new SchoolWalk(state.school);state.suspendedWalk=null;scene.setClassroomSession(state.walk.startClassroomSession());scene.setMode('walk');scene.setPlayer(state.walk.player);scene.setTeachers(state.walk.teachers);scene.setFollow(true);refresh();teacherSpeech.reset();schoolVoice.unlock();schoolVoice.resume();navigationGuide.start(navigationContext());}
function backBuild(){
 
 if(state.mode==='walk'&&state.walk)state.suspendedWalk={walk:state.walk,signature:JSON.stringify(state.school)};
 endRoom(false);state.mode='build';state.walk=null;scene.setMode('build');scene.setPlayer(null);scene.setTeachers([]);scene.setTarget(null);scene.fit();clearKeys();refresh();
}
function clearKeys(){$('scene')?.cancelGesture?.();keys.clear();resetMovementStick();document.querySelectorAll('[data-key],#run-button').forEach(b=>b.classList.remove('held'));}
function input(){return {up:keys.has('w')||keys.has('ArrowUp'),down:keys.has('s')||keys.has('ArrowDown'),left:keys.has('a')||keys.has('ArrowLeft'),right:keys.has('d')||keys.has('ArrowRight'),moveX:movementStick.x,moveY:movementStick.y,run:keys.has('Shift')};}
function resetMovementStick(){
 const pointer=movementStick.pointer;movementStick.pointer=null;movementStick.x=movementStick.y=0;
 const stick=$('movement-stick');if(pointer!==null&&stick?.hasPointerCapture?.(pointer))stick.releasePointerCapture(pointer);
 if($('stick-thumb'))$('stick-thumb').style.transform='translate(0px,0px)';
 stick?.classList.remove('held');
}
function wireMovementStick(){
 const stick=$('movement-stick');
 const move=e=>{if(e.pointerId!==movementStick.pointer)return;e.preventDefault();const rect=stick.getBoundingClientRect(),radius=rect.width*.34,dx=e.clientX-rect.left-rect.width/2,dy=e.clientY-rect.top-rect.height/2;const axes=joystickAxes(dx,dy,radius);movementStick.x=axes.x;movementStick.y=axes.y;const length=Math.hypot(dx,dy),scale=length>radius?radius/length:1;$('stick-thumb').style.transform='translate('+dx*scale+'px,'+dy*scale+'px)';};
 stick.addEventListener('pointerdown',e=>{if(movementStick.pointer!==null||!['walk','controller'].includes(state.mode)||$('modal').open||$('start-dialog').open)return;e.preventDefault();movementStick.pointer=e.pointerId;stick.setPointerCapture(e.pointerId);stick.classList.add('held');move(e);});
 stick.addEventListener('pointermove',move);
 for(const type of ['pointerup','pointercancel','lostpointercapture'])stick.addEventListener(type,e=>{if(e.pointerId===movementStick.pointer)resetMovementStick();});
}

function ground(e){const p=scene.screenToGround(e.clientX,e.clientY);return p&&Number.isFinite(p.x)&&Number.isFinite(p.z)?{x:Math.floor(p.x),z:Math.floor(p.z)}:null;}
function preview(p){if(!p||state.mode!=='build'||!['place','move'].includes(state.tool))return;const room=state.moving&&state.school.rooms.find(r=>r.id===state.moving),type=room?.type||state.selected;if(!type)return;const d=BY_TYPE[type]||{w:1,d:1};let x=p.x-Math.floor(d.w/2),z=p.z-Math.floor(d.d/2); // pointer stays at the footprint centre
 const valid=BY_TYPE[type]?canPlaceRoom(state.school,type,x,z,state.moving):canPlaceDecoration(state.school,type,x,z);ghost={type,x,z,valid:valid.ok,reason:valid.reason};scene.setGhost(ghost);}
function commitPlacement(){if(!ghost)return;if(!ghost.valid)return toast(ghost.reason);remember();const g=ghost;let r;if(state.moving)r=moveRoom(state.school,state.moving,g.x,g.z);else r=BY_TYPE[g.type]?addRoom(state.school,g.type,g.x,g.z):addDecoration(state.school,g.type,g.x,g.z);if(r.ok){state.moving=null;if(!BY_TYPE[g.type]?.unlimited){state.selected=null;state.tool='hand';scene.setGhost(null);ghost=null;}changed();updateTools();}else{state.undo.pop();toast(r.reason);}}
function wireCanvas(){
 const canvas=$('scene');
 let freeMouse=null,lastPointerType='mouse',freeLookSuspended=true;
 const validPoint=e=>Number.isFinite(e.clientX)&&Number.isFinite(e.clientY);
 const blocked=()=>$('modal').open||$('start-dialog').open;
 const capture=id=>{try{canvas.setPointerCapture(id);}catch{}};
 const releaseCapture=id=>{try{if(canvas.hasPointerCapture?.(id))canvas.releasePointerCapture(id);}catch{}};
 const clearPreview=()=>{ghost=null;scene.setGhost(null);scene.setCorridorPreview?.([],true);};
 const discardEdit=d=>{
  if(d?.pickedRoom&&state.mode===d.mode&&state.tool===d.tool&&state.moving===d.pickedRoom){state.moving=d.selection.moving;state.selected=d.selection.selected;}
  if(d){d.pickedRoom=null;d.editAllowed=false;d.cameraOnly=true;}
  clearPreview();
 };
 const cancel=()=>{
  const old=drag,ids=[...touches.keys()];if(old&&!old.multi&&!old.touch)ids.push(old.id);
  drag=null;touches.clear();discardEdit(old);
  for(const id of ids)releaseCapture(id);
 };
 // Other controls, dialogs and focus changes must end the old pointer stroke.
 const isWalking=()=>['walk','controller'].includes(state.mode);
 const canFreeLook=()=>isWalking()&&scene.follow===false&&!blocked();
 const isFreeLook=()=>canFreeLook()&&!freeLookSuspended;
 canvas.releaseFreeLook=()=>{freeMouse=null;freeLookSuspended=true;if(document.pointerLockElement===canvas)document.exitPointerLock?.();};
 canvas.requestFreeLook=event=>{
  if(!canFreeLook())return;freeLookSuspended=false;
  const pointerType=event?.pointerType||lastPointerType;
  if(pointerType==='touch'||(!event?.pointerType&&globalThis.matchMedia?.('(pointer:coarse)').matches))return;
  try{const request=canvas.requestPointerLock?.();request?.catch?.(()=>{});}catch{}
 };
 canvas.cancelGesture=()=>{cancel();canvas.releaseFreeLook();};
 document.addEventListener('mousemove',e=>{
  if(document.pointerLockElement!==canvas)return;
  if(!isFreeLook()){canvas.releaseFreeLook();return;}
  if(Number.isFinite(e.movementX)&&Number.isFinite(e.movementY))scene.orbit(e.movementX,e.movementY);
 });
 document.addEventListener('pointerlockchange',()=>{freeMouse=null;cancel();if(document.pointerLockElement!==canvas){freeLookSuspended=true;keys.clear();resetMovementStick();}});
 canvas.addEventListener('pointerleave',()=>{freeMouse=null;});
 const pan=(dx,dy)=>{
  if(scene.panBy){scene.panBy(dx,dy);return;}
  const c=Math.cos(scene.yaw),s=Math.sin(scene.yaw),x=(-dx*c-dy*s)*.045,z=(dx*s-dy*c)*.045;
  if(Number.isFinite(x)&&Number.isFinite(z)&&(dx||dy))scene.pan(x,z);
 };
 const single=(id,point,{touch=false,button=0,cameraOnly=false}={})=>({id,touch,x:point.x,y:point.y,lastX:point.x,lastY:point.y,p:cameraOnly?null:ground({clientX:point.x,clientY:point.y}),button,right:button===2,moved:false,mode:state.mode,tool:state.tool,cameraOnly,editAllowed:!cameraOnly&&state.mode==='build'&&button===0&&permitted('builder'),selection:{moving:state.moving,selected:state.selected}});
 const geometry=ids=>{
  const a=touches.get(ids[0]),b=touches.get(ids[1]);if(!a||!b)return null;
  return {distance:Math.hypot(b.x-a.x,b.y-a.y),angle:Math.atan2(b.y-a.y,b.x-a.x),mid:{x:(a.x+b.x)/2,y:(a.y+b.y)/2}};
 };
 const rebaseTouches=()=>{
  const ids=[...touches.keys()];
  if(ids.length>=2){const pair=ids.slice(0,2);drag={multi:true,ids:pair,...geometry(pair),gesture:beginBuildGesture(touches.get(pair[0]),touches.get(pair[1])),mode:state.mode,tool:state.tool};}
  else if(ids.length===1){drag=single(ids[0],touches.get(ids[0]),{touch:true,cameraOnly:true});drag.moved=true;}
  else drag=null;
 };
 const owns=id=>touches.has(id)||!!(drag&&!drag.multi&&drag.id===id);
 const sameContext=()=>!drag||(drag.mode===state.mode&&drag.tool===state.tool);
 canvas.oncontextmenu=e=>{e.preventDefault();if(drag&&!drag.multi&&!drag.touch)discardEdit(drag);};
 canvas.addEventListener('pointerdown',e=>{
  if(blocked()||!validPoint(e))return;
  if(!sameContext())cancel();
  const touch=e.pointerType==='touch';lastPointerType=e.pointerType||'mouse';
  if(!touch&&isWalking()&&scene.follow===false&&e.button===0){e.preventDefault();cancel();canvas.focus({preventScroll:true});canvas.requestFreeLook(e);return;}
  // A second input device cannot take over an existing pointer sequence.
  if(touch&&drag&&!drag.multi&&!drag.touch||!touch&&touches.size)return;
  if(!touch&&![0,1,2].includes(e.button))return;
  if(!touch&&drag){if(drag.id===e.pointerId&&(e.button===2||(e.buttons&2))){discardEdit(drag);drag.right=true;}return;}
  if(touch&&touches.has(e.pointerId))return;
  e.preventDefault();canvas.focus({preventScroll:true});capture(e.pointerId);
  const point={x:e.clientX,y:e.clientY};
  if(touch){
   touches.set(e.pointerId,point);
   if(touches.size>=2){if(touches.size===2){discardEdit(drag);rebaseTouches();}return;}
  }
  drag=single(e.pointerId,point,{touch,button:e.button,cameraOnly:state.mode!=='build'||state.tool==='hand'||e.button!==0||(!touch&&(e.ctrlKey||keys.has('Space')))});
  const p=drag.p;
  if(drag.editAllowed){
   if(state.tool==='move'&&!state.moving){const r=p&&roomAt(state.school,p.x+.5,p.z+.5);if(r){drag.pickedRoom=r.id;state.moving=r.id;state.selected=r.type;preview(p);}}
   else if(state.tool==='place'||state.moving)preview(p);
  }
 });
 canvas.addEventListener('pointermove',e=>{
  if(blocked()||!sameContext()){cancel();return;}
  if(document.pointerLockElement===canvas)return;
  if(!validPoint(e))return;
  if(e.pointerType==='mouse'&&isFreeLook()){
   const next={x:e.clientX,y:e.clientY};
   if(freeMouse)scene.orbit(next.x-freeMouse.x,next.y-freeMouse.y);
   freeMouse=next;return;
  }
  freeMouse=null;
  if(!drag){if(e.pointerType!=='touch'&&!e.buttons)preview(ground(e));return;}
  if(!owns(e.pointerId))return;
  e.preventDefault();
  if(touches.has(e.pointerId))touches.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(drag.multi){
   // Extra fingers are tracked, but cannot change the active two-finger pair.
   if(!drag.ids.includes(e.pointerId))return;
   const next=geometry(drag.ids);if(!next){discardEdit(drag);rebaseTouches();return;}
   const motion=moveBuildGesture(drag.gesture,touches.get(drag.ids[0]),touches.get(drag.ids[1]));
   if(motion.zoomFactor!==1)scene.zoom(motion.zoomFactor);
   if(state.mode==='build'||state.mode==='host'){
    if(motion.turn)scene.rotate(motion.turn);
    if(motion.tilt)scene.orbit(0,motion.tilt);
    if(motion.panX)pan(motion.panX,0);
   }
   Object.assign(drag,next);return;
  }
  if(!drag.touch){
   if(!(e.buttons&7)){cancel();return;}
   const right=!!(e.buttons&2);
   if(right||e.ctrlKey||keys.has('Space')||(e.buttons&4))discardEdit(drag);
   drag.right=right;
  }
  const dx=e.clientX-drag.lastX,dy=e.clientY-drag.lastY;
  drag.lastX=e.clientX;drag.lastY=e.clientY;
  if(!Number.isFinite(dx)||!Number.isFinite(dy))return;
  if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)>4)drag.moved=true;
  if(state.mode==='build'||state.mode==='host'){
   if(drag.right)scene.orbit(dx,dy);
   else if(drag.cameraOnly||state.tool==='hand'||state.mode==='host')pan(dx,dy);
   else if(!permitted('builder'))discardEdit(drag);
   else if(state.tool==='corridor'){const p=ground(e),check=canDrawCorridor(state.school,drag.p,p);scene.setCorridorPreview?.(check.cells||[],check.ok);}
   else preview(ground(e));
  }else{scene.orbit(dx,dy);}
 });
 canvas.addEventListener('pointerup',e=>{
  if(!owns(e.pointerId))return;
  e.preventDefault();
  if(blocked()||!sameContext()){cancel();return;}
  if(drag?.multi){
   const active=drag.ids.includes(e.pointerId);touches.delete(e.pointerId);
   if(active)rebaseTouches();
   releaseCapture(e.pointerId);return;
  }
  if(!drag||drag.id!==e.pointerId){touches.delete(e.pointerId);releaseCapture(e.pointerId);return;}
  // Some pointer implementations report individual mouse-button releases.
  if(!drag.touch&&e.buttons){
   if(!(e.buttons&7)){cancel();return;}
   if((e.buttons&6)||e.button===2||e.ctrlKey||keys.has('Space'))discardEdit(drag);
   drag.right=!!(e.buttons&2);
   if(validPoint(e)){drag.lastX=e.clientX;drag.lastY=e.clientY;}
   return;
  }
  const old=drag;drag=null;touches.delete(e.pointerId);releaseCapture(e.pointerId);
  scene.setCorridorPreview?.([],true);
  if(!old.editAllowed||old.cameraOnly||old.right||e.button!==0||state.mode!=='build'||!permitted('builder')||!validPoint(e)){discardEdit(old);return;}
  const p=ground(e);if(!p){discardEdit(old);return;}
  if(state.tool==='corridor'){
   remember();const r=drawCorridor(state.school,old.p,p);if(r.ok)changed();else{state.undo.pop();toast(r.reason);}
  }else if(state.tool==='erase'&&!old.moved){
   remember();const r=deleteAt(state.school,p.x,p.z);if(r.ok)changed();else state.undo.pop();
  }else if(state.tool==='place'||state.moving){preview(p);commitPlacement();}
 });
 canvas.addEventListener('pointercancel',e=>{if(owns(e.pointerId)){cancel();clearKeys();}});
 canvas.addEventListener('lostpointercapture',e=>{if(owns(e.pointerId))cancel();});
 window.addEventListener('blur',()=>{cancel();canvas.releaseFreeLook();});
 document.addEventListener('visibilitychange',()=>{cancel();canvas.releaseFreeLook();});
 canvas.addEventListener('wheel',e=>{e.preventDefault();if(blocked()||!Number.isFinite(e.deltaY))return;cancel();const factor=Math.exp(Math.max(-2,Math.min(2,e.deltaY*.001)));scene.zoom(factor);},{passive:false});
}
function undo(){if(!permitted('builder')||state.mode!=='build'||!state.undo.length)return;state.redo.push(JSON.stringify(state.school));state.school=JSON.parse(state.undo.pop());changed();}
function redo(){if(!permitted('builder')||state.mode!=='build'||!state.redo.length)return;state.undo.push(JSON.stringify(state.school));state.school=JSON.parse(state.redo.pop());changed();}
function exportSchool(){const blob=new Blob([JSON.stringify({format:'aroha-school-builder',school:state.school},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='My_School.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
function printMap(){const school=state.school;const v=school.rooms.length?{minX:Math.max(0,Math.min(...school.rooms.map(r=>r.x))-2),minZ:Math.max(0,Math.min(...school.rooms.map(r=>r.z))-2),maxX:Math.min(W,Math.max(...school.rooms.map(r=>r.x+BY_TYPE[r.type].w))+2),maxZ:Math.min(H,Math.max(...school.rooms.map(r=>r.z+BY_TYPE[r.type].d))+2)}:{minX:0,minZ:0,maxX:W,maxZ:H};const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${v.minX} ${v.minZ} ${v.maxX-v.minX} ${v.maxZ-v.minZ}"><rect x="0" y="0" width="${W}" height="${H}" fill="#f4f7ee"/>${school.corridors.map(k=>`<rect x="${k%W}" y="${Math.floor(k/W)}" width="1" height="1" fill="#f5ddb4" stroke="#a9a59a" stroke-width=".035"/>`).join('')}${school.rooms.map(r=>{const d=BY_TYPE[r.type],door=roomDoor(r);return `<rect x="${r.x}" y="${r.z}" width="${d.w}" height="${d.d}" rx=".09" fill="${d.color}" stroke="#284554" stroke-width=".055"/><text x="${r.x+d.w/2}" y="${r.z+d.d/2}" text-anchor="middle" dominant-baseline="middle" font-size=".25" font-family="Arial">${esc(d.en)}</text><path d="M${door.x-.33} ${door.z}h.66" stroke="#fff" stroke-width=".13"/>`;}).join('')}</svg>`;const frame=document.createElement('iframe');frame.style.cssText='position:fixed;width:1px;height:1px;opacity:0;pointer-events:none';document.body.append(frame);const doc=frame.contentDocument;doc.open();doc.write(`<!doctype html><html><head><title>My School</title><style>@page{size:A4 landscape;margin:12mm}body{font:16px Arial;color:#153a47}h1{font-size:24px;margin:0 0 10px}.fields{display:flex;gap:50px;margin-bottom:20px}svg{width:100%;max-height:155mm}</style></head><body><h1>My School</h1><div class="fields"><span>Class: ____________________</span><span>Name: ____________________________________</span></div>${svg}</body></html>`);doc.close();setTimeout(()=>{frame.contentWindow.focus();frame.contentWindow.print();setTimeout(()=>frame.remove(),1000);},250);}
function showHelp(){showModal(t('Controls','操作'),`<div class="help-grid"><h3>${t('Build','学校づくり')}</h3><p>${t('Place the entrance first. Draw corridors, then line up each room’s doorway with a corridor.','まず玄関を置こう。廊下を引いて、部屋のドアを廊下につなごう。')}</p><p>${t('Drag with Move view, or hold Ctrl or Space while dragging with any building tool. Middle-drag also pans; right-drag rotates and tilts. On touchscreens, slide two fingers up/down to change view height, sideways to pan, pinch to zoom, or twist to rotate. The view buttons work the same way. Fit shows the whole school.','「視点移動」でドラッグ、またはどの道具でもCtrl・Spaceを押しながらドラッグして移動。中央ドラッグでも移動、右ドラッグで回転・角度調整。タッチ画面では2本指を上下に動かすと視点の高さ、左右で移動、ピンチで拡大縮小、ひねると回転。視点ボタンでも同じ操作。「全体」で学校全体を表示。')}</p><h3>${t('Walk','歩く')}</h3><p>${t('WASD, arrow keys or the touch stick move your character. The camera starts locked behind you. Choose Free camera, then move the mouse to look around; Escape releases the mouse and clicking the scene resumes. On touchscreens, swipe the scene to look. Behind player restores the locked view. Hold Shift or Run to run. In solo Directions, listen to the English guide or switch Voice off. Stop at the destination door or inside the room.','WASD・矢印キー・タッチスティックで移動。カメラは最初プレイヤーの後ろに固定。「自由カメラ」ではマウスを動かすと周りを見られます。Escapeでマウスを解放し、画面をクリックすると再開。タッチ画面ではスワイプして周りを見ます。「プレイヤーの後ろ」で固定に戻ります。Shift・走るボタンで走れます。1人の道案内では英語の音声案内が流れ、「音声オフ」で止められます。目的地のドアの前か部屋の中で止まろう。')}</p><h3>${t('Guide your partner','ペアに道案内')}</h3><p class="learning">Go straight. Turn left. Turn right. Stop.</p></div><div class="action-row"><button id="help-undo">${t('Undo','元に戻す')}</button><button id="help-print">${t('Print map','地図を印刷')}</button><button id="help-export">${t('Save a copy','コピーを保存')}</button><label class="file-button">${t('Open a copy','コピーを開く')}<input id="help-import" type="file" accept=".json,application/json" hidden></label></div>`);if(state.mode!=='build')$('modal-body').querySelector('.action-row').hidden=true;$('help-undo').onclick=()=>{undo();closeModal();};$('help-print').onclick=printMap;$('help-export').onclick=exportSchool;$('help-import').onchange=async e=>{if(state.mode!=='build'||!permitted('builder'))return;try{const f=e.target.files[0];if(!f||f.size>150000)throw Error('Choose a School Builder file.');const s=normalizeSchool(JSON.parse(await f.text()).school);remember();state.school=s;changed();closeModal();}catch(e){error(e);}};}
function roomSend(){}
function endRoom(goBuild=false){teacherWarningUntil=0;teacherSpeech.reset();schoolVoice.cancel();navigationGuide.stop();clearKeys();if(goBuild)backBuild();}
function applyControlLabels(){
 const language=interfaceLanguage(state);document.documentElement.lang=language;
 $('lang').hidden=!showLanguageSwitch(state);$('lang').textContent=language==='en'?'日本語':'English';
 const labelContext=language+':'+!!state.session?.authenticated+':'+(state.session?.role||'');
 if(applyControlLabels.current===labelContext)return;applyControlLabels.current=labelContext;
 const text={
  'build-mode':['Build','つくる'],'walk-mode':['Directions','道案内'],'host-mode':['Pair devices','ペアで遊ぶ'],
  'teacher-open':['Teacher controls','先生の操作'],'back-build':['Build','つくる'],'restart-walk':['Entrance','玄関へ'],
  'next-destination':['Next room','次の部屋'],'end-room':['End room','終了する'],'qr-open':['QR code','QRコード'],
  'demo-school':['Explore a school','学校を探検'],'new-school':['Build a school','学校をつくる'],'join-open':['Join with a code','コードで参加'],
  'login-open':['Student sign in','児童ログイン'],'teacher-login':['Teacher sign in','先生ログイン'],'continue-school':['Continue building','つづきから'],
  'run-button':['Run','走る'],'target-label':['Destination','目的地'],'rooms-tab':['Rooms','部屋'],'grounds-tab':['Grounds','校庭'],
  'palette-heading':['Your school','自分の学校'],'empty-message':['Place the entrance to begin.','まず玄関を置こう。'],
  'pair-heading-label':['Guide your partner','ペアに道案内'],'start-description':['Build a school and explore it on this device.','学校をつくって、この端末で探検しよう。'],'games-link':['Games','ゲーム一覧'],
 };
 if(state.session?.authenticated){text['teacher-login']=['Open saved school','保存した学校を開く'];if(state.session.role!=='student')text['login-open']=['Teacher controls','先生の操作'];}
 for(const [id,labels]of Object.entries(text)){
  const button=$(id);if(!button)continue;const label=button.querySelector?.('[data-control-label]');
  if(label)label.textContent=t(...labels);else button.textContent=t(...labels);
 }
 const aria={
  'undo':['Undo','元に戻す'],'help':['Show controls','操作を見る'],'grid':['Show grid','マス目を表示'],'fit':['Fit school','学校全体を表示'],
  'rotate-left':['Rotate left','左に回転'],'rotate-right':['Rotate right','右に回転'],'tilt-up':['Raise viewing angle','視点を上げる'],'tilt-down':['Lower viewing angle','視点を下げる'],
  'zoom-out':['Zoom out','縮小'],'zoom-in':['Zoom in','拡大'],'fullscreen':['Fullscreen','全画面'],'account-open':['Account','アカウント'],'modal-close':['Close','閉じる'],
  'movement-stick':['Move in any direction','スティックで移動'],'touch-controls':['Walking controls','移動の操作'],'walk-hud':['Directions activity','道案内'],'host-hud':['Paired directions','ペアで道案内'],
  'room-catalog':['Rooms and grounds','部屋と校庭'],'build-panel':['Build your school','学校をつくる'],'viewport':['School view','学校の画面'],'scene':['3D school. Build rooms and corridors, or walk through your school.','部屋と廊下を置いて学校をつくり、学校の中を歩こう。'],
 };
 for(const [id,labels]of Object.entries(aria)){const element=$(id);element?.setAttribute('aria-label',t(...labels));element?.setAttribute('title',t(...labels));}
 $('run-button').setAttribute('aria-label',t('Hold to run','押している間走る'));
 $('lang').setAttribute('aria-label',t('Switch interface language','表示言語を切り替える'));
 for(const button of document.querySelectorAll('[data-tool]')){
  const labels={hand:['Move view','視点移動'],corridor:['Corridor','廊下'],move:['Move room','部屋移動'],erase:['Erase','消す']}[button.dataset.tool];
  if(!labels)continue;const label=button.querySelector('span');if(label)label.textContent=t(...labels);button.setAttribute('title',t(...labels));button.setAttribute('aria-label',t(...labels));
 }
 document.querySelector('.camera-tools')?.setAttribute('aria-label',t('View controls','視点の操作'));
 document.querySelector('.mode-tabs')?.setAttribute('aria-label',t('Game mode','遊び方'));
}
function resetSchoolDialog(){
 if(state.mode!=='build'||!permitted('builder'))return;
 showModal(t('Delete this school and start fresh?','学校を消して、最初からつくる？'),`<p>${t('This removes all rooms, corridors and decorations from this school. Only the copy saved in this browser is affected.','この学校の部屋・廊下・飾りをすべて消します。このブラウザの保存だけが変わります。')}</p><div class="action-row"><button id="reset-cancel">${t('Keep my school','学校を残す')}</button><button id="reset-confirm">${t('Delete and start fresh','消して最初から')}</button></div><p id="reset-error" role="alert"></p>`);
 $('reset-cancel').onclick=closeModal;
 $('reset-confirm').onclick=async()=>{const button=$('reset-confirm');button.disabled=true;try{
  if(state.mode!=='build'||!permitted('builder'))throw Error(t('Building is locked.','編集はロックされています。'));
  
  if(state.saveBlocked)throw Error(t('Load the latest school before starting fresh.','最新版の学校を開いてから、やり直してください。'));
  const fresh=createSchool(),demo=state.demo;
  loadSchool(fresh,{demo});localWrite();closeModal();toast(t('Your new school is ready to build.','新しい学校をつくろう！'));
 }catch(e){$('reset-error').textContent=e.message;button.disabled=false;}};
}
function applyLanguage(){applyControlLabels.current=null;applyControlLabels();updatePalette();refresh();}
async function init(){try{scene=new SchoolScene($('scene'),{studentVariant:soloStudentVariant});scene.setSchool(state.school);scene.fit();}catch(e){$('start-dialog').close();showModal('3D graphics unavailable','<p>Your browser could not start WebGL. Enable hardware acceleration or try another browser.</p>');return;}
 wireCanvas();wireMovementStick();$('modal-close').onclick=closeModal;$('modal').addEventListener('close',clearKeys);$('modal').addEventListener('cancel',clearKeys);$('build-mode').onclick=backBuild;$('walk-mode').onclick=()=>{if(!['walk','controller'].includes(state.mode)&&permitted('localDirections')&&validateSchool(state.school).ready)chooseStudent(enterWalk);};$('back-build').onclick=backBuild;$('readiness').onclick=showChecklist;$('help').onclick=showHelp;if($('undo'))$('undo').onclick=undo;$('reset-school').onclick=resetSchoolDialog;$('demo-school').onclick=()=>{loadSchool(createDemoSchool());localWrite();};$('new-school').onclick=()=>{loadSchool(createSchool());state.selected='entrance';state.tool='place';updateTools();updatePalette();localWrite();};
 const draft=localStorage.getItem(draftKey());if(draft){$('continue-school').hidden=false;$('continue-school').onclick=()=>{try{loadSchool(JSON.parse(draft).school);}catch(e){error(e);}};}
 document.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>{if(!permitted('builder')&&b.dataset.tool!=='hand')return toast(t('Building is locked.','編集はロックされています。'));state.tool=b.dataset.tool;state.moving=null;state.selected=null;updateTools();updatePalette();});document.querySelectorAll('[data-palette]').forEach(b=>b.onclick=()=>{state.ground=b.dataset.palette==='grounds';document.querySelectorAll('[data-palette]').forEach(x=>x.classList.toggle('active',x===b));updatePalette();});
 const viewAction=action=>()=>{$('scene').cancelGesture?.();action();};$('zoom-in').onclick=viewAction(()=>scene.zoom(.82));$('zoom-out').onclick=viewAction(()=>scene.zoom(1.22));$('fit').onclick=viewAction(()=>scene.fit());$('rotate-left').onclick=viewAction(()=>scene.rotate(-Math.PI/4));$('rotate-right').onclick=viewAction(()=>scene.rotate(Math.PI/4));$('tilt-up').onclick=viewAction(()=>scene.orbit(0,45));$('tilt-down').onclick=viewAction(()=>scene.orbit(0,-45));$('grid').onclick=()=>{state.grid=!state.grid;scene.setGrid(state.grid);$('grid').classList.toggle('active',state.grid);$('grid').setAttribute('aria-pressed',String(state.grid));};$('follow-camera').onclick=()=>{$('scene').cancelGesture?.();scene.setCameraMode('locked');refreshCameraControls();};$('free-camera').onclick=e=>{const free=scene.cameraMode!=='free';clearKeys();scene.setCameraMode(free?'free':'locked');refreshCameraControls();if(free)$('scene').requestFreeLook?.(e);};$('voice-directions').onclick=()=>{voiceMuted=!voiceMuted;try{localStorage.setItem('school-voice-muted',String(voiceMuted));}catch{}schoolVoice.unlock();schoolVoice.resume();schoolVoice.setMuted(voiceMuted);navigationGuide.setMuted(voiceMuted);refreshCameraControls();};$('restart-walk').onclick=()=>{if(state.mode==='controller')return toast(t('Finish this destination first.','まず目的地まで行こう。'));if(state.walk){const lock=state.walk.runLocked,target=state.walk.targetId;state.walk.reset(state.school,{classroomSeed:state.walk.classroomSeed});state.walk.choose(target);state.walk.runLocked=lock;teacherWarningUntil=0;navigationGuide.start(navigationContext());}};$('next-destination').onclick=()=>{if(state.mode==='controller')roomSend({type:'next'});else state.walk?.next();refresh();};$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch(e){toast(t('Fullscreen is unavailable in this browser.','このブラウザでは全画面にできません。'));}};$('lang').onclick=()=>{state.lang=state.lang==='en'?'ja':'en';localStorage.setItem('school-language',state.lang);applyLanguage();};
 document.querySelectorAll('[data-key],#run-button').forEach(b=>{const k=b.id==='run-button'?'Shift':b.dataset.key;const down=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);keys.add(k);b.classList.add('held');};const up=()=>{keys.delete(k);b.classList.remove('held');};b.addEventListener('pointerdown',down);b.addEventListener('pointerup',up);b.addEventListener('pointercancel',up);b.addEventListener('lostpointercapture',up);});
 window.addEventListener('keydown',e=>{const key=e.key.length===1?e.key.toLowerCase():e.key;if($('modal').open||$('start-dialog').open||['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName))return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();return e.shiftKey?redo():undo();}if(e.key==='Escape'){$('scene').releaseFreeLook?.();if(state.mode==='build'){state.moving=null;state.selected=null;state.tool='hand';updateTools();updatePalette();}clearKeys();return;}if(e.code==='Space'&&['build','host'].includes(state.mode)){e.preventDefault();keys.add('Space');return;}if(['w','a','s','d','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Shift'].includes(key)){e.preventDefault();keys.add(key);}});window.addEventListener('keyup',e=>keys.delete(e.code==='Space'?'Space':e.key.length===1?e.key.toLowerCase():e.key));window.addEventListener('blur',()=>{schoolVoice.pause();navigationGuide.pause();clearKeys();frameAt=performance.now();});window.addEventListener('focus',()=>{frameAt=performance.now();});document.addEventListener('visibilitychange',()=>{if(document.hidden){schoolVoice.pause();navigationGuide.pause();}clearKeys();frameAt=performance.now();});window.addEventListener('beforeunload',e=>{if(state.dirty&&!state.demo){localWrite();e.preventDefault();e.returnValue='';}});
 applyLanguage();scene.setGrid(true);if(!$('start-dialog').open)$('start-dialog').showModal();
 const frame=now=>{let caughtThisFrame=false;const dt=document.hidden?0:Math.max(0,Math.min(1,(now-frameAt)/1000||.016));frameAt=now;if(state.walk&&['walk','controller'].includes(state.mode)){const paused=$('modal').open||$('start-dialog').open||state.walk.pendingArrival||state.mode==='controller'&&!state.room?.peerConnected;const steps=Math.max(1,Math.ceil(dt/.04)),events={caught:false,arrived:false};for(let i=0;i<steps&&!state.walk.pendingArrival;i++){const event=state.walk.update(dt/steps,paused?{}:input(),scene.yaw,scene.follow);events.caught ||=event.caught;events.arrived ||=event.arrived;}scene.setPlayer(state.walk.player);scene.setTeachers(state.walk.teachers);caughtThisFrame=events.caught;if(events.caught)refresh();if(events.arrived&&!state.walk.pendingArrival){if(state.mode==='controller'){const target=state.walk.targetId,room=state.room;state.walk.arrived=false;state.walk.pendingArrival=true;state.walk.arrivalHold=0;roomSend({type:'state',player:{...state.walk.player,speed:0,running:false},runLocked:state.walk.runLocked});setTimeout(()=>{if(state.room===room&&state.walk?.pendingArrival&&state.walk.targetId===target)roomSend({type:'arrival'});},320);}else toast(t('You found it!','着いた！'));refresh();}networkClock+=dt;if(state.mode==='controller'&&networkClock>.10){roomSend({type:'state',player:state.walk.player,targetId:state.walk.targetId,runLocked:state.walk.runLocked});networkClock=0;}}
 const audioContext=navigationContext();if(audioContext.paused)schoolVoice.pause();else schoolVoice.resume();const teacherLine=teacherSpeech.update({...audioContext,teachers:state.walk?.teachers,caught:caughtThisFrame,runLocked:state.walk?.runLocked,scoldTime:state.walk?.scoldTime},dt);if(teacherLine?.type==='greeting')toast(teacherLine.text,2200);if(teacherLine?.type==='scold')teacherWarningUntil=now+3000;navigationGuide.update(audioContext,dt);if(state.room&&now-state.room.lastSeen>10000&&state.room.socket?.readyState===1)state.room.socket.close();sessionClock+=dt;if(sessionClock>1.5){sessionClock=0;roomSend({type:'ping'});}scene.update(dt,now/1000);updateTeacherWarning(now,!audioContext.paused&&['walk','controller'].includes(audioContext.mode));raf=requestAnimationFrame(frame);};raf=requestAnimationFrame(frame);
 refresh();
}
init().catch(error);
