import {createCharacter as buildCharacter,animateCharacter,disposeModel} from './models.mjs';
export {animateCharacter};
export function createCharacter(options={}){const variant=!options.teacher&&options.variant===1?2:options.variant;return buildCharacter({...options,variant});}
export const disposeCharacter=disposeModel;
export function createStaticCharacter(options={}) {
 const group=createCharacter(options);
 if(options.seated){group.scale.y=.78;}
 return group;
}
