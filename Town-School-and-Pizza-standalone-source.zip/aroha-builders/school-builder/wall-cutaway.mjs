import * as THREE from './vendor/three.module.js';

export const FULL_WALL_HEIGHT=1.34;
export const CUTAWAY_WALL_HEIGHT=.24;
const unitBox=new THREE.BoxGeometry(1,1,1);unitBox.userData.shared=true;
const capMaterial=new THREE.MeshStandardMaterial({color:0xf3eddf,roughness:.9});
const matrix=new THREE.Matrix4();

export function wallSideRaised(side,yaw){
 const x=Math.sin(yaw),z=Math.cos(yaw);
 return !(side==='east'&&x>.08||side==='west'&&x<-.08||side==='south'&&z>.08||side==='north'&&z<-.08);
}

// Structure and fittings are kept separate. Shortening the axis-aligned wall
// boxes retains a real solid top, including the opening beneath each lintel.
// Window frames, posters and doors retain their original proportions.
export function prepareWallCutaway(wall,shell,{capMatrices=null}={}){
 shell.name='wall-structure';shell.userData.cutawayStructure=true;
 const buckets=new Map(),caps=[];
 for(const object of [...shell.children]){
  if(!object.isMesh||object.isInstancedMesh)continue;
  object.updateMatrix();
  let bucket=buckets.get(object.material);
  if(!bucket){bucket={material:object.material,geometry:object.geometry,matrices:[]};buckets.set(object.material,bucket);}
  bucket.matrices.push(object.matrix.clone());
  if(object.scale.y>1){const cap=object.matrix.clone();cap.elements[0]+=0.025;cap.elements[10]+=0.025;caps.push(cap);}
 }
 shell.clear();
 const batches=[];
 for(const bucket of buckets.values()){
  const mesh=new THREE.InstancedMesh(bucket.geometry,bucket.material,bucket.matrices.length);
  bucket.matrices.forEach((m,i)=>mesh.setMatrixAt(i,m));
  mesh.castShadow=true;mesh.receiveShadow=true;mesh.instanceMatrix.needsUpdate=true;
  mesh.computeBoundingBox();mesh.computeBoundingSphere();shell.add(mesh);batches.push({mesh,originals:bucket.matrices});
 }
 // Windows split the plaster into shorter pieces. Their low stubs still
 // need an unbroken cap along each wall span, excluding doorway openings.
 if(capMatrices){caps.length=0;for(const cap of capMatrices)caps.push(cap.clone());}
 const capMesh=new THREE.InstancedMesh(unitBox,capMaterial,caps.length);capMesh.name='wall-cutaway-cap';capMesh.userData.cutawayCap=true;
 capMesh.castShadow=true;capMesh.receiveShadow=true;capMesh.visible=false;wall.add(capMesh);
 wall.userData.wallCutaway={shell,batches,capMesh,caps,height:FULL_WALL_HEIGHT,target:FULL_WALL_HEIGHT};
 return wall;
}

export function stepWallCutaway(wall,{lowered=false,dt=0,snap=false}={}){
 const state=wall.userData.wallCutaway;
 if(!state)return;
 wall.visible=true;
 const target=lowered?CUTAWAY_WALL_HEIGHT:FULL_WALL_HEIGHT;
 state.target=target;
 const elapsed=Number.isFinite(dt)?Math.max(0,dt):0;
 let height=snap?target:state.height+(target-state.height)*(1-Math.exp(-elapsed*13));
 if(Math.abs(height-target)<.002)height=target;
 const raised=height===FULL_WALL_HEIGHT;
 // Refresh fitting visibility even when the wall is already settled: artwork
 // can be attached after the structure was created or reused during an edit.
 for(const child of wall.children)if(child!==state.shell&&child!==state.capMesh)child.visible=raised;
 state.capMesh.visible=!raised;
 if(height===state.height)return;
 state.height=height;
 for(const {mesh,originals} of state.batches){
  for(let i=0;i<originals.length;i++){
   matrix.copy(originals[i]);const e=matrix.elements,bottom=e[13]-e[5]/2,top=e[13]+e[5]/2;
   const clippedBottom=Math.min(bottom,height),clippedTop=Math.min(top,height);
   e[5]=Math.max(0,clippedTop-clippedBottom);e[13]=(clippedTop+clippedBottom)/2;
   // A zero-height box still has a visible top face in the CPU renderer.
   // Collapse fully clipped pieces to a point, particularly door lintels.
   if(bottom>=height)e[0]=e[5]=e[10]=0;
   mesh.setMatrixAt(i,matrix);
  }
  mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingBox();mesh.computeBoundingSphere();
 }
 for(let i=0;i<state.caps.length;i++){
  matrix.copy(state.caps[i]);matrix.elements[5]=.018;matrix.elements[13]=height+.004;state.capMesh.setMatrixAt(i,matrix);
 }
 state.capMesh.instanceMatrix.needsUpdate=true;state.capMesh.computeBoundingBox();state.capMesh.computeBoundingSphere();
}
