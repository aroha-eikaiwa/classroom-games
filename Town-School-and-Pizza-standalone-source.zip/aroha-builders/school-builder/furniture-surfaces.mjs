import * as THREE from './vendor/three.module.js';

// Albedo textures generated specifically for these surfaces. Each face uses
// its real dimensions, so narrow desk edges don't stretch a full square image.
const textureCache=new Map(),geometryCache=new Map();
const wood=new Set([0xc79a62,0xe1bf86,0xd9bd83,0xcdb184,0xd5cfb5,0xdfd6ba,0xa79d85,0xe8d9b9]);
const walnut=new Set([0x865c3d,0xb59b78,0x945c40,0x9b5d3c]);
const metal=new Set([0x73858b,0xb4beb5,0x425b63,0x77817e,0x7d9091,0xb4bdb6,0xcbd7d3]);
const laminate=new Set([0xf9faf7,0xd8dace,0xc5d2cc,0xd8dfcc,0xd0d7c6,0xe4dec9,0xd7dfdc,0xf0ebda,0xe2e9e1,0xccd7c9,0xe4e8e3,0xdde3dc,0xe3e8df,0x6f7770,0xc7dad5,0xe4ece4,0x263232,0x273638,0x324343]);
const fabric=new Set([0x6e9996,0x83b0a7,0x64828e,0x3a6667,0x80a49b,0x77a59e,0xb4d0bf,0xb7d1c6,0xfaf9e9,0x5f8b9d]);
export function furnitureSurface(color){
 if(fabric.has(color))return {name:'fabric',color,roughness:.92,density:3};
 if(wood.has(color))return {name:'birch',color:0xffffff,roughness:.63,density:1.4};
 if(walnut.has(color))return {name:'walnut',color:0xffffff,roughness:.66,density:1.4};
 if(metal.has(color))return {name:'powder-metal',color,roughness:.54,metalness:.24,density:2};
 if(laminate.has(color))return {name:'ivory-laminate',color,roughness:.53,density:2};
 return null;
}
export function surfaceOptions(surface){
 if(typeof document==='undefined')return {color:surface.color,roughness:surface.roughness,metalness:surface.metalness||0};
 let texture=textureCache.get(surface.name);
 if(!texture){
  texture=new THREE.TextureLoader().load(new URL(`./assets/interiors/${surface.name}.webp`,import.meta.url).href);
  texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.anisotropy=4;
  textureCache.set(surface.name,texture);
 }
 return {color:surface.color,map:texture,roughness:surface.roughness,metalness:surface.metalness||0};
}
export function surfaceGeometry(original,kind,sx,sy,sz,density=1.4){
 if(kind!=='box'&&kind!=='cylinder')return original;
 const key=[kind,sx,sy,sz,density].join(':');if(geometryCache.has(key))return geometryCache.get(key);
 const geometry=original.clone(),uv=geometry.attributes.uv,normal=geometry.attributes.normal;
 for(let i=0;i<uv.count;i++){
  const nx=Math.abs(normal.getX(i)),ny=Math.abs(normal.getY(i)),nz=Math.abs(normal.getZ(i));
  let u,v;
  if(kind==='cylinder'){u=ny>.9?sx:2*Math.PI*sx;v=ny>.9?sz:sy;}
  else if(nx>.9){u=sz;v=sy;}else if(ny>.9){u=sx;v=sz;}else {u=sx;v=sy;}
  uv.setXY(i,uv.getX(i)*u*density,uv.getY(i)*v*density);
 }
 geometry.userData.shared=true;geometryCache.set(key,geometry);return geometry;
}
