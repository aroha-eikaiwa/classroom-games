// Pure poster metadata shared by hallway placement and client rendering.
export const POSTERS = [
 ['MAKE MUSIC','Listen • sing • play',0,'#436f79'],
 ['GROW & DISCOVER','Look closely. Ask questions.',1,'#557950'],
 ['CREATE SOMETHING','Draw • paint • imagine',2,'#ac6755'],
 ['COOK TOGETHER','Wash • cut • mix',3,'#788444'],
 ['READ & EXPLORE','A new adventure on every page',4,'#53785d'],
 ['BE KIND','Help each other',5,'#a66c61'],
 ['FOUR SEASONS','Spring • summer • autumn • winter',6,'#a07842'],
 ['LET’S MOVE','Play fair. Try your best.',7,'#577f99'],
 ['OUR SCHOOL BAND','Find your rhythm',0,'#7d698a'],
 ['CURIOUS MINDS','What can you discover?',1,'#437c80'],
 ['STUDENT GALLERY','Everyone has an idea',2,'#ac7f43'],
 ['COLOURFUL FOOD','What do you like?',3,'#69905f'],
 ['BOOK CLUB','Share your favourite story',4,'#9c6d58'],
 ['FRIENDS TOGETHER','A little help makes a big difference',5,'#657c97'],
 ['廊下で歩こう','Walk in the hallway.',null,'#247d75','walk'],
 ['走らん','No running.',null,'#bd564b','no-running']
];
export const POSTER_COUNT=POSTERS.length;
export const HALLWAY_SAFETY_POSTERS=Object.freeze(POSTERS.map((p,i)=>p[4]?i:-1).filter(i=>i>=0));
