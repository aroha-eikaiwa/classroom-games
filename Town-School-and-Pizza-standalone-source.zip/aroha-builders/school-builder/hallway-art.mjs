import * as THREE from './vendor/three.module.js';
import {POSTERS,artworkMaterial,posterMaterial,drawPoster} from './school-art.mjs';
const face=new THREE.PlaneGeometry(1,1);face.userData.shared=true;
function line(c,x,y,xx,yy,color,width=4){c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x,y);c.lineTo(xx,yy);c.stroke();}
function circle(c,x,y,r,color){c.fillStyle=color;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();}
export function createHallwayDecoration(item){
 const g=new THREE.Group();g.name=item.kind;g.userData.hallwayDecoration=true;
 let material,width,height;
 if(item.kind==='clock'){
  width=height=.31;
  material=artworkMaterial('clock',256,256,c=>{
   c.fillStyle='#fffdf4';c.fillRect(0,0,256,256);circle(c,128,128,124,'#49666c');circle(c,128,128,111,'#fffdf4');
   for(let i=0;i<12;i++){const a=i*Math.PI/6;line(c,128+Math.sin(a)*91,128-Math.cos(a)*91,128+Math.sin(a)*102,128-Math.cos(a)*102,'#596c71',5);}
   c.lineCap='round';line(c,128,128,128,70,'#344a55',9);line(c,128,128,188,144,'#344a55',6);circle(c,128,128,7,'#344a55');
  });
 }else if(item.kind==='noticeboard'){
  width=.76;height=.48;
  material=artworkMaterial('board-'+item.variant,1024,640,c=>{
   c.fillStyle='#9a7254';c.fillRect(0,0,1024,640);c.fillStyle='#c6a276';c.fillRect(18,18,988,604);
   for(let i=0;i<4;i++){c.save();c.translate(171+i*225,i%2?230:390);c.rotate(i%2?.07:-.06);c.fillStyle='#77563d60';c.fillRect(-87,-104,180,230);drawPoster(c,(item.variant+i)%POSTERS.length,-90,-110,180,225);circle(c,0,-95,8,'#698a91');c.restore();}
  });
 }else{width=.44;height=.55;material=posterMaterial(item.variant);}
 const panel=new THREE.Mesh(face,material);panel.scale.set(width,height,1);g.add(panel);
 g.position.set(item.x,item.y,item.z);g.rotation.y=item.rotation;return g;
}
