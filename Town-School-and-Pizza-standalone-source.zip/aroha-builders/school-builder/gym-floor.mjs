import * as THREE from './vendor/three.module.js';
let maple;
export function gymFloorMaterial(){
 if(maple)return maple;
 const width=1024,height=512,pixels=new Uint8Array(width*height*4);
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const row=Math.floor(y/16),shift=(row*97)%256,board=Math.floor((x+shift)/256),seam=y%16===0||(x+shift)%256===0;
  const shade=Math.sin(row*7.31+board*4.73)*9,grain=Math.sin(x*.045+Math.sin(y*.7)*2+row)*2.4+Math.sin(x*.17+y*.6)*1.3;
  const k=seam?-24:shade+grain,i=(y*width+x)*4;
  pixels.set([218+k,171+k,111+k,255],i);
 }
 const texture=new THREE.DataTexture(pixels,width,height);texture.colorSpace=THREE.SRGBColorSpace;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=true;texture.needsUpdate=true;texture.anisotropy=4;
 maple=new THREE.MeshStandardMaterial({map:texture,roughness:.48});maple.name='gym-maple-planks';return maple;
}
export function basketballCourtLayout(w,d){return {left:.53,right:w-.53,top:1.45,bottom:d-.41,centerX:w/2,centerZ:(1.45+d-.41)/2};}
export function createBasketballCourt(w,d){
 const g=new THREE.Group();g.name='basketball-court';const c=basketballCourtLayout(w,d);g.userData.court=c;
 const paint=new THREE.MeshStandardMaterial({color:0xfff6dc,roughness:.65});
 function stroke(points,width=.025){const vertices=[];for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b[0]-a[0],b[1]-a[1]);if(!len)continue;const dx=-(b[1]-a[1])*width/len/2,dz=(b[0]-a[0])*width/len/2;const p=[a[0]+dx,.012,a[1]+dz],q=[a[0]-dx,.012,a[1]-dz],r=[b[0]+dx,.012,b[1]+dz],s=[b[0]-dx,.012,b[1]-dz];vertices.push(...p,...r,...q,...q,...r,...s);}const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.computeVertexNormals();const mesh=new THREE.Mesh(geometry,paint);g.add(mesh);}
 const rect=(x1,z1,x2,z2)=>stroke([[x1,z1],[x2,z1],[x2,z2],[x1,z2],[x1,z1]]);
 const arc=(x,z,r,start=0,end=Math.PI*2)=>stroke(Array.from({length:65},(_,i)=>{const a=start+(end-start)*i/64;return [x+Math.cos(a)*r,z+Math.sin(a)*r];}));
 rect(c.left,c.top,c.right,c.bottom);stroke([[c.centerX,c.top],[c.centerX,c.bottom]]);arc(c.centerX,c.centerZ,.48);
 for(const side of [-1,1]){const x=side<0?c.left:c.right,free=x-side*1.05;rect(x,c.centerZ-.48,free,c.centerZ+.48);arc(free,c.centerZ,.48);arc(x,c.centerZ,1.35,side<0?-Math.PI/2:Math.PI/2,side<0?Math.PI/2:Math.PI*1.5);}
 return g;
}
