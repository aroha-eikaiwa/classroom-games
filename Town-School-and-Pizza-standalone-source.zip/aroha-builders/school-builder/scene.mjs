import * as THREE from './vendor/three.module.js';
import {Canvas3DRenderer} from './software-renderer.mjs';
import { BY_TYPE, W, H, roomDoor } from './core.mjs';
import { createRoomModel, createDecoration, disposeModel } from './models.mjs';
import {createCharacter, createStaticCharacter, animateCharacter, disposeCharacter} from './characters.mjs';
import {hallwayDecorations} from './hallway-layout.mjs';
import {createHallwayDecoration} from './hallway-art.mjs';
import {prepareWallCutaway,stepWallCutaway,wallSideRaised} from './wall-cutaway.mjs';
import {behindPlayerYaw,projectedModelScale} from './walk-camera.mjs';
import {createDestinationArrow,createPlayerLocator,setRoomGlow,disposeGuidance,setGuidePlayerOverlay} from './host-guidance.mjs';
import {roomWindowKey} from './room-layout.mjs';
import {classroomPlan, classroomStudents} from './classroom-occupancy.mjs';
import {syncOfficePrincipals,clearOfficePrincipals} from './office-principal.mjs';
import {syncOfficeNurses,clearOfficeNurses} from './office-nurse.mjs';
import {floorSurfaceOptions} from './floor-surface.mjs';

const TAU = Math.PI * 2;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const finiteVector = v => Number.isFinite(v.x)&&Number.isFinite(v.y)&&Number.isFinite(v.z);
const angularDelta = (a,b) => Math.atan2(Math.sin(b-a),Math.cos(b-a));
const unitBox = new THREE.BoxGeometry(1,1,1);
const corridorMaterial = new THREE.MeshStandardMaterial({color:0xe8dfca,roughness:.87});
const corridorTrimMaterial = new THREE.MeshStandardMaterial({color:0x96aaa7,roughness:.75});
const wallMaterial = new THREE.MeshStandardMaterial({color:0xf1eee4,roughness:.86});
const floorMaterial = new THREE.MeshStandardMaterial({color:0xe9e1cf,...floorSurfaceOptions()});
const ceilingMaterial = new THREE.MeshStandardMaterial({color:0xf7f6ee,roughness:.94});
const lampMaterial = new THREE.MeshStandardMaterial({color:0xfffdf5,emissive:0xfffdf5,emissiveIntensity:.65,roughness:.3});
const edgeMaterial = new THREE.MeshStandardMaterial({color:0xa9b2a8,roughness:.92});
const fenceMaterial = new THREE.MeshStandardMaterial({color:0xf6f3e6,roughness:.9});
const yardMaterial = new THREE.MeshStandardMaterial({color:0x93b894,roughness:1});

function box(parent,x,y,z,w,h,d,material,shadow=true){
 const mesh=new THREE.Mesh(unitBox,material); mesh.position.set(x,y,z);mesh.scale.set(w,h,d);mesh.castShadow=shadow;mesh.receiveShadow=true;parent.add(mesh);return mesh;
}
// Instance the repeated architecture without changing cutaway groups.
function instanceBoxes(group){
 group.updateMatrixWorld(true);const inverse=group.matrixWorld.clone().invert(),buckets=new Map();
 group.traverse(o=>{if(!o.isMesh||o.geometry!==unitBox)return;let b=buckets.get(o.material);if(!b){b={matrices:[],shadow:false};buckets.set(o.material,b);}b.matrices.push(new THREE.Matrix4().multiplyMatrices(inverse,o.matrixWorld));b.shadow ||= o.castShadow;});
 group.clear();for(const [material,b]of buckets){const mesh=new THREE.InstancedMesh(unitBox,material,b.matrices.length);b.matrices.forEach((m,i)=>mesh.setMatrixAt(i,m));mesh.castShadow=b.shadow;mesh.receiveShadow=true;mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingBox();mesh.computeBoundingSphere();group.add(mesh);}
}
function makeGrid(){
 const vertices=[];for(let x=0;x<=W;x++)vertices.push(x,.015,0,x,.015,H);
 for(let z=0;z<=H;z++)vertices.push(0,.015,z,W,.015,z);
 const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
 return new THREE.LineSegments(geometry,new THREE.LineBasicMaterial({color:0xf8fff9,transparent:true,opacity:.25,depthWrite:false}));
}

function makeRoomLabel(text){
 const canvas=document.createElement('canvas'),context=canvas.getContext('2d');context.font='600 26px Arial, sans-serif';
 canvas.width=Math.ceil(context.measureText(text).width)+34;canvas.height=58;
 context.fillStyle='rgba(255,255,251,.94)';context.strokeStyle='#abc4c7';context.lineWidth=2;
 context.beginPath();context.roundRect(1,1,canvas.width-2,56,13);context.fill();context.stroke();
 context.fillStyle='#173f4d';context.font='600 26px Arial, sans-serif';context.textAlign='center';context.textBaseline='middle';context.fillText(text,canvas.width/2,29);
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
 const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,transparent:true,depthTest:false,depthWrite:false}));sprite.renderOrder=22;sprite.userData.ratio=canvas.width/58;
 return sprite;
}

/** Camera yaw points from focus toward camera. Forward in free-camera mode is
 * (-sin(yaw),-cos(yaw)); characters face +Z at angle=0. All lengths are grid cells.
 * orbit uses pixels, rotate radians, pan world cells and zoom a distance factor. */
const updateLocalTree=(mesh,camera,seconds)=>{if(mesh.name==='decoration-wind-tree') mesh.rotation.z=Math.sin(seconds*1.7)*0.035;};
export class SchoolScene {
 constructor(canvas,{studentVariant=0}={}){
  this.canvas=canvas;
  try{this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});}catch{this.renderer=new Canvas3DRenderer({canvas});}
  this.software=!!this.renderer.software;
  this.renderer.setPixelRatio(Math.min(globalThis.devicePixelRatio||1,1.65));
  this.renderer.outputColorSpace=THREE.SRGBColorSpace;
  this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.18;
  this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  this.scene=new THREE.Scene();this.scene.userData.schoolView='build';this.scene.background=new THREE.Color(0xcbdde0);
  this.scene.fog=new THREE.Fog(0xcbdde0,180,400);
  this.camera=new THREE.PerspectiveCamera(40,1,.025,400);
  this.scene.add(new THREE.HemisphereLight(0xf2faff,0x78966b,2.25));
  this.sun=new THREE.DirectionalLight(0xfff1d7,2.5);this.sun.position.set(W/2-18,38,H/2+14);this.sun.target.position.set(W/2,0,H/2);
  this.sun.castShadow=true;this.sun.shadow.mapSize.set(2048,2048);this.sun.shadow.camera.near=.5;this.sun.shadow.camera.far=100;
  Object.assign(this.sun.shadow.camera,{left:-40,right:40,top:35,bottom:-35});
  this.sun.shadow.normalBias=.035;this.sun.shadow.bias=-.00015;this.scene.add(this.sun);this.scene.add(this.sun.target);
  this.scene.add(new THREE.AmbientLight(0xffffff,.24));
  this.yard=new THREE.Group();this.yard.userData.softwareBackground=1;this.scene.add(this.yard);
  box(this.yard,W/2,-.11,H/2,W+.35,.2,H+.35,edgeMaterial,false);
  box(this.yard,W/2,-.017,H/2,W,.08,H,yardMaterial,false);
  // A supplied schoolground: low perimeter fence, clear central southern gate.
  for(let x=0;x<=W;x+=2.5)for(const z of [0,H]){
   if(z===H&&Math.abs(x-W/2)<2.7)continue;box(this.yard,x,.24,z,.085,.55,.085,fenceMaterial);
  }
  for(let z=2.5;z<H;z+=2.5)for(const x of [0,W])box(this.yard,x,.24,z,.085,.55,.085,fenceMaterial);
  for(const y of [.15,.36]){
   box(this.yard,W/2,y,0,W,.04,.045,fenceMaterial);
   box(this.yard,(W/2-2.7)/2,y,H,W/2-2.7,.04,.045,fenceMaterial);
   box(this.yard,W-(W/2-2.7)/2,y,H,W/2-2.7,.04,.045,fenceMaterial);
   box(this.yard,0,y,H/2,.045,.04,H,fenceMaterial);box(this.yard,W,y,H/2,.045,.04,H,fenceMaterial);
  }
  instanceBoxes(this.yard);
  this.grid=makeGrid();this.scene.add(this.grid);this.gridEnabled=true;
  this.schoolRoot=new THREE.Group();this.scene.add(this.schoolRoot);
  this.corridorRoot=new THREE.Group();this.schoolRoot.add(this.corridorRoot);
  this.roomRoot=new THREE.Group();this.schoolRoot.add(this.roomRoot);
  this.decorRoot=new THREE.Group();this.schoolRoot.add(this.decorRoot);
  this.actors=new THREE.Group();this.scene.add(this.actors);
  this.studentVariant=studentVariant===1?1:0;
  this.playerMesh=createCharacter({teacher:false,variant:this.studentVariant,software:this.software});this.playerMesh.visible=false;this.actors.add(this.playerMesh);
  this.classroomSeed=null;this.classroomGroups=new Map();this.principalMeshes=new Map();this.nurseMeshes=new Map();
  this.teacherMeshes=new Map();this.roomMeshes=new Map();this.decorationMeshes=new Map();this.roomLabels=new Map();this.labelsRoot=new THREE.Group();this.labelsRoot.visible=false;this.scene.add(this.labelsRoot);
  this.player=null;this.teachers=[];this.school=null;this.mode='build';this.follow=true;
  this.yaw=Math.PI/4;this.buildYaw=this.yaw;this.walkYaw=Math.PI*2;this.elevation=.96;this.walkPitch=.23;
  this.buildDistance=40;this.center=new THREE.Vector3(W/2,0,H/2);this.lookTarget=new THREE.Vector3(W/2,0,H/2);
  this.cameraPosition=new THREE.Vector3();this.raycaster=new THREE.Raycaster();this.pickPlane=new THREE.Plane(new THREE.Vector3(0,1,0),0);
  this.pointer=new THREE.Vector2();this.wallObjects=[];this.sides=[];this.ceilings=[];this.cameraReady=false;this.lastCutawayYaw=NaN;
  this.ghost=new THREE.Group();this.scene.add(this.ghost);this.ghost.visible=false;
  this.ghostMaterial=new THREE.MeshBasicMaterial({color:0x2da98a,transparent:true,opacity:.30,depthWrite:false});
  this.ghostPlate=new THREE.Mesh(unitBox,this.ghostMaterial);this.ghost.add(this.ghostPlate);
  this.ghostOutline=new THREE.LineSegments(new THREE.EdgesGeometry(unitBox),new THREE.LineBasicMaterial({color:0x188b6f,transparent:true,opacity:.9}));this.ghost.add(this.ghostOutline);
  this.ghostDoor=box(this.ghost,0,.08,0,.7,.1,.16,new THREE.MeshBasicMaterial({color:0xffffff}),false);
  this.targetRoot=new THREE.Group();this.scene.add(this.targetRoot);this.targetRoot.visible=false;
  const ringGeometry=new THREE.RingGeometry(.36,.47,40);ringGeometry.rotateX(-Math.PI/2);
  this.targetRing=new THREE.Mesh(ringGeometry,new THREE.MeshBasicMaterial({color:0xffc542,transparent:true,opacity:.85,depthWrite:false,side:THREE.DoubleSide}));this.targetRing.material.depthTest=false;this.targetRing.renderOrder=29;this.targetRoot.add(this.targetRing);
  this.targetMarker=createDestinationArrow();this.targetMarker.position.y=1.9;this.targetRoot.add(this.targetMarker);
  this.playerLocator=createPlayerLocator();this.playerLocator.visible=false;this.scene.add(this.playerLocator);this.highlightedRoom=null;
  this.corridorPreview=new THREE.Group();this.scene.add(this.corridorPreview);this.corridorPreview.visible=false;
  this.corridorPreviewFill=new THREE.Mesh(new THREE.BufferGeometry(),new THREE.MeshBasicMaterial({color:0x20b38c,transparent:true,opacity:.38,depthTest:false,depthWrite:false,side:THREE.DoubleSide}));this.corridorPreviewFill.renderOrder=18;this.corridorPreview.add(this.corridorPreviewFill);
  this.corridorPreviewLines=new THREE.LineSegments(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:0x168d70,transparent:true,opacity:.9,depthTest:false,depthWrite:false}));this.corridorPreviewLines.renderOrder=19;this.corridorPreview.add(this.corridorPreviewLines);
  this.targetId=null;this.elapsed=0;
  this.resizeObserver=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>this.resize()):null;this.resizeObserver?.observe(canvas);
  this.resize();this._updateCamera(0,true);
 }
 resize(){
  const rect=this.canvas.getBoundingClientRect(),width=Math.max(1,Math.round(rect.width)),height=Math.max(1,Math.round(rect.height));
  if(this.width===width&&this.height===height)return;
  this.width=width;this.height=height;this.renderer.setSize(width,height,false);this.camera.aspect=width/height;this.camera.updateProjectionMatrix();
 }
 setSchool(s){
  this.school=s;
  // Preserve permanent office occupants while changed room shells are rebuilt.
  for(const person of this.principalMeshes.values())person.removeFromParent();
  for(const person of this.nurseMeshes.values())person.removeFromParent();
  const roomIds=new Set((s.rooms||[]).map(r=>r.id));
  for(const [id,label]of this.roomLabels)if(!roomIds.has(id)){this.labelsRoot.remove(label);label.material.map.dispose();label.material.dispose();this.roomLabels.delete(id);}
  for(const [id,mesh]of this.roomMeshes)if(!roomIds.has(id)){this.roomRoot.remove(mesh);disposeModel(mesh);this.roomMeshes.delete(id);}
  for(const room of s.rooms||[]){
   const def=BY_TYPE[room.type];if(!def)continue;
   const windowKey=roomWindowKey(room,def,s);
   let mesh=this.roomMeshes.get(room.id);
   if(!mesh||mesh.userData.schoolType!==room.type||mesh.userData.windowKey!==windowKey){if(mesh){this.roomRoot.remove(mesh);disposeModel(mesh);}mesh=createRoomModel(room,def,s);mesh.userData.windowKey=windowKey;const floor=mesh.children.find(c=>c.isMesh);if(floor){floor.userData.softwareBackground=2;floor.userData.softwareRoomInterior=true;}const furniture=mesh.children.find(c=>c.name==='furniture');if(furniture)furniture.userData.softwareRoomInterior=true;mesh.userData.schoolType=room.type;if(!def.outdoor){const ceiling=box(mesh,def.w/2,1.31,def.d/2,def.w+.06,.045,def.d+.06,ceilingMaterial,false);ceiling.userData.schoolCeiling=true;ceiling.visible=this.mode==='walk';}this.roomMeshes.set(room.id,mesh);this.roomRoot.add(mesh);}
   mesh.position.set(room.x,0,room.z);mesh.userData.roomId=room.id;mesh.userData.softwareRoom={x:room.x,z:room.z,w:def.w,d:def.d,door:roomDoor(room),outdoor:!!def.outdoor};
   let label=this.roomLabels.get(room.id);if(!label){label=makeRoomLabel(def.en);this.roomLabels.set(room.id,label);this.labelsRoot.add(label);}label.position.set(room.x+def.w/2,.30,room.z+def.d/2);label.userData.maxWidth=def.w-.25;
  }
  const decorIds=new Set((s.decorations||[]).map(r=>r.id));
  for(const [id,mesh]of this.decorationMeshes)if(!decorIds.has(id)){this.decorRoot.remove(mesh);disposeModel(mesh);this.decorationMeshes.delete(id);}
  for(const deco of s.decorations||[]){
   let mesh=this.decorationMeshes.get(deco.id);if(!mesh){mesh=createDecoration(deco.type);if(!mesh)continue;this.decorationMeshes.set(deco.id,mesh);this.decorRoot.add(mesh);}
   mesh.position.set(deco.x+.5,0,deco.z+.5);
  }
  this._buildCorridors(s);this._decorateHallways(s);this._populateNurses();this._populatePrincipals();this._populateClassrooms();this._collectWalls();this._cutaway(true);this.setTarget(this.targetId);
 }
 _buildCorridors(s){
  this.corridorRoot.traverse(o=>{if(o.isInstancedMesh)o.dispose();});this.corridorRoot.clear();
  const floorGroup=new THREE.Group(),ceilingGroup=new THREE.Group();floorGroup.userData.softwareBackground=2;ceilingGroup.userData.schoolCeiling=true;ceilingGroup.visible=this.mode==='walk';this.corridorRoot.add(floorGroup,ceilingGroup);
  const corridorSet=new Set(s.corridors||[]),roomTiles=new Set();
  for(const room of s.rooms||[]){const d=BY_TYPE[room.type];if(!d)continue;for(let z=room.z;z<room.z+d.d;z++)for(let x=room.x;x<room.x+d.w;x++)roomTiles.add(z*W+x);}
  const walls={north:new THREE.Group(),south:new THREE.Group(),east:new THREE.Group(),west:new THREE.Group()};
  for(const [side,g]of Object.entries(walls)){g.userData.wallSide=side;const shell=new THREE.Group();g.add(shell);g.userData.structuralShell=shell;this.corridorRoot.add(g);}
  const directions=[{dx:0,dz:-1,side:'north'},{dx:0,dz:1,side:'south'},{dx:1,dz:0,side:'east'},{dx:-1,dz:0,side:'west'}];
  for(const key of corridorSet){
   const x=key%W,z=Math.floor(key/W);box(floorGroup,x+.5,.018,z+.5,1,.055,1,floorMaterial,false);
   const ceiling=box(ceilingGroup,x+.5,1.31,z+.5,1.06,.045,1.06,ceilingMaterial,false);
   const lamp=box(ceiling,0,-.7,0,.48,.25,.10,lampMaterial,false);lamp.castShadow=false;
   // Thin alternating floor-board joints keep the hall readable at walking height.
   box(floorGroup,x+.5,.048,z+.5,.012,.003,1,corridorMaterial,false);
   for(const {dx,dz,side}of directions){
    const nx=x+dx,nz=z+dz,k=nz*W+nx;
    if(nx>=0&&nx<W&&nz>=0&&nz<H&&(corridorSet.has(k)||roomTiles.has(k)))continue;
    const wx=x+.5+dx*.5,wz=z+.5+dz*.5,ww=dx?.075:1.075,wd=dz?.075:1.075;
    box(walls[side].userData.structuralShell,wx,.66,wz,ww,1.25,wd,wallMaterial);
    box(walls[side].userData.structuralShell,wx,.14,wz,ww+.012,.18,wd+.012,corridorTrimMaterial);
    box(walls[side].userData.structuralShell,wx,1.294,wz,ww+.035,.035,wd+.035,corridorTrimMaterial);
   }
  }
  instanceBoxes(floorGroup);instanceBoxes(ceilingGroup);for(const group of Object.values(walls))prepareWallCutaway(group,group.userData.structuralShell);
 }
 _decorateHallways(s){
  // Room meshes are reused through edits; remove only their previous hall art.
  const old=[];this.roomRoot.traverse(o=>{if(o.userData.hallwayDecoration)old.push(o);});for(const o of old)o.removeFromParent();
  const plan=hallwayDecorations(s);
  this.canvas.dataset.hallDecorations=String(plan.length);
  for(const item of plan){
   let parent;
   if(item.roomId){const room=s.rooms.find(r=>r.id===item.roomId),mesh=this.roomMeshes.get(item.roomId);parent=mesh?.children.find(c=>c.userData.wallSide===item.roomSide);if(!parent)continue;const art=createHallwayDecoration({...item,x:item.x-room.x,z:item.z-room.z});const wall=parent.children.find(c=>c.userData.wallSide===item.roomSide);(wall||parent).add(art);}
   else{parent=this.corridorRoot.children.find(c=>c.userData.wallSide===item.side);if(parent)parent.add(createHallwayDecoration(item));}
  }
 }
 _collectWalls(){
  this.wallObjects=[];this.sides=[];this.ceilings=[];
  this.schoolRoot.traverse(o=>{if(o.userData.schoolCeiling){this.ceilings.push(o);if(o.isMesh)this.wallObjects.push(o);else o.traverse(child=>{if(child.isMesh)this.wallObjects.push(child);});}if(o.userData.wallSide){this.sides.push(o);o.traverse(child=>{if(child.isMesh&&!child.userData.cutawayCap)this.wallObjects.push(child);});}});
 }
 _cutaway(force=false,dt=0){
  this.lastCutawayMode=this.mode;this.lastCutawayYaw=this.yaw;
  for(const group of this.sides){
   const lowered=this.mode!=='walk'&&!wallSideRaised(group.userData.wallSide,this.yaw);
   stepWallCutaway(group,{lowered,dt,snap:this.mode==='walk'});
  }
  for(const ceiling of this.ceilings)ceiling.visible=this.mode==='walk';
 }

 setMode(mode){
  if(!['build','walk','host'].includes(mode))throw new Error('Unknown school view');
  this._ensureCameraState();
  if(this.mode===mode)return;
  if(this.mode==='walk')this.walkYaw=this.yaw;else this.buildYaw=this.yaw;
  this.mode=mode;this.scene.userData.schoolView=mode;this.yaw=mode==='walk'?this.walkYaw:this.buildYaw;
  this.camera.fov=mode==='walk'?64:40;this.camera.updateProjectionMatrix();
  this.grid.visible=mode==='build'&&this.gridEnabled;this.ghost.visible=false;this.corridorPreview.visible=false;this.labelsRoot.visible=mode==='host';
  for(const group of this.classroomGroups.values())group.visible=mode!=='build';
  this.playerMesh.visible=!!this.player&&mode!=='build';this.targetRoot.visible=mode==='host'&&!!this.targetId;
  this.cameraReady=false;this._cutaway(true);this.setTarget(this.targetId);this._updateHostGuidance();
 }
 _populateNurses(){
  const count=syncOfficeNurses(this.roomMeshes,this.nurseMeshes,createStaticCharacter,disposeCharacter);
  this.canvas.dataset.nurses=String(count);
 }
 _populatePrincipals(){
  const count=syncOfficePrincipals(this.roomMeshes,this.principalMeshes,createStaticCharacter,disposeCharacter);
  this.canvas.dataset.principals=String(count);
 }
 setClassroomSession(seed){
  const value=Number.isInteger(seed)?seed>>>0:null;
  if(this.classroomSeed===value)return;
  this.classroomSeed=value;this._populateClassrooms();
 }
 _clearClassrooms(){
  for(const group of this.classroomGroups.values()){
   for(const person of group.children)disposeCharacter(person);
   group.removeFromParent();
  }
  this.classroomGroups.clear();
 }
 _populateClassrooms(){
  this._clearClassrooms();
  if(this.classroomSeed===null||!this.school){this.canvas.dataset.classrooms=JSON.stringify({seed:this.classroomSeed,occupied:[],students:0});return;}
  const plan=classroomPlan(this.school,this.classroomSeed);
  let studentCount=0;
  for(const item of plan){
   const room=this.roomMeshes.get(item.roomId),layout=room?.userData.classroomLayout;
   if(!layout?.teacher)continue;
   const group=new THREE.Group();group.name='Class in progress';group.userData.softwareRoomInterior=true;
   group.userData.classroomOccupants=true;group.visible=this.mode!=='build';room.add(group);this.classroomGroups.set(item.roomId,group);
   const teacher=createStaticCharacter({teacher:true,variant:item.teacherVariant});
   teacher.position.set(layout.teacher.x,layout.teacher.y+.055,layout.teacher.z);teacher.rotation.y=layout.teacher.rotation;
   teacher.userData.classroomRole='teacher';group.add(teacher);
   for(const seat of classroomStudents(layout.seats,item.seatSeed)){
    const student=createStaticCharacter({variant:seat.variant,appearance:seat.appearance,seated:true});
    student.position.set(seat.x,seat.y+.012,seat.z);student.rotation.y=seat.rotation;
    student.userData.classroomRole='student';student.userData.seatIndex=seat.seatIndex;
    group.add(student);studentCount++;
   }
  }
  this.canvas.dataset.classrooms=JSON.stringify({seed:this.classroomSeed,occupied:[...this.classroomGroups.keys()],students:studentCount});
 }
 setStudentVariant(value){
  const variant=value===1?1:0;
  if(variant===this.studentVariant)return;
  const previous=this.playerMesh;
  const next=createCharacter({teacher:false,variant,software:this.software});
  next.position.copy(previous.position);
  next.quaternion.copy(previous.quaternion);
  next.visible=previous.visible;
  if(previous.userData.headLook)next.userData.headLook={...previous.userData.headLook};
  this.actors.add(next);
  this.playerMesh=next;this.studentVariant=variant;
  this.actors.remove(previous);
  // Mark in-flight character loads disposed before their promises can attach a mesh.
  disposeCharacter(previous);
 }
 setPlayer(player){
  this.player=player?{...player}:null;this.scene.userData.schoolPlayer=this.player;this.canvas.dataset.player=JSON.stringify(player?{x:player.x,z:player.z,angle:player.angle}:null);this.playerMesh.visible=!!player&&this.mode!=='build';
  if(player){this.playerMesh.position.set(player.x,.055,player.z);this.playerMesh.rotation.set(0,Number.isFinite(player.angle)?player.angle:Math.PI,0);}
 }
 setTeachers(teachers=[]){
  this.teachers=teachers;const present=new Set();
  teachers.forEach((t,i)=>{const id=t.id??i;present.add(id);let mesh=this.teacherMeshes.get(id);if(!mesh){mesh=createCharacter({teacher:true,variant:i+1,software:this.software});this.teacherMeshes.set(id,mesh);this.actors.add(mesh);}mesh.visible=true;mesh.position.set(t.x,.055,t.z);mesh.rotation.y=t.angle||0;mesh.userData.teacherState=t;});
  for(const [id,mesh]of this.teacherMeshes)if(!present.has(id)){this.actors.remove(mesh);disposeCharacter(mesh);this.teacherMeshes.delete(id);}
 }
 scoldingTeacherAnchor(){
  const teacher=this.teachers.find(teacher=>teacher.scolding);
  if(this.mode!=='walk'||!teacher)return null;
  const mesh=this.teacherMeshes.get(teacher.id);
  const headHeight=mesh?.userData.characterLoaded ? .75 : 1;
  const anchor=new THREE.Vector3(teacher.x,headHeight,teacher.z).project(this.camera);
  if(Math.abs(anchor.x)>1||Math.abs(anchor.y)>1||Math.abs(anchor.z)>1)return null;
  return {x:(anchor.x+1)*50,y:(1-anchor.y)*50};
 }
 setGhost(value){
  if(!value||this.mode!=='build'){this.ghost.visible=false;return;}
  const def=BY_TYPE[value.type];const w=def?.w||value.w||1,d=def?.d||value.d||1;
  const color=value.valid?0x21b78e:0xec5353;
  this.ghost.visible=true;this.ghost.position.set(value.x,0,value.z);
  this.ghostPlate.position.set(w/2,.09,d/2);this.ghostPlate.scale.set(w,.10,d);this.ghostMaterial.color.setHex(color);
  this.ghostOutline.position.set(w/2,.14,d/2);this.ghostOutline.scale.set(w,.20,d);this.ghostOutline.material.color.setHex(color);
  this.ghostDoor.visible=!!def;this.ghostDoor.position.set(1.5,.2,value.type==='entrance'?0:d);this.ghostDoor.material.color.setHex(color);
 }
 setCorridorPreview(cells,valid=true){
  if(!cells?.length||this.mode!=='build'){this.corridorPreview.visible=false;return;}
  const vertices=[],edges=[];
  for(const cell of cells){const x=typeof cell==='number'?cell%W:cell.x,z=typeof cell==='number'?Math.floor(cell/W):(cell.z??cell.y);if(!Number.isFinite(x)||!Number.isFinite(z))continue;
   const y=.075;vertices.push(x,y,z,x+1,y,z,x+1,y,z+1,x,y,z,x+1,y,z+1,x,y,z+1);
   edges.push(x,y,z,x+1,y,z,x+1,y,z,x+1,y,z+1,x+1,y,z+1,x,y,z+1,x,y,z+1,x,y,z);
  }
  for(const object of [this.corridorPreviewFill,this.corridorPreviewLines])object.geometry.dispose();
  this.corridorPreviewFill.geometry=new THREE.BufferGeometry();this.corridorPreviewFill.geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
  this.corridorPreviewLines.geometry=new THREE.BufferGeometry();this.corridorPreviewLines.geometry.setAttribute('position',new THREE.Float32BufferAttribute(edges,3));
  this.corridorPreviewFill.material.color.setHex(valid?0x20b38c:0xee5454);this.corridorPreviewLines.material.color.setHex(valid?0x168d70:0xc52635);this.corridorPreview.visible=true;
 }
 setTarget(id){
  this.targetId=id;const room=this.school?.rooms.find(r=>r.id===id);
  const highlight=this.mode==='host'&&room?this.roomMeshes.get(room.id):null;
  if(this.highlightedRoom!==highlight){setRoomGlow(this.highlightedRoom,false);this.highlightedRoom=highlight;}
  setRoomGlow(highlight,true,this.elapsed||0);
  this.targetRoot.visible=this.mode==='host'&&!!room;
  if(room){
   const door=roomDoor(room),def=BY_TYPE[room.type],x=room.x+def.w/2,z=room.z+def.d/2;
   this.targetRoot.position.set(x,.075,z);this.targetRing.position.set(door.outX-x,0,door.outZ-z);
  }
 }
 _updateHostGuidance(){
  if(!this.playerLocator)return;
  const host=this.mode==='host';this.playerLocator.visible=host&&!!this.player;setGuidePlayerOverlay(this.playerMesh,host);
  if(host&&this.player){
   const distance=this.camera.position.distanceTo(this.playerMesh.position);
   const scale=projectedModelScale({distance,fov:this.camera.fov,viewportHeight:this.height,modelHeight:.52,minPixels:34,maxScale:3.2});
   this.playerMesh.scale.setScalar(scale);this.playerMesh.visible=true;
   this.playerLocator.position.set(this.player.x,.095,this.player.z);this.playerLocator.scale.setScalar(Math.max(1,scale*.8));
   this.canvas.dataset.guidePlayerScale=scale.toFixed(2);
  }else this.playerMesh.scale.setScalar(1);
  if(host&&this.targetRoot.visible){
   const distance=this.camera.position.distanceTo(this.targetRoot.position);
   const scale=projectedModelScale({distance,fov:this.camera.fov,viewportHeight:this.height,modelHeight:.85,minPixels:36,maxScale:2.8});
   this.targetMarker.scale.setScalar(scale);this.targetMarker.position.y=1.40+scale*.5+.12*Math.sin(this.elapsed*2.5);
   this.targetMarker.rotation.y=this.elapsed*.5;
   this.targetRing.scale.setScalar(1+.09*Math.sin(this.elapsed*3));
   setRoomGlow(this.highlightedRoom,true,this.elapsed);
  }
 }

 setGrid(value){this.gridEnabled=!!value;this.grid.visible=!!value&&this.mode==='build';}
 _ensureCameraState(){
  let repaired=false;
  const restore=(key,fallback,min=-Infinity,max=Infinity)=>{const before=this[key],value=clamp(Number.isFinite(before)?before:fallback,min,max);if(value!==before){this[key]=value;repaired=true;}};
  restore('buildYaw',Math.PI/4);restore('walkYaw',TAU);
  restore('yaw',this.mode==='walk'?this.walkYaw:this.buildYaw);
  restore('elevation',.96,.55,1.4);restore('walkPitch',.23,-.1,.65);restore('buildDistance',40,6,180);
  for(const [axis,limit]of [['x',W],['z',H]]){const before=this.center[axis],value=clamp(Number.isFinite(before)?before:limit/2,0,limit);if(value!==before){this.center[axis]=value;repaired=true;}}
  if(this.center.y!==0){this.center.y=0;repaired=true;}
  if(!Number.isFinite(this.camera.aspect)||this.camera.aspect<=0){this.camera.aspect=Number.isFinite(this.width)&&Number.isFinite(this.height)&&this.width>0&&this.height>0?this.width/this.height:1;this.camera.updateProjectionMatrix();repaired=true;}
  if(!finiteVector(this.camera.up)||this.camera.up.lengthSq()===0){this.camera.up.set(0,1,0);repaired=true;}
  if(![this.camera.quaternion.x,this.camera.quaternion.y,this.camera.quaternion.z,this.camera.quaternion.w].every(Number.isFinite)){this.camera.quaternion.identity();repaired=true;}
  if(!finiteVector(this.camera.position)||!finiteVector(this.lookTarget))repaired=true;
  if(repaired)this.cameraReady=false;
  return repaired;
 }
 rotate(delta){if(!Number.isFinite(delta)||this.mode==='walk'&&this.follow)return;this._ensureCameraState();this.yaw=(this.yaw%TAU+delta%TAU)%TAU;if(this.mode==='walk')this.walkYaw=this.yaw;else this.buildYaw=this.yaw;this._cutaway(true);}
 zoom(factor){if(!Number.isFinite(factor)||factor<=0)return;this._ensureCameraState();if(this.mode==='walk'){this.walkPitch=clamp(this.walkPitch+(factor-1)*.3,-.1,.65);}else this.buildDistance=clamp(this.buildDistance*factor,6,180);}
 pan(dx,dz){if(this.mode==='walk'||!Number.isFinite(dx)||!Number.isFinite(dz))return;this._ensureCameraState();this.center.x=clamp(this.center.x+dx,0,W);this.center.z=clamp(this.center.z+dz,0,H);}
 panBy(dx,dy){
  if(this.mode==='walk'||!Number.isFinite(dx)||!Number.isFinite(dy))return;
  this._ensureCameraState();
  const height=Number.isFinite(this.height)&&this.height>0?this.height:800;
  const scale=2*this.buildDistance*Math.tan(this.camera.fov*Math.PI/360)/height;
  const along=dy*scale/Math.max(.35,Math.sin(this.elevation)),across=dx*scale;
  this.pan(-across*Math.cos(this.yaw)-along*Math.sin(this.yaw),across*Math.sin(this.yaw)-along*Math.cos(this.yaw));
 }
 fit(){
  this._ensureCameraState();
  const rooms=this.school?.rooms||[],corridors=this.school?.corridors||[];
  let minX=W,maxX=0,minZ=H,maxZ=0;
  for(const r of rooms){const def=BY_TYPE[r.type];if(!def)continue;minX=Math.min(minX,r.x);maxX=Math.max(maxX,r.x+def.w);minZ=Math.min(minZ,r.z);maxZ=Math.max(maxZ,r.z+def.d);}
  for(const key of corridors){const x=key%W,z=Math.floor(key/W);minX=Math.min(minX,x);maxX=Math.max(maxX,x+1);minZ=Math.min(minZ,z);maxZ=Math.max(maxZ,z+1);}
  if(!rooms.length&&!corridors.length){minX=0;minZ=0;maxX=W;maxZ=H;}
  const width=maxX-minX+4,depth=maxZ-minZ+4;this.center.set((minX+maxX)/2,0,(minZ+maxZ)/2);
  // Project the occupied footprint onto camera right/up so tall layouts fit too.
  const horizontal=Math.abs(Math.cos(this.yaw))*width+Math.abs(Math.sin(this.yaw))*depth;
  const vertical=(Math.abs(Math.sin(this.yaw))*width+Math.abs(Math.cos(this.yaw))*depth)*Math.sin(this.elevation)+2;
  const tan=Math.tan(40*Math.PI/360);
  this.buildDistance=clamp(Math.max(horizontal/(2*tan*Math.max(.4,this.camera.aspect)),vertical/(2*tan))*1.05,10,180);
  this.cameraReady=false;this._updateCamera(0,true);this._cutaway(true);
 }
 screenToGround(clientX,clientY){
  if(!Number.isFinite(clientX)||!Number.isFinite(clientY))return null;
  const rect=this.canvas.getBoundingClientRect();if(![rect.left,rect.top,rect.width,rect.height].every(Number.isFinite)||rect.width<=0||rect.height<=0)return null;
  this._ensureCameraState();if(!this.cameraReady)this._updateCamera(0,true);
  this.pointer.set((clientX-rect.left)/rect.width*2-1,-(clientY-rect.top)/rect.height*2+1);
  if(!Number.isFinite(this.pointer.x)||!Number.isFinite(this.pointer.y))return null;
  this.raycaster.setFromCamera(this.pointer,this.camera);const point=new THREE.Vector3();
  return this.raycaster.ray.intersectPlane(this.pickPlane,point)&&finiteVector(point)?{x:point.x,z:point.z}:null;
 }
 orbit(dx,dy){
  if(!Number.isFinite(dx)||!Number.isFinite(dy))return;
  this._ensureCameraState();
  if(this.mode==='walk'){
   if(!this.follow)this.yaw=(this.yaw%TAU-(dx*.006)%TAU)%TAU;
   this.walkPitch=clamp(this.walkPitch+dy*.004,-.05,.65);this.walkYaw=this.yaw;
  }else{this.yaw=(this.yaw%TAU-(dx*.006)%TAU)%TAU;this.elevation=clamp(this.elevation+dy*.003,.55,1.4);this.buildYaw=this.yaw;}
  this._cutaway();
 }
 get cameraMode(){return this.follow?'locked':'free';}
 setCameraMode(mode){
  if(!['locked','free'].includes(mode))throw new Error('Unknown camera mode');
  this.setFollow(mode==='locked');
 }
 setFollow(value){
  this.follow=!!value;
  if(this.canvas?.dataset)this.canvas.dataset.cameraMode=this.cameraMode;
  if(!this.follow)return;
  this._ensureCameraState();this.walkPitch=.23;
  if(this.player){this.yaw=behindPlayerYaw(this.player.angle,this.yaw);this.walkYaw=this.yaw;}
  this.cameraReady=false;this._updateCamera(0,true);
 }

 _keepCameraInside(position,focus){
  if(!finiteVector(position)||!finiteVector(focus))return;
  const vector=position.clone().sub(focus),distance=vector.length();if(distance<.001)return;
  this.raycaster.set(focus,vector.normalize());this.raycaster.far=distance;
  const hit=this.raycaster.intersectObjects(this.wallObjects,false).find(i=>i.distance>.002);
  if(hit)position.copy(focus).addScaledVector(vector,Math.max(.005,hit.distance-.045));
  this.raycaster.far=Infinity;
 }
 _updateCamera(dt,snap=false){
  const repaired=this._ensureCameraState();
  const desired=new THREE.Vector3(),focus=new THREE.Vector3();
  const walking=this.mode==='walk'&&this.player&&Number.isFinite(this.player.x)&&Number.isFinite(this.player.z);
  if(walking){
   const p=this.player;
   if(this.follow){this.yaw=behindPlayerYaw(p.angle,this.yaw);this.walkYaw=this.yaw;}
   focus.set(clamp(p.x,0,W),.40,clamp(p.z,0,H));
   const distance=1.65,vertical=.43+this.walkPitch;
   desired.set(focus.x+Math.sin(this.yaw)*distance,focus.y+vertical,focus.z+Math.cos(this.yaw)*distance);
   this._keepCameraInside(desired,focus);
  }else{
   focus.copy(this.center);focus.y=.15;
   const radius=Math.cos(this.elevation)*this.buildDistance;
   desired.set(focus.x+Math.sin(this.yaw)*radius,Math.sin(this.elevation)*this.buildDistance,focus.z+Math.cos(this.yaw)*radius);
  }
  // lerp(...,1) still preserves NaN, so reset the pose with direct copies.
  if(snap||!this.cameraReady||repaired){this.camera.position.copy(desired);this.lookTarget.copy(focus);}
  else{const k=1-Math.exp(-Math.max(0,Number.isFinite(dt)?dt:0)*13);this.camera.position.lerp(desired,k);this.lookTarget.lerp(focus,k);}
  if(walking){
   // Recheck after smoothing: orbit interpolation can otherwise cut a corner.
   this._keepCameraInside(this.camera.position,focus);
   this.playerMesh.visible=this.camera.position.distanceTo(focus)>.22;
  }
  this.camera.lookAt(this.lookTarget);this.camera.updateMatrixWorld();this.cameraReady=true;
  if(repaired)this._cutaway(true);
 }
 update(dt,time){
  dt=Number.isFinite(dt)?Math.max(0,dt):0;
  this.elapsed=Number.isFinite(time)?time:this.elapsed+dt;
  this.resize();this._cutaway(false,dt);this._updateCamera(dt);
  for(const mesh of this.decorationMeshes.values())updateLocalTree(mesh,this.camera,this.elapsed);
  if(this.mode==='host')for(const label of this.roomLabels.values()){const height=Math.min(.75,label.userData.maxWidth/label.userData.ratio,14*2*Math.tan(this.camera.fov*Math.PI/360)*this.camera.position.distanceTo(label.position)/Math.max(1,this.height));label.scale.set(height*label.userData.ratio,height,1);}
  if(this.player)animateCharacter(this.playerMesh,{time:this.elapsed,speed:this.player.speed||0,running:!!this.player.running,scolding:false,stopped:!!this.player.scolded,lookYaw:this.mode==='walk'?angularDelta(this.player.angle??Math.PI,this.yaw+Math.PI):0,lookPitch:this.mode==='walk'?(this.walkPitch-.23)*.65:0});
  this.canvas.dataset.headLook=JSON.stringify(this.playerMesh.userData.headLook?{yaw:this.playerMesh.userData.headLook.yaw,pitch:this.playerMesh.userData.headLook.pitch}:null);
  for(const mesh of this.teacherMeshes.values()){const t=mesh.userData.teacherState;animateCharacter(mesh,{time:this.elapsed+(t.phase||0),speed:t.speed||0,running:false,scolding:!!t.scolding,stopped:!!t.scolding});}
  this._updateHostGuidance();
  // Sliding doors have genuine travel; the panel rests closed until a person approaches.
  for(const room of this.school?.rooms||[]){const mesh=this.roomMeshes.get(room.id);if(!mesh?.userData.doors)continue;const door=roomDoor(room);const nearby=this.mode==='walk'&&this.player&&Math.hypot(this.player.x-door.x,this.player.z-door.z)<1.05;
   for(const d of mesh.userData.doors){if(!d.panel)continue;const closed=d.closedX??d.panel.position.x,open=d.openX??closed+.6;d.panel.position.x=THREE.MathUtils.lerp(d.panel.position.x,nearby?open:closed,1-Math.exp(-dt*7));}
  }
  this.renderer.render(this.scene,this.camera);
 }
 dispose(){
  clearOfficeNurses(this.nurseMeshes,disposeCharacter);clearOfficePrincipals(this.principalMeshes,disposeCharacter);this._clearClassrooms();this.resizeObserver?.disconnect();this.scene.traverse(o=>{if(o.isInstancedMesh)o.dispose();});disposeModel(this.roomRoot);disposeModel(this.decorRoot);disposeCharacter(this.playerMesh);for(const mesh of this.teacherMeshes.values())disposeCharacter(mesh);this.renderer.dispose();
  for(const label of this.roomLabels.values()){label.material.map.dispose();label.material.dispose();}for(const o of [this.corridorPreviewFill,this.corridorPreviewLines]){o.geometry.dispose();o.material.dispose();}
  this.grid.geometry.dispose();this.grid.material.dispose();this.ghostMaterial.dispose();this.ghostOutline.geometry.dispose();this.ghostOutline.material.dispose();this.ghostDoor.material.dispose();this.targetRing.geometry.dispose();this.targetRing.material.dispose();disposeGuidance(this.targetMarker);disposeGuidance(this.playerLocator);setRoomGlow(this.highlightedRoom,false);
 }
}
