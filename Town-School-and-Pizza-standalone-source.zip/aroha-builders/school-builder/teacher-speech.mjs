import {lineOfSight,roomAt} from './core.mjs';

export const RUNNING_REPRIMAND='Stop. Please walk in the hallway.';
export const TEACHER_GREETINGS=Object.freeze(['Hello!','Hi there!','Hello! How are you?','Have a nice day!']);
const valid=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.z);
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
function facing(a,b){const angle=Number.isFinite(a.angle)?a.angle:0,d=distance(a,b);return (Math.sin(angle)*(b.x-a.x)+Math.cos(angle)*(b.z-a.z))/(d||1);}

/** Local teacher chatter is available to walkers and paired controllers only.
 * Encounters need a clear hallway sightline and both actors looking broadly
 * toward one another. Each approach gets at most one brief opportunity, with
 * global and per-teacher cooldowns; remaining nearby cannot retrigger it. */
export function createSchoolTeacherSpeech({voice}={}){
 if(!voice)throw Error('Teacher speech needs the shared school voice.');
 const greeting=voice.channel('greeting'),scold=voice.channel('scold');
 let time=0,lastGreeting=-Infinity,lastScold=-Infinity,school=null,runLocked=false,sequence=0;
 const encounters=new Map();
 function reset(){greeting.cancel();scold.cancel();encounters.clear();time=0;lastGreeting=lastScold=-Infinity;school=null;runLocked=false;sequence=0;}
 function reprimand(){
  if(time-lastScold<2)return false;
  for(const encounter of encounters.values())encounter.opportunityUntil=-Infinity;
  lastScold=time;return scold.speak(RUNNING_REPRIMAND);
 }
 function update(context,dt=0){
  time+=Number.isFinite(dt)?Math.max(0,Math.min(1,dt)):0;
  if(!context||!['walk','controller'].includes(context.mode)||!context.school||!valid(context.player)){
   if(school)reset();return null;
  }
  const firstContext=school!==context.school;
  if(school&&firstContext)reset();school=context.school;
  // A resumed walk can already have a running restriction. Only a fresh catch
  // event or a later false-to-true change should reprimand the child.
  if(firstContext)runLocked=!!context.runLocked;
  const newlyCaught=!!context.caught||!!context.runLocked&&!runLocked;runLocked=!!context.runLocked;
  if(context.paused){for(const e of encounters.values())e.opportunityUntil=-Infinity;return null;}
  if(newlyCaught){reprimand();return {type:'scold',text:RUNNING_REPRIMAND};}
  const player=context.player,candidates=[],seen=new Set();
  for(const [index,teacher] of (context.teachers||[]).entries()){
   if(!valid(teacher))continue;
   const id=teacher.id??`teacher-${index}`;seen.add(id);
   let entry=encounters.get(id);if(!entry){entry={near:false,lastGreeting:-Infinity,opportunityUntil:-Infinity};encounters.set(id,entry);}
   const d=distance(player,teacher);
   if(d>2.3){entry.near=false;entry.opportunityUntil=-Infinity;continue;}
   const visible=d>=.25&&d<=1.5&&!roomAt(school,player.x,player.z)&&!roomAt(school,teacher.x,teacher.z)&&lineOfSight(school,player,teacher);
   if(!entry.near&&visible){entry.near=true;entry.opportunityUntil=time+4;}
   if(visible&&entry.opportunityUntil>=time&&facing(teacher,player)>0&&facing(player,teacher)>-.15&&!teacher.scolding)candidates.push({teacher,entry,d});
  }
  for(const id of encounters.keys())if(!seen.has(id))encounters.delete(id);
  if(context.scoldTime>0||context.runLocked||player.running||time-lastScold<10||time-lastGreeting<18||!voice.greetingReady)return null;
  const candidate=candidates.sort((a,b)=>a.d-b.d).find(({entry})=>time-entry.lastGreeting>=60);
  if(!candidate)return null;
  const text=TEACHER_GREETINGS[sequence%TEACHER_GREETINGS.length];
  if(!greeting.speak(text))return null;
  sequence++;lastGreeting=time;candidate.entry.lastGreeting=time;candidate.entry.opportunityUntil=-Infinity;
  return {type:'greeting',teacherId:candidate.teacher.id,text};
 }
 return {update,reprimand,reset};
}
