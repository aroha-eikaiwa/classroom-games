import {gymFloorMaterial,createBasketballCourt,basketballCourtLayout} from './gym-floor.mjs';
import * as THREE from './vendor/three.module.js';
import {prepareWallCutaway} from './wall-cutaway.mjs';
import {roomFurnitureObstacles} from './room-obstacles.mjs';
import {roomWallLayout, classroomSeats} from './room-layout.mjs';
import {furnitureSurface,surfaceOptions,surfaceGeometry} from './furniture-surfaces.mjs';
import {createClassroomArt} from './school-art.mjs';
import {floorSurfaceOptions,floorSurfaceGeometry,resilientFloorColors} from './floor-surface.mjs';
import {WINDOW_FRAME,glazingKind,glazingMaterial,createGlazingPane,windowOpening,wallApertureRectangles} from './glazing.mjs';

// Models use the builder's grid units. A corridor is one unit wide.
// Shared geometry and per-part baking keep the school practical on classroom laptops.
const palette = {
  wall: 0xf3f0e7, wallLow: 0xd6e3dc, trim: 0xb59b78, wood: 0xc79a62,
  lightWood: 0xe1bf86, darkWood: 0x865c3d, metal: 0x73858b, ink: 0x263c46,
  white: 0xf9faf7, green: 0x346f60, glass: 0xa8d2d7, cream: 0xf8e7bd,
  coral: 0xe97a68, blue: 0x4c8eaf, yellow: 0xf3c761, leaf: 0x548d55
};
const materials = new Map();
function material(color, options = {}) {
  const key = `${color}:${JSON.stringify(Object.fromEntries(Object.entries(options).map(([key,value])=>[key,value?.isTexture?value.uuid:value])))}`;
  if (!materials.has(key)) materials.set(key, new THREE.MeshStandardMaterial({ color, roughness: .78, ...options }));
  return materials.get(key);
}
const sharedGeometry = {
  box: new THREE.BoxGeometry(1, 1, 1),
  cylinder: new THREE.CylinderGeometry(1, 1, 1, 12),
  cone: new THREE.ConeGeometry(1, 1, 12),
  sphere: new THREE.SphereGeometry(1, 12, 8),
  torus: new THREE.TorusGeometry(1, .065, 6, 24)
};
for (const geometry of Object.values(sharedGeometry)) geometry.userData.shared = true;
function mesh(parent, kind, x, y, z, sx, sy, sz, color, options) {
  let textured=false;for(let ancestor=parent;ancestor;ancestor=ancestor.parent)if(ancestor.userData.surfaceTextures){textured=true;break;}
  const surface=textured&&!options?.map?furnitureSurface(color):null;
  const geometry=surface?surfaceGeometry(sharedGeometry[kind],kind,sx,sy,sz,surface.density):sharedGeometry[kind];
  const object = new THREE.Mesh(geometry, material(color, surface?{...surfaceOptions(surface),...options}:options));
  object.position.set(x, y, z); object.scale.set(sx, sy, sz);
  object.castShadow = true; object.receiveShadow = true;
  parent.add(object); return object;
}
const box = (p,x,y,z,w,h,d,c,o) => mesh(p,'box',x,y,z,w,h,d,c,o);
const ball = (p,x,y,z,rx,ry,rz,c,o) => mesh(p,'sphere',x,y,z,rx,ry,rz,c,o);
const cylinder = (p,x,y,z,r,h,c,o) => mesh(p,'cylinder',x,y,z,r,h,r,c,o);
function rod(parent, start, end, radius, color) {
  const a = new THREE.Vector3(...start), b = new THREE.Vector3(...end), delta = b.clone().sub(a);
  const object = cylinder(parent, (a.x+b.x)/2, (a.y+b.y)/2, (a.z+b.z)/2, radius, delta.length(), color);
  object.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0), delta.normalize());
  return object;
}
function groupAt(parent, x=0, y=0, z=0, rotation=0) {
  const g = new THREE.Group(); g.position.set(x,y,z);g.rotation.y=rotation;parent.add(g);return g;
}

// Bake only static subtrees. Animated panels and skeletal pivots are kept outside.
function bake(group) {
  group.updateMatrixWorld(true);
  const inverse = group.matrixWorld.clone().invert(), buckets = new Map(), sources=[];
  group.traverse(object => {
    if (!object.isMesh || Array.isArray(object.material)) return;
    sources.push(object);
    const geometry = object.geometry.index ? object.geometry.toNonIndexed() : object.geometry.clone();
    geometry.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inverse, object.matrixWorld));
    const bucket = buckets.get(object.material) || {positions:[],normals:[],uvs:[]};
    bucket.positions.push(geometry.attributes.position.array);
    bucket.normals.push(geometry.attributes.normal.array);
    bucket.uvs.push(geometry.attributes.uv?.array || new Float32Array(geometry.attributes.position.count*2));
    buckets.set(object.material,bucket);geometry.dispose();
  });
  if (!sources.length) return group;
  group.clear();
  const combine = arrays => {const out = new Float32Array(arrays.reduce((n,a)=>n+a.length,0));let at=0;for(const a of arrays){out.set(a,at);at+=a.length;}return out;};
  for(const [mat,bucket] of buckets) {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.BufferAttribute(combine(bucket.positions),3));
    geometry.setAttribute('normal',new THREE.BufferAttribute(combine(bucket.normals),3));
    geometry.setAttribute('uv',new THREE.BufferAttribute(combine(bucket.uvs),2));
    geometry.computeBoundingSphere();geometry.userData.owned=true;
    const object = new THREE.Mesh(geometry,mat);object.castShadow=true;object.receiveShadow=true;group.add(object);
  }
  return group;
}

let woodTexture;
function woodMaterial() {
  if (!woodTexture) {
    const size=128,data=new Uint8Array(size*size*4);
    for(let y=0;y<size;y++)for(let x=0;x<size;x++){
      const i=(y*size+x)*4, seam=y%16===0||((x+(Math.floor(y/16)%2)*64)%128===0), grain=Math.sin(x*.21+y*4.3)*3+Math.sin(x*.08+y)*2;
      data[i]=seam?148:211+grain;data[i+1]=seam?111:177+grain;data[i+2]=seam?76:126+grain;data[i+3]=255;
    }
    woodTexture=new THREE.DataTexture(data,size,size,THREE.RGBAFormat);woodTexture.wrapS=woodTexture.wrapT=THREE.RepeatWrapping;woodTexture.repeat.set(2,2);woodTexture.colorSpace=THREE.SRGBColorSpace;woodTexture.needsUpdate=true;
  }
  return material(0xffffff,{map:woodTexture});
}

const textTextures=new Map();
function label(parent,text,x,y,z,width=.8,height=.14,color='#244552',bg='#fffdf5',rotation=0) {
  if(typeof document==='undefined') return;
  const key=`${text}|${color}|${bg}`;
  let texture=textTextures.get(key);
  if(!texture){
    const canvas=document.createElement('canvas');canvas.width=512;canvas.height=96;
    const ctx=canvas.getContext('2d');ctx.fillStyle=bg;ctx.fillRect(0,0,512,96);ctx.fillStyle=color;ctx.font='600 42px Arial, sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
    const lines=text.split('\n');if(lines.length>1){ctx.font='600 28px Arial, sans-serif';lines.slice(0,2).forEach((line,i)=>ctx.fillText(line,256,26+i*40,486));}else ctx.fillText(text,256,49,486);
    texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;textTextures.set(key,texture);
  }
  const planeMaterial=new THREE.MeshBasicMaterial({map:texture,side:THREE.DoubleSide});planeMaterial.userData.owned=true;
  const plane=new THREE.Mesh(new THREE.PlaneGeometry(width,height),planeMaterial);
  plane.geometry.userData.owned=true;plane.position.set(x,y,z);plane.rotation.y=rotation;parent.add(plane);return plane;
}

function table(parent,x,z,w=.56,d=.4,h=.32,top=palette.lightWood,drawers=false) {
  const g=groupAt(parent,x,0,z);
  box(g,0,h,0,w,.035,d,top);
  for(const px of [-w/2+.035,w/2-.035])for(const pz of [-d/2+.035,d/2-.035]) box(g,px,h/2,pz,.023,h,.023,palette.metal);
  if(drawers){box(g,w*.28,h*.58,0,w*.27,h*.60,d*.87,0xd2d8d3);box(g,w*.28,h*.76,d*.45,w*.18,.014,.016,palette.metal);box(g,w*.28,h*.50,d*.45,w*.18,.014,.016,palette.metal);}
  else {box(g,0,h-.11,-d*.33,w*.75,.025,d*.5,0xb3bdba);}
  return g;
}
function chair(parent,x,z,rotation=0,color=palette.lightWood,adult=false) {
  const g=groupAt(parent,x,0,z,rotation), h=adult?.235:.19,w=adult?.24:.21;
  box(g,0,h,0,w,.025,.22,color);
  box(g,0,h+.145,-.095,w,.17,.026,color);
  for(const px of [-w/2+.023,w/2-.023])for(const pz of [-.075,.075])box(g,px,h/2,pz,.018,h,.018,palette.metal);
  for(const px of [-w/2+.023,w/2-.023])box(g,px,h+.07,-.095,.017,.16,.017,palette.metal);
  return g;
}
function cabinet(parent,x,z,w=.8,h=.66,d=.25,color=0xd8dace,rotation=0) {
  const g=groupAt(parent,x,0,z,rotation);
  box(g,0,h/2,0,w,h,d,color);box(g,0,h/2,d/2+.005,.008,h-.03,.008,0xb4beb5);
  for(const side of [-1,1])box(g,side*.035,h*.56,d/2+.018,.012,.065,.025,palette.metal);
  box(g,0,.025,0,w+.025,.05,d+.02,palette.metal);return g;
}
const bookColors=[0xe47b64,0x548bab,0xd9b85e,0x6a9a7b,0xf0e3c0,0x8f83ab,0xb95d65];
function bookshelf(parent,x,z,w=.78,h=.82,rotation=0,books=true) {
  const g=groupAt(parent,x,0,z,rotation),d=.22;
  box(g,0,h/2,-d/2,w,h,.025,palette.wood);
  for(const px of [-w/2,w/2])box(g,px,h/2,0,.03,h,d,palette.wood);
  for(let row=0;row<=3;row++)box(g,0,.04+row*(h-.06)/3,0,w,.025,d,palette.wood);
  if(books)for(let row=0;row<3;row++)for(let i=0;i<8;i++) {
    const bh=.13+((i*3+row)%4)*.018,bw=.045+(i%3)*.008;
    box(g,-w*.40+i*w*.105,.067+row*(h-.06)/3+bh/2,.015,bw,bh,.145,bookColors[(i+row*3)%bookColors.length]);
  }
  return g;
}
function blackboard(parent,w,z=.11) {
  const fixture=groupAt(parent);fixture.userData.wallFixtureSide='north';fixture.name='blackboard';parent=fixture;
  box(parent,w/2,.85,z,Math.min(w-1,2.8),.55,.06,palette.darkWood);
  box(parent,w/2,.85,z+.033,Math.min(w-1.08,2.72),.48,.009,palette.green);
  box(parent,w/2,.575,z+.07,Math.min(w-.9,2.9),.025,.10,palette.trim);
  box(parent,w/2-.14,.595,z+.085,.07,.012,.012,palette.white);
  box(parent,w/2+.10,.595,z+.075,.09,.022,.035,palette.ink);
  // Lesson writing is a separate subject-specific surface attached to this wall.
}
function wallClock(parent,x,y,z,rotation=0) {
  const g=groupAt(parent,x,y,z,rotation);g.userData.wallFixtureSide='north';g.name='wall-clock';
  const rim=cylinder(g,0,0,0,.095,.025,palette.ink);rim.rotation.x=Math.PI/2;
  const face=cylinder(g,0,0,.017,.080,.009,palette.white);face.rotation.x=Math.PI/2;
  box(g,0,.023,.025,.008,.049,.005,palette.ink);const minute=box(g,.018,-.004,.026,.044,.006,.005,palette.ink);minute.rotation.z=-.25;
}
function pottedPlant(parent,x,z,size=.18) {
  cylinder(parent,x,.065,z,size*.42,.13,0xc88762);
  for(let i=0;i<5;i++){const a=i*Math.PI*2/5;ball(parent,x+Math.sin(a)*size*.35,.20+(i%2)*.035,z+Math.cos(a)*size*.35,size*.34,.095,size*.20,[0x4c8566,0x75a568,0x5a9461][i%3]);}
}
function sink(parent,x,z,rotation=0,heightOffset=0) {
  const g=groupAt(parent,x,heightOffset,z,rotation);
  box(g,0,.34,0,.32,.055,.27,0xe4e8e3);
  box(g,0,.371,0,.22,.006,.17,0x8caaad);
  box(g,0,.374,0,.16,.008,.11,0xbcd3d2);
  rod(g,[0,.36,-.09],[0,.48,-.09],.012,palette.metal);rod(g,[0,.48,-.09],[0,.48,-.01],.012,palette.metal);
  cylinder(g,.075,.39,-.09,.018,.035,palette.metal);
}
function sofa(parent,x,z,w=.95,rotation=0,color=0x6e9996) {
  const g=groupAt(parent,x,0,z,rotation);box(g,0,.16,0,w,.20,.34,color);box(g,0,.31,-.13,w,.27,.10,color);
  for(const px of [-w/2+.04,w/2-.04])box(g,px,.23,0,.09,.25,.36,color);
  for(let i=0;i<3;i++)box(g,-w/3+i*w/3,.272,.025,w/3-.023,.025,.23,0x83b0a7);
  for(const px of [-w/2+.10,w/2-.10])for(const pz of [-.11,.11])box(g,px,.035,pz,.04,.07,.04,palette.darkWood);
}

function roomWalls(room,definition,layout) {
  const {w,d}=definition, entrance=room.type==='entrance';
  const walls=[];
  for(const side of ['north','south','east','west']) {
    const wall=new THREE.Group();wall.name=`wall-${side}`;wall.userData.wallSide=side;
    const shell=new THREE.Group(),fittings=new THREE.Group();fittings.name='wall-fittings';wall.add(shell,fittings);walls.push(wall);
    const horizontal=side==='north'||side==='south',length=horizontal?w:d,at=side==='south'?d:side==='east'?w:0;
    const hasDoor=side==='south'||(side==='north'&&entrance),doorX=1.5,half=.355;
    const windows=layout.windows.filter(slot=>slot.side===side),capMatrices=[];
    function wallSegment(from,to){
      if(to-from<.001)return;
      const middle=(from+to)/2,width=to-from;
      for(const piece of wallApertureRectangles(from,to,windows)){
        const center=(piece.from+piece.to)/2,length=piece.to-piece.from,height=piece.top-piece.bottom;
        box(shell,horizontal?center:at,(piece.bottom+piece.top)/2,horizontal?at:center,horizontal?length:.065,height,horizontal?.065:length,palette.wall);
      }
      capMatrices.push(new THREE.Matrix4().compose(new THREE.Vector3(horizontal?middle:at,0,horizontal?at:middle),new THREE.Quaternion(),new THREE.Vector3(horizontal?width:.09,.018,horizontal?.09:width)));
      box(shell,horizontal?middle:at,.21,horizontal?at:middle,horizontal?width:.074,.39,horizontal?.074:width,definition.wallColor||palette.wallLow);
      box(shell,horizontal?middle:at,.045,horizontal?at:middle,horizontal?width:.08,.075,horizontal?.08:width,palette.trim);
      box(shell,horizontal?middle:at,1.255,horizontal?at:middle,horizontal?width:.085,.035,horizontal?.085:width,palette.white);
    }
    if(hasDoor){wallSegment(0,doorX-half);wallSegment(doorX+half,length);box(shell,doorX,1.145,at,.71,.23,.065,palette.wall);}
    else wallSegment(0,length);
    // Thin frames surround an open aperture. A separate pane keeps glass out
    // of the opaque baked frame mesh and avoids solid glass shadow rectangles.
    for(const slot of windows){
      const pos=slot.position,rotation=horizontal?0:Math.PI/2;
      const window=groupAt(fittings,horizontal?pos:at,slot.y,horizontal?at:pos,rotation);
      const t=WINDOW_FRAME;
      for(const x of [-slot.width/2+t/2,slot.width/2-t/2])box(window,x,0,0,t,slot.height,.082,0xe9e7dc);
      for(const y of [-slot.height/2+t/2,slot.height/2-t/2])box(window,0,y,0,slot.width,t,.082,0xe9e7dc);
      box(window,0,0,0,.016,slot.height-t*2,.045,0xe9e7dc);
      box(window,0,-slot.height/2-.006,0,slot.width+.055,.021,.12,palette.lightWood);
      const opening=windowOpening(slot),pane=createGlazingPane(opening.to-opening.from,opening.top-opening.bottom,glazingKind(room.type));
      pane.position.set(horizontal?pos:at,slot.y,horizontal?at:pos);pane.rotation.y=rotation;wall.add(pane);
    }
    prepareWallCutaway(wall,shell,{capMatrices});bake(fittings);
    if(hasDoor){
      const atZ=at,frame=new THREE.Group();wall.add(frame);
      for(const px of [doorX-half,doorX+half])box(frame,px,.53,atZ,.035,1.05,.10,palette.darkWood);
      box(frame,doorX,1.06,atZ,.76,.035,.11,palette.darkWood);
      box(frame,doorX,.017,atZ,.76,.018,.11,palette.trim);bake(frame);
      const panel=groupAt(wall,doorX,0,atZ);panel.name='sliding-door';
      box(panel,0,.52,0,.65,1.01,.032,palette.lightWood);
      const doorGlass=box(panel,0,.77,0,.54,.36,.039,0xd1e0db);doorGlass.material=glazingMaterial(glazingKind(room.type,{door:true}));doorGlass.castShadow=false;
      for(const s of [-1,1])box(panel,.24,.47,s*.03,.025,.13,.026,palette.darkWood);
      box(panel,0,.60,0,.57,.022,.047,palette.trim);bake(panel);
      wall.userData.door={panel,closedX:doorX,openX:doorX+.67,side};
      label(wall,definition.en||definition.name||room.type,doorX,1.16,atZ+(side==='south'?.043:-.043),.82,.13,'#244552','#fffdf5',side==='north'?Math.PI:0);
    }
  }
  return walls;
}

function entranceFurniture(g,w,d) {
  for(const x of [.28,w-.28]){
    const side=x<1?1:-1,bank=groupAt(g,x,0,d/2,side>0?Math.PI/2:-Math.PI/2);
    box(bank,0,.43,0,d-1,.86,.27,0xdfd6ba);
    for(let row=0;row<3;row++)for(let col=0;col<6;col++){
      const px=-(d-1)/2+.19+col*(d-1)/6,py=.16+row*.255;
      box(bank,px,py,.143,(d-1)/6-.035,.205,.012,0xa79d85);
      box(bank,px-.045,py-.07,.18,.07,.025,.11,0xf5f5eb);box(bank,px+.045,py-.07,.18,.07,.025,.11,0xf5f5eb);
    }
  }
  box(g,w/2,.017,d-.43,w-.9,.025,.42,0x667f7c);
  box(g,2.85,.16,1.40,.70,.12,.26,palette.lightWood);for(const x of [2.58,3.12])box(g,x,.07,1.40,.055,.14,.22,palette.darkWood);
  pottedPlant(g,w-.55,.45,.25);
}
function classroomFurniture(g,w,d) {
  blackboard(g,w);table(g,w/2,.52,.8,.37,.34,palette.wood,true);
  for(const seat of classroomSeats('classroom')){
    const {x}=seat,z=seat.z-.29;table(g,x,z,.49,.33,.29);chair(g,x,seat.z,seat.rotation);
    box(g,x-.08,.315,z-.025,.16,.008,.18,0xf4f0df);box(g,x+.12,.315,z+.04,.06,.017,.10,0x5894aa);
  }
  wallClock(g,w-.38,1.05,.11);cabinet(g,w-.55,d-.20,.83,.57,.29);
}
function teacherFurniture(g,w,d) {
  for(let row=0;row<2;row++)for(let col=0;col<3;col++){
    const x=2.05+col*.83,z=.8+row*1.15;table(g,x,z,.72,.46,.35,0xd5cfb5,true);chair(g,x,z+.36,Math.PI,0x64828e,true);
    box(g,x-.12,.379,z,.20,.012,.16,0xf5f3e8);box(g,x+.12,.42,z-.12,.19,.11,.025,0x425b63);box(g,x+.12,.377,z-.11,.12,.015,.13,palette.ink);
  }
  cabinet(g,.42,.7,.65,.91,.38,0xc5d2cc,Math.PI/2);cabinet(g,.42,1.65,.65,.91,.38,0xc5d2cc,Math.PI/2);
  blackboard(g,2.1);pottedPlant(g,w-.3,d-.3,.19);
}
function principalFurniture(g,w,d) {
  table(g,1.65,.70,1.05,.53,.37,palette.darkWood,true);chair(g,1.65,.32,0,0x3a6667,true);
  box(g,1.73,.40,.7,.28,.012,.20,0xf9f6e8);box(g,1.38,.42,.70,.11,.06,.08,palette.ink);
  sofa(g,.55,1.55,1.12,Math.PI/2);sofa(g,w-.47,1.55,1.12,-Math.PI/2);
  table(g,w/2,1.6,.60,.65,.20,palette.wood);pottedPlant(g,w-.37,.30,.25);
  bookshelf(g,.5,.18,.72,.75,0,false);
  box(g,w/2,.91,.08,.45,.27,.035,palette.darkWood);box(g,w/2,.91,.102,.39,.21,.006,palette.cream);
}
function scienceFurniture(g,w,d) {
  blackboard(g,w);
  for(let row=0;row<2;row++)for(let col=0;col<2;col++){
    const x=1.32+col*2.05,z=1.15+row*1.60;
    table(g,x,z,1.22,.74,.36,0x6f7770,true);sink(g,x+.37,z-.18);
    for(const [dx,dz,rot] of [[-.35,.57,Math.PI],[.35,.57,Math.PI],[-.35,-.57,0],[.35,-.57,0]])chair(g,x+dx,z+dz,rot,0xcdb184);
    cylinder(g,x-.34,.415,z,.035,.09,0x89bac5,{roughness:.25});
    cylinder(g,x-.12,.40,z-.08,.055,.06,0xd19b88,{roughness:.3});
  }
  cabinet(g,w-.25,1.45,.95,.76,.34,0xd8dfcc,-Math.PI/2);
  cabinet(g,.24,1.55,.9,.76,.34,0xd8dfcc,Math.PI/2);
}
function piano(parent,x,z,rotation=0) {
  const p=groupAt(parent,x,0,z,rotation);
  box(p,0,.40,-.12,.84,.72,.30,0x263232);box(p,0,.36,.11,.87,.14,.28,0x273638);
  box(p,0,.447,.13,.76,.016,.19,0xf1efdf);
  for(let i=0;i<16;i++)box(p,-.36+i*.048,.456,.13,.003,.006,.18,0x77817e);
  for(let i=0;i<15;i++)if(i%7!==2&&i%7!==6)box(p,-.336+i*.048,.468,.073,.026,.022,.11,0x202b2b);
  box(p,0,.68,.05,.73,.11,.025,0x324343);
  table(p,0,.52,.43,.22,.22,0x354b4a);return p;
}
function musicFurniture(g,w,d) {
  blackboard(g,w);piano(g,.8,.67,.16);
  for(const seat of classroomSeats('music'))chair(g,seat.x,seat.z,seat.rotation,0xd9bd83);
  for(let i=0;i<2;i++){
    const x=w-.48,z=.55+i*.7;cylinder(g,x,.36,z,.16,.24,0x945c40);cylinder(g,x,.49,z,.17,.02,0xf2e3bd);for(const dx of [-.10,.10])rod(g,[x+dx,.24,z],[x+dx*.8,.02,z+.1],.016,palette.metal);
  }
  const xy=groupAt(g,.46,0,2.12,Math.PI/2);table(xy,0,0,.7,.35,.32,palette.darkWood);
  for(let i=0;i<8;i++)box(xy,-.29+i*.083,.35,0,.064,.025,.28-i*.016,bookColors[i%7]);
}
function artFurniture(g,w,d) {
  blackboard(g,w);
  for(let row=0;row<2;row++)for(let col=0;col<2;col++){
    const x=1.30+col*2,z=1.20+row*1.55;table(g,x,z,1.15,.72,.33,palette.lightWood);
    for(const dx of [-.35,.35])for(const dz of [-.51,.51])chair(g,x+dx,z+dz,dz<0?0:Math.PI);
    box(g,x-.15,.354,z,.33,.006,.25,0xf6f1df);box(g,x-.14,.360,z,.11,.003,.11,0xe68e72);
    cylinder(g,x+.28,.40,z-.13,.04,.12,0x8ea9a5);for(let i=0;i<3;i++)rod(g,[x+.26+i*.02,.41,z-.13],[x+.25+i*.025,.55,z-.14],.004,0x9b5d3c);
  }
  cabinet(g,.24,1.40,1.0,.63,.30,0xd0d7c6,Math.PI/2);
  for(let i=0;i<3;i++){
    const x=w-.25,z=.75+i*.8;rod(g,[x-.12,.04,z],[x,.77,z],.014,palette.wood);rod(g,[x+.12,.04,z],[x,.77,z],.014,palette.wood);
    box(g,x,.58,z+.02,.29,.32,.025,0xe8d9b9);box(g,x,.58,z+.037,.24,.27,.003,0x9fc2b3);ball(g,x+.04,.62,z+.045,.055,.04,.006,0xedb270);
  }
}
function cookingFurniture(g,w,d) {
  blackboard(g,w);
  for(let row=0;row<2;row++)for(let col=0;col<2;col++){
    const x=1.35+col*2.05,z=1.12+row*1.70;
    box(g,x,.21,z,1.28,.39,.72,0xe4dec9);box(g,x,.42,z,1.34,.06,.78,0xd7dfdc);
    for(let i=0;i<3;i++){box(g,x-.42+i*.42,.20,z+.367,.39,.33,.012,0xf0ebda);box(g,x-.42+i*.42,.30,z+.38,.12,.014,.022,palette.metal);}
    sink(g,x+.35,z-.07,0,.10);box(g,x-.32,.458,z,.45,.012,.42,0x33474a);
    for(const dx of [-.11,.11])for(const dz of [-.11,.11]){const coil=cylinder(g,x-.32+dx,.469,z+dz,.068,.009,0x7d9091);}
    cylinder(g,x-.43,.52,z-.11,.06,.10,0xb4bdb6);box(g,x-.34,.55,z-.11,.08,.015,.02,palette.ink);
  }
  cabinet(g,.32,.65,.48,.86,.44,0xe2e9e1);box(g,.32,.65,.88,.018,.18,.022,palette.metal);
  cabinet(g,w-.23,2.0,1.05,.90,.29,0xccd7c9,-Math.PI/2);
}
function libraryFurniture(g,w,d) {
  for(const x of [.65,1.65,2.65,3.65])bookshelf(g,x,.20,.85,.91);
  for(const x of [.28,w-.28])for(let i=0;i<2;i++)bookshelf(g,x,1.45+i*1.1,.86,.82,x<1?Math.PI/2:-Math.PI/2);
  for(const z of [1.55,2.85]){
    table(g,2.5,z,1.82,.60,.32,palette.lightWood);
    for(const dx of [-.57,0,.57])for(const dz of [-.44,.44])chair(g,2.5+dx,z+dz,dz<0?0:Math.PI,0x80a49b);
    for(let i=0;i<3;i++)box(g,2.0+i*.50,.347,z,.19,.025,.25,bookColors[i+1]);
  }
}
function gymFurniture(g,w,d) {
  box(g,w/2,.16,.43,w-.35,.27,.72,palette.wood);box(g,w/2,.32,.65,1.10,.02,.22,palette.lightWood);
  g.add(createBasketballCourt(w,d));
  for(const side of [-1,1]){
    const x=side<0?.30:w-.30,z=basketballCourtLayout(w,d).centerZ;rod(g,[x,.05,z],[x,1.09,z],.026,palette.metal);
    const board=box(g,x,1.12,z,.035,.43,.66,palette.white);box(g,x+(side<0?.025:-.025),1.10,z,.009,.22,.28,palette.coral);
    const hoop=new THREE.Mesh(sharedGeometry.torus,material(0xe77e4e));hoop.rotation.x=Math.PI/2;hoop.scale.set(.13,.13,.13);hoop.position.set(x+(side<0?.17:-.17),.95,z);g.add(hoop);
    for(let i=0;i<6;i++){const a=i*Math.PI/3;rod(g,[hoop.position.x+Math.sin(a)*.12,.95,z+Math.cos(a)*.12],[hoop.position.x+Math.sin(a)*.07,.78,z+Math.cos(a)*.07],.003,palette.white);}
  }
  box(g,w-.55,.12,d-.35,.70,.23,.40,0x5f8b9d);
}
function restroomFurniture(g,w,d) {
  for(let i=0;i<3;i++){
    const x=.50+i*.85,z=.70;
    box(g,x-.40,.42,z,.025,.84,1.05,0xc7dad5);box(g,x,.42,1.20,.77,.84,.025,0xc7dad5);
    box(g,x,.42,1.218,.69,.75,.01,0xe4ece4);box(g,x+.25,.43,1.232,.032,.032,.024,palette.metal);
    box(g,x,.30,.30,.30,.38,.13,palette.white);ball(g,x,.19,.55,.17,.12,.22,palette.white);box(g,x,.10,.51,.16,.20,.20,palette.white);
  }
  // Wash basins and mirrors belong on a side wall, never across the exit
  // or in the sliding door's travel. Two basins fit the clear rear wash area.
  for(const z of [1.62,2.36]){
    sink(g,.26,z,Math.PI/2);
    box(g,.26,.24,z,.24,.40,.29,0xdde3dc);
    const mirror=groupAt(g);mirror.userData.wallFixtureSide='west';mirror.name='washroom-mirror';
    box(mirror,.084,.80,z,.02,.44,.48,palette.metal);
    box(mirror,.099,.80,z,.01,.39,.43,0xbed7d5,{metalness:.2,roughness:.15});
  }
}
function nurseFurniture(g,w,d) {
  for(let i=0;i<2;i++){
    const x=2.25+i*1.05,z=.95;
    box(g,x,.19,z,.67,.16,1.13,0xd9dfd4);box(g,x,.29,z,.63,.07,1.08,palette.white);box(g,x,.35,z-.35,.42,.08,.23,0xfaf9e9);box(g,x,.335,z+.18,.64,.02,.58,0xb7d1c6);
    for(const dx of [-.27,.27])for(const dz of [-.48,.48])box(g,x+dx,.08,z+dz,.035,.16,.035,palette.metal);
    box(g,x,.39,z-.55,.67,.34,.035,palette.metal);
  }
  rod(g,[1.75,.03,.3],[1.75,1.05,.3],.017,palette.metal);rod(g,[1.75,1.05,.3],[3.82,1.05,.3],.017,palette.metal);
  // Gathered curtain; room remains readable from above and the aisle is clear.
  for(let i=0;i<6;i++)box(g,1.80+i*.035,.68,.33+(i%2)*.025,.028,.70,.05,0xb4d0bf);
  table(g,.65,.75,.8,.43,.34,palette.lightWood,true);chair(g,.65,1.10,Math.PI,0x77a59e,true);
  cabinet(g,.27,1.9,.65,.85,.30,0xe3e8df,Math.PI/2);
  box(g,3.57,.035,2.5,.31,.04,.33,0xcbd7d3);rod(g,[3.57,.05,2.38],[3.57,.87,2.38],.015,palette.metal);box(g,3.57,.86,2.42,.15,.10,.045,palette.white);
}
function playgroundFurniture(g,w,d) {
  box(g,w/2,-.012,d/2,w,.035,d,0xd4bf8b);
  const fence=groupAt(g);for(let x=.1;x<w;x+=.55)for(const z of [.08,d-.08])if(!(z>d/2&&x>1.1&&x<1.9))box(fence,x,.23,z,.035,.46,.035,0x879f8e);
  for(let z=.1;z<d;z+=.55)for(const x of [.08,w-.08])box(fence,x,.23,z,.035,.46,.035,0x879f8e);
  for(const z of [.08,d-.08]){if(z>d/2){box(fence,.55,.30,z,1.05,.035,.025,0xb1c0af);box(fence,(w+1.86)/2,.30,z,w-1.86,.035,.025,0xb1c0af);}else box(fence,w/2,.30,z,w,.035,.025,0xb1c0af);}
  for(const x of [.08,w-.08])box(fence,x,.30,d/2,.025,.035,d,0xb1c0af);
  // Playground collision footprints match these posts, ladder and slide.
  for(const x of [1.1,2.6])for(const z of [1.0,2.1])rod(g,[x,.02,z],[x,.93,z],.025,0x4e8c9f);
  for(const z of [1.0,2.1])rod(g,[1.1,.93,z],[2.6,.93,z],.025,0x4e8c9f);
  for(let x=1.1;x<=2.61;x+=.25)rod(g,[x,.94,1],[x,.94,2.1],.017,0xe2b458);
  for(let y=.2;y<.94;y+=.2)rod(g,[1.1,y,1],[1.1,y,2.1],.017,0xe2b458);
  const slide=groupAt(g,4.75,0,1.1);box(slide,0,.67,0,.48,.05,.48,0xe3b659);
  for(const x of [-.18,.18])rod(slide,[x,.03,-.18],[x,.67,-.18],.023,0x6d8b7c);
  const ramp=box(slide,0,.35,.60,.45,.035,1.27,0xc6d9d3);ramp.rotation.x=.55;
  for(const x of [-.23,.23]){const rail=box(slide,x,.40,.60,.025,.12,1.27,0xe1b058);rail.rotation.x=.55;}
  for(let i=0;i<4;i++)box(slide,0,.15+i*.15,-.42+i*.06,.35,.025,.12,0x5e8e96);
  for(const z of [3.2,4.1])box(g,4.65,.02,z,2.35,.006,.025,0xf8f4df);for(const x of [3.48,5.82])box(g,x,.02,3.65,.025,.006,.90,0xf8f4df);
}
const furnishers={entrance:entranceFurniture,classroom:classroomFurniture,teachers:teacherFurniture,principal:principalFurniture,science:scienceFurniture,music:musicFurniture,art:artFurniture,cooking:cookingFurniture,library:libraryFurniture,gym:gymFurniture,restroom:restroomFurniture,nurse:nurseFurniture,playground:playgroundFurniture};

export function createRoomModel(room,definition,school) {
  const g=new THREE.Group();g.name=`room-${room.type}`;g.userData.roomId=room.id;g.userData.doors=[];g.userData.furnitureObstacles=roomFurnitureObstacles(room.type);
  const {w,d}=definition;
  const layout=roomWallLayout(room,definition,school);g.userData.classroomLayout=layout;
  const resilient=resilientFloorColors[room.type];
  const floor=new THREE.Mesh(resilient?floorSurfaceGeometry(sharedGeometry.box,w,.10,d):sharedGeometry.box,resilient?material(resilient,floorSurfaceOptions()):room.type==='playground'?material(0xd4bf8b):room.type==='gym'?gymFloorMaterial():woodMaterial());
  floor.position.set(w/2,-.055,d/2);floor.scale.set(w,.10,d);floor.receiveShadow=true;g.add(floor);
  const furniture=new THREE.Group();furniture.name='furniture';furniture.userData.surfaceTextures=true;g.add(furniture);
  (furnishers[room.type]||classroomFurniture)(furniture,w,d);
  const fixtures=[];furniture.traverse(o=>{if(o.userData.wallFixtureSide)fixtures.push(o);});
  for(const fixture of fixtures)fixture.removeFromParent();
  bake(furniture);
  const art=createClassroomArt(layout,room.type);
  if(room.type!=='playground')for(const wall of roomWalls(room,definition,layout)){
    g.add(wall);if(wall.userData.door)g.userData.doors.push(wall.userData.door);
    for(const fixture of fixtures)if(fixture.userData.wallFixtureSide===wall.userData.wallSide)wall.add(fixture);
    for(const panel of [...art.children])if(panel.userData.wallSide===wall.userData.wallSide){delete panel.userData.wallSide;wall.add(panel);}
  }
  else {
    const sign=groupAt(g,1.5,0,d-.025);box(sign,-.36,.33,0,.035,.66,.035,palette.darkWood);box(sign,.36,.33,0,.035,.66,.035,palette.darkWood);box(sign,0,.58,0,.82,.17,.035,palette.white);label(sign,definition.en||'Playground',0,.58,.021,.75,.14);
  }
  g.userData.doorPanel=g.userData.doors[0]?.panel||null;
  return g;
}

function characterLimb(parent,x,y,z,{length=.17,width=.065,color=palette.blue,lowerColor=color,shoe=false}) {
  const pivot=groupAt(parent,x,y,z),upper=new THREE.Group();pivot.add(upper);
  ball(upper,0,-length*.43,0,width*.53,length*.53,width*.53,color);
  const joint=groupAt(pivot,0,-length,0),lower=new THREE.Group();joint.add(lower);
  ball(lower,0,-length*.43,0,width*.48,length*.53,width*.48,lowerColor);
  const end=groupAt(joint,0,-length,0);
  if(shoe){box(end,0,-.012,.025,width*1.15,.041,.12,0xf2f2e9);box(end,0,-.033,.027,width*1.19,.012,.124,0x62757a);box(end,0,.011,.019,width*.96,.008,.052,0x8fa7b5);}
  else ball(end,0,-.015,0,width*.48,.035,width*.45,lowerColor);
  bake(upper);bake(lower);bake(end);return{pivot,joint,end};
}

export function createCharacter({teacher=false,variant=0,uniform=''}={}) {
  const root=new THREE.Group();root.name=teacher?'teacher':'student';
  const scale=teacher?1.17:1;root.scale.setScalar(scale);
  const body=groupAt(root,0,0,0),torso=groupAt(body,0,.438,0);
  const skin=[0xe0b592,0xcc9f7b,0xe8c5a2,0xc38d67][variant%4];
  const clothing=uniform==='nurse'?0xfaf4e8:teacher?[0xe3e7de,0xb8d0d8,0xe7c4bd][variant%3]:[0xf0bf52,0x5a9fb1,0xe58f7c,0x83a586][variant%4];
  const trousers=teacher?[0x3d5460,0x53665b,0x484e64][variant%3]:0x415c76;
  const hairColor=[0x3b302b,0x322d2a,0x574032,0x45352e][variant%4];
  const chest=new THREE.Group();torso.add(chest);
  ball(chest,0,.005,0,.112,.137,.068,clothing);box(chest,0,-.085,0,.176,.035,.12,clothing);
  if(teacher){
    box(chest,0,.016,.066,.008,.17,.009,0xf4f1e6);for(let i=0;i<3;i++)ball(chest,.008,.065-i*.04,.074,.005,.005,.004,0x7d8d89);
    const collar1=box(chest,-.025,.105,.054,.045,.035,.018,palette.white);collar1.rotation.z=.25;const collar2=box(chest,.025,.105,.054,.045,.035,.018,palette.white);collar2.rotation.z=-.25;
    box(chest,.061,.052,.067,.037,.045,.007,0xf2eee2);
    if(variant%2===0){box(chest,0,.05,.081,.022,.10,.008,0x507a87);}
  }else{
    box(chest,0,.005,.068,.074,.06,.008,0xf6f4e3);box(chest,0,.005,.073,.045,.033,.004,clothing);
  }
  bake(chest);
  const pelvis=groupAt(body,0,.327,0);ball(pelvis,0,0,0,.091,.060,.061,trousers);bake(pelvis);
  const head=groupAt(torso,0,.166,0),face=new THREE.Group();head.add(face);
  cylinder(face,0,-.037,0,.031,.055,skin);ball(face,0,.046,0,.092,.105,.083,skin);
  ball(face,0,.091,-.011,.096,.079,.083,hairColor);
  // Fringe stays above the eyes and the ears/cheeks give a readable silhouette.
  for(let i=0;i<4;i++)ball(face,-.059+i*.039,.105,.058,.030,.028,.030,hairColor);
  for(const side of [-1,1]){
    ball(face,side*.090,.041,-.002,.016,.026,.015,skin);
    ball(face,side*.032,.049,.077,.009,.012,.005,0x29383c);
    ball(face,side*.034,.053,.081,.002,.003,.002,palette.white);
    ball(face,side*.045,.021,.074,.017,.009,.003,0xdba487);
  }
  ball(face,0,.031,.082,.010,.014,.012,skin);box(face,0,.001,.078,.031,.003,.003,0x9c715d);
  if(teacher&&variant%2===0){
    for(const side of [-1,1]){
      const lens=new THREE.Mesh(sharedGeometry.torus,material(0x344b52));lens.scale.set(.023,.019,.023);lens.position.set(side*.033,.050,.084);face.add(lens);
    }
    rod(face,[-.01,.05,.085],[.01,.05,.085],.002,0x344b52);
  }
  if(!teacher&&variant%3===2){ball(face,-.090,.046,-.046,.038,.048,.035,hairColor);ball(face,.090,.046,-.046,.038,.048,.035,hairColor);}
  bake(face);
  const leftLeg=characterLimb(body,-.047,.31,0,{length:.139,width:.07,color:trousers,lowerColor:teacher?trousers:skin,shoe:true});
  const rightLeg=characterLimb(body,.047,.31,0,{length:.139,width:.07,color:trousers,lowerColor:teacher?trousers:skin,shoe:true});
  const leftArm=characterLimb(torso,-.115,.090,0,{length:.103,width:.054,color:clothing,lowerColor:skin});
  const rightArm=characterLimb(torso,.115,.090,0,{length:.103,width:.054,color:clothing,lowerColor:skin});
  root.userData.rig={body,torso,head,leftLeg,rightLeg,leftArm,rightArm,teacher};
  root.userData.animation={phase:0,lastTime:null};return root;
}

export function animateCharacter(group,{time=0,speed=0,running=false,scolding=false,stopped=false,lookYaw=0,lookPitch=0}={}) {
  const rig=group.userData.rig;if(!rig)return;
  const a=group.userData.animation,dt=a.lastTime==null?0:Math.min(.08,Math.max(0,time-a.lastTime));a.lastTime=time;
  const moving=!stopped&&speed>.025,weight=moving?Math.min(1,speed/(running?.7:.35)):0;
  a.phase+=dt*(running?15:10)*Math.min(1.4,Math.max(.45,speed/(running?1.55:.80)));
  const phase=a.phase,swing=Math.sin(phase),amp=running?.70:.43;
  rig.body.position.y=moving?(Math.cos(phase*2)+1)*(running?.014:.006):Math.sin(time*1.8)*.002;
  rig.torso.rotation.x=running&&moving?.12:0;
  rig.torso.rotation.y=swing*.035*weight;
  for(const [leg,offset] of [[rig.leftLeg,0],[rig.rightLeg,Math.PI]]){
    const p=phase+offset,s=Math.sin(p);
    leg.pivot.rotation.x=s*amp*weight;
    leg.joint.rotation.x=Math.max(0,-s)*(running?1.05:.55)*weight;
    leg.end.rotation.x=-leg.joint.rotation.x*.40-Math.max(0,s)*.10*weight;
  }
  for(const [arm,offset] of [[rig.leftArm,Math.PI],[rig.rightArm,0]]){
    arm.pivot.rotation.x=Math.sin(phase+offset)*(running?.63:.35)*weight;
    arm.pivot.rotation.z=arm===rig.leftArm?.065:-.065;
    arm.joint.rotation.x=-(running?.90:.12)*weight;
  }
  rig.head.rotation.y=(Math.sin(time*.65)*.025+Math.max(-.66,Math.min(.66,lookYaw)))*(1-.85*weight);rig.head.rotation.x=Math.max(-.22,Math.min(.22,lookPitch))*(1-.85*weight);
  if(scolding){
    rig.rightArm.pivot.rotation.x=-1.02+Math.sin(time*7)*.13;
    rig.rightArm.pivot.rotation.z=-.20;rig.rightArm.joint.rotation.x=-.36;
    rig.head.rotation.x=.05+Math.sin(time*5)*.025;
    rig.leftArm.pivot.rotation.x=-.10;
  }
}

export function createDecoration(type='tree') {
  const g=new THREE.Group();g.name=`decoration-${type}`;
  if(type==='bench'){
    for(let i=0;i<3;i++)box(g,0,.19,-.12+i*.10,.78,.035,.075,palette.wood);
    for(let i=0;i<3;i++)box(g,0,.31+i*.065,-.16,.78,.045,.026,palette.wood);
    for(const x of [-.29,.29]){box(g,x,.09,0,.055,.18,.32,palette.metal);box(g,x,.32,-.15,.032,.39,.032,palette.metal);}
  }else if(type==='flowers'){
    box(g,0,.065,0,.72,.13,.54,0xc28a61);box(g,0,.133,0,.65,.009,.47,0x745e44);
    for(let i=0;i<8;i++){
      const x=(i%4-.5*3)*.15,z=(Math.floor(i/4)-.5)*.22,h=.23+(i%3)*.03;
      rod(g,[x,.13,z],[x,h,z],.006,0x5e8f56);ball(g,x,h,z,.038,.025,.038,[0xe9877c,0xf3cf6d,0xf1e5d3][i%3]);
      ball(g,x+.025,h-.05,z,.035,.013,.015,0x72a064);
    }
  }else{
    const leafSets={tree:[0x64965c,0x74a665,0x55884e,0x79a76a],maple:[0xba603a,0xce773c,0xb0532f,0xdc8950],ornamental:[0x568173,0x63a28d,0x418372,0x71a898],cherry:[0xd999ad,0xe4aabb,0xce7897,0xf2b6c6],'wind-tree':[0x739454,0x8fa55e,0x617d46,0xa1b176]};const leaves=leafSets[type]||leafSets.tree;
    cylinder(g,0,.38,0,.075,.76,0x8c6b49);
    for(const [i,[x,y,z,rx,ry,rz]] of [[0,.98,0,.43,.47,.40],[-.26,.82,.07,.31,.32,.31],[.25,.88,.02,.33,.37,.32],[0,1.18,-.11,.31,.32,.30]].entries())ball(g,x,y,z,rx,ry,rz,leaves[i]);
    cylinder(g,0,.018,0,.31,.025,0x83a56f);
  }
  bake(g);return g;
}

export function disposeModel(group) {
  const disposed=new Set();group.traverse(object=>{if(!object.isMesh)return;if(object.isInstancedMesh)object.dispose();if(object.geometry?.userData.owned&&!disposed.has(object.geometry)){object.geometry.dispose();disposed.add(object.geometry);}for(const mat of Array.isArray(object.material)?object.material:[object.material])if(mat?.userData.owned&&!disposed.has(mat)){mat.dispose();disposed.add(mat);}});
}
export const disposeRoomModel=disposeModel;
