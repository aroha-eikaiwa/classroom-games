import {playgroundWalkable} from './playground-layout.mjs';
import {roomFurnitureWalkable} from './room-obstacles.mjs';

/** School Builder rules. All positions are in grid cells; x is east, z is south. */
export const W=48, H=36, WIDTH=W, HEIGHT=H, CELL_SIZE=1;
export const WALL_HEIGHT=1.25, AVATAR_HEIGHT=.72, PLAYER_RADIUS=.105, TEACHER_RADIUS=.12, PATROL_OFFSET=.22, DOOR_WIDTH=.76;
export const MAX_ROOMS=120, MAX_DECORATIONS=240;

export const ROOMS=Object.freeze([
  {type:'entrance',en:'Entrance',ja:'玄関',w:4,d:3,color:'#d1b896',required:true},
  {type:'classroom',en:'Classroom',ja:'教室',w:4,d:3,color:'#f1c779',required:true,unlimited:true},
  {type:'teachers',en:"Teachers’ office",ja:'職員室',w:5,d:3,color:'#a9cfbe',required:true},
  {type:'principal',en:"Principal’s office",ja:'校長室',w:3,d:3,color:'#c9b6d7',required:true},
  {type:'science',en:'Science room',ja:'理科室',w:5,d:4,color:'#b0d9db',required:true},
  {type:'music',en:'Music room',ja:'音楽室',w:5,d:4,color:'#dfb5c8',required:true},
  {type:'art',en:'Arts and crafts room',ja:'図工室',w:5,d:4,color:'#e5bb90',required:true},
  {type:'cooking',en:'Cooking room',ja:'家庭科室',w:5,d:4,color:'#e5d1a4',required:true},
  {type:'library',en:'Library',ja:'図書室',w:5,d:4,color:'#aebecf',required:true},
  {type:'gym',en:'Gym',ja:'体育館',w:7,d:5,color:'#b9c6a7',required:true},
  {type:'restroom',en:'Restroom',ja:'トイレ',w:3,d:3,color:'#a9d5df',required:true},
  {type:'nurse',en:"Nurse’s office",ja:'保健室',w:4,d:3,color:'#c6ddd4',required:true},
  {type:'playground',en:'Playground',ja:'運動場',w:7,d:5,color:'#b4cc8a',required:true,outdoor:true},
].map(Object.freeze));
export const BY_TYPE=Object.freeze(Object.fromEntries(ROOMS.map(r=>[r.type,r])));
export const DECORATIONS=Object.freeze([
  {type:'tree',en:'Oak tree',ja:'オークの木',w:1,d:1},
  {type:'maple',en:'Maple tree',ja:'カエデ',w:1,d:1},
  {type:'ornamental',en:'Ornamental tree',ja:'庭木',w:1,d:1},
  {type:'cherry',en:'Cherry blossom tree',ja:'桜',w:1,d:1},
  {type:'wind-tree',en:'Swaying tree',ja:'風に揺れる木',w:1,d:1},
  {type:'flowers',en:'Flowers',ja:'花',w:1,d:1},
  {type:'bench',en:'Bench',ja:'ベンチ',w:1,d:1},
].map(Object.freeze));
const decorationTypes=new Set(DECORATIONS.map(v=>v.type));
const own=(o,k)=>Object.hasOwn(o,k);
export const key=(x,z)=>z*W+x;
export const cellFromKey=k=>({x:k%W,z:Math.floor(k/W)});
const inBounds=(x,z)=>Number.isInteger(x)&&Number.isInteger(z)&&x>=0&&z>=0&&x<W&&z<H;
const finite=v=>typeof v==='number'&&Number.isFinite(v);
const fail=reason=>({ok:false,reason});
let serial=0;
const newId=()=>globalThis.crypto?.randomUUID?.()??`room-${Date.now().toString(36)}-${++serial}`;
export function createSchool(){return {version:1,rooms:[],corridors:[],decorations:[]};}
export function roomAt(s,x,z){return s.rooms.find(r=>{const t=BY_TYPE[r.type];return t&&x>=r.x&&z>=r.z&&x<r.x+t.w&&z<r.z+t.d;})||null;}
export function roomDoor(room){const t=BY_TYPE[room.type];if(!t)throw Error('Unknown room type.');return room.type==='entrance'?{x:room.x+1.5,z:room.z,outX:room.x+1.5,outZ:room.z-.5}:{x:room.x+1.5,z:room.z+t.d,outX:room.x+1.5,outZ:room.z+t.d+.5};}
export function entranceStart(s){const e=s.rooms.find(r=>r.type==='entrance');return e?{x:e.x+1.5,z:e.z+1.5,yaw:Math.PI}:null;}
const overlaps=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.z<b.z+b.d&&a.z+a.d>b.z;
function box(room){return {...room,...BY_TYPE[room.type]};}
function occupied(s,x,z,ignoreId){return s.rooms.some(r=>r.id!==ignoreId&&overlaps({x,z,w:1,d:1},box(r)))||s.decorations.some(d=>d.id!==ignoreId&&d.x===x&&d.z===z);}
export function canPlaceRoom(s,type,x,z,ignoreId=null){
  if(!own(BY_TYPE,type))return fail('Choose a room.');
  const t=BY_TYPE[type];
  if(!Number.isInteger(x)||!Number.isInteger(z)||x<0||z<0||x+t.w>W||z+t.d>H)return fail('Keep the room inside the school grounds.');
  const others=s.rooms.filter(r=>r.id!==ignoreId);
  if(type!=='entrance'&&!others.some(r=>r.type==='entrance'))return fail('Place the entrance first.');
  if(!t.unlimited&&others.some(r=>r.type===type))return fail('This room is already placed.');
  if(s.rooms.length>=MAX_ROOMS&&!ignoreId)return fail('The school is full.');
  const b={x,z,w:t.w,d:t.d};
  if(others.some(r=>overlaps(b,box(r)))||s.corridors.some(k=>overlaps(b,{...cellFromKey(k),w:1,d:1}))||s.decorations.some(d=>overlaps(b,{...d,w:1,d:1})))return fail('This space is occupied.');
  const door=roomDoor({type,x,z});
  const dx=Math.floor(door.outX),dz=Math.floor(door.outZ);
  if(!inBounds(dx,dz))return fail('Leave space for a corridor at the doorway.');
  if(type!=='entrance'&&!s.corridors.includes(key(dx,dz)))return fail('Connect the doorway to a corridor.');
  return {ok:true,reason:'',door};
}
export function addRoom(s,type,x,z){const check=canPlaceRoom(s,type,x,z);if(!check.ok)return check;const room={id:newId(),type,x,z};s.rooms.push(room);return {...check,room};}
export function moveRoom(s,id,x,z){const room=s.rooms.find(r=>r.id===id);if(!room)return fail('Choose a room.');const check=canPlaceRoom(s,room.type,x,z,id);if(check.ok){room.x=x;room.z=z;}return {...check,room};}
export function canPlaceDecoration(s,type,x,z,ignoreId=null){
  if(!decorationTypes.has(type))return fail('Choose a decoration.');
  if(!s.rooms.some(r=>r.type==='entrance'))return fail('Place the entrance first.');
  if(!validateSchool(s).ready)return fail('Complete the rooms and corridor connections to unlock the grounds.');
  if(!inBounds(x,z))return fail('Keep decorations inside the grounds.');
  if(occupied(s,x,z,ignoreId)||s.corridors.includes(key(x,z)))return fail('Decorations belong outdoors.');
  if(s.decorations.length>=MAX_DECORATIONS&&!ignoreId)return fail('The grounds are full.');
  return {ok:true,reason:''};
}
export function addDecoration(s,type,x,z){const check=canPlaceDecoration(s,type,x,z);if(!check.ok)return check;const decoration={id:newId(),type,x,z};s.decorations.push(decoration);return {...check,decoration};}
export function corridorLine(a,b){
  if(!a||!b||![a.x,a.z,b.x,b.z].every(Number.isInteger))return [];
  // A drag draws one straight section. Follow-up drags create corners and branches.
  const end=Math.abs(b.x-a.x)>=Math.abs(b.z-a.z)?{x:b.x,z:a.z}:{x:a.x,z:b.z};
  const n=Math.abs(end.x-a.x)+Math.abs(end.z-a.z);
  if(n>W+H)return [];
  return Array.from({length:n+1},(_,i)=>({x:a.x+Math.sign(end.x-a.x)*i,z:a.z+Math.sign(end.z-a.z)*i}));
}
export function canDrawCorridor(s,a,b){
  if(!s.rooms.some(r=>r.type==='entrance'))return fail('Place the entrance first.');
  const cells=corridorLine(a,b);
  if(!cells.length||cells.some(c=>!inBounds(c.x,c.z)))return fail('Keep corridors inside the grounds.');
  if(cells.some(c=>occupied(s,c.x,c.z)))return fail('A room or decoration blocks this corridor.');
  return {ok:true,reason:'',cells};
}
export function drawCorridor(s,a,b){const check=canDrawCorridor(s,a,b);if(!check.ok)return check;s.corridors=[...new Set([...s.corridors,...check.cells.map(c=>key(c.x,c.z))])];return check;}
export function deleteAt(s,x,z){
  const r=roomAt(s,x,z);if(r){s.rooms=s.rooms.filter(v=>v.id!==r.id);return {ok:true,room:r};}
  const d=s.decorations.find(v=>v.x===Math.floor(x)&&v.z===Math.floor(z));if(d){s.decorations=s.decorations.filter(v=>v.id!==d.id);return {ok:true,decoration:d};}
  const k=key(Math.floor(x),Math.floor(z));if(s.corridors.includes(k)){s.corridors=s.corridors.filter(v=>v!==k);return {ok:true};}
  return fail('Nothing here to erase.');
}
function cellRegion(s,x,z){
  if(!inBounds(x,z))return null;
  return s.corridors.includes(key(x,z))?'corridor':roomAt(s,x+.5,z+.5);
}
function rawNavigable(s,x,z){return !!cellRegion(s,x,z);}
function passage(s,ax,az,bx,bz){
  const a=cellRegion(s,ax,az),b=cellRegion(s,bx,bz);
  if(!a||!b)return false;
  if(a===b)return true;
  if(a!=='corridor'&&b!=='corridor')return false;
  const door=roomDoor(a==='corridor'?b:a);
  return ax===Math.floor(door.x)&&bx===ax&&Math.min(az,bz)===door.z-1&&Math.max(az,bz)===door.z;
}
function clearDoorFrame(s,x,z,cx,cz,radius){
  for(const dz of [-1,1]){
    const edge=dz<0?cz:cz+1;
    if(Math.abs(z-edge)>Math.max(radius,.035))continue;
    const a=cellRegion(s,cx,cz),b=cellRegion(s,cx,cz+dz);
    if(a!==b&&passage(s,cx,cz,cx,cz+dz)&&Math.abs(x-(cx+.5))>DOOR_WIDTH/2-radius)return false;
  }
  return true;
}
export function navigationGraph(s){
  const nodes=new Map();
  for(const k of s.corridors){const c=cellFromKey(k);nodes.set(k,{x:c.x+.5,z:c.z+.5,neighbors:[]});}
  // Teachers keep to one side of a hallway. Preserve that lateral margin at
  // entrance furniture too, so no patrol goal sits behind a locker or bench.
  const clearance=TEACHER_RADIUS+PATROL_OFFSET;
  const e=s.rooms.find(r=>r.type==='entrance');if(e){const t=BY_TYPE.entrance;for(let z=e.z;z<e.z+t.d;z++)for(let x=e.x;x<e.x+t.w;x++)if(walkable(s,x+.5,z+.5,clearance))nodes.set(key(x,z),{x:x+.5,z:z+.5,neighbors:[]});}
  for(const [k,n] of nodes){const {x,z}=cellFromKey(k);for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const next=key(x+dx,z+dz),target=nodes.get(next);if(target&&passage(s,x,z,x+dx,z+dz)&&lineOfSight(s,n,target,clearance))n.neighbors.push(next);}}
  return nodes;
}
export function connectedCorridors(s){
  const e=s.rooms.find(r=>r.type==='entrance'),seen=new Set();if(!e)return seen;
  const door=roomDoor(e),root=key(Math.floor(door.outX),Math.floor(door.outZ)),set=new Set(s.corridors);if(!set.has(root))return seen;
  const q=[root];seen.add(root);for(let i=0;i<q.length;i++){const c=cellFromKey(q[i]);for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1]]){const x=c.x+dx,z=c.z+dz,k=key(x,z);if(inBounds(x,z)&&set.has(k)&&!seen.has(k)){seen.add(k);q.push(k);}}}return seen;
}
export function validateSchool(s){
  const missing=ROOMS.filter(t=>t.required&&!s.rooms.some(r=>r.type===t.type)).map(t=>t.type),errors=[];
  const connected=connectedCorridors(s),disconnected=s.corridors.filter(k=>!connected.has(k));
  if(!s.rooms.some(r=>r.type==='entrance'))errors.push('Place the entrance first.');
  else if(!connected.size)errors.push('Connect a corridor to the entrance.');
  if(disconnected.length)errors.push('Connect every corridor to the entrance.');
  const disconnectedRooms=s.rooms.filter(r=>{const d=roomDoor(r);return !connected.has(key(Math.floor(d.outX),Math.floor(d.outZ)));}).map(r=>r.id);
  if(disconnectedRooms.length)errors.push('Connect every room doorway to the entrance.');
  for(const t of ROOMS)if(!t.unlimited&&s.rooms.filter(r=>r.type===t.type).length>1)errors.push(`Place ${t.en} only once.`);
  // Imports must meet the same geometry rules as hand placement.
  for(const r of s.rooms){const t=BY_TYPE[r.type];if(!t){errors.push('Unknown room.');continue;}if(r.x<0||r.z<0||r.x+t.w>W||r.z+t.d>H)errors.push('A room is outside the grounds.');if(s.rooms.some(o=>o!==r&&overlaps(box(r),box(o)))||s.corridors.some(k=>overlaps(box(r),{...cellFromKey(k),w:1,d:1})))errors.push('Rooms and corridors overlap.');}
  if(missing.length)errors.push('Place all required rooms.');
  return {ready:missing.length===0&&errors.length===0,missing,disconnected,disconnectedRooms,errors:[...new Set(errors)],connected};
}
export function findPath(s,start,goal){
  if(!start||!goal)return [];
  const graph=navigationGraph(s),a=key(Math.floor(start.x),Math.floor(start.z)),b=key(Math.floor(goal.x),Math.floor(goal.z));if(!graph.has(a)||!graph.has(b))return [];
  const parents=new Map([[a,null]]),q=[a];for(let i=0;i<q.length&&!parents.has(b);i++)for(const n of graph.get(q[i]).neighbors)if(!parents.has(n)){parents.set(n,q[i]);q.push(n);}
  if(!parents.has(b))return [];const route=[];for(let k=b;k!==null;k=parents.get(k)){const n=graph.get(k);route.push({x:n.x,z:n.z});}return route.reverse();
}
export function walkable(s,x,z,radius=PLAYER_RADIUS){
  if(!finite(x)||!finite(z)||!finite(radius)||radius<0||radius>.49)return false;
  const cx=Math.floor(x),cz=Math.floor(z);if(!rawNavigable(s,cx,cz))return false;
  // A solid boundary blocks the circle even if the neighboring cell happens to be
  // another walkable region (e.g. the side wall of the entrance).
  const distances=[[x-cx,-1,0],[cx+1-x,1,0],[z-cz,0,-1],[cz+1-z,0,1]];
  for(const [d,dx,dz] of distances)if(d<radius-1e-9&&!passage(s,cx,cz,cx+dx,cz+dz))return false;
  if(!clearDoorFrame(s,x,z,cx,cz,radius))return false;
  const room=roomAt(s,x,z);
  if(room?.type==='playground'&&!playgroundWalkable(x-room.x,z-room.z,radius))return false;
  if(room&&room.type!=='playground'&&!roomFurnitureWalkable(room.type,x-room.x,z-room.z,radius))return false;
  // Rounded collision at concave hallway corners avoids diagonally clipping walls.
  for(const dx of [-1,1])for(const dz of [-1,1]){const bx=dx<0?cx:cx+1,bz=dz<0?cz:cz+1;if(Math.hypot(x-bx,z-bz)<radius-1e-9&&!rawNavigable(s,cx+dx,cz+dz))return false;}
  return true;
}
export function movePlayer(s,player,dx,dz,radius=PLAYER_RADIUS,people=[]){
  let x=player.x,z=player.z;
  if(!finite(dx)||!finite(dz)||!finite(x)||!finite(z))return {x,z};
  const clear=(nx,nz)=>walkable(s,nx,nz,radius)&&people.every(person=>{
    const clearance=radius+(person.radius??TEACHER_RADIUS);
    const before=Math.hypot(x-person.x,z-person.z),after=Math.hypot(nx-person.x,nz-person.z);
    // Existing overlapping positions may separate after a reset or network update.
    return after>=clearance-1e-9||after>before+1e-9;
  });
  // Substeps stop high frame times, Shift running, and network catch-up tunneling.
  const steps=Math.max(1,Math.ceil(Math.hypot(dx,dz)/.06));
  if(steps>1000)return {x,z};
  for(let i=0;i<steps;i++){
    const nx=x+dx/steps,nz=z+dz/steps;
    if(clear(nx,nz)){x=nx;z=nz;}
    else{
      if(clear(nx,z))x=nx;
      if(clear(x,nz))z=nz;
    }
  }
  return {x,z};
}
export function lineOfSight(s,a,b,radius=0){
  if(!a||!b||![a.x,a.z,b.x,b.z].every(finite))return false;
  const distance=Math.hypot(b.x-a.x,b.z-a.z),steps=Math.max(1,Math.ceil(distance/.035));if(steps>3000)return false;
  let last={x:Math.floor(a.x),z:Math.floor(a.z)};if(!rawNavigable(s,last.x,last.z))return false;
  for(let i=1;i<=steps;i++){
    const x=a.x+(b.x-a.x)*i/steps,z=a.z+(b.z-a.z)*i/steps,cell={x:Math.floor(x),z:Math.floor(z)};
    if(!walkable(s,x,z,radius))return false;
    if(cell.x!==last.x||cell.z!==last.z){if(cell.x!==last.x&&cell.z!==last.z){if(!passage(s,last.x,last.z,cell.x,last.z)||!passage(s,cell.x,last.z,cell.x,cell.z)||!passage(s,last.x,last.z,last.x,cell.z)||!passage(s,last.x,cell.z,cell.x,cell.z))return false;}else if(!passage(s,last.x,last.z,cell.x,cell.z))return false;last=cell;}

  }return true;
}
export function nearDoor(player,room,distance=.48){const d=roomDoor(room);return Math.hypot(player.x-d.outX,player.z-d.outZ)<=distance;}
export function atDestination(s,player,room){return nearDoor(player,room)||roomAt(s,player.x,player.z)?.id===room.id;}
export function randomDestination(s,excludeId=null,random=Math.random){const choices=s.rooms.filter(r=>r.type!=='entrance'&&r.id!==excludeId);return choices[Math.min(choices.length-1,Math.floor(Math.max(0,random())*choices.length))]||null;}
export function normalizeSchool(input){
  if(!input||typeof input!=='object'||Array.isArray(input)||input.version!==1||!Array.isArray(input.rooms)||!Array.isArray(input.corridors)||!Array.isArray(input.decorations))throw Error('Invalid school file.');
  if(input.rooms.length>MAX_ROOMS||input.corridors.length>W*H||input.decorations.length>MAX_DECORATIONS)throw Error('School file is too large.');
  const ids=new Set(),s=createSchool();
  const validId=v=>typeof v==='string'&&v.length>0&&v.length<=100&&/^[a-zA-Z0-9_-]+$/.test(v)&&!ids.has(v);
  for(const r of input.rooms){if(!r||!own(BY_TYPE,r.type)||!validId(r.id)||!inBounds(r.x,r.z)||r.x+BY_TYPE[r.type].w>W||r.z+BY_TYPE[r.type].d>H)throw Error('Invalid room.');ids.add(r.id);s.rooms.push({id:r.id,type:r.type,x:r.x,z:r.z});}
  for(const k of input.corridors){if(!Number.isInteger(k)||k<0||k>=W*H)throw Error('Invalid corridor.');}s.corridors=[...new Set(input.corridors)];
  for(const d of input.decorations){if(!d||!decorationTypes.has(d.type)||!validId(d.id)||!inBounds(d.x,d.z))throw Error('Invalid decoration.');ids.add(d.id);s.decorations.push({id:d.id,type:d.type,x:d.x,z:d.z});}
  for(const t of ROOMS)if(!t.unlimited&&s.rooms.filter(r=>r.type===t.type).length>1)throw Error('Duplicate room.');
  for(const r of s.rooms){if(s.rooms.some(o=>o!==r&&overlaps(box(r),box(o)))||s.corridors.some(k=>overlaps(box(r),{...cellFromKey(k),w:1,d:1})))throw Error('Room geometry overlaps.');}
  for(const d of s.decorations){if(roomAt(s,d.x+.5,d.z+.5)||s.corridors.includes(key(d.x,d.z))||s.decorations.some(o=>o!==d&&o.x===d.x&&o.z===d.z))throw Error('Decoration geometry overlaps.');}
  return s;
}
export function createDemoSchool(){
  const s=createSchool();
  // A connected spine with three wings leaves room for children to extend it.
  s.rooms=[
    {id:'demo-entrance',type:'entrance',x:8,z:29},
    {id:'demo-classroom',type:'classroom',x:12,z:25},
    {id:'demo-teachers',type:'teachers',x:18,z:25},
    {id:'demo-principal',type:'principal',x:25,z:25},
    {id:'demo-restroom',type:'restroom',x:30,z:25},
    {id:'demo-nurse',type:'nurse',x:35,z:25},
    {id:'demo-science',type:'science',x:12,z:16},
    {id:'demo-music',type:'music',x:19,z:16},
    {id:'demo-art',type:'art',x:26,z:16},
    {id:'demo-cooking',type:'cooking',x:33,z:16},
    {id:'demo-library',type:'library',x:12,z:8},
    {id:'demo-gym',type:'gym',x:19,z:7},
    {id:'demo-playground',type:'playground',x:29,z:7},
  ];
  const corridors=new Set();for(let z=12;z<=28;z++)corridors.add(key(9,z));for(const [z,end]of [[12,35],[20,37],[28,39]])for(let x=9;x<=end;x++)corridors.add(key(x,z));s.corridors=[...corridors];
  s.decorations=[{id:'demo-tree-a',type:'tree',x:5,z:29},{id:'demo-tree-b',type:'tree',x:5,z:24},{id:'demo-tree-c',type:'tree',x:42,z:27},{id:'demo-flowers-a',type:'flowers',x:12,z:31},{id:'demo-flowers-b',type:'flowers',x:13,z:31},{id:'demo-bench',type:'bench',x:17,z:31}];
  return s;
}
