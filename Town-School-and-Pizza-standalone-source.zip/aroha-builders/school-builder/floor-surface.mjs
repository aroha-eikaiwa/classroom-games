import * as THREE from './vendor/three.module.js';
import {surfaceGeometry} from './furniture-surfaces.mjs';

// One subtle albedo shared by every resilient floor. World-sized UVs keep
// the grain consistent in narrow corridors and differently sized rooms.
let texture;
export const resilientFloorColors=Object.freeze({nurse:0xecf0e7,restroom:0xcbded7,science:0xd8e4da,cooking:0xe9e3d5});
export function floorSurfaceOptions(){
 if(typeof document==='undefined')return {roughness:.84};
 if(!texture){
  texture=new THREE.TextureLoader().load(new URL('./assets/interiors/linoleum.webp',import.meta.url).href);
  texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.anisotropy=4;
 }
 return {map:texture,roughness:.84};
}
export function floorSurfaceGeometry(original,width,height,depth){return surfaceGeometry(original,'box',width,height,depth,1);}
