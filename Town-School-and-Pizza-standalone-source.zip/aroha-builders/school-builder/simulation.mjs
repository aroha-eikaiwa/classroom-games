import {newClassroomSeed} from './classroom-occupancy.mjs';
import {W,PLAYER_RADIUS,TEACHER_RADIUS,PATROL_OFFSET,entranceStart,movePlayer,roomDoor,atDestination,navigationGraph,lineOfSight,randomDestination} from './core.mjs';

const WALK_SPEED=.82;
const RUN_SPEED=1.85;
const TEACHER_SPEED=.48;
const YIELD_OFFSET=.31;

// Screen-relative analog axes; the stick keeps a circular range and a small dead zone.
export function joystickAxes(x,y,radius){
  if(![x,y,radius].every(Number.isFinite)||radius<=0)return {x:0,y:0};
  const length=Math.hypot(x,y),fraction=Math.min(1,length/radius);
  if(fraction<=.13)return {x:0,y:0};
  const strength=(fraction-.13)/.87;
  return {x:x/length*strength,y:-y/length*strength};
}

export class SchoolWalk {
  constructor(school){this.reset(school);}
  reset(school,{classroomSeed=newClassroomSeed()}={}){
    this.classroomSeed=Number(classroomSeed)>>>0;
    this.school=school;this.movementYaw=null;this.movementFollow=null;
    const p=entranceStart(school);
    this.player={x:p?.x||1.5,z:p?.z||1.5,angle:Math.PI,speed:0,running:false};
    this.runLocked=false;this.scoldTime=0;this.arrived=false;this.arrivalHold=0;
    this.targetId=randomDestination(school)?.id||null;
    this.graph=navigationGraph(school);this.teachers=[];
    for(const [index,room]of school.rooms.filter(r=>['teachers','principal'].includes(r.type)).entries()){
      const d=roomDoor(room),key=Math.floor(d.outZ)*W+Math.floor(d.outX),at=this.graph.get(key);
      if(at)this.teachers.push({id:room.id,x:at.x,z:at.z,angle:0,speed:0,scolding:false,node:key,next:null,previous:null,pause:index*.8});
    }
  }
  startClassroomSession(){this.classroomSeed=newClassroomSeed();return this.classroomSeed;}
  choose(id){if(this.school.rooms.some(r=>r.id===id&&r.type!=='entrance')){this.targetId=id;this.arrived=false;this.arrivalHold=0;}}
  next(){if(!this.arrived)return false;const r=randomDestination(this.school,this.targetId);if(!r)return false;this.choose(r.id);this.runLocked=false;return true;}

  moveTeacher(teacher,dt){
    const player=this.player;
    if(teacher.scolding&&this.scoldTime>0){
      teacher.speed=0;
      teacher.angle=Math.atan2(player.x-teacher.x,player.z-teacher.z);
      return;
    }
    teacher.scolding=false;
    teacher.pause=Math.max(0,teacher.pause-dt);
    const node=this.graph.get(teacher.node);
    if(!node){teacher.speed=0;return;}
    if(teacher.next===null&&teacher.pause===0){
      let choices=node.neighbors.filter(key=>key!==teacher.previous);
      if(!choices.length)choices=node.neighbors;
      teacher.next=choices[Math.floor(Math.random()*choices.length)]??null;
    }
    const next=this.graph.get(teacher.next);
    let directionX=next?next.x-node.x:Math.sin(player.angle);
    let directionZ=next?next.z-node.z:Math.cos(player.angle);
    // A stopped teacher steps sideways relative to the approaching child's path.
    if(!next){
      if(Math.abs(directionX)>Math.abs(directionZ)){directionX=Math.sign(directionX);directionZ=0;}
      else{directionX=0;directionZ=Math.sign(directionZ)||1;}
    }
    const rightX=-directionZ,rightZ=directionX;
    let goalX=next?next.x+rightX*PATROL_OFFSET:teacher.x;
    let goalZ=next?next.z+rightZ*PATROL_OFFSET:teacher.z;
    const distanceToPlayer=Math.hypot(player.x-teacher.x,player.z-teacher.z);
    const yielding=distanceToPlayer<.85&&lineOfSight(this.school,teacher,player);
    if(yielding){
      const playerSide=(player.x-node.x)*rightX+(player.z-node.z)*rightZ;
      teacher.yieldSide??=playerSide>.05?-1:1;
      const currentSide=(teacher.x-node.x)*rightX+(teacher.z-node.z)*rightZ;
      const correction=teacher.yieldSide*YIELD_OFFSET-currentSide;
      // Preserve forward progress while giving lateral clearance priority.
      const along=next?Math.max(-.3,Math.min(.3,(next.x-teacher.x)*directionX+(next.z-teacher.z)*directionZ)):0;
      goalX=teacher.x+directionX*along+rightX*correction*2;
      goalZ=teacher.z+directionZ*along+rightZ*correction*2;
    }else delete teacher.yieldSide;
    if(teacher.pause>0&&!yielding){teacher.speed=0;return;}
    const dx=goalX-teacher.x,dz=goalZ-teacher.z,distance=Math.hypot(dx,dz);
    const before={x:teacher.x,z:teacher.z};
    if(distance>.005){
      const step=Math.min(distance,dt*TEACHER_SPEED);
      const people=[{...player,radius:PLAYER_RADIUS},...this.teachers.filter(other=>other!==teacher)];
      const moved=movePlayer(this.school,teacher,dx/distance*step,dz/distance*step,TEACHER_RADIUS,people);
      teacher.x=moved.x;teacher.z=moved.z;
      if(Math.hypot(moved.x-before.x,moved.z-before.z)>.001)teacher.angle=Math.atan2(moved.x-before.x,moved.z-before.z);
    }
    teacher.speed=dt>0?Math.hypot(teacher.x-before.x,teacher.z-before.z)/dt:0;
    if(next){
      const remaining=(next.x-teacher.x)*directionX+(next.z-teacher.z)*directionZ;
      if(Math.abs(remaining)<.035){
        teacher.previous=teacher.node;teacher.node=teacher.next;teacher.next=null;
        teacher.pause=Math.random()<.12?.5+Math.random():0;
      }
    }
  }

  update(dt,input,cameraYaw=0,follow=false){
    dt=Number.isFinite(dt)?Math.max(0,Math.min(dt,.05)):0;
    const p=this.player;
    let caught=false,newArrival=false;
    const axis=value=>Number.isFinite(value)?Math.max(-1,Math.min(1,value)):0;
    let forward=(input.up?1:0)-(input.down?1:0)+axis(input.moveY);
    let side=(input.right||input.strafeRight?1:0)-(input.left||input.strafeLeft?1:0)+axis(input.moveX);
    if(this.scoldTime>0){this.scoldTime=Math.max(0,this.scoldTime-dt);forward=side=0;}

    // Camera orientation is independent of character facing. Turning the body
    // never rotates the movement axes, even when changing direction continuously.
    const currentYaw=Number.isFinite(cameraYaw)?cameraYaw:0;
    // Keep the movement basis fixed while a stick/key gesture is held. The
    // locked camera can follow the body's turn without feeding that turn back
    // into strafe input and making a held direction spiral.
    const active=Math.hypot(forward,side)>1e-6;
    if(this.movementFollow!==!!follow||!active)this.movementYaw=null;
    this.movementFollow=!!follow;
    if(follow&&active&&this.movementYaw===null)this.movementYaw=currentYaw;
    const yaw=follow&&active?this.movementYaw:currentYaw;
    let dx=-Math.sin(yaw)*forward+Math.cos(yaw)*side;
    let dz=-Math.cos(yaw)*forward-Math.sin(yaw)*side;
    const length=Math.hypot(dx,dz);
    if(length>1){dx/=length;dz/=length;}
    p.running=!!input.run&&length>0&&!this.runLocked&&!this.arrived&&this.scoldTime<=0;
    const speed=p.running?RUN_SPEED:WALK_SPEED,before={x:p.x,z:p.z};
    if(length>0){
      const moved=movePlayer(this.school,p,dx*speed*dt,dz*speed*dt,PLAYER_RADIUS,this.teachers);
      p.x=moved.x;p.z=moved.z;
      const desired=Math.atan2(dx,dz),delta=Math.atan2(Math.sin(desired-p.angle),Math.cos(desired-p.angle));
      p.angle+=Math.max(-dt*12,Math.min(dt*12,delta));
    }
    p.speed=dt>0?Math.hypot(p.x-before.x,p.z-before.z)/dt:0;
    if(p.speed<.04)p.running=false;
    for(const teacher of this.teachers){
      // Evaluate the teacher's original facing before avoidance turns their body.
      if(p.running&&!this.runLocked){
        const ax=p.x-teacher.x,az=p.z-teacher.z,distance=Math.hypot(ax,az);
        const facing=(Math.sin(teacher.angle)*ax+Math.cos(teacher.angle)*az)/(distance||1);
        if(distance<3.2&&(distance<.9||facing>.2)&&lineOfSight(this.school,teacher,p)){
          this.runLocked=true;this.scoldTime=2.1;teacher.scolding=true;p.running=false;p.speed=0;caught=true;
        }
      }
      this.moveTeacher(teacher,dt);
    }
    const target=this.school.rooms.find(room=>room.id===this.targetId);
    if(!this.arrived&&target&&atDestination(this.school,p,target)&&p.speed<.07){
      this.arrivalHold+=dt;
      if(this.arrivalHold>.4){this.arrived=true;this.runLocked=false;newArrival=true;}
    }else this.arrivalHold=0;
    return {caught,arrived:newArrival};
  }
}
