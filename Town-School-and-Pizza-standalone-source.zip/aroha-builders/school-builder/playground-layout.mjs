// Footprints of the playground geometry in models.mjs, in local room units.
// The high monkey-bar roof is deliberately absent: the child can walk below it.
const circle=(id,x,z,r)=>Object.freeze({id,type:'circle',x,z,r});
const rect=(id,x,z,w,d)=>Object.freeze({id,type:'rect',x,z,w,d});
export const PLAYGROUND_COLLIDERS=Object.freeze([
 ...[1.1,2.6].flatMap((x,column)=>[1.0,2.1].map((z,row)=>circle(`monkey-post-${column}-${row}`,x,z,.025))),
 rect('monkey-ladder',1.1,1.55,.034,1.10),
 rect('slide-platform',4.75,1.10,.48,.48),
 // Includes the projecting side rails of the rotated ramp.
 rect('slide-ramp',4.75,1.70,.49,1.15),
 rect('slide-steps',4.75,.77,.35,.30),
 rect('north-fence',3.5,.08,6.84,.035),
 rect('west-fence',.08,2.5,.035,4.84),
 rect('east-fence',6.92,2.5,.035,4.84),
 rect('south-fence-left',.59,4.92,1.02,.035),
 rect('south-fence-right',4.40,4.92,5.04,.035),
]);

export function playgroundWalkable(x,z,radius){
 return PLAYGROUND_COLLIDERS.every(obstacle=>{
  if(obstacle.type==='circle')return Math.hypot(x-obstacle.x,z-obstacle.z)>=radius+obstacle.r-1e-9;
  const dx=Math.max(0,Math.abs(x-obstacle.x)-obstacle.w/2),dz=Math.max(0,Math.abs(z-obstacle.z)-obstacle.d/2);
  if(radius===0)return dx>0||dz>0;
  return dx*dx+dz*dz>=radius*radius-1e-12;
 });
}
