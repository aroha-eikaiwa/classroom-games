const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a),0,1);return t*t*(3-2*t);};

// Yaw is relative to the body's last walking direction. Once the camera looks
// behind the body, relax the gaze forward rather than twisting the neck around.
export function advanceHeadLook(state,{time=0,lookYaw=0,lookPitch=0,speed=0,running=false}={}){
 const dt=state.lastTime==null?0:clamp(Number.isFinite(time-state.lastTime)?time-state.lastTime:0,0,.1);
 state.lastTime=time;
 const yaw=Number.isFinite(lookYaw)?Math.atan2(Math.sin(lookYaw),Math.cos(lookYaw)):0;
 const behind=1-smooth(1.5,Math.PI,Math.abs(yaw));
 const idle=running?0:1-.78*smooth(.02,.35,speed);
 const targetYaw=clamp(yaw,-1,1)*behind*idle;
 const targetPitch=clamp(Number.isFinite(lookPitch)?lookPitch:0,-.25,.30)*behind*idle;
 const amount=1-Math.exp(-dt*8);
 state.yaw=(state.yaw||0)+(targetYaw-(state.yaw||0))*amount;
 state.pitch=(state.pitch||0)+(targetPitch-(state.pitch||0))*amount;
 return state;
}

// The supplied people use vertex animation rather than a live skeleton. Make a
// continuous neck mask from the neutral frame, then apply gaze after sampling.
export function createHeadRig(data,frames){
 const height=data.height,indices=[],weights=[],anchors=[];
 if (data.headWeights?.length===data.vertices) {
   for(let i=0;i<data.vertices;i++)if(data.headWeights[i]>0){indices.push(i);weights.push(data.headWeights[i]/255);}
   return {indices:Uint32Array.from(indices),weights:Float32Array.from(weights),anchors:[],height};
 }
 for(let i=0;i<data.vertices;i++){
  const at=i*6,x=frames[at],y=frames[at+1],z=frames[at+2];
  const weight=smooth(height*.79,height*.85,y)*(1-smooth(height*.10,height*.14,Math.abs(x)));
  if(weight>0){indices.push(i);weights.push(weight);}
  if(y>height*.79&&y<height*.83&&Math.abs(x)<height*.03&&Math.abs(z)<height*.04)anchors.push(i);
 }
 return {indices:Uint32Array.from(indices),weights:Float32Array.from(weights),anchors:Uint32Array.from(anchors),height};
}

export function applyHeadLook(positions,normals,rig,yaw,pitch,pivot=null){
 if(Math.abs(yaw)+Math.abs(pitch)<1e-7)return;
 let px=0,py=rig.height*.81,pz=0;
 if(pivot){[px,py,pz]=pivot;}
 else if(rig.anchors.length){py=0;for(const i of rig.anchors){px+=positions[i*3];py+=positions[i*3+1];pz+=positions[i*3+2];}px/=rig.anchors.length;py/=rig.anchors.length;pz/=rig.anchors.length;}
 const cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
 for(let j=0;j<rig.indices.length;j++){
  const at=rig.indices[j]*3,w=rig.weights[j];
  const x=positions[at]-px,y=positions[at+1]-py,z=positions[at+2]-pz;
  const pitchedY=cp*y-sp*z,pitchedZ=sp*y+cp*z;
  positions[at]+=(cy*x+sy*pitchedZ-x)*w;
  positions[at+1]+=(pitchedY-y)*w;
  positions[at+2]+=(-sy*x+cy*pitchedZ-z)*w;
  const nx=normals[at],ny=normals[at+1],nz=normals[at+2],npy=cp*ny-sp*nz,npz=sp*ny+cp*nz;
  let a=nx+(cy*nx+sy*npz-nx)*w,b=ny+(npy-ny)*w,c=nz+(-sy*nx+cy*npz-nz)*w;
  const length=Math.hypot(a,b,c)||1;normals[at]=a/length;normals[at+1]=b/length;normals[at+2]=c/length;
 }
}
