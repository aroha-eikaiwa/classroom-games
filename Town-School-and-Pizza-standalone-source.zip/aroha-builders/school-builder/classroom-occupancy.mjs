// A session seed is shared by both devices. Saved school layouts contain no
// occupants: each new Directions game chooses its own classes in progress.
const teachingTypes = new Set(['classroom', 'science', 'music', 'art', 'cooking']);
export function newClassroomSeed() {
  if (globalThis.crypto?.getRandomValues) return globalThis.crypto.getRandomValues(new Uint32Array(1))[0];
  return (Math.random() * 0x100000000) >>> 0;
}
export function classroomRandom(seed) {
  let value = Number(seed) >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let x = value;
    x = Math.imul(x ^ x >>> 15, x | 1);
    x ^= x + Math.imul(x ^ x >>> 7, x | 61);
    return ((x ^ x >>> 14) >>> 0) / 0x100000000;
  };
}
export function classroomPlan(school, seed) {
  const random = classroomRandom(seed);
  const rooms = (school?.rooms || []).filter(room => teachingTypes.has(room.type)).slice().sort((a,b)=>String(a.id).localeCompare(String(b.id)));
  for (let i = rooms.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [rooms[i], rooms[j]] = [rooms[j], rooms[i]];
  }
  // Always leave a teaching room empty when at least two exist. Keep the total
  // number of detailed people bounded even in a very large user-built school.
  const count = rooms.length > 1
    ? Math.min(8, rooms.length - 1, Math.max(1, Math.round(rooms.length * (.4 + random() * .25))))
    : rooms.length && random() < .6 ? 1 : 0;
  return rooms.slice(0, count).map(room => ({
    roomId: room.id,
    teacherVariant: Math.floor(random() * 3),
    seatSeed: Math.floor(random() * 0x100000000) >>> 0,
  }));
}
export function classroomStudents(seats, seed) {
  const random = classroomRandom(seed);
  const order = seats.map((seat, index) => ({...seat, seatIndex:index}));
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  return order.slice(0, Math.min(12, Math.max(1, Math.ceil(order.length * (.65 + random() * .25))))).map(seat => ({
    ...seat, variant: random() < .5 ? 0 : 1,
    appearance: random() < .62 ? 0 : 1 + Math.floor(random() * 3),
  }));
}
