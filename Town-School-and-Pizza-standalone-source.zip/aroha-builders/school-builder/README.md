# School Builder · standalone edition

This is the actual 24 November 2026 School Builder frontend, adapted to run as a static single-device game. It includes the current procedural wooden basketball court.

## Play

Serve this directory with a static web server. For example:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

Open http://127.0.0.1:8000/ in a browser. It can also run below a subdirectory on a static host. The page uses ES modules, so do not open it as a file URL.

- **Build a school:** Place its entrance, lay out corridors, and make a connected school. The placement rules, fixtures, windows, room collision, and camera come from the original game.
- **Explore a school:** Start with a ready-made school. Choose Directions and a character to walk around. Use WASD, the arrow keys, or the on-screen joystick. The English speech controls use the device's available voices; instruction captions remain when audio is muted.
- **Continue:** The current editor draft stays in this browser. Confirm before clearing it with Delete and start fresh. In the editor, Help can print a map or save/load a JSON copy.

No sign-in, classroom data, remote room codes, external saving, or production services are used. This edition supports solo Directions, not the original hosted multi-device guide mode. It uses the bundled procedural avatar and tree geometry in place of imported media, and system fonts in place of the original handwriting font. The interior source-generated textures and poster atlas retain provenance notes in `assets/interiors/CREDITS.md`. The bundled Three.js renderer retains its MIT notice in `vendor/THREE-LICENSE.txt`; that notice does not license everything else in the game.

## Tests

Run `npm test` with Node 24. The local startup, solo directions and save/reset sequence are tested through the actual browser entry module in a simulated DOM and canvas, with a failed test if a network connection is attempted. Original game unit suites exercise room placement, collision, speech, navigation and office characters. Automated rendering on real browser hardware was not verified.
