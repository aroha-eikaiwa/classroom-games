import {createSchoolSpeech} from './school-voice.mjs';
export {createSchoolSpeech} from './school-voice.mjs';
import {BY_TYPE,W,key,roomAt,roomDoor,navigationGraph,lineOfSight,walkable,atDestination,PLAYER_RADIUS} from './core.mjs';
import {furnitureNavigationPoints,roomFurnitureWalkable} from './room-obstacles.mjs';

// Grade 4 school-direction language. Coordinates and angles follow SchoolWalk:
// x east, z south, angle atan2(dx,dz); positive angle changes are left turns.
const EPS=1e-7,TURN=Math.PI/5,LOOK_AHEAD=.72;
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const heading=(a,b)=>Math.atan2(b.x-a.x,b.z-a.z);
const delta=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
const validPose=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.z);
const turnText=angle=>Math.abs(angle)>Math.PI*.78?'Turn left. Turn left.':`Turn ${angle>0?'left':'right'}.`;
const arrivalText=room=>`Stop. This is the ${BY_TYPE[room.type].en.toLowerCase().replaceAll('’',"'")}.`;

function project(point,a,b){
 const dx=b.x-a.x,dz=b.z-a.z,length=Math.hypot(dx,dz),u=length?Math.max(0,Math.min(1,((point.x-a.x)*dx+(point.z-a.z)*dz)/(length*length))):0;
 const x=a.x+dx*u,z=a.z+dz*u;return {x,z,u,length,distance:Math.hypot(point.x-x,point.z-z)};
}

// Rooms have one usable doorway. Add the current room only, so taking a wrong
// doorway can route back out without inventing a shortcut through solid walls.
function graphFromPosition(school,pose){
 const graph=navigationGraph(school),room=roomAt(school,pose.x,pose.z);
 if(!room)return graph;
 const size=BY_TYPE[room.type];if(size.outdoor)return graph;
 // Replace the entrance's old cell-centre links when starting inside it.
 // Cell centres can lie inside desks/lockers or miss a narrow usable aisle.
 for(const [id,node] of graph)if(node.x>=room.x&&node.x<room.x+size.w&&node.z>=room.z&&node.z<room.z+size.d)graph.delete(id);
 for(const node of graph.values())node.neighbors=node.neighbors.filter(id=>graph.has(id));
 const localPose={x:pose.x-room.x,z:pose.z-room.z},exit={x:1.5,z:room.type==='entrance'?.16:size.d-.16};
 const local=[localPose,exit,...furnitureNavigationPoints(room.type,size.w,size.d,PLAYER_RADIUS)];
 const nodes=[];
 for(const [i,p] of local.entries()){
  if(!walkable(school,room.x+p.x,room.z+p.z,PLAYER_RADIUS))continue;
  const id=`interior:${i}`,node={x:room.x+p.x,z:room.z+p.z,neighbors:[]};
  graph.set(id,node);nodes.push([id,node,p]);if(i===0)graph.startId=id;
 }
 const clear=(a,b)=>{
  const count=Math.max(1,Math.ceil(distance(a,b)/.04));
  for(let i=0;i<=count;i++)if(!roomFurnitureWalkable(room.type,a.x+(b.x-a.x)*i/count,a.z+(b.z-a.z)*i/count,PLAYER_RADIUS))return false;
  return true;
 };
 for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++)if(clear(nodes[i][2],nodes[j][2])){nodes[i][1].neighbors.push(nodes[j][0]);nodes[j][1].neighbors.push(nodes[i][0]);}
 const door=roomDoor(room),outside=key(Math.floor(door.outX),Math.floor(door.outZ)),external=graph.get(outside),inside=graph.get('interior:1');
 if(external&&inside&&lineOfSight(school,inside,external,PLAYER_RADIUS)){inside.neighbors.push(outside);external.neighbors.push('interior:1');}
 return graph;
}

/** Shortest usable corridor route to the actual room doorway, including a
 * route out of the room currently being explored. Returns null if disconnected. */
export function planSchoolRoute(school,pose,targetId){
 if(!validPose(pose)||!school?.rooms||!school?.corridors)return null;
 const room=school.rooms.find(r=>r.id===(targetId?.id??targetId));if(!room||!BY_TYPE[room.type])return null;
 const graph=graphFromPosition(school,pose),door=roomDoor(room),goal=key(Math.floor(door.outX),Math.floor(door.outZ));
 if(!graph.has(goal))return null;
 let start=graph.startId??key(Math.floor(pose.x),Math.floor(pose.z));
 if(!graph.has(start)||!lineOfSight(school,pose,graph.get(start),PLAYER_RADIUS)){
  const nearby=[...graph].sort((a,b)=>distance(pose,a[1])-distance(pose,b[1]));
  start=nearby.find(([,n])=>distance(pose,n)<2&&lineOfSight(school,pose,n,PLAYER_RADIUS))?.[0];
 }
 if(start===undefined||!graph.has(start))return null;
 const previous=new Map([[start,null]]),queue=[start];
 for(let i=0;i<queue.length&&!previous.has(goal);i++)for(const id of graph.get(queue[i]).neighbors)if(!previous.has(id)){previous.set(id,queue[i]);queue.push(id);}
 if(!previous.has(goal))return null;
 const points=[];for(let id=goal;id!==null;id=previous.get(id)){const n=graph.get(id);points.push({id,x:n.x,z:n.z});}points.reverse();
 const cumulative=[0];for(let i=1;i<points.length;i++)cumulative.push(cumulative[i-1]+distance(points[i-1],points[i]));
 const turns=[];for(let i=1;i<points.length-1;i++){
  const angle=delta(heading(points[i-1],points[i]),heading(points[i],points[i+1]));
  if(Math.abs(angle)>TURN)turns.push({index:i,distance:cumulative[i],angle,outHeading:heading(points[i],points[i+1]),text:turnText(angle)});
 }
 return {room,graph,points,cumulative,turns,length:cumulative.at(-1),target:{x:door.outX,z:door.outZ}};
}

function projection(plan,pose,previousProgress){
 if(plan.points.length===1)return {distance:distance(plan.points[0],pose),progress:0};
 let best=null;
 for(let i=1;i<plan.points.length;i++){
  const p=project(pose,plan.points[i-1],plan.points[i]),progress=plan.cumulative[i-1]+p.u*p.length;
  if(!best||p.distance<best.distance-EPS||Math.abs(p.distance-best.distance)<EPS&&Math.abs(progress-previousProgress)<Math.abs(best.progress-previousProgress))best={...p,progress,index:i-1};
 }
 return best;
}

function cueAt(plan,pose,progress,arrived){
 if(arrived)return {key:'arrival',text:arrivalText(plan.room)};
 const orientation=Number.isFinite(pose.angle)?pose.angle:Math.PI;
 if(progress<.7&&plan.points.length>1){
  const initial=delta(orientation,heading(plan.points[0],plan.points[1]));
  if(Math.abs(initial)>TURN)return {key:'initial-turn',text:turnText(initial)};
 }
 const next=plan.turns.find(t=>{
  if(t.distance<progress-.28)return false;
  // Once the child takes the corner, do not keep telling them to turn.
  if(progress>=t.distance-.12&&Math.abs(delta(orientation,t.outHeading))<TURN)return false;
  return true;
 });
 if(next&&next.distance-progress<=LOOK_AHEAD){
  const earlierExit=plan.points.some((p,i)=>i>0&&plan.cumulative[i]>progress+.12&&plan.cumulative[i]<next.distance-EPS&&plan.graph.get(p.id)?.neighbors.length>=3);
  if(!earlierExit)return {key:`turn:${next.index}`,text:next.text};
 }
 return {key:`straight:${next?.index??'end'}`,text:'Go straight.'};
}

/** Pure navigation state. The browser adapter below owns speech and mode gates. */
export class SpokenSchoolGuide{
 constructor(school){this.school=school;this.stop();}
 stop(){this.plan=null;this.instruction='';this.promptKey='';this.progress=0;this.furthest=0;this.lastPose=null;this.time=0;this.nextRecovery=0;this.arrived=false;}
 start(pose,targetId,{arrived=false}={}){
  this.stop();this.plan=planSchoolRoute(this.school,pose,targetId);if(!this.plan)return null;
  this.lastPose={...pose};this.arrived=arrived;this.progress=projection(this.plan,pose,0).progress;this.furthest=this.progress;
  return this.setCue(cueAt(this.plan,pose,this.progress,arrived||atDestination(this.school,pose,this.plan.room)),true);
 }
 result({spoken='',rerouted=false}={}){return this.plan?{instruction:this.instruction,cueKey:this.promptKey,spoken,rerouted,arrived:this.arrived,room:this.plan.room,route:this.plan.points}:null;}
 setCue(cue,force=false,rerouted=false){const changed=force||cue.key!==this.promptKey||cue.text!==this.instruction;this.promptKey=cue.key;this.instruction=cue.text;return this.result({spoken:changed?cue.text:'',rerouted});}
 update(pose,dt=0,{arrived=false}={}){
  if(!this.plan||!validPose(pose))return null;
  this.time+=Number.isFinite(dt)?Math.max(0,dt):0;this.arrived=arrived;
  if(arrived||atDestination(this.school,pose,this.plan.room)){this.lastPose={...pose};return this.setCue({key:'arrival',text:arrivalText(this.plan.room)});}
  const p=projection(this.plan,pose,this.progress),moved=this.lastPose?distance(pose,this.lastPose):0;
  const wrong=p.distance>.64||p.progress<this.furthest-.64||moved>2;
  if(wrong&&moved>EPS&&this.time>=this.nextRecovery){
   this.nextRecovery=this.time+.35;const plan=planSchoolRoute(this.school,pose,this.plan.room.id);
   if(plan){this.plan=plan;this.progress=projection(plan,pose,0).progress;this.furthest=this.progress;this.lastPose={...pose};return this.setCue(cueAt(plan,pose,this.progress,false),true,true);}
  }
  this.progress=p.progress;this.furthest=Math.max(this.furthest,p.progress);this.lastPose={...pose};
  return this.setCue(cueAt(this.plan,pose,this.progress,false));
 }
}

/** App adapter. Call start(context) inside the character-selection click, then
 * update(context,dt) each frame. A context must explicitly allow solo directions:
 * {school,player,targetId,arrived,mode:'walk',localDirections:true,paired:false,
 * paused:false}. stop() on leaving; pause() immediately on blur/modal; setMuted
 * from the voice toggle. Paired/controller/build contexts can never speak. */
export function createSchoolNavigationGuide({scope=globalThis,speech:providedSpeech,muted=false,onInstruction=()=>{},onWrongWay=()=>{},onState=()=>{}}={}){
 const speech=providedSpeech||createSchoolSpeech({scope,onState});
 let navigator=null,context=null,paused=false,lastText='',lastCue='',nextSpeechAt=0,time=0,pending=false;
 let lastWarningAt=-Infinity,warningPending=false;
 const enabled=c=>c?.mode==='walk'&&c.localDirections===true&&!c.paired&&validPose(c.player)&&!!c.targetId;
 function emit(text,force=false,cueKey=navigator?.promptKey){
  onInstruction(text||'');if(!text||muted||paused)return;
  if(!force&&!warningPending&&text===lastText&&(text==='Go straight.'||cueKey===lastCue)){pending=false;return;}
  if(!force&&time<nextSpeechAt){pending=true;return;}
  const spoken=warningPending?'Wrong way. '+text:text;
  if(speech.speak(spoken)){
   lastText=text;lastCue=cueKey;nextSpeechAt=time+(warningPending?2.6:1.15);
   warningPending=false;pending=false;
  }else pending=true;
 }
 function clearWarning(){warningPending=false;onWrongWay(false);}
 function stop(){speech.cancel();navigator=null;context=null;paused=false;lastText='';lastCue='';pending=false;nextSpeechAt=0;lastWarningAt=-Infinity;clearWarning();onInstruction('');}
 function pause(){if(!paused){speech.cancel();clearWarning();}paused=true;pending=false;}
 function start(next){
  stop();if(!enabled(next))return null;context=next;navigator=new SpokenSchoolGuide(next.school);paused=!!next.paused;
  const result=navigator.start(next.player,next.targetId,{arrived:!!next.arrived});if(result)emit(result.instruction,true);return result;
 }
 function update(next,dt=0){
  time+=Number.isFinite(dt)?Math.max(0,dt):0;
  if(!enabled(next)){if(navigator||context)stop();return null;}
  if(!navigator||context?.school!==next.school||context?.targetId!==next.targetId)return start(next);
  context=next;if(next.paused){pause();return navigator.result();}
  if(paused){paused=false;const result=navigator.start(next.player,next.targetId,{arrived:!!next.arrived});if(result)emit(result.instruction,true);return result;}
  const result=navigator.update(next.player,dt,{arrived:!!next.arrived});
  const arriving=result?.cueKey==='arrival';
  const wrongWay=result?.rerouted&&time-lastWarningAt>=3;
  if(wrongWay){
   lastWarningAt=time;warningPending=!muted;onWrongWay(true);
  }else if(result?.spoken&&arriving)clearWarning();
  if(time-lastWarningAt>=3)warningPending=false;
  if(result?.spoken)emit(result.spoken,wrongWay||arriving);
  else if(pending&&time>=nextSpeechAt)emit(navigator.instruction);
  return result;
 }
 function setMuted(value){muted=!!value;if(muted){speech.cancel();pending=false;warningPending=false;onState('muted');}else if(context&&enabled(context)&&!paused)emit(navigator?.instruction,true);}
 return {start,update,stop,pause,setMuted,available:speech.available,get supported(){return speech.available();},get muted(){return muted;}};
}
