export const TAU=Math.PI*2;
export const angleDelta=(from,to)=>Math.atan2(Math.sin(to-from),Math.cos(to-from));
// A player's visual forward is +Z; orbit yaw is measured from player to camera.
export function behindPlayerYaw(angle,current=0){
 const facing=Number.isFinite(angle)?angle:Math.PI;
 const base=Number.isFinite(current)?current:0;
 const delta=angleDelta(base,facing+Math.PI);
 return Math.abs(delta)<1e-12?base:base+delta;
}
export function projectedModelScale({distance,fov=40,viewportHeight,modelHeight=.52,minPixels=34,maxScale=3.2}){
 if(![distance,fov,viewportHeight,modelHeight].every(Number.isFinite)||viewportHeight<=0||modelHeight<=0)return 1;
 const unitsPerPixel=2*Math.max(.01,distance)*Math.tan(fov*Math.PI/360)/viewportHeight;
 return Math.max(1,Math.min(maxScale,minPixels*unitsPerPixel/modelHeight));
}
