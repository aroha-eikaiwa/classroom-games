# School furniture material textures

Generated with the built-in image generation tool on 2026-11-21. All supplied WebP assets are 512×512, compressed from the untouched generated PNG originals using Sharp. No painted edits or synthetic replacement textures were made.

Shared brief: seamless square orthographic PBR albedo surface swatch for a stylized 3D school game; uniform neutral diffuse lighting; no baked shadows, shine, perspective, objects, labels, borders, seams, or watermark; low contrast fine material detail.

- `birch.webp`: Pale natural blond birch school-desk wood with restrained warm honey tone, subtle fine mostly straight horizontal grain, tasteful organic variation, clean furniture finish, and no dramatic knots or plank joints.
- `walnut.webp`: Medium warm brown walnut shelving and musical-instrument wood with fine natural horizontal straight grain and subtle gentle curves, restrained rich brown finish, and no plank joints.
- `powder-metal.webp`: Very light cool neutral gray powder-coated steel for chair legs and cabinets, extremely fine matte stipple microtexture, clean smooth paint, no scratches, rust, grime, or bolts.
- `ivory-laminate.webp`: Neutral warm off-white laminate and porcelain with ultra-fine mottled microscopic grain, mostly smooth clean finish, minimal contrast and bright non-clipped cream-white tone, no cracks or dirt.
- `fabric.webp`: Neutral ivory fine cotton upholstery and linen, tightly woven smooth soft microscopic cross weave, low contrast, clean modern school fabric, no folds, wrinkles, coarse burlap, knitted wool, shadows, highlights, or objects. Intended to be tinted for sofa upholstery, seat pads, nurse-bed linens and curtains, and gym mats.

Suggested integration: mark textures as sRGB; choose UV repeats by physical surface dimensions so material grain is not stretched on thin furniture edges; wood grain is horizontal in texture coordinates. Metallic response and roughness belong in the material settings rather than baked texture highlights.

Poster atlas: eight original AI-generated illustrations made for this game, using the built-in image generation tool. Equal 4 × 2 panels: music, science, art, cooking, reading, kindness, seasons, sports. Friendly minimalist gouache style; no generated lettering. Exact poster headings and blackboard lessons are rendered by school-art.mjs.

## Quiet school linoleum · 21 November 2026
Generated with built-in image generation for the school floors. Prompt: seamless square pale ivory linoleum albedo with extremely subtle mineral grain and sparse grey-beige flecks; near-white neutral base for room tinting; no lighting, shadows, grout, lines, furniture or text. The complete generated swatch is resized and WebP-encoded for use at a fixed world scale.
