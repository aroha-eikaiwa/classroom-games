// Solid footprints for the major indoor furnishings in models.mjs. The same
// plan is used by local movement, server validation and room-model metadata.
// Chairs, wall art and loose objects stay outside this coarse collision layer.
const cache=new Map();
const definitions={entrance:[4,3],classroom:[4,3],teachers:[5,3],principal:[3,3],science:[5,4],music:[5,4],art:[5,4],cooking:[5,4],library:[5,4],gym:[7,5],restroom:[3,3],nurse:[4,3]};
export function roomFurnitureObstacles(type){
 if(cache.has(type))return cache.get(type);
 const size=definitions[type];if(!size)return [];
 const [w,d]=size,items=[];
 const rect=(id,x,z,width,depth,rotation=0)=>items.push({id,shape:'rect',x,z,w:width,d:depth,rotation});
 const circle=(id,x,z,r)=>items.push({id,shape:'circle',x,z,r});
 const shelf=(id,x,z,width,rotation=0)=>{
  // Outer bookshelf boards: width + two half-width side panels; back extends
  // 0.0125 behind the nominal depth, so offset the exact rectangle slightly.
  const offset=-.00625;rect(id,x+Math.sin(rotation)*offset,z+Math.cos(rotation)*offset,width+.03,.2325,rotation);
 };
 if(type==='entrance'){
  rect('shoe-lockers-left',.28,d/2,d-1,.27,Math.PI/2);rect('shoe-lockers-right',w-.28,d/2,d-1,.27,-Math.PI/2);rect('entrance-bench',2.85,1.4,.70,.26);
 }else if(type==='classroom'){
  rect('teacher-desk',w/2,.52,.8,.37);
  for(let row=0;row<3;row++)for(const [col,x] of [.45,1.17,2.50,3.22].entries())rect(`student-desk-${row}-${col}`,x,1.06+row*.63,.49,.33);
  rect('classroom-cabinet',w-.55,d-.20,.855,.31);
 }else if(type==='teachers'){
  for(let row=0;row<2;row++)for(let col=0;col<3;col++)rect(`office-desk-${row}-${col}`,2.05+col*.83,.8+row*1.15,.72,.46);
  for(const [i,z]of [.7,1.65].entries())rect(`office-cabinet-${i}`,.42,z,.675,.40,Math.PI/2);
 }else if(type==='principal'){
  rect('principal-desk',1.65,.70,1.05,.53);rect('visitor-sofa-left',.55,1.55,1.12,.36,Math.PI/2);rect('visitor-sofa-right',w-.47,1.55,1.12,.36,-Math.PI/2);rect('visitor-table',w/2,1.6,.60,.65);shelf('principal-shelf',.5,.18,.72);
 }else if(type==='science'){
  for(let row=0;row<2;row++)for(let col=0;col<2;col++)rect(`lab-table-${row}-${col}`,1.32+col*2.05,1.15+row*1.60,1.22,.74);
  rect('lab-cabinet-right',w-.25,1.45,.975,.36,-Math.PI/2);rect('lab-cabinet-left',.24,1.55,.925,.36,Math.PI/2);
 }else if(type==='music'){
  const yaw=.16;rect('piano',.8-Math.sin(yaw)*.01,.67-Math.cos(yaw)*.01,.87,.52,yaw);rect('piano-bench',.8+Math.sin(yaw)*.52,.67+Math.cos(yaw)*.52,.43,.22,yaw);
  rect('xylophone-table',.46,2.12,.7,.35,Math.PI/2);
  for(let i=0;i<2;i++)circle(`drum-${i}`,w-.48,.55+i*.7,.17);
 }else if(type==='art'){
  for(let row=0;row<2;row++)for(let col=0;col<2;col++)rect(`art-table-${row}-${col}`,1.30+col*2,1.20+row*1.55,1.15,.72);
  rect('art-cabinet',.24,1.40,1.025,.32,Math.PI/2);
 }else if(type==='cooking'){
  for(let row=0;row<2;row++)for(let col=0;col<2;col++)rect(`cooking-counter-${row}-${col}`,1.35+col*2.05,1.12+row*1.70,1.34,.78);
  rect('fridge',.32,.65,.505,.46);rect('kitchen-cabinet',w-.23,2,1.075,.31,-Math.PI/2);
 }else if(type==='library'){
  for(const [i,x]of [.65,1.65,2.65,3.65].entries())shelf(`north-shelf-${i}`,x,.20,.85);
  for(const [side,x]of [.28,w-.28].entries())for(let i=0;i<2;i++)shelf(`side-shelf-${side}-${i}`,x,1.45+i*1.1,.86,x<1?Math.PI/2:-Math.PI/2);
  for(const [i,z]of [1.55,2.85].entries())rect(`reading-table-${i}`,2.5,z,1.82,.60);
 }else if(type==='gym'){
  rect('stage',w/2,.43,w-.35,.72);rect('gym-mats',w-.55,d-.35,.70,.40);
 }else if(type==='restroom'){
  // The cubicle doors are closed static geometry, so their interiors are not
  // walkable. Leave the rear wash area and the room doorway entirely open.
  for(let i=0;i<3;i++)rect(`closed-cubicle-${i}`,.50+i*.85,.70,.825,1.05);
  for(const [i,z]of [1.62,2.36].entries())rect(`wash-basin-${i}`,.26,z,.27,.32);
 }else if(type==='nurse'){
  for(let i=0;i<2;i++)rect(`bed-${i}`,2.25+i*1.05,.95,.67,1.13);
  rect('nurse-desk',.65,.75,.8,.43);rect('medical-cabinet',.27,1.9,.675,.32,Math.PI/2);
 }
 const plan=Object.freeze(items.map(Object.freeze));cache.set(type,plan);return plan;
}
export function furnitureCollision(obstacle,x,z,radius=0){
 if(obstacle.shape==='circle')return Math.hypot(x-obstacle.x,z-obstacle.z)<obstacle.r+radius-1e-9;
 const dx=x-obstacle.x,dz=z-obstacle.z,c=Math.cos(obstacle.rotation),s=Math.sin(obstacle.rotation);
 const localX=dx*c-dz*s,localZ=dx*s+dz*c;
 if(Math.abs(localX)<obstacle.w/2-1e-9&&Math.abs(localZ)<obstacle.d/2-1e-9)return true;
 const nearX=Math.max(0,Math.abs(localX)-obstacle.w/2),nearZ=Math.max(0,Math.abs(localZ)-obstacle.d/2);
 return Math.hypot(nearX,nearZ)<radius-1e-9;
}
export function roomFurnitureWalkable(type,x,z,radius=0){
 return !roomFurnitureObstacles(type).some(obstacle=>furnitureCollision(obstacle,x,z,radius));
}

// Visibility-graph waypoints sit just outside each expanded footprint. Unlike
// a one-cell lattice they retain the narrow real aisles between school desks.
export function furnitureNavigationPoints(type,width,depth,radius=.105){
 const points=[],padding=radius+.003,edge=radius+.008;
 for(const x of [edge,width-edge])for(const z of [edge,depth-edge])points.push({x,z});
 for(const obstacle of roomFurnitureObstacles(type)){
  const hw=(obstacle.shape==='circle'?obstacle.r:obstacle.w/2)+padding,hd=(obstacle.shape==='circle'?obstacle.r:obstacle.d/2)+padding,yaw=obstacle.rotation||0,c=Math.cos(yaw),s=Math.sin(yaw);
  for(const x of [-hw,hw])for(const z of [-hd,hd])points.push({x:obstacle.x+x*c+z*s,z:obstacle.z-x*s+z*c});
 }
 const unique=new Map();for(const point of points)if(point.x>radius&&point.x<width-radius&&point.z>radius&&point.z<depth-radius&&roomFurnitureWalkable(type,point.x,point.z,radius))unique.set(`${point.x.toFixed(5)},${point.z.toFixed(5)}`,point);
 return [...unique.values()];
}
