// The principal is a permanent member of this office, independent of which
// classrooms are in use during a Directions session. Stand beside the desk,
// clear of its chair, bookshelves and the route from the door.
export const PRINCIPAL_PLACEMENT=Object.freeze({x:.95,y:.055,z:.70,rotation:0});

export function syncOfficePrincipals(roomMeshes,principals,create,dispose){
  const present=new Set();
  for(const [id,room]of roomMeshes){
    if(room.userData.schoolType!=='principal')continue;
    present.add(id);
    let person=principals.get(id);
    if(!person){
      person=create({teacher:true,variant:0});principals.set(id,person);
      person.name='Principal';person.userData.officePrincipal=true;
      person.userData.softwareRoomInterior=true;
    }
    if(person.parent!==room)room.add(person);
    const p=PRINCIPAL_PLACEMENT;person.position.set(p.x,p.y,p.z);person.rotation.y=p.rotation;
    person.visible=true;
  }
  for(const [id,person]of principals)if(!present.has(id)){
    person.removeFromParent();dispose(person);principals.delete(id);
  }
  return principals.size;
}

export function clearOfficePrincipals(principals,dispose){
  for(const person of principals.values()){person.removeFromParent();dispose(person);}
  principals.clear();
}
