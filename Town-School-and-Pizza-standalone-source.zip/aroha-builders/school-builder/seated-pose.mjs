import * as THREE from './vendor/three.module.js';

// Static pose for the original boy/girl meshes, with +Z toward the desk.
// The origin is the centre of the chair seat, not the soles of the feet.
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a));return t*t*(3-2*t);};
const mix=(a,b,t)=>a+(b-a)*t;

function seatedPoint(x,y,z,region,head,variant) {
  const hip=.17,knee=.09,pelvis=.024,drop=hip-pelvis;
  const upright=[x,y-drop,z];
  if(head>.1||y>.285)return upright;
  const arm=smooth(.052,.068,Math.abs(x))*(1-smooth(.267,.287,y))*(region===2?0:1);
  let body;
  if(variant===1&&region===2){
    // The skirt drapes from the waist over the horizontal thighs.
    const bend=1-smooth(.164,.185,y);
    body=[x,mix(y-drop,.027+z*.42+(y-.15)*.2,bend),mix(z,(.182-y)*1.5+z*.7,bend)];
  }else{
    const thigh=[x,pelvis+z,hip-y];
    const calf=[x,y-knee+pelvis,z+hip-knee];
    const hipWeight=1-smooth(.157,.185,y),kneeWeight=1-smooth(.078,.104,y);
    const leg=thigh.map((v,i)=>mix(v,calf[i],kneeWeight));
    body=upright.map((v,i)=>mix(v,leg[i],hipWeight));
  }
  if(arm>0){
    // Bend the elbows: upper arms remain beside the body and the hands rest
    // forward over the lap, leaving the desk top above the wrists.
    const elbow=.223,shoulder=.273;
    const upper=[x,y-drop,z+(shoulder-y)*.28];
    const fore=[x*.63,elbow-drop-.012+z*.8,.018+(elbow-y)*.8];
    const foreWeight=1-smooth(.215,.235,y);
    body=body.map((v,i)=>mix(v,mix(upper[i],fore[i],foreWeight),arm));
  }
  return body;
}

export function applySeatedPose(positions,normals,{region=[],headWeights=[],height=.5,variant=0}={}){
  const scale=height/.5,epsilon=.0001;
  for(let at=0,i=0;at<positions.length;at+=3,i++){
    const x=positions[at]/scale,y=positions[at+1]/scale,z=positions[at+2]/scale;
    const r=region[i]||0,h=(headWeights[i]||0)/255;
    const p=seatedPoint(x,y,z,r,h,variant);
    if(normals){
      // Transform two surface tangents, retaining the source's smooth normals
      // across its atlas seams even around the bent knees and elbows.
      const nx=normals[at],ny=normals[at+1],nz=normals[at+2];
      let tx=-ny,ty=nx,tz=0;
      if(Math.hypot(tx,ty)<.1){tx=0;ty=-nz;tz=ny;}
      const length=Math.hypot(tx,ty,tz)||1;tx/=length;ty/=length;tz/=length;
      const bx=ny*tz-nz*ty,by=nz*tx-nx*tz,bz=nx*ty-ny*tx;
      const a=seatedPoint(x+tx*epsilon,y+ty*epsilon,z+tz*epsilon,r,h,variant);
      const b=seatedPoint(x+bx*epsilon,y+by*epsilon,z+bz*epsilon,r,h,variant);
      const ax=a[0]-p[0],ay=a[1]-p[1],az=a[2]-p[2];
      const dx=b[0]-p[0],dy=b[1]-p[1],dz=b[2]-p[2];
      const ox=ay*dz-az*dy,oy=az*dx-ax*dz,oz=ax*dy-ay*dx;
      const n=Math.hypot(ox,oy,oz);
      if(n>1e-12){normals[at]=ox/n;normals[at+1]=oy/n;normals[at+2]=oz/n;}
    }
    positions[at]=p[0]*scale;positions[at+1]=p[1]*scale;positions[at+2]=p[2]*scale;
  }
}

// Both original atlases use the same hair swatch and face iris coordinates.
// Restrict hair tint to head vertices so footwear and uniform stay unchanged.
export function isStudentHairVertex(data,index){
  const u=data.uv[index*2],v=data.uv[index*2+1];
  return (data.headWeights?.[index]||0)>128&&u>.76&&v>.612&&v<.656;
}
export const STUDENT_IRISES=Object.freeze([
  Object.freeze({x:119/512,y:178/512,radius:19/512}),
  Object.freeze({x:241/512,y:178/512,radius:19/512}),
]);

const appearanceTextures=new WeakMap();
const appearances=[
  {hair:[89,52,31],eye:[112,83,39]},
  {hair:[43,34,30],eye:[63,91,74]},
  {hair:[104,87,62],eye:[66,86,110]},
];

export function createStudentAppearanceTexture(original,appearance=1){
  if(typeof document==='undefined'||!original?.image)return original;
  const variant=(Math.max(1,Math.trunc(appearance))-1)%appearances.length;
  let variants=appearanceTextures.get(original);
  if(!variants){variants=new Map();appearanceTextures.set(original,variants);}
  if(variants.has(variant))return variants.get(variant);
  const source=original.image,width=source.naturalWidth||source.width,height=source.naturalHeight||source.height;
  const canvas=document.createElement('canvas');canvas.width=width*2;canvas.height=height;
  const ctx=canvas.getContext('2d',{willReadFrequently:true});
  if(!ctx)return original;
  ctx.drawImage(source,0,0,width,height);ctx.drawImage(source,width,0,width,height);
  const pixels=ctx.getImageData(0,0,width*2,height),{hair,eye}=appearances[variant];
  for(let y=0;y<height;y++)for(let x=0;x<width*2;x++){
    const u=(x%width)/width,v=y/height,at=(y*width*2+x)*4;
    const r=pixels.data[at],g=pixels.data[at+1],b=pixels.data[at+2];
    const luminance=.2126*r+.7152*g+.0722*b;
    if(x>=width&&u>.76&&v>.612&&v<.656){
      // Only geometry tagged as hair samples this right-hand atlas copy.
      const shading=Math.max(.5,Math.min(1.3,luminance/42));
      pixels.data[at]=Math.min(255,hair[0]*shading);
      pixels.data[at+1]=Math.min(255,hair[1]*shading);
      pixels.data[at+2]=Math.min(255,hair[2]*shading);
    }else if(STUDENT_IRISES.some(iris=>Math.hypot(u-iris.x,v-iris.y)<iris.radius)&&luminance>37&&luminance<175&&r>b*1.15){
      // Keep the pupil, eye white, catchlight and outlines unchanged.
      const shading=luminance/85;
      pixels.data[at]=Math.min(220,eye[0]*shading);
      pixels.data[at+1]=Math.min(220,eye[1]*shading);
      pixels.data[at+2]=Math.min(220,eye[2]*shading);
    }
  }
  ctx.putImageData(pixels,0,0);
  const texture=new THREE.CanvasTexture(canvas);
  texture.colorSpace=THREE.SRGBColorSpace;texture.flipY=original.flipY;texture.anisotropy=original.anisotropy;
  texture.userData.shared=true;texture.userData.studentAppearance=variant+1;
  variants.set(variant,texture);return texture;
}
