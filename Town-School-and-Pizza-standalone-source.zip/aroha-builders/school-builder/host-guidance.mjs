import * as THREE from './vendor/three.module.js';

// The same yellow downward arrow language as Town Builder. It is deliberately
// unlit and drawn above architecture so a guide can find the selected room.
export function createDestinationArrow(){
 const arrow=new THREE.Group();arrow.name='destination-arrow';
 const material=new THREE.MeshBasicMaterial({color:0xffcd32,depthTest:false,depthWrite:false});
 const head=new THREE.Mesh(new THREE.ConeGeometry(.24,.43,5),material);
 const shaft=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.52,12),material);
 head.rotation.z=Math.PI;head.position.y=-.22;shaft.position.y=.22;arrow.add(head,shaft);
 arrow.traverse(o=>o.renderOrder=30);return arrow;
}
export function createPlayerLocator(){
 const locator=new THREE.Group();locator.name='guide-player-locator';
 const geometry=new THREE.RingGeometry(.23,.31,32);geometry.rotateX(-Math.PI/2);
 const material=new THREE.MeshBasicMaterial({color:0x18cde0,transparent:true,opacity:.9,side:THREE.DoubleSide,depthTest:false,depthWrite:false});
 const ring=new THREE.Mesh(geometry,material);ring.renderOrder=31;locator.add(ring);return locator;
}
export function setRoomGlow(room,enabled,time=0){
 if(!room)return;
 room.traverse(mesh=>{
  if(!mesh.isMesh||Array.isArray(mesh.material))return;
  // Static people are separate from the room's walls/furniture, and keep their
  // normal appearance while the selected room itself glows.
  for(let p=mesh;p&&p!==room;p=p.parent)if(p.userData.staticCharacter||p.userData.classroomOccupants)return;
  const base=mesh.userData.guideGlowBase;
  if(!enabled){if(base){mesh.material.dispose();mesh.material=base;delete mesh.userData.guideGlowBase;}return;}
  if(!base&&mesh.material?.emissive){mesh.userData.guideGlowBase=mesh.material;mesh.material=mesh.material.clone();mesh.material.userData={...mesh.material.userData,owned:true};mesh.material.emissive.setHex(0xffc842);}
  if(mesh.userData.guideGlowBase)mesh.material.emissiveIntensity=.32+.10*Math.sin(time*2.5);
 });
}
export function disposeGuidance(group){
 const seen=new Set();group.traverse(o=>{for(const resource of [o.geometry,...(Array.isArray(o.material)?o.material:[o.material])])if(resource&&!seen.has(resource)){resource.dispose();seen.add(resource);}});
}

// Keep the actual student visible in the guide's overhead view, including
// inside rooms. GPU depth is cleared once before this actor, retaining depth
// testing within the model. The CPU renderer uses the matching actor layer.
export function setGuidePlayerOverlay(group,enabled){
 group.userData.guideOverlay=enabled;group.userData.softwareBackground=enabled?20.1:0;group.renderOrder=enabled?40:0;
 group.traverse(mesh=>{
  if(!mesh.isMesh)return;
  mesh.renderOrder=enabled?40:0;
  if(mesh.userData.guideDepthHook)return;
  const previous=mesh.onBeforeRender;
  mesh.onBeforeRender=function(renderer,...args){
   if(group.userData.guideOverlay&&renderer.info?.render?.frame!==group.userData.guideDepthFrame){renderer.clearDepth();group.userData.guideDepthFrame=renderer.info.render.frame;}
   previous?.call(this,renderer,...args);
  };
  mesh.userData.guideDepthHook=true;
 });
}
