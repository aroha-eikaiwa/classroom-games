// A permanent nurse in the clear space between the clinic desk and first bed.
// Its presence and outfit do not depend on randomized classroom sessions.
export const NURSE_PLACEMENT=Object.freeze({x:1.52,y:.055,z:.86,rotation:.22});

export function syncOfficeNurses(roomMeshes,nurses,create,dispose){
  const present=new Set();
  for(const [id,room]of roomMeshes){
    if(room.userData.schoolType!=='nurse')continue;
    present.add(id);
    let person=nurses.get(id);
    if(!person){
      person=create({teacher:true,variant:1,uniform:'nurse'});nurses.set(id,person);
      person.name='School nurse';person.userData.officeNurse=true;
      person.userData.softwareRoomInterior=true;
    }
    if(person.parent!==room)room.add(person);
    const p=NURSE_PLACEMENT;person.position.set(p.x,p.y,p.z);person.rotation.y=p.rotation;
    person.visible=true;
  }
  for(const [id,person]of nurses)if(!present.has(id)){
    person.removeFromParent();dispose(person);nurses.delete(id);
  }
  return nurses.size;
}

export function clearOfficeNurses(nurses,dispose){
  for(const person of nurses.values()){person.removeFromParent();dispose(person);}
  nurses.clear();
}
