import * as THREE from './vendor/three.module.js';

export const WINDOW_FRAME=.028;
const materials=new Map();
const paneGeometry=new THREE.PlaneGeometry(1,1);paneGeometry.userData.shared=true;

export function glazingKind(roomType,{door=false}={}){
 // A partner must still identify rooms by entering them. Interior door panes
 // stay opaque, and medical/washroom exterior windows use privacy glass too.
 return door||roomType==='restroom'||roomType==='nurse'?'frosted':'clear';
}
export function glazingMaterial(kind='clear'){
 if(!materials.has(kind)){
  const clear=kind==='clear';
  const material=new THREE.MeshStandardMaterial({
   color:clear?0xb6d8dd:0xd1e0db,
   roughness:clear?.18:.91,metalness:clear?.04:0,
   transparent:clear,opacity:clear?.27:1,depthWrite:!clear,
   side:THREE.DoubleSide,forceSinglePass:true,
  });
  material.name=clear?'Lightly tinted exterior glass':'Frosted privacy glass';
  material.userData.glazingKind=kind;material.userData.privacy=!clear;
  materials.set(kind,material);
 }
 return materials.get(kind);
}
export function createGlazingPane(width,height,kind='clear'){
 const pane=new THREE.Mesh(paneGeometry,glazingMaterial(kind));
 pane.name=kind==='clear'?'exterior-window-glass':'privacy-window-glass';
 pane.scale.set(width,height,1);pane.castShadow=false;pane.receiveShadow=false;
 pane.userData.glazingKind=kind;pane.renderOrder=kind==='clear'?2:0;
 return pane;
}
export function windowOpening(slot){
 const halfWidth=Math.max(.001,slot.width/2-WINDOW_FRAME),halfHeight=Math.max(.001,slot.height/2-WINDOW_FRAME);
 return {from:slot.position-halfWidth,to:slot.position+halfWidth,bottom:slot.y-halfHeight,top:slot.y+halfHeight};
}

// These are real apertures through the plaster, not transparent rectangles
// laid over an opaque wall. Window slots come only from checked exterior bays.
export function wallApertureRectangles(from,to,slots,{bottom=.015,top=1.265}={}){
 const result=[],add=(a,b,low,high)=>{if(b-a>1e-6&&high-low>1e-6)result.push({from:a,to:b,bottom:low,top:high});};
 let cursor=from;
 for(const opening of slots.map(windowOpening).filter(o=>o.to>from&&o.from<to).sort((a,b)=>a.from-b.from)){
  const left=Math.max(cursor,from,opening.from),right=Math.min(to,opening.to);
  if(right<=left)continue;
  add(cursor,left,bottom,top);
  add(left,right,bottom,Math.min(top,opening.bottom));
  add(left,right,Math.max(bottom,opening.top),top);
  cursor=right;
 }
 add(cursor,to,bottom,top);return result;
}
