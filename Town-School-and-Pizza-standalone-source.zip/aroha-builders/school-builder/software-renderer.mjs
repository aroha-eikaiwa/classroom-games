import * as THREE from './vendor/three.module.js';

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const linearSRGB=v=>{v=clamp(v,0,1);return Math.round(255*(v<=.0031308?12.92*v:1.055*v**(1/2.4)-.055));};
const light=new THREE.Vector3(-18,38,14).normalize();
const tempMatrix=new THREE.Matrix4(),instanceMatrix=new THREE.Matrix4();
const imageCache=new WeakMap(),textureColors=new WeakMap();
const tintedImages=new WeakMap();
function tintTexture(image,color){
 if(!image||!color||color.getHex()===0xffffff)return image;
 const key=color.getHexString();let variants=tintedImages.get(image);if(!variants){variants=new Map();tintedImages.set(image,variants);}if(variants.has(key))return variants.get(key);
 const canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;const c=canvas.getContext('2d');
 c.drawImage(image,0,0);c.globalCompositeOperation='multiply';c.fillStyle='#'+key;c.fillRect(0,0,canvas.width,canvas.height);c.globalCompositeOperation='destination-in';c.drawImage(image,0,0);
 variants.set(key,canvas);return canvas;
}
function dataTextureColor(texture){
 if(!texture?.isDataTexture||!texture.image?.data)return null;let color=textureColors.get(texture);if(color)return color;
 const data=texture.image.data;let r=0,g=0,b=0,n=0;for(let i=0;i<data.length;i+=64){r+=data[i]||0;g+=data[i+1]||0;b+=data[i+2]||0;n++;}color=new THREE.Color().setRGB(r/n/255,g/n/255,b/n/255,THREE.SRGBColorSpace);textureColors.set(texture,color);return color;
}
function textureImage(texture){
 const image=texture?.image;if(!image)return null;
 if(image.getContext||typeof ImageBitmap!=='undefined'&&image instanceof ImageBitmap||typeof HTMLImageElement!=='undefined'&&image instanceof HTMLImageElement)return image;
 if(image.data&&image.width&&image.height){
  let canvas=imageCache.get(texture);if(!canvas){canvas=document.createElement('canvas');canvas.width=image.width;canvas.height=image.height;const context=canvas.getContext('2d'),data=context.createImageData(image.width,image.height);data.data.set(image.data);context.putImageData(data,0,0);imageCache.set(texture,canvas);}return canvas;
 }
 return null;
}
function matrixSame(a,b){if(!a)return false;for(let i=0;i<16;i++)if(a[i]!==b[i])return false;return true;}
function clipNear(vertices,near){
 const out=[];for(let i=0;i<vertices.length;i++){const a=vertices[i],b=vertices[(i+1)%vertices.length],ain=a[2]<=-near,bin=b[2]<=-near;if(ain)out.push(a);if(ain!==bin){const t=(-near-a[2])/(b[2]-a[2]);out.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,-near,a[3]+(b[3]-a[3])*t,a[4]+(b[4]-a[4])*t]);}}return out;
}
function affineTexture(context,image,points,uvs){
 const x0=uvs[0]*image.width,y0=(1-uvs[1])*image.height,x1=uvs[2]*image.width,y1=(1-uvs[3])*image.height,x2=uvs[4]*image.width,y2=(1-uvs[5])*image.height;
 const den=x0*(y1-y2)+x1*(y2-y0)+x2*(y0-y1);if(Math.abs(den)<1e-7)return false;
 const sx0=points[0],sy0=points[1],sx1=points[2],sy1=points[3],sx2=points[4],sy2=points[5];
 const a=(sx0*(y1-y2)+sx1*(y2-y0)+sx2*(y0-y1))/den,c=(sx0*(x2-x1)+sx1*(x0-x2)+sx2*(x1-x0))/den,e=(sx0*(x1*y2-x2*y1)+sx1*(x2*y0-x0*y2)+sx2*(x0*y1-x1*y0))/den;
 const b=(sy0*(y1-y2)+sy1*(y2-y0)+sy2*(y0-y1))/den,d=(sy0*(x2-x1)+sy1*(x0-x2)+sy2*(x1-x0))/den,f=(sy0*(x1*y2-x2*y1)+sy1*(x2*y0-x0*y2)+sy2*(x0*y1-x1*y0))/den;
 context.save();context.beginPath();context.moveTo(sx0,sy0);context.lineTo(sx1,sy1);context.lineTo(sx2,sy2);context.closePath();context.clip();context.transform(a,b,c,d,e,f);
 // Surface UVs are measured in world units and can repeat beyond one image.
 // Fill the complete source triangle to keep thin edges and long tables intact.
 if(Math.min(x0,x1,x2)<0||Math.min(y0,y1,y2)<0||Math.max(x0,x1,x2)>image.width||Math.max(y0,y1,y2)>image.height){
  context.fillStyle=context.createPattern(image,'repeat');
  const x=Math.floor(Math.min(x0,x1,x2))-1,y=Math.floor(Math.min(y0,y1,y2))-1;
  context.fillRect(x,y,Math.ceil(Math.max(x0,x1,x2))-x+1,Math.ceil(Math.max(y0,y1,y2))-y+1);
 }else context.drawImage(image,0,0);
 context.restore();return true;
}

/** A deterministic CPU fallback for browsers with WebGL disabled. The same real
 * geometry, collision world and camera are retained; only drawing is replaced. */
export class Canvas3DRenderer {
 constructor({canvas}){
  this.domElement=canvas;this.context=canvas.getContext('2d',{alpha:false});if(!this.context)throw Error('Canvas graphics unavailable');
  this.pixelRatio=1;this.width=1;this.height=1;this.shadowMap={enabled:false,type:null};this.outputColorSpace=THREE.SRGBColorSpace;this.toneMappingExposure=1;
  this.info={render:{calls:0,triangles:0},memory:{geometries:0,textures:0}};this.cache=new WeakMap();this.lastFrame=-Infinity;this.software=true;
 }
 setPixelRatio(ratio){this.pixelRatio=Math.min(1.2,ratio||1);}
 setSize(width,height,style=true){this.width=width;this.height=height;this.domElement.width=Math.max(1,Math.round(width*this.pixelRatio));this.domElement.height=Math.max(1,Math.round(height*this.pixelRatio));if(style){this.domElement.style.width=width+'px';this.domElement.style.height=height+'px';}this.lastFrame=-Infinity;}
 _record(object,matrix,index=0){
  let all=this.cache.get(object);if(!all){all=[];this.cache.set(object,all);}let cached=all[index];
  const geometry=object.geometry,positions=geometry.attributes.position;if(!positions)return null;
  if(cached&&cached.geometry===geometry&&cached.version===positions.version&&matrixSame(cached.matrix,matrix.elements))return cached;
  const world=new Float32Array(positions.count*3),e=matrix.elements;
  for(let i=0;i<positions.count;i++){const x=positions.getX(i),y=positions.getY(i),z=positions.getZ(i),k=i*3;world[k]=e[0]*x+e[4]*y+e[8]*z+e[12];world[k+1]=e[1]*x+e[5]*y+e[9]*z+e[13];world[k+2]=e[2]*x+e[6]*y+e[10]*z+e[14];}
  const indices=geometry.index?.array||null,n=indices?indices.length:positions.count,shades=new Uint8Array(Math.floor(n/3));
  for(let i=0;i+2<n;i+=3){const ai=(indices?indices[i]:i)*3,bi=(indices?indices[i+1]:i+1)*3,ci=(indices?indices[i+2]:i+2)*3;
   const ux=world[bi]-world[ai],uy=world[bi+1]-world[ai+1],uz=world[bi+2]-world[ai+2],vx=world[ci]-world[ai],vy=world[ci+1]-world[ai+1],vz=world[ci+2]-world[ai+2];
   const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,len=Math.hypot(nx,ny,nz)||1;const strength=.62+.42*Math.max(0,(nx*light.x+ny*light.y+nz*light.z)/len);shades[i/3]=clamp(Math.round((strength-.5)*16),0,12);
  }
  geometry.computeBoundingSphere();const sphere=geometry.boundingSphere?.clone().applyMatrix4(matrix);
  cached={geometry,version:positions.version,matrix:Array.from(e),world,indices,shades,sphere,uv:geometry.attributes.uv,camera:new Float32Array(world.length)};all[index]=cached;return cached;
 }
 render(scene,camera){
  const now=performance.now();if(now-this.lastFrame<65)return;this.lastFrame=now;
  const ctx=this.context,w=this.width,h=this.height;ctx.setTransform(this.pixelRatio,0,0,this.pixelRatio,0,0);ctx.globalAlpha=1;ctx.fillStyle=scene.background?.isColor?scene.background.getStyle():'#d2e1df';ctx.fillRect(0,0,w,h);
  scene.updateMatrixWorld();camera.updateMatrixWorld();const view=camera.matrixWorldInverse.elements,projection=camera.projectionMatrix.elements,near=Math.max(.035,camera.near||.05),far=camera.far||250;
  const triangles=[],lines=[],sprites=[];
  const project=(x,y,z)=>{const cw=projection[3]*x+projection[7]*y+projection[11]*z+projection[15];return[((projection[0]*x+projection[4]*y+projection[8]*z+projection[12])/cw*.5+.5)*w,(.5-(projection[1]*x+projection[5]*y+projection[9]*z+projection[13])/cw*.5)*h];};
  const cameraPoint=(x,y,z)=>[view[0]*x+view[4]*y+view[8]*z+view[12],view[1]*x+view[5]*y+view[9]*z+view[13],view[2]*x+view[6]*y+view[10]*z+view[14]];
  const drawRecord=(object,matrix,instance,layer)=>{
   const record=this._record(object,matrix,instance);if(!record)return;const material=Array.isArray(object.material)?object.material[0]:object.material;if(!material||material.visible===false||material.opacity===0)return;
   if(record.sphere){const c=cameraPoint(record.sphere.center.x,record.sphere.center.y,record.sphere.center.z),r=record.sphere.radius;if(c[2]-r>-near||-c[2]-r>far)return;
    if(Math.abs(c[0])-r>(-c[2]+r)/Math.max(.01,Math.abs(projection[0]))||Math.abs(c[1])-r>(-c[2]+r)/Math.max(.01,Math.abs(projection[5])))return;
   }
   const world=record.world,verts=record.camera;for(let i=0;i<world.length;i+=3){const x=world[i],y=world[i+1],z=world[i+2];verts[i]=view[0]*x+view[4]*y+view[8]*z+view[12];verts[i+1]=view[1]*x+view[5]*y+view[9]*z+view[13];verts[i+2]=view[2]*x+view[6]*y+view[10]*z+view[14];}
   const colors=[],color=(material.color||new THREE.Color(0xffffff)).clone(),em=material.emissive||{r:0,g:0,b:0},unlit=material.isMeshBasicMaterial;const mapColor=dataTextureColor(material.map);if(mapColor)color.multiply(mapColor);
   for(let bin=0;bin<=12;bin++){const shade=unlit?1:.5+bin/16;colors.push(`rgb(${linearSRGB(color.r*shade+em.r*.3)},${linearSRGB(color.g*shade+em.g*.3)},${linearSRGB(color.b*shade+em.b*.3)})`);}
   const indices=record.indices,n=indices?indices.length:verts.length/3,uv=record.uv;
   // Canvas text planes are kept sharp. Repeating data textures use their base material.
   const image=material.map&&!material.map.isDataTexture?tintTexture(textureImage(material.map),material.color):null;
   const alpha=material.opacity??1,priority=material.depthTest===false?20+(object.renderOrder||0)/100:layer||10;
   for(let i=0;i+2<n;i+=3){const ai=indices?indices[i]:i,bi=indices?indices[i+1]:i+1,ci=indices?indices[i+2]:i+2,a=ai*3,b=bi*3,c=ci*3;
    if(verts[a+2]>-near&&verts[b+2]>-near&&verts[c+2]>-near)continue;
    if(verts[a+2]<-far&&verts[b+2]<-far&&verts[c+2]<-far)continue;
    const original=[[verts[a],verts[a+1],verts[a+2],uv?.getX(ai)||0,uv?.getY(ai)||0],[verts[b],verts[b+1],verts[b+2],uv?.getX(bi)||0,uv?.getY(bi)||0],[verts[c],verts[c+1],verts[c+2],uv?.getX(ci)||0,uv?.getY(ci)||0]];
    const clipped=original.some(v=>v[2]>-near)?clipNear(original,near):original;if(clipped.length<3)continue;
    for(let j=1;j<clipped.length-1;j++){const a=clipped[0],b=clipped[j],c=clipped[j+1],pa=project(...a),pb=project(...b),pc=project(...c),area=(pb[0]-pa[0])*(pc[1]-pa[1])-(pb[1]-pa[1])*(pc[0]-pa[0]);
     if(Math.abs(area)<.06||material.side===THREE.FrontSide&&area>=0||material.side===THREE.BackSide&&area<=0)continue;
     if(Math.max(pa[0],pb[0],pc[0])<0||Math.min(pa[0],pb[0],pc[0])>w||Math.max(pa[1],pb[1],pc[1])<0||Math.min(pa[1],pb[1],pc[1])>h)continue;
     triangles.push({p:[...pa,...pb,...pc],depth:-(a[2]+b[2]+c[2])/3,color:colors[record.shades[Math.floor(i/3)]||0],alpha,layer:priority,image,uv:image?[a[3],a[4],b[3],b[4],c[3],c[4]]:null});
    }
   }
  };
  const visit=(object,layer=0,hideInterior=false)=>{
   if(!object.visible||hideInterior&&object.userData.softwareRoomInterior)return;layer=object.userData.softwareBackground||layer;
   if(object.userData.softwareRoom&&scene.userData.schoolView==='walk'&&scene.userData.schoolPlayer){const room=object.userData.softwareRoom,p=scene.userData.schoolPlayer,inside=p.x>=room.x&&p.x<=room.x+room.w&&p.z>=room.z&&p.z<=room.z+room.d;hideInterior=!room.outdoor&&!inside&&Math.hypot(p.x-room.door.x,p.z-room.door.z)>1.35;}
   if(object.isInstancedMesh){for(let i=0;i<object.count;i++){object.getMatrixAt(i,instanceMatrix);tempMatrix.multiplyMatrices(object.matrixWorld,instanceMatrix);drawRecord(object,tempMatrix,i,layer);}}
   else if(object.isMesh)drawRecord(object,object.matrixWorld,0,layer);
   else if(object.isSprite){const m=object.matrixWorld.elements,p=cameraPoint(m[12],m[13],m[14]);if(p[2]<-near){const point=project(...p),sx=Math.hypot(m[0],m[1],m[2]),sy=Math.hypot(m[4],m[5],m[6]),sizeX=Math.abs(projection[0]*sx/(-p[2])*w/2),sizeY=Math.abs(projection[5]*sy/(-p[2])*h/2);sprites.push({image:textureImage(object.material.map),x:point[0]-sizeX/2,y:point[1]-sizeY/2,w:sizeX,h:sizeY,alpha:object.material.opacity??1});}}
   else if(object.isLineSegments){const pos=object.geometry.attributes.position,m=object.matrixWorld.elements,arr=[];for(let i=0;i<pos.count;i++){const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i);arr.push(cameraPoint(m[0]*x+m[4]*y+m[8]*z+m[12],m[1]*x+m[5]*y+m[9]*z+m[13],m[2]*x+m[6]*y+m[10]*z+m[14]));}for(let i=0;i+1<arr.length;i+=2){let a=arr[i],b=arr[i+1];if(a[2]>-near&&b[2]>-near)continue;if(a[2]>-near||b[2]>-near){const t=(-near-a[2])/(b[2]-a[2]),v=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,-near];if(a[2]>-near)a=v;else b=v;}lines.push({p:[...project(...a),...project(...b)],color:object.material.color.getStyle(),alpha:object.material.opacity??1,overlay:object.material.depthTest===false});}}
   for(const child of object.children)visit(child,layer,hideInterior);
  };
  visit(scene);
  triangles.sort((a,b)=>a.layer-b.layer||b.depth-a.depth);
  // Grid lines sit on the ground beneath opaque furniture and architecture.
  let gridDrawn=false;const drawLines=overlay=>{for(const line of lines){if(line.overlay!==overlay)continue;ctx.globalAlpha=line.alpha;ctx.strokeStyle=line.color;ctx.lineWidth=overlay?1.2:.7;ctx.beginPath();ctx.moveTo(line.p[0],line.p[1]);ctx.lineTo(line.p[2],line.p[3]);ctx.stroke();}};
  let count=0;
  for(const face of triangles){if(!gridDrawn&&face.layer>=10){drawLines(false);gridDrawn=true;}ctx.globalAlpha=face.alpha;const p=face.p;
   if(face.image&&face.uv&&affineTexture(ctx,face.image,p,face.uv)){count++;continue;}
   ctx.fillStyle=face.color;ctx.beginPath();ctx.moveTo(p[0],p[1]);ctx.lineTo(p[2],p[3]);ctx.lineTo(p[4],p[5]);ctx.closePath();ctx.fill();if(face.alpha>=.995){ctx.strokeStyle=face.color;ctx.lineWidth=.55;ctx.lineJoin='round';ctx.stroke();}count++;
  }
  if(!gridDrawn)drawLines(false);drawLines(true);
  for(const sprite of sprites)if(sprite.image){ctx.globalAlpha=sprite.alpha;ctx.drawImage(sprite.image,sprite.x,sprite.y,sprite.w,sprite.h);}
  ctx.globalAlpha=1;this.info.render.calls=count;this.info.render.triangles=triangles.length;this.domElement.dataset.renderMs=(performance.now()-now).toFixed(1);this.domElement.dataset.triangles=String(triangles.length);
 }
 dispose(){this.cache=new WeakMap();}
}

export {clipNear};
