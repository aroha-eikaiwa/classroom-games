/** A single replaceable utterance; English is independent of the UI language.
 * Browsers often report no voices until their first utterance. Setting lang
 * still selects their English fallback without blocking on voiceschanged. */
export function createSchoolSpeech({scope=globalThis,onState=()=>{}}={}){
 const synth=()=>scope.speechSynthesis||scope.window?.speechSynthesis;
 const utterance=()=>scope.SpeechSynthesisUtterance||scope.window?.SpeechSynthesisUtterance;
 let generation=0;
 function cancel(){generation++;try{synth()?.cancel();}catch{}}
 function available(){return !!synth()&&typeof utterance()==='function';}
 function speak(text){
  cancel();if(!text)return false;if(!available()){onState('unavailable');return false;}
  try{const engine=synth(),u=new (utterance())(text),voices=engine.getVoices?.()||[],id=generation;
   const voice=voices.find(v=>/^en-(NZ|GB|AU)/i.test(v.lang))||voices.find(v=>/^en(?:-|$)/i.test(v.lang));
   if(voice)u.voice=voice;u.lang=voice?.lang||'en-GB';u.rate=.83;u.pitch=1;u.volume=.95;
   u.onend=()=>{if(id===generation)onState('ready');};u.onerror=()=>{if(id===generation)onState('error');};
   engine.resume?.();engine.speak(u);onState('speaking');return true;
  }catch{onState('error');return false;}
 }
 return {speak,cancel,available};
}

export const SCHOOL_SPEECH_PRIORITY=Object.freeze({greeting:1,navigation:2,room:3,scold:4});

/** One browser speech channel for the whole game. Lower priority speech is
 * dropped, never queued behind an old instruction. Navigation retries its
 * current cue. The app unlocks on a trusted gesture and pauses on blur/modal. */
export function createSchoolVoice({scope=globalThis,muted=false,onState=()=>{},now=()=>globalThis.performance?.now?.()??Date.now()}={}){
 let unlocked=false,paused=false,active=null,lastFinished=-Infinity;
 const speech=createSchoolSpeech({scope,onState:state=>{
  if(state==='ready'||state==='error'||state==='unavailable'){active=null;lastFinished=now();}
  onState(state);
 }});
 const available=()=>speech.available();
 const blocked=()=>!unlocked||paused||muted||scope.document?.hidden===true;
 function cancel(channel){
  if(channel&&active?.channel!==channel)return;
  active=null;lastFinished=now();speech.cancel();
 }
 function expireStalledSpeech(){
  // Some mobile speech engines omit both completion callbacks. A generous
  // length-based deadline prevents one such utterance blocking the game forever.
  // Cancel it first, so a late engine recovery cannot overlap the next cue.
  if(active&&now()>=active.deadline){cancel();onState('ready');}
 }
 function speak(text,{channel='navigation'}={}){
  expireStalledSpeech();
  if(!text||blocked()||!Object.hasOwn(SCHOOL_SPEECH_PRIORITY,channel))return false;
  const priority=SCHOOL_SPEECH_PRIORITY[channel];
  if(active&&(active.priority>priority||channel==='greeting'))return false;
  if(channel==='greeting'&&now()-lastFinished<2200)return false;
  const duration=Math.min(30000,Math.max(6000,String(text).length*110+3500));
  active={channel,priority,text,deadline:now()+duration};
  const accepted=speech.speak(String(text));if(!accepted)active=null;
  return accepted;
 }
 function setMuted(value){muted=!!value;if(muted){cancel();onState('muted');}}
 function pause(){if(!paused)cancel();paused=true;}
 function resume(){paused=false;}
 const channels=new Map();
 function channel(name){
  if(!Object.hasOwn(SCHOOL_SPEECH_PRIORITY,name))throw Error('Unknown school speech channel.');
  if(!channels.has(name))channels.set(name,{speak:text=>speak(text,{channel:name}),cancel:()=>cancel(name),available});
  return channels.get(name);
 }
 return {speak,cancel,available,channel,setMuted,pause,resume,
  unlock(){unlocked=true;},
  room:name=>speak(String(name||'').replaceAll('’',"'"),{channel:'room'}),
  get busy(){expireStalledSpeech();return !!active;},get activeChannel(){expireStalledSpeech();return active?.channel||null;},
  get greetingReady(){expireStalledSpeech();return !blocked()&&!active&&now()-lastFinished>=2200;},
  get muted(){return muted;},get unlocked(){return unlocked;},get paused(){return paused;}};
}

