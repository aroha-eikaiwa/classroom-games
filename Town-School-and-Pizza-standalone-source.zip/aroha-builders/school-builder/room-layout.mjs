import {BY_TYPE, W, H} from './core.mjs';

// Local room coordinates. Furniture, windows and wall art share one plan so
// fixtures cannot independently claim the same patch of wall.
const BOARD_ROOMS=new Set(['classroom','science','music','art','cooking']);
const overlap=(a,b)=>a.from<b.to&&b.from<a.to;
const span=(from,to)=>({from,to});
const tallWallFurniture={
 entrance:({d})=>({west:[span(.35,d-.35)],east:[span(.35,d-.35)]}),
 teachers:()=>({west:[span(.32,2.03)]}),
 science:()=>({west:[span(1.05,2.05)],east:[span(.93,1.98)]}),
 art:()=>({east:[span(.52,2.58)]}),
 cooking:()=>({west:[span(.37,.93)],east:[span(1.43,2.58)]}),
 library:()=>({west:[span(.98,3.02)],east:[span(.98,3.02)]}),
 gym:()=>({west:[span(2.65,3.39)],east:[span(2.65,3.39)]}),
 restroom:()=>({west:[span(.10,2.75)],east:[span(.10,1.26)]}),
 nurse:()=>({west:[span(1.50,2.30)]}),
};
function exteriorSpan(room,definition,school,side,from,to){
 if(!school)return true;
 const horizontal=side==='north'||side==='south';
 const outside=side==='north'?-0.02:side==='south'?definition.d+.02:side==='west'?-0.02:definition.w+.02;
 const halls=new Set(school.corridors||[]);
 // Check every grid cell touched by a window, including a small frame margin.
 for(let at=Math.floor(from);at<=Math.floor(to-1e-6);at++){
  const x=room.x+(horizontal?at+.5:outside),z=room.z+(horizontal?outside:at+.5);
  if(x>=0&&x<W&&z>=0&&z<H&&halls.has(Math.floor(z)*W+Math.floor(x)))return false;
  if(school.rooms.some(other=>{const def=BY_TYPE[other.type];return other.id!==room.id&&def&&!def.outdoor&&x>=other.x&&x<other.x+def.w&&z>=other.z&&z<other.z+def.d;}))return false;
 }
 return true;
}
export function classroomSeats(type){
 const seats=[];
 const seat=(x,z,rotation=Math.PI)=>seats.push({x,y:.19,z,rotation});
 if(type==='classroom')for(let row=0;row<3;row++)for(const x of [.45,1.17,2.50,3.22])seat(x,1.35+row*.63);
 if(type==='music')for(let row=0;row<3;row++)for(let col=0;col<5;col++)seat(1.2+col*.7,1.35+row*.72);
 if(type==='science'||type==='art'){
  const science=type==='science',dx=science?2.05:2,rowGap=science?1.60:1.55,offset=science?.57:.51;
  for(let row=0;row<2;row++)for(let col=0;col<2;col++){
   const x=(science?1.32:1.30)+col*dx,z=(science?1.15:1.20)+row*rowGap;
   for(const side of [-.35,.35])for(const dz of [-offset,offset])seat(x+side,z+dz,dz<0?0:Math.PI);
  }
 }
 return seats;
}
export function roomWallLayout(room,definition=BY_TYPE[room.type],school){
 const {w,d}=definition,windows=[],posters=[];
 if(definition.outdoor)return {windows,posters,board:null,seats:[],teacher:null};
 const blocked=tallWallFurniture[room.type]?.(definition)||{};
 // Door walls and teaching walls stay solid. Windows belong to an exterior
 // side wall and are centred in regular bays, clear of tall furniture.
 for(const side of ['west','east']){
  for(let i=0;i<Math.floor((d-.45)/1.1);i++){
   const position=.65+i*1.1,candidate=span(position-.40,position+.40);
   if((blocked[side]||[]).some(item=>overlap(candidate,span(item.from-.05,item.to+.05))))continue;
   if(!exteriorSpan(room,definition,school,side,candidate.from,candidate.to))continue;
   windows.push({side,position,width:.70,height:.40,y:.87});
  }
 }
 // The complete sliding-door envelope is x=1.12..2.54. These slots are
 // deliberately outside it; the art faces into the room.
 for(const x of w>=4?[.50,w-.55]:[.50])posters.push({side:'south',x,y:.90,z:d-.055,rotation:Math.PI,width:.68,height:.46});
 const board=BOARD_ROOMS.has(room.type)?{x:w/2,y:.85,z:.148,width:Math.min(w-1.08,2.72),height:.48}:null;
 const seats=classroomSeats(room.type);
 const teacher=board?{x:w/2+(room.type==='classroom'?.67:0),y:0,z:.50,rotation:0}:null;
 return {windows,posters,board,seats,teacher};
}
export function roomWindowKey(room,definition=BY_TYPE[room.type],school){
 return JSON.stringify(roomWallLayout(room,definition,school).windows);
}
