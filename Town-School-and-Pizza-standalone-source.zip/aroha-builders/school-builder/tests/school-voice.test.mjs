import test from 'node:test';
import assert from 'node:assert/strict';
import {createSchoolVoice} from '../school-voice.mjs';
import {createSchoolNavigationGuide} from '../navigation-guide.mjs';
import {createDemoSchool,key} from '../core.mjs';
import {createSchoolTeacherSpeech,RUNNING_REPRIMAND} from '../teacher-speech.mjs';

function browser(){
 let clock=0,cancelled=0;const calls=[];
 class Utterance{constructor(text){this.text=text;}}
 const scope={SpeechSynthesisUtterance:Utterance,document:{hidden:false},speechSynthesis:{getVoices:()=>[{lang:'ja-JP'},{lang:'en-NZ'}],cancel(){cancelled++;},resume(){},speak:u=>calls.push(u)}};
 const voice=createSchoolVoice({scope,now:()=>clock});
 return {voice,scope,calls,get cancelled(){return cancelled;},advance:seconds=>{clock+=seconds*1000;},finish(){calls.at(-1)?.onend?.();}};
}
function hallwayContext(extra={}){
 return {school:{rooms:[],corridors:[key(10,10),key(10,11),key(10,12),key(10,13)]},mode:'walk',player:{x:10.5,z:11.5,angle:Math.PI,running:false},teachers:[{id:'teacher-one',x:10.5,z:10.5,angle:0}],paused:false,runLocked:false,scoldTime:0,...extra};
}

test('one shared voice enforces scold > selected room > navigation > greeting without a queue',()=>{
 const b=browser(),v=b.voice;assert.equal(v.room('Music room'),false,'Must wait for a user gesture');v.unlock();
 assert.equal(v.channel('greeting').speak('Hello!'),true);
 assert.equal(v.channel('navigation').speak('Turn left.'),true);
 assert.equal(v.channel('greeting').speak('Hi there!'),false);
 assert.equal(v.room('Music room'),true);
 assert.equal(v.channel('navigation').speak('Go straight.'),false);
 assert.equal(v.channel('scold').speak(RUNNING_REPRIMAND),true);
 assert.equal(v.room('Library'),false);
 assert.deepEqual(b.calls.map(u=>u.text),['Hello!','Turn left.','Music room',RUNNING_REPRIMAND]);
 assert.ok(b.calls.every(u=>u.lang==='en-NZ'));
 const before=b.cancelled;v.channel('navigation').cancel();assert.equal(b.cancelled,before,'Navigation exit must not cancel a teacher reprimand');
 b.finish();b.advance(1);assert.equal(v.channel('greeting').speak('Hello!'),false,'Leave space after important speech');
 b.advance(2);assert.equal(v.channel('greeting').speak('Hello!'),true);
});

test('mute, modal/blur pause and visibility immediately suppress all speech channels',()=>{
 const b=browser(),v=b.voice;v.unlock();v.room('Teachers’ office');assert.equal(b.calls[0].text,"Teachers' office");
 v.pause();assert.equal(v.busy,false);assert.equal(v.room('Library'),false);v.resume();assert.equal(v.room('Library'),true);
 v.setMuted(true);assert.equal(v.busy,false);assert.equal(v.channel('scold').speak(RUNNING_REPRIMAND),false);
 v.setMuted(false);b.scope.document.hidden=true;assert.equal(v.room('Music room'),false);
 b.scope.document.hidden=false;assert.equal(v.room('Music room'),true);v.cancel();assert.equal(v.busy,false);
});

test('navigation retries only its latest cue after a teacher reprimand and never speaks in controller mode',()=>{
 const b=browser();b.voice.unlock();const school=createDemoSchool();
 const guide=createSchoolNavigationGuide({speech:b.voice.channel('navigation')});
 const context={school,mode:'walk',localDirections:true,paired:false,player:{x:9.5,z:22.5,angle:Math.PI},targetId:'demo-music'};
 guide.start(context);b.voice.channel('scold').speak(RUNNING_REPRIMAND);
 guide.update({...context,player:{x:9.5,z:21.1,angle:Math.PI}},2);
 assert.equal(b.calls.at(-1).text,RUNNING_REPRIMAND);b.finish();
 guide.update({...context,player:{x:9.5,z:21.1,angle:Math.PI}},2);assert.equal(b.calls.at(-1).text,'Turn right.');
 const length=b.calls.length;guide.update({...context,mode:'controller',paired:true},1);assert.equal(b.calls.length,length);
});

test('hallway meetings greet once, with global and teacher cooldowns and no continued-proximity spam',()=>{
 const b=browser();b.voice.unlock();const teacher=createSchoolTeacherSpeech({voice:b.voice}),c=hallwayContext();
 assert.equal(teacher.update(c,.1)?.type,'greeting');b.finish();
 for(let i=0;i<90;i++){b.advance(1);teacher.update(c,1);}
 assert.equal(b.calls.length,1,'Standing near a teacher must never repeat a greeting');
 teacher.update({...c,player:{...c.player,z:13.5}},1);
 assert.equal(teacher.update(c,1)?.type,'greeting','A later separate encounter can greet again');b.finish();
 teacher.update({...c,player:{...c.player,z:13.5}},1);b.advance(3);assert.equal(teacher.update(c,1),null,'Per-teacher cooldown applies to a quick return');
});

test('teachers do not greet through walls, behind the player, while running, paused, or during navigation',()=>{
 const b=browser();b.voice.unlock();const c=hallwayContext(),teacher=createSchoolTeacherSpeech({voice:b.voice});
 assert.equal(teacher.update({...c,player:{...c.player,angle:0}},.1),null);
 const throughWall=hallwayContext({school:{rooms:[{id:'wall-room',type:'classroom',x:10,z:11}],corridors:[key(10,10)]}});
 assert.equal(teacher.update(throughWall,.1),null);
 teacher.reset();assert.equal(teacher.update({...c,player:{...c.player,running:true}},.1),null);
 assert.equal(teacher.update({...c,paused:true},.1),null);teacher.reset();
 b.voice.channel('navigation').speak('Go straight.');assert.equal(teacher.update(c,.1),null);
 for(let i=0;i<6;i++)teacher.update(c,1);b.finish();b.advance(3);
 assert.equal(teacher.update(c,1),null,'An expired encounter must not greet after a long instruction');
 assert.equal(b.calls.filter(u=>u.text==='Hello!').length,0);
});

test('paired controller teachers greet and reprimand once; host/build remain silent',()=>{
 const b=browser();b.voice.unlock();const teacher=createSchoolTeacherSpeech({voice:b.voice}),c=hallwayContext({mode:'controller'});
 assert.equal(teacher.update(c,.1)?.type,'greeting');
 assert.equal(teacher.update({...c,caught:true,runLocked:true,scoldTime:2},.1)?.type,'scold');
 for(let i=0;i<120;i++)teacher.update({...c,runLocked:true,scoldTime:1},1/60);
 assert.equal(b.calls.filter(u=>u.text===RUNNING_REPRIMAND).length,1);
 const count=b.calls.length;
 teacher.update({...c,mode:'host',caught:true},1);teacher.update({...c,mode:'build',caught:true},1);
 assert.equal(b.calls.length,count);
});

test('resuming an existing running restriction is silent; a fresh catch still reprimands',()=>{
 const b=browser();b.voice.unlock();const teacher=createSchoolTeacherSpeech({voice:b.voice}),c=hallwayContext({runLocked:true});
 assert.equal(teacher.update(c,.1),null);assert.equal(b.calls.length,0);
 for(let i=0;i<5;i++)teacher.update(c,1);assert.equal(b.calls.length,0);
 teacher.update({...c,mode:'build'},.1);
 assert.equal(teacher.update(c,.1),null);assert.equal(b.calls.length,0,'Returning from build must preserve the restriction without scolding again');
 teacher.update({...c,runLocked:false,teachers:[]},1);
 assert.equal(teacher.update(c,1)?.type,'scold','A later authoritative running catch must speak');
 b.finish();teacher.reset();
 assert.equal(teacher.update({...c,caught:true},.1)?.type,'scold','A real first-frame catch must still speak');
 assert.equal(b.calls.filter(u=>u.text===RUNNING_REPRIMAND).length,2);
});

test('a browser that omits speech completion cannot hold a priority channel forever',()=>{
 const b=browser(),v=b.voice;v.unlock();v.channel('scold').speak(RUNNING_REPRIMAND);
 const old=b.calls.at(-1);b.advance(5);assert.equal(v.room('Library'),false,'Do not cut off a normal short reprimand early');
 const before=b.cancelled;b.advance(4);assert.equal(v.room('Library'),true);
 assert.ok(b.cancelled>before,'Flush a stalled utterance before speaking again');
 old.onend();assert.equal(v.activeChannel,'room','Late callbacks from the expired utterance must not clear new speech');
 b.advance(31);assert.equal(v.busy,false);assert.equal(v.greetingReady,false,'Retain the quiet gap after timeout recovery');
 b.advance(3);assert.equal(v.greetingReady,true);
});
