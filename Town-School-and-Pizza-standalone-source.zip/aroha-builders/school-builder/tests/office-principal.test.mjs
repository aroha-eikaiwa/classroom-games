import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {SchoolScene} from '../scene.mjs';
import {PRINCIPAL_PLACEMENT,syncOfficePrincipals,clearOfficePrincipals} from '../office-principal.mjs';

function room(type='principal',x=0,z=0){const value=new THREE.Group();value.userData.schoolType=type;value.position.set(x,0,z);return value;}
function setup(){
 const office=room('principal',4,7),rooms=new Map([['office',office],['class',room('classroom')]]),principals=new Map(),created=[],disposed=[];
 const create=options=>{created.push(options);const person=new THREE.Group();person.userData.staticCharacter=true;return person;};
 const dispose=person=>{person.userData.characterDisposed=true;disposed.push(person);};
 const sync=()=>syncOfficePrincipals(rooms,principals,create,dispose);
 return{office,rooms,principals,created,disposed,sync,dispose};
}

test('the office always has one fixed static adult, without needing a Directions seed',()=>{
 const h=setup();assert.equal(h.sync(),1);const principal=h.principals.get('office');
 assert.deepEqual(h.created,[{teacher:true,variant:0}]);assert.equal(principal.userData.staticCharacter,true);
 assert.equal(principal.parent,h.office);assert.equal(principal.name,'Principal');assert.equal(principal.visible,true);
 const p=PRINCIPAL_PLACEMENT;
 assert.deepEqual(principal.position.toArray(),[p.x,p.y,p.z]);
 for(let i=0;i<20;i++)h.sync();
 assert.equal(h.created.length,1);assert.equal(h.principals.get('office'),principal);
});

test('the principal follows office moves and transfers safely to rebuilt room shells',()=>{
 const h=setup();h.sync();const principal=h.principals.get('office');
 h.office.position.set(12,0,18);h.sync();h.office.updateMatrixWorld(true);
 assert.deepEqual(principal.getWorldPosition(new THREE.Vector3()).toArray(),[12.95,.055,18.7]);
 principal.removeFromParent();const rebuilt=room('principal',12,18);h.rooms.set('office',rebuilt);h.sync();
 assert.equal(principal.parent,rebuilt);assert.equal(h.created.length,1);assert.equal(h.disposed.length,0);
 h.rooms.delete('office');assert.equal(h.sync(),0);assert.equal(h.disposed[0],principal);
 assert.equal(principal.parent,null);assert.equal(principal.userData.characterDisposed,true);
});

test('build, guide and third-person view changes keep the principal visible',()=>{
 const h=setup();h.sync();const principal=h.principals.get('office');
 const s=Object.create(SchoolScene.prototype);
 Object.assign(s,{mode:'build',yaw:0,buildYaw:0,walkYaw:0,scene:{userData:{}},camera:{updateProjectionMatrix(){}},grid:{},ghost:{},corridorPreview:{},labelsRoot:{},classroomGroups:new Map(),playerMesh:{},targetRoot:{},gridEnabled:true,_ensureCameraState(){},_cutaway(){}});
 for(const mode of ['walk','build','host','walk','build']){s.setMode(mode);assert.equal(principal.visible,true);assert.equal(principal.parent,h.office);}
 clearOfficePrincipals(h.principals,h.dispose);assert.equal(h.principals.size,0);assert.equal(principal.parent,null);
});
