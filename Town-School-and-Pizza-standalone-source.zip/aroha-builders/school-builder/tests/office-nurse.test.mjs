import test from 'node:test';
import assert from 'node:assert/strict';
import {createStaticCharacter} from '../characters.mjs';
import * as THREE from '../vendor/three.module.js';
import {SchoolScene} from '../scene.mjs';
import {NURSE_PLACEMENT,syncOfficeNurses,clearOfficeNurses} from '../office-nurse.mjs';

function room(type='nurse',x=0,z=0){const value=new THREE.Group();value.userData.schoolType=type;value.position.set(x,0,z);return value;}
function setup(){
 const office=room('nurse',4,7),rooms=new Map([['clinic',office],['class',room('classroom')]]),nurses=new Map(),created=[],disposed=[];
 const create=options=>{created.push(options);const person=new THREE.Group();person.userData.staticCharacter=true;return person;};
 const dispose=person=>{person.userData.characterDisposed=true;disposed.push(person);};
 const sync=()=>syncOfficeNurses(rooms,nurses,create,dispose);
 return{office,rooms,nurses,created,disposed,sync,dispose};
}

test('the clinic always has one static adult in nurse attire without a classroom session',()=>{
 const h=setup();assert.equal(h.sync(),1);const nurse=h.nurses.get('clinic');
 assert.deepEqual(h.created,[{teacher:true,variant:1,uniform:'nurse'}]);assert.equal(nurse.userData.staticCharacter,true);
 assert.equal(nurse.parent,h.office);assert.equal(nurse.name,'School nurse');assert.equal(nurse.visible,true);
 const p=NURSE_PLACEMENT;assert.deepEqual(nurse.position.toArray(),[p.x,p.y,p.z]);
 for(let i=0;i<20;i++)h.sync();assert.equal(h.created.length,1);assert.equal(h.nurses.get('clinic'),nurse);
});

test('the nurse follows clinic moves and survives room-shell rebuilds without duplicates',()=>{
 const h=setup();h.sync();const nurse=h.nurses.get('clinic');
 h.office.position.set(12,0,18);h.sync();h.office.updateMatrixWorld(true);
 assert.deepEqual(nurse.getWorldPosition(new THREE.Vector3()).toArray(),[13.52,.055,18.86]);
 nurse.removeFromParent();const rebuilt=room('nurse',12,18);h.rooms.set('clinic',rebuilt);h.sync();
 assert.equal(nurse.parent,rebuilt);assert.equal(h.created.length,1);assert.equal(h.disposed.length,0);
 h.rooms.delete('clinic');assert.equal(h.sync(),0);assert.equal(h.disposed[0],nurse);
 assert.equal(nurse.parent,null);assert.equal(nurse.userData.characterDisposed,true);
});

test('the procedural adult fits between the clinic desk and first bed',()=>{
 const p=NURSE_PLACEMENT,nurse=createStaticCharacter({teacher:true,variant:1,uniform:'nurse'});
 nurse.position.set(p.x,p.y,p.z);nurse.rotation.y=p.rotation;
 const bounds=new THREE.Box3().setFromObject(nurse,true);
 assert.ok(bounds.min.x>1.17 && bounds.max.x<1.795);
 assert.ok(bounds.min.z>.50 && bounds.max.z<1.17);
});

test('build, guide and third-person views keep the nurse visible and cleanup removes it',()=>{
 const h=setup();h.sync();const nurse=h.nurses.get('clinic');
 const scene=Object.create(SchoolScene.prototype);
 Object.assign(scene,{mode:'build',yaw:0,buildYaw:0,walkYaw:0,scene:{userData:{}},camera:{updateProjectionMatrix(){}},grid:{},ghost:{},corridorPreview:{},labelsRoot:{},classroomGroups:new Map(),playerMesh:{},targetRoot:{},gridEnabled:true,_ensureCameraState(){},_cutaway(){}});
 for(const mode of ['walk','build','host','walk','build']){scene.setMode(mode);assert.equal(nurse.visible,true);assert.equal(nurse.parent,h.office);}
 clearOfficeNurses(h.nurses,h.dispose);assert.equal(h.nurses.size,0);assert.equal(nurse.parent,null);
});
