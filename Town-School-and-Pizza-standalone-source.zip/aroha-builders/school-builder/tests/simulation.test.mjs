import test from 'node:test';
import assert from 'node:assert/strict';
import {SchoolWalk,joystickAxes} from '../simulation.mjs';
import {W,createSchool,createDemoSchool,addRoom,drawCorridor,roomDoor,entranceStart,walkable,validateSchool} from '../core.mjs';

function straightSchool(){
  const s=createSchool();addRoom(s,'entrance',10,20);
  drawCorridor(s,{x:11,z:8},{x:11,z:19});
  drawCorridor(s,{x:11,z:8},{x:22,z:8});
  return s;
}
function teacher(x,z,angle=0){return {id:'test-teacher',x,z,angle,speed:0,scolding:false,node:Math.floor(z)*W+Math.floor(x),next:null,previous:null,pause:999};}
function position(w,x,z,angle=Math.PI){Object.assign(w.player,{x,z,angle,speed:0,running:false});}
function tick(w,n,input={},yaw=0,follow=true){let events;for(let i=0;i<n;i++)events=w.update(.05,input,yaw,follow);return events;}

test('Shift runs in every camera-relative direction while run restrictions still apply',()=>{
  const school=straightSchool();const w=new SchoolWalk(school);w.teachers=[];
  for(const input of [{up:true},{down:true},{left:true},{right:true},{up:true,right:true}]){
    position(w,11.5,21.5);w.update(.05,input,0);assert.ok(Math.abs(w.player.speed-.82)<1e-8);
    position(w,11.5,21.5);w.update(.05,{...input,run:true},0);assert.ok(Math.abs(w.player.speed-1.85)<1e-8);assert.equal(w.player.running,true);
    position(w,11.5,21.5);w.runLocked=true;w.update(.05,{...input,run:true},0);assert.ok(w.player.speed<=.82+1e-8);assert.equal(w.player.running,false);w.runLocked=false;
  }
});

test('a teacher looking toward a visible runner scolds and locks running',()=>{
  const w=new SchoolWalk(straightSchool());position(w,11.5,13.5);w.teachers=[teacher(11.5,15.5,Math.PI)];
  const event=w.update(.05,{up:true,run:true},0,true);
  assert.equal(event.caught,true);assert.equal(w.runLocked,true);assert.equal(w.player.running,false);assert.equal(w.teachers[0].scolding,true);assert.ok(w.scoldTime>0);
  const stopped={x:w.player.x,z:w.player.z};tick(w,10,{up:true,run:true});assert.deepEqual({x:w.player.x,z:w.player.z},stopped);
});

test('a runner outside a teacher’s view is not caught unless immediately adjacent',()=>{
  const w=new SchoolWalk(straightSchool());position(w,11.5,13.5);w.teachers=[teacher(11.5,15.5,0)];
  assert.equal(w.update(.05,{up:true,run:true},0,true).caught,false);
  assert.equal(w.runLocked,false);
  position(w,11.5,15);assert.equal(w.update(.05,{up:true,run:true},0,true).caught,true);
});

test('teachers cannot see a runner through the corner between two hallways',()=>{
  const w=new SchoolWalk(straightSchool());position(w,13,8.5,Math.PI/2);
  const t=teacher(11.5,10,Math.atan2(1.5,-1.5));w.teachers=[t];
  const event=w.update(.05,{up:true,run:true},0,true);
  assert.equal(event.caught,false);assert.equal(w.runLocked,false);assert.equal(w.player.running,true);
});

test('running punishment lasts after scolding and cannot be removed by choosing or advancing a target',()=>{
  const s=createDemoSchool(),w=new SchoolWalk(s);w.runLocked=true;w.scoldTime=.1;
  tick(w,10);assert.equal(w.scoldTime<=0,true);assert.equal(w.runLocked,true);
  const room=s.rooms.find(r=>r.type==='library');w.choose(room.id);assert.equal(w.runLocked,true);
  const before=w.targetId;assert.equal(w.next(),false);assert.equal(w.targetId,before);assert.equal(w.runLocked,true);
  const d=roomDoor(s.rooms.find(r=>r.type==='classroom'));position(w,d.outX,d.outZ,Math.PI/2);w.teachers=[];
  w.update(.05,{up:true,run:true},0,true);assert.equal(w.player.running,false);assert.ok(w.player.speed<=.82+1e-8);
});

test('arriving requires stopping at the actual target; arrival clears the punishment once',()=>{
  const s=createDemoSchool(),w=new SchoolWalk(s);w.teachers=[];w.runLocked=true;
  const target=s.rooms.find(r=>r.type==='library'),wrong=s.rooms.find(r=>r.type==='music');w.choose(target.id);
  let d=roomDoor(wrong);position(w,d.outX,d.outZ);tick(w,12);assert.equal(w.arrived,false);assert.equal(w.runLocked,true);
  d=roomDoor(target);position(w,d.outX,d.outZ,Math.PI/2);
  w.update(.05,{up:true},0,true);assert.equal(w.arrivalHold,0);assert.equal(w.arrived,false);
  position(w,d.outX,d.outZ);let arrivalEvents=0;for(let i=0;i<12;i++)arrivalEvents+=w.update(.05,{},0,true).arrived?1:0;
  assert.equal(arrivalEvents,1);assert.equal(w.arrived,true);assert.equal(w.runLocked,false);
  const before=w.targetId;assert.equal(w.next(),true);assert.notEqual(w.targetId,before);assert.equal(w.arrived,false);
});

test('teachers patrol connected halls without crossing walls or leaving the walkable area',()=>{
  const s=createDemoSchool(),w=new SchoolWalk(s);assert.equal(validateSchool(s).ready,true);assert.equal(w.teachers.length,2);
  const starts=w.teachers.map(t=>({x:t.x,z:t.z}));
  for(let i=0;i<500;i++){w.update(.05,{},0,true);for(const t of w.teachers)assert.equal(walkable(s,t.x,t.z,.12),true,`teacher at ${t.x},${t.z}`);}
  assert.ok(w.teachers.some((t,i)=>Math.hypot(t.x-starts[i].x,t.z-starts[i].z)>.5));
});

test('reset returns to the entrance and the app can preserve the existing target and punishment',()=>{
  const s=createDemoSchool(),w=new SchoolWalk(s),target=w.targetId;w.runLocked=true;const lock=w.runLocked;
  w.reset(s);w.choose(target);w.runLocked=lock;
  const spawn=entranceStart(s);assert.equal(w.player.x,spawn.x);assert.equal(w.player.z,spawn.z);assert.equal(w.targetId,target);assert.equal(w.runLocked,true);
});

test('invalid frame times do not move the player or corrupt simulation state',()=>{
  const w=new SchoolWalk(straightSchool());w.teachers=[];const before={x:w.player.x,z:w.player.z};
  for(const dt of [NaN,Infinity,-1])w.update(dt,{up:true,run:true},0,true);
  assert.deepEqual({x:w.player.x,z:w.player.z},before);assert.equal(Number.isFinite(w.player.speed),true);
});

test('each new movement gesture starts camera-relative regardless of body facing',()=>{
  for(const follow of [true,false])for(const angle of [0,Math.PI/2,Math.PI]){
    const w=new SchoolWalk(straightSchool());w.teachers=[];
    position(w,11.5,21.5,angle);w.update(.05,{right:true},0,follow);
    assert.ok(w.player.x>11.5);assert.equal(w.player.z,21.5);
    w.update(0,{},0,follow);position(w,11.5,21.5,angle);w.update(.05,{up:true},Math.PI/2,follow);
    assert.ok(w.player.x<11.5);assert.equal(w.player.z,21.5);
    w.update(0,{},0,follow);position(w,11.5,21.5,angle);w.update(.05,{up:true,right:true},0,follow);
    assert.ok(Math.abs(w.player.speed-.82)<1e-8);assert.ok(w.player.x>11.5&&w.player.z<21.5);
  }
});

test('character turns toward travel without curving a held movement vector',()=>{
  const w=new SchoolWalk(straightSchool());w.teachers=[];position(w,11.5,21.5,Math.PI);
  tick(w,5,{right:true},0,true);
  assert.equal(w.player.z,21.5);assert.ok(Math.abs(w.player.angle-Math.PI/2)<1e-8);
  const z=w.player.z;tick(w,5,{left:true},0,true);assert.equal(w.player.z,z);assert.ok(Math.abs(w.player.angle+Math.PI/2)<.15);
});

test('analog joystick supports arbitrary angles, proportional speed, dead zone and bounded diagonals',()=>{
  assert.deepEqual(joystickAxes(2,1,40),{x:0,y:0});assert.deepEqual(joystickAxes(NaN,1,40),{x:0,y:0});
  const axes=joystickAxes(18,-30,40),w=new SchoolWalk(straightSchool());w.teachers=[];position(w,11.5,21.5);
  const start={...w.player};w.update(.05,{moveX:axes.x,moveY:axes.y},0);
  assert.ok(w.player.x>start.x&&w.player.z<start.z);assert.ok(Math.abs((w.player.x-start.x)/(start.z-w.player.z)-.6)<1e-8);
  assert.ok(w.player.speed>0&&w.player.speed<.82);
  const outer=joystickAxes(100,-100,40);assert.ok(Math.abs(Math.hypot(outer.x,outer.y)-1)<1e-8);
  position(w,11.5,21.5);w.update(.05,{moveX:outer.x,moveY:outer.y},0);assert.ok(Math.abs(w.player.speed-.82)<1e-8);
});

test('a child passes a stopped teacher in a one-cell corridor while the teacher yields',()=>{
  const w=new SchoolWalk(straightSchool());position(w,11.5,18.5);
  w.teachers=[teacher(11.5,16.5)];
  for(let i=0;i<100;i++){
    w.update(.05,{up:true},0,true);
    const t=w.teachers[0];
    assert.ok(Math.hypot(w.player.x-t.x,w.player.z-t.z)>=.225-1e-8);
    assert.equal(walkable(w.school,t.x,t.z,.12),true);
  }
  assert.ok(w.player.z<16);
  assert.ok(Math.abs(w.teachers[0].x-11.5)>.23);
});

test('a child passes a stopped teacher at the entrance door without clipping its jamb',()=>{
  const w=new SchoolWalk(straightSchool());position(w,11.5,21.3);
  w.teachers=[teacher(11.5,20)];
  for(let i=0;i<100;i++){
    w.update(.05,{up:true},0,true);
    const t=w.teachers[0];
    assert.ok(Math.hypot(w.player.x-t.x,w.player.z-t.z)>=.225-1e-8);
    assert.equal(walkable(w.school,t.x,t.z,.12),true);
  }
  assert.ok(w.player.z<19);
});

test('oncoming teachers can pass one another without overlapping',()=>{
  const w=new SchoolWalk(straightSchool());position(w,11.5,21.5);
  const a=teacher(11.5,17.5,Math.PI),b=teacher(11.5,14.5,0);
  a.id='a';b.id='b';a.pause=b.pause=0;
  a.next=16*W+11;b.next=15*W+11;
  a.previous=18*W+11;b.previous=13*W+11;
  w.teachers=[a,b];
  for(let i=0;i<110;i++){
    w.update(.05,{},0,true);
    assert.ok(Math.hypot(a.x-b.x,a.z-b.z)>=.24-1e-8);
  }
  assert.ok(a.z<b.z);
});

test('locked following camera does not curve held strafing or diagonal movement',()=>{
 for(const input of [{right:true},{moveX:.6,moveY:.8}]){
  const w=new SchoolWalk(straightSchool());w.teachers=[];position(w,11.5,21.5,Math.PI);
  const start={...w.player};
  for(let i=0;i<12;i++)w.update(.05,input,w.player.angle+Math.PI,true);
  const dx=w.player.x-start.x,dz=w.player.z-start.z;
  if(input.right){assert.ok(dx>.45);assert.ok(Math.abs(dz)<1e-8);}
  else{assert.ok(dx>.2&&dz<-.3);assert.ok(Math.abs(dx/-dz-.75)<1e-8);}
 }
});

test('locked movement relatches after neutral or a camera mode change',()=>{
 const w=new SchoolWalk(straightSchool());w.teachers=[];position(w,11.5,21.5,Math.PI);
 w.update(.05,{up:true},0,true);const first={...w.player};
 w.update(.05,{up:true},Math.PI/2,true);assert.equal(w.player.x,first.x);
 w.update(.05,{},Math.PI/2,true);const second={...w.player};
 w.update(.05,{up:true},Math.PI/2,true);assert.ok(w.player.x<second.x);assert.ok(Math.abs(w.player.z-second.z)<1e-8);
 const third={...w.player};w.update(.05,{up:true},0,false);assert.equal(w.player.x,third.x);assert.ok(w.player.z<third.z);
});
