import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {ROOMS,BY_TYPE,PLAYER_RADIUS,TEACHER_RADIUS,PATROL_OFFSET,roomDoor,key,walkable,movePlayer,lineOfSight,navigationGraph,createDemoSchool} from '../core.mjs';
import {roomFurnitureObstacles,furnitureCollision} from '../room-obstacles.mjs';
import {createRoomModel,disposeModel} from '../models.mjs';
import {planSchoolRoute} from '../navigation-guide.mjs';
import {SchoolWalk} from '../simulation.mjs';

const indoor=ROOMS.filter(t=>!t.outdoor);
function fixture(type){
 const room={id:type,type,x:5,z:5},door=roomDoor(room),school={version:1,rooms:[room],corridors:[key(Math.floor(door.outX),Math.floor(door.outZ))],decorations:[]};
 return {school,room,door,world:(x,z)=>({x:room.x+x,z:room.z+z})};
}
function freeSamples(school,room){
 const {w,d}=BY_TYPE[room.type],points=new Map();
 for(let iz=2;iz<d*10;iz++)for(let ix=2;ix<w*10;ix++){
  const p={x:room.x+ix/10,z:room.z+iz/10};if(walkable(school,p.x,p.z))points.set(`${ix},${iz}`,{...p,ix,iz});
 }
 return points;
}
const near=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z)<1e-7;

test('major indoor collider footprints sit on the actual rendered furniture',()=>{
 for(const definition of indoor){
  const model=createRoomModel({id:definition.type,type:definition.type,x:0,z:0},definition),furniture=model.getObjectByName('furniture');model.updateMatrixWorld(true);
  assert.equal(model.userData.furnitureObstacles,roomFurnitureObstacles(definition.type));
  for(const obstacle of model.userData.furnitureObstacles){
   const c=Math.cos(obstacle.rotation||0),s=Math.sin(obstacle.rotation||0);
   // Closed restroom cubicles deliberately include the inaccessible space
   // behind their visible, permanently closed doors.
   const points=obstacle.id.startsWith('closed-cubicle')?[[0,.50]]:obstacle.shape==='circle'?[[0,0],[obstacle.r*.8,0],[-obstacle.r*.8,0],[0,obstacle.r*.8],[0,-obstacle.r*.8]]:[[0,0],[-obstacle.w*.4,-obstacle.d*.4],[-obstacle.w*.4,obstacle.d*.4],[obstacle.w*.4,-obstacle.d*.4],[obstacle.w*.4,obstacle.d*.4]];
   for(const [x,z]of points){
    const ray=new THREE.Raycaster(new THREE.Vector3(obstacle.x+x*c+z*s,2,obstacle.z-x*s+z*c),new THREE.Vector3(0,-1,0),0,2);
    assert.ok(ray.intersectObject(furniture,true).length,`${definition.type}/${obstacle.id} footprint must match visible furniture`);
   }
  }
  disposeModel(model);
 }
});

test('rounded avatar collision respects the piano rotation and rectangular corners',()=>{
 const piano=roomFurnitureObstacles('music').find(o=>o.id==='piano'),c=Math.cos(piano.rotation),s=Math.sin(piano.rotation);
 const point=(x,z)=>({x:piano.x+x*c+z*s,z:piano.z-x*s+z*c});
 const inside=point(piano.w/2+PLAYER_RADIUS-.002,0),outside=point(piano.w/2+PLAYER_RADIUS+.002,0);
 assert.equal(furnitureCollision(piano,inside.x,inside.z,PLAYER_RADIUS),true);assert.equal(furnitureCollision(piano,outside.x,outside.z,PLAYER_RADIUS),false);
 const corner=point(piano.w/2+PLAYER_RADIUS*.8,piano.d/2+PLAYER_RADIUS*.8);
 assert.equal(furnitureCollision(piano,corner.x,corner.z,PLAYER_RADIUS),false,'a round character can pass outside a rectangular corner');
});

test('running and large catch-up movements cannot pass through desks, piano or beds',()=>{
 for(const [type,id,dx,dz,offset]of [['classroom','student-desk-2-2',0,-1,.5],['music','piano',-1,0,.8],['nurse','bed-0',0,1,.7],['cooking','cooking-counter-0-0',0,1,.7]]){
  const {school,world}=fixture(type),o=roomFurnitureObstacles(type).find(o=>o.id===id);
  const start=world(o.x-dx*offset,o.z-dz*offset);assert.ok(walkable(school,start.x,start.z),type);
  const end=movePlayer(school,start,dx*1.5,dz*1.5);
  assert.ok(walkable(school,end.x,end.z),type);assert.ok((end.x-start.x)*dx+(end.z-start.z)*dz<.6,`${type} blocks passage through ${id}`);
 }
});

test('each doorway connects to every usable room aisle and its front area at full player radius',()=>{
 for(const definition of indoor){
  const {school,room,door,world}=fixture(definition.type),points=freeSamples(school,room),entrance=definition.type==='entrance';
  const rootId=`15,${entrance?2:definition.d*10-2}`,root=points.get(rootId);assert.ok(root,`${definition.type} inside doorway`);
  const outside={x:door.outX,z:door.outZ};assert.ok(near(movePlayer(school,outside,root.x-outside.x,root.z-outside.z),root),`${definition.type} enter`);
  const reached=new Set([rootId]),queue=[root];
  for(let i=0;i<queue.length;i++)for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){
   const from=queue[i],id=`${from.ix+dx},${from.iz+dz}`,to=points.get(id);if(!to||reached.has(id))continue;
   if(lineOfSight(school,from,to,PLAYER_RADIUS)&&near(movePlayer(school,from,to.x-from.x,to.z-from.z),to)){reached.add(id);queue.push(to);}
  }
  assert.equal(reached.size,points.size,`${definition.type}: every sampled open aisle must connect to its door`);
  assert.ok(queue.some(p=>p.z<room.z+1),`${definition.type} front teaching/work area is reachable`);
  assert.ok(near(movePlayer(school,root,outside.x-root.x,outside.z-root.z),outside),`${definition.type} exit`);
  // The classroom door is off centre: turn right after entry to reach the
  // central aisle, instead of assuming the path straight ahead is empty.
  if(definition.type==='classroom'){
   let p=world(1.5,2.8);for(const next of [world(1.85,2.8),world(1.85,.83)]){p=movePlayer(school,p,next.x-p.x,next.z-p.z);assert.ok(near(p,next));}
  }
 }
});

test('a child far inside every wrong room can follow the actual guided route back out',()=>{
 const school=createDemoSchool();
 for(const room of school.rooms.filter(r=>!BY_TYPE[r.type].outdoor)){
  const door=roomDoor(room),samples=[...freeSamples(school,room).values()];samples.sort((a,b)=>Math.hypot(b.x-door.x,b.z-door.z)-Math.hypot(a.x-door.x,a.z-door.z));
  const start=samples[0],target=school.rooms.find(r=>r.type!=='entrance'&&r.id!==room.id),route=planSchoolRoute(school,start,target.id);assert.ok(route,room.type);
  let current=start;for(const point of route.points){assert.ok(lineOfSight(school,current,point,PLAYER_RADIUS),`${room.type} radius clearance`);current=movePlayer(school,current,point.x-current.x,point.z-current.z);assert.ok(near(current,point),`${room.type} route can actually be walked`);}
  assert.ok(near(current,route.target),room.type);
 }
});

test('entrance patrol nodes and every edge retain furniture clearance including the patrol offset',()=>{
 const school=createDemoSchool(),graph=navigationGraph(school),entrance=school.rooms.find(r=>r.type==='entrance'),clearance=TEACHER_RADIUS+PATROL_OFFSET;
 assert.equal(graph.has(key(entrance.x,entrance.z+1)),false,'locker cell is not a patrol goal');
 assert.equal(graph.has(key(entrance.x+2,entrance.z+1)),false,'bench cell is not a patrol goal');
 for(const node of graph.values())for(const id of node.neighbors){const target=graph.get(id);assert.ok(lineOfSight(school,node,target,clearance));}
 // Exercise the real steering (including corner changes), not only graph data.
 const walk=new SchoolWalk(school);walk.player={x:40,z:30,angle:0};
 const ids=[...graph].filter(([,p])=>p.x>=entrance.x&&p.x<entrance.x+4&&p.z>=entrance.z&&p.z<entrance.z+3).map(([id])=>id);
 for(const id of ids)for(const next of graph.get(id).neighbors){
  const start=graph.get(id),teacher={id:'test',x:start.x,z:start.z,angle:0,speed:0,node:id,next,previous:null,pause:0};walk.teachers=[teacher];
  for(let i=0;i<250&&teacher.node!==next;i++)walk.moveTeacher(teacher,.05);
  assert.equal(teacher.node,next,`patrol completes entrance edge ${id} -> ${next}`);assert.ok(walkable(school,teacher.x,teacher.z,TEACHER_RADIUS));
 }
});
