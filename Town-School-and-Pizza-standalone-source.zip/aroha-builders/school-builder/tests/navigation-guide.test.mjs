import test from 'node:test';
import assert from 'node:assert/strict';
import {createDemoSchool,entranceStart,roomDoor,lineOfSight,key} from '../core.mjs';
import {planSchoolRoute,SpokenSchoolGuide,createSchoolSpeech,createSchoolNavigationGuide} from '../navigation-guide.mjs';

const pose=(x,z,angle=Math.PI)=>({x,z,angle,speed:0});
function fakeBrowser(voices=[{lang:'ja-JP'},{lang:'en-NZ'}]){
 const calls=[],events=[];let cancelled=0;
 class Utterance{constructor(text){this.text=text;}}
 const scope={SpeechSynthesisUtterance:Utterance,speechSynthesis:{getVoices:()=>voices,cancel:()=>{cancelled++;events.push('cancel');},resume(){},speak:u=>{calls.push(u);events.push(u.text);}}};
 return {scope,calls,events,get cancelled(){return cancelled;}};
}
function context(school,extra={}){return {school,player:{...entranceStart(school),angle:Math.PI},targetId:'demo-music',arrived:false,mode:'walk',localDirections:true,paired:false,paused:false,...extra};}

test('each demo destination has a route using real corridor connections and its doorway',()=>{
 const school=createDemoSchool(),start={...entranceStart(school),angle:Math.PI};
 for(const room of school.rooms.filter(r=>r.type!=='entrance')){
  const route=planSchoolRoute(school,start,room.id),door=roomDoor(room);assert.ok(route,room.type);
  assert.deepEqual(route.target,{x:door.outX,z:door.outZ});assert.equal(route.points.at(-1).x,door.outX);assert.equal(route.points.at(-1).z,door.outZ);
  for(let i=1;i<route.points.length;i++)assert.ok(lineOfSight(school,route.points[i-1],route.points[i]),`${room.type} segment ${i}`);
 }
});

test('disconnected targets and invalid poses do not invent a route through walls',()=>{
 const school=createDemoSchool();school.corridors=school.corridors.filter(k=>k!==key(9,24));
 assert.equal(planSchoolRoute(school,entranceStart(school),'demo-music'),null);
 assert.equal(planSchoolRoute(school,{x:NaN,z:4},'demo-music'),null);
 assert.equal(planSchoolRoute(school,entranceStart(school),'missing'),null);
});

test('a child in the wrong room is routed through its only doorway',()=>{
 const school=createDemoSchool(),start=pose(13.85,26),route=planSchoolRoute(school,start,'demo-music');assert.ok(route);
 assert.ok(route.points.some(p=>p.x===13.5&&p.z===28.5));
 for(let i=1;i<route.points.length;i++)assert.ok(lineOfSight(school,route.points[i-1],route.points[i]));
});

test('instructions use correct left/right relative to the child and stop at the target',()=>{
 const school=createDemoSchool(),nav=new SpokenSchoolGuide(school);
 assert.equal(nav.start(pose(9.5,27.5,Math.PI),'demo-music').instruction,'Go straight.');
 assert.equal(nav.update(pose(9.5,21.1,Math.PI),2).instruction,'Turn right.');
 assert.equal(nav.update(pose(9.5,20.5,Math.PI/2),.6).instruction,'Go straight.');
 assert.equal(nav.update(pose(20.2,20.5,Math.PI/2),7).instruction,'Stop. This is the music room.');
 const west=new SpokenSchoolGuide(school);assert.equal(west.start(pose(21.5,20.5,-Math.PI/2),'demo-library').instruction,'Go straight.');
 assert.equal(west.update(pose(10.1,20.5,-Math.PI/2),10).instruction,'Turn right.');
 const left=new SpokenSchoolGuide(school);assert.equal(left.start(pose(9.5,19.5,0),'demo-music').instruction,'Go straight.');
 assert.equal(left.update(pose(9.5,20.1,0),.6).instruction,'Turn left.');
});

test('turn cue ends after the child makes the corner and cues are not repeated every frame',()=>{
 const school=createDemoSchool(),nav=new SpokenSchoolGuide(school);nav.start(pose(9.5,23.5,Math.PI),'demo-music');
 const turn=nav.update(pose(9.5,21.1,Math.PI),2);assert.equal(turn.spoken,'Turn right.');
 for(let i=0;i<90;i++)assert.equal(nav.update(pose(9.5,21.1,Math.PI),1/60).spoken,'');
 assert.equal(nav.update(pose(9.55,20.5,Math.PI/2),.1).spoken,'Go straight.');
});

test('wrong turns and overshooting a doorway reroute from the current position',()=>{
 const school=createDemoSchool(),nav=new SpokenSchoolGuide(school);nav.start(pose(9.5,23.5,Math.PI),'demo-music');
 nav.update(pose(9.5,20.5,Math.PI),2);
 const wrong=nav.update(pose(9.5,19.7,Math.PI),1);assert.equal(wrong.rerouted,true);assert.equal(wrong.instruction,'Turn left. Turn left.');
 nav.start(pose(19.5,20.5,Math.PI/2),'demo-music');assert.match(nav.update(pose(20.5,20.5,Math.PI/2),1).instruction,/^Stop\./);
 const overshoot=nav.update(pose(21.3,20.5,Math.PI/2),1);assert.equal(overshoot.rerouted,true);assert.equal(overshoot.instruction,'Turn left. Turn left.');
});

test('wrong turns show a cross and announce the recovery once, with visual feedback when muted',()=>{
 const school=createDemoSchool(),browser=fakeBrowser(),warnings=[],captions=[];
 const guide=createSchoolNavigationGuide({scope:browser.scope,onWrongWay:show=>warnings.push(show),onInstruction:text=>captions.push(text)});
 const c=context(school,{player:pose(9.5,21.3)});
 const wrong={...c,player:pose(9.5,19.7)};
 guide.start(c);
 assert.equal(guide.update(wrong,1).rerouted,true);
 assert.equal(browser.calls.at(-1).text,'Wrong way. Turn left. Turn left.');
 assert.equal(captions.at(-1),'Turn left. Turn left.');
 assert.equal(warnings.at(-1),true);
 for(let i=0;i<60;i++)guide.update({...wrong,player:pose(9.5,19.7-i*.02)},1/60);
 assert.equal(warnings.filter(Boolean).length,1);
 assert.equal(browser.calls.filter(u=>u.text.startsWith('Wrong way.')).length,1);
 guide.pause();assert.equal(warnings.at(-1),false);
 guide.setMuted(true);guide.start(c);const count=browser.calls.length;
 assert.equal(guide.update(wrong,1).rerouted,true);
 assert.equal(warnings.at(-1),true);
 assert.equal(browser.calls.length,count);
 guide.update({...wrong,mode:'controller',paired:true},1);
 assert.equal(warnings.at(-1),false);
});

test('speech picks an English voice regardless of UI language and replaces stale utterances',()=>{
 const browser=fakeBrowser(),speech=createSchoolSpeech({scope:browser.scope});assert.equal(speech.speak('Go straight.'),true);speech.speak('Turn left.');
 assert.equal(browser.calls[0].lang,'en-NZ');assert.equal(browser.calls[0].voice.lang,'en-NZ');assert.equal(browser.cancelled,2);assert.deepEqual(browser.events,['cancel','Go straight.','cancel','Turn left.']);
});

test('no loaded voices uses an English browser fallback and missing speech API is harmless',()=>{
 const browser=fakeBrowser([]),speech=createSchoolSpeech({scope:browser.scope});assert.equal(speech.speak('Go straight.'),true);assert.equal(browser.calls[0].lang,'en-GB');assert.equal(browser.calls[0].voice,undefined);
 const missing=createSchoolSpeech({scope:{}});assert.equal(missing.available(),false);assert.equal(missing.speak('Go straight.'),false);missing.cancel();
});

test('only explicitly enabled own-device walk contexts can speak; paired modes remain silent',()=>{
 const school=createDemoSchool(),browser=fakeBrowser(),guide=createSchoolNavigationGuide({scope:browser.scope});
 for(const extra of [{mode:'controller'},{mode:'host'},{mode:'build'},{paired:true},{localDirections:false},{localDirections:undefined}]){guide.start(context(school,extra));guide.update(context(school,extra),1);}
 assert.equal(browser.calls.length,0);assert.equal(guide.supported,true);
 guide.start(context(school));assert.equal(browser.calls.length,1);
 guide.update(context(school,{mode:'controller'}),1);assert.equal(browser.calls.length,1);assert.ok(browser.cancelled>0);
});

test('modal/pause, mute, exit and target change cancel stale speech and resume the current cue',()=>{
 const school=createDemoSchool(),browser=fakeBrowser(),guide=createSchoolNavigationGuide({scope:browser.scope});const c=context(school);
 guide.start(c);const before=browser.cancelled;guide.pause();assert.ok(browser.cancelled>before);
 guide.update({...c,paused:true},1);assert.equal(browser.calls.length,1);
 guide.update(c,1);assert.equal(browser.calls.length,2);
 guide.setMuted(true);guide.update({...c,player:pose(9.5,21.1)},3);assert.equal(browser.calls.length,2);
 guide.setMuted(false);assert.equal(browser.calls.at(-1).text,'Turn right.');
 guide.update({...c,targetId:'demo-classroom'},1);assert.equal(browser.calls.at(-1).text,'Go straight.');
 const stopped=browser.cancelled;guide.stop();assert.ok(browser.cancelled>stopped);
});

test('rapid frame updates do not build speech queues and paused target changes remain silent',()=>{
 const school=createDemoSchool(),browser=fakeBrowser(),guide=createSchoolNavigationGuide({scope:browser.scope});const c=context(school);
 guide.start(c);for(let i=0;i<600;i++)guide.update(c,1/60);assert.equal(browser.calls.length,1);
 guide.update({...c,targetId:'demo-library',paused:true},1);assert.equal(browser.calls.length,1);
 guide.update({...c,targetId:'demo-library'},1);assert.equal(browser.calls.length,2);
});

test('continuous walking to every demo room announces each route turn and one arrival',()=>{
 const school=createDemoSchool(),start={...entranceStart(school),angle:Math.PI};
 for(const room of school.rooms.filter(r=>r.type!=='entrance')){
  const route=planSchoolRoute(school,start,room.id),nav=new SpokenSchoolGuide(school),spoken=[];nav.start(start,room.id);
  for(let i=1;i<route.points.length;i++){
   const a=route.points[i-1],b=route.points[i],angle=Math.atan2(b.x-a.x,b.z-a.z);
   for(let step=1;step<=20;step++){
    const result=nav.update(pose(a.x+(b.x-a.x)*step/20,a.z+(b.z-a.z)*step/20,angle),.05/.82);
    if(result.spoken)spoken.push(result.spoken);assert.equal(result.rerouted,false,`${room.type} should stay on route`);
   }
  }
  assert.deepEqual(spoken.filter(text=>text.startsWith('Turn')),route.turns.map(t=>t.text),room.type);
  assert.equal(spoken.filter(text=>text.startsWith('Stop.')).length,1,room.type);
 }
});
