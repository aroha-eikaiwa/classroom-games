import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createBasketballCourt,gymFloorMaterial} from '../gym-floor.mjs';
import {createDemoSchool,validateSchool} from '../core.mjs';
test('the existing school demo is playable with all rooms and the original procedural court',()=>{
  assert.equal(validateSchool(createDemoSchool()).ready,true);
  const court=createBasketballCourt(8,6);
  assert.ok(court.children.length>=8);
  assert.equal(gymFloorMaterial().map.image.data.length,1024*512*4);
});
test('current HTML and app forbid live services and strip account and partner controls',()=>{
  const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
  const app=fs.readFileSync(new URL('../app.mjs',import.meta.url),'utf8');
  assert.match(html,/connect-src 'none'/);
  assert.match(html,/src=".\/app\.mjs"/);
  assert.doesNotMatch(html,/id="(?:host-mode|account-open|teacher-open|login-open|join-open)"/);
  assert.doesNotMatch(app,/\/api\/|\bfetch\(|\bWebSocket\b|aroha-eikaiwa\.com/);
});
test('start, reload, walking and confirmed reset run through the actual local app entry', async()=>{
  const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
  const context=new Proxy({measureText:()=>({width:120}),createImageData:(width,height)=>({data:new Uint8ClampedArray(width*height*4)})},{get:(obj,k)=>obj[k]??(()=>{}),set:(obj,k,v)=>(obj[k]=v,true)});
  let avatars=[];
  class Element{
    constructor(id){this.id=id;this.style={};this.hidden=false;this.open=id==='start-dialog';this.dataset={};const classes=new Set();this.classList={toggle:(k,on)=>on?classes.add(k):classes.delete(k),add:k=>classes.add(k),remove:k=>classes.delete(k),contains:k=>classes.has(k)};}
    set innerHTML(s){this.markup=s;if(this.id==='modal-body'){avatars=[...s.matchAll(/data-avatar="(.*?)"/g)].map((m)=>Object.assign(new Element(m[1]),{dataset:{avatar:m[1]}}));for(const m of s.matchAll(/id="(reset-[^"]+)"/g))fields.set(m[1],new Element(m[1]));}}
    get innerHTML(){return this.markup;}
    removeEventListener(){}
    addEventListener(name,cb){this['on'+name]=cb;}
    getContext(kind){return kind==='2d'?context:null;}
    setAttribute(){}
    querySelector(){return null;}
    querySelectorAll(selector){return selector==='[data-avatar]'?avatars:[];}
    getBoundingClientRect(){return {width:800,height:550,left:0,top:0,right:800,bottom:550};}
    close(){this.open=false;}
    showModal(){this.open=true;}
  }
  const fields=new Map([...html.matchAll(/\bid="([^"]+)"/g)].map((m)=>[m[1],new Element(m[1])]));
  fields.get('continue-school').hidden=true;
  globalThis.document={getElementById:id=>fields.get(id),querySelectorAll:()=>[],querySelector:()=>null,addEventListener(){},documentElement:{},hasFocus:()=>true,createElement:tag=>new Element(tag),createElementNS:(_,tag)=>new Element(tag)};
  globalThis.window={addEventListener(){}};globalThis.Image=class{};
  globalThis.requestAnimationFrame=()=>1;globalThis.cancelAnimationFrame=()=>{};
  const storage=new Map();
  globalThis.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)};
  let requests=0;
  globalThis.fetch=()=>{requests++;throw Error('Network should not be used');};
  globalThis.WebSocket=class{constructor(){requests++;throw Error('Network should not be used');}};
  await import('../app.mjs?startup');
  assert.equal(typeof fields.get('demo-school').onclick,'function','initialisation reaches actual startup handler');
  fields.get('demo-school').onclick();
  assert.equal(fields.get('start-dialog').open,false,'sample school enters editor');
  assert.equal(fields.get('walk-mode').disabled,false,'real demo permits Directions');
  fields.get('walk-mode').onclick();
  assert.equal(fields.get('modal').open,true,'avatar chooser opens');
  assert.equal(avatars.length,2);
  avatars[1].onclick();
  assert.equal(fields.get('walk-mode').classList.contains('active'),true);
  assert.equal(fields.get('walk-hud').hidden,false);
  assert.equal(storage.get('school-student-avatar'),'girl');
  fields.get('build-mode').onclick();
  fields.get('reset-school').onclick();
  assert.equal(fields.get('modal').open,true);
  assert.ok(JSON.parse(storage.get('aroha-school-standalone-v1')).school.rooms.length>0,'reset waits for confirmation');
  await fields.get('reset-confirm').onclick();
  assert.equal(fields.get('modal').open,false);
  const saved=JSON.parse(storage.get('aroha-school-standalone-v1')).school;
  assert.deepEqual(saved.rooms,[]);assert.deepEqual(saved.corridors,[]);
  assert.equal(fields.get('walk-mode').disabled,true);
  fields.get('start-dialog').open=true;
  fields.get('continue-school').hidden=true;
  await import('../app.mjs?reloaded');
  assert.equal(fields.get('continue-school').hidden,false,'private draft is offered after a new load');
  fields.get('continue-school').onclick();
  assert.equal(fields.get('walk-mode').disabled,true,'the empty saved school was restored, not the built-in demo');
  assert.equal(requests,0);
});
