import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {BY_TYPE,ROOMS,W} from '../core.mjs';
import {roomWallLayout,roomWindowKey,classroomSeats} from '../room-layout.mjs';
import {createRoomModel,disposeRoomModel} from '../models.mjs';

const room=(type='classroom',x=6,z=7)=>({id:'test-room',type,x,z});

test('windows occupy exterior side bays and never the door, board or mirror wall',()=>{
 for(const def of ROOMS){
  const r=room(def.type),plan=roomWallLayout(r,def);
  for(const window of plan.windows){
   assert.ok(['east','west'].includes(window.side));
   assert.ok(window.position-window.width/2>.1);
   assert.ok(window.position+window.width/2<def.d-.1);
  }
  for(const poster of plan.posters){
   const left=poster.x-poster.width/2,right=poster.x+poster.width/2;
   assert.ok(right<1.12||left>2.54,'Poster must clear opening and sliding pocket');
   assert.ok(left>0&&right<def.w);
   assert.equal(poster.rotation,Math.PI);
  }
 }
 assert.equal(roomWallLayout(room('entrance')).windows.length,0,'Shoe lockers occupy both side walls');
 assert.ok(roomWallLayout(room('restroom')).windows.every(w=>w.side==='east'));
 assert.ok(roomWallLayout(room('teachers')).windows.every(w=>w.side==='east'));
 assert.ok(roomWallLayout(room('science')).windows.every(w=>w.position>2.5),'Lab cupboards cannot appear inside a window');
});

test('windows disappear on shared walls, including partly covered bays, and keys change',()=>{
 const r=room(),def=BY_TYPE.classroom,school={rooms:[r],corridors:[]};
 const original=roomWindowKey(r,def,school);
 assert.equal(roomWallLayout(r,def,school).windows.length,4);
 school.rooms.push({id:'east-neighbour',type:'classroom',x:r.x+def.w,z:r.z});
 assert.ok(roomWallLayout(r,def,school).windows.every(w=>w.side==='west'));
 assert.notEqual(roomWindowKey(r,def,school),original);
 // A single corridor square touching part of the next bay excludes that bay.
 school.corridors.push((r.z+2)*W+r.x-1);
 const remaining=roomWallLayout(r,def,school).windows;
 assert.ok(remaining.every(w=>w.side==='west'&&w.position<1));
 assert.equal(remaining.length,1);
 school.rooms=[];school.corridors=[];
 assert.equal(roomWindowKey(r,def,school),original);
});

test('ordinary and music classroom chairs face the blackboard, table seats face their table',()=>{
 for(const type of ['classroom','music']){
  const seats=classroomSeats(type);
  assert.equal(seats.length,type==='classroom'?12:15);
  for(const seat of seats){assert.equal(seat.rotation,Math.PI);assert.equal(seat.y,.19);}
 }
 for(const type of ['science','art']){
  const seats=classroomSeats(type);
  assert.equal(seats.length,16);
  for(let i=0;i<seats.length;i+=2){
   assert.equal(seats[i].rotation,0);
   assert.equal(seats[i+1].rotation,Math.PI);
   assert.ok(seats[i].z<seats[i+1].z);
  }
 }
});

test('actual furniture meshes keep the central doorway approach clear in every room',()=>{
 for(const def of ROOMS.filter(d=>!d.outdoor)){
  const model=createRoomModel(room(def.type),def),furniture=model.getObjectByName('furniture');
  model.updateMatrixWorld(true);
  const point=new THREE.Vector3();let overlaps=0;
  // Test all baked furniture vertices in the walking entrance lane, excluding
  // floor mats. This catches the previous wash basins spanning the restroom exit.
  furniture.traverse(mesh=>{
   if(!mesh.isMesh)return;
   const position=mesh.geometry.attributes.position;
   for(let i=0;i<position.count;i++){
    point.fromBufferAttribute(position,i).applyMatrix4(mesh.matrixWorld);
    if(point.x>1.33&&point.x<1.67&&point.z>def.d-.36&&point.z<def.d+.02&&point.y>.08)overlaps++;
   }
  });
  assert.equal(overlaps,0,`${def.type} furniture blocks the doorway`);
  assert.deepEqual(model.userData.classroomLayout.seats,classroomSeats(def.type));
  disposeRoomModel(model);
 }
});
