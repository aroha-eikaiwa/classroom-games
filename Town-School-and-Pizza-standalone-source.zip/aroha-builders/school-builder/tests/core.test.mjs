import test from 'node:test';
import assert from 'node:assert/strict';
import {W,H,BY_TYPE,createSchool,createDemoSchool,canPlaceRoom,addRoom,drawCorridor,deleteAt,validateSchool,roomDoor,entranceStart,walkable,movePlayer,findPath,lineOfSight,normalizeSchool,addDecoration,nearDoor,randomDestination,key} from '../core.mjs';

function entranceSchool(){const s=createSchool();assert.equal(addRoom(s,'entrance',10,20).ok,true);return s;}

test('entrance comes first and specialist rooms cannot be duplicated',()=>{
  const s=createSchool();assert.equal(canPlaceRoom(s,'classroom',4,4).ok,false);
  assert.equal(addRoom(s,'entrance',10,20).ok,true);
  assert.equal(canPlaceRoom(s,'entrance',20,20).ok,false);
  assert.equal(drawCorridor(s,{x:11,z:19},{x:35,z:19}).ok,true);
  assert.equal(addRoom(s,'teachers',15,16).ok,true);
  assert.equal(canPlaceRoom(s,'teachers',23,16).ok,false);
  assert.equal(addRoom(s,'classroom',22,16).ok,true);
  assert.equal(addRoom(s,'classroom',28,16).ok,true);
});

test('doorway snaps to its fixed corridor and rejects overlap or off-grid placement',()=>{
  const s=entranceSchool();
  assert.equal(canPlaceRoom(s,'science',20,10).ok,false);
  drawCorridor(s,{x:11,z:19},{x:30,z:19});
  assert.equal(canPlaceRoom(s,'science',20,15).ok,true);
  assert.equal(addRoom(s,'science',20,15).ok,true);
  assert.equal(canPlaceRoom(s,'classroom',21,16).ok,false);
  assert.equal(canPlaceRoom(s,'gym',W-2,5).ok,false);
  assert.equal(canPlaceRoom(s,'classroom',1.5,2).ok,false);
  assert.deepEqual(roomDoor(s.rooms.find(r=>r.type==='science')),{x:21.5,z:19,outX:21.5,outZ:19.5});
});

test('corridor strokes are atomic and cannot draw through a room',()=>{
  const s=entranceSchool();
  const before=structuredClone(s);
  assert.equal(drawCorridor(s,{x:11,z:15},{x:11,z:25}).ok,false);
  assert.deepEqual(s,before);
  assert.equal(drawCorridor(s,{x:11,z:19},{x:20,z:21}).ok,true);
  assert.equal(s.corridors.length,10);
  assert.ok(s.corridors.every(k=>Math.floor(k/W)===19));
});

test('all demo rooms and all corridor sections reach the entrance',()=>{
  const s=createDemoSchool(),validation=validateSchool(s);
  assert.equal(validation.ready,true,validation.errors.join('\n'));
  assert.deepEqual(validation.missing,[]);
  const spawn=entranceStart(s);
  for(const room of s.rooms){const d=roomDoor(room);assert.ok(findPath(s,spawn,{x:d.outX,z:d.outZ}).length>0,room.type);}
  assert.deepEqual(normalizeSchool(s),s);
});

test('removing a connecting corridor locks directions; undo restores completeness',()=>{
  const s=createDemoSchool(),before=structuredClone(s);
  deleteAt(s,9,25);
  const broken=validateSchool(s);assert.equal(broken.ready,false);assert.ok(broken.disconnected.length>0);
  assert.equal(validateSchool(before).ready,true);
  deleteAt(s,13,9);assert.ok(validateSchool(s).missing.includes('library'));
});

test('walking goes through entrance doorway but not through its other walls',()=>{
  const s=entranceSchool();
  drawCorridor(s,{x:11,z:18},{x:11,z:19});
  drawCorridor(s,{x:9,z:20},{x:9,z:22});
  let p=movePlayer(s,{x:11.5,z:21.5},0,-2);
  assert.ok(p.z<20);assert.ok(walkable(s,p.x,p.z));
  p=movePlayer(s,{x:10.5,z:21.5},-1,0);
  assert.ok(p.x>=10.12-1e-8);
  assert.equal(lineOfSight(s,{x:10.5,z:21.5},{x:9.5,z:21.5}),false);
  assert.equal(lineOfSight(s,{x:11.5,z:21.5},{x:11.5,z:18.5}),true);
});

test('every school room can be entered and exited through its doorway while solid walls block movement',()=>{
  const school=createDemoSchool();
  for(const room of school.rooms){
    const d=roomDoor(room),dir=room.type==='entrance'?1:-1;
    const start={x:d.outX,z:d.outZ};
    const inside=movePlayer(school,start,0,dir*.85);
    assert.ok((inside.z-d.z)*dir>.3,room.type);
    const back=movePlayer(school,inside,0,-dir*.85);
    assert.ok(Math.hypot(back.x-start.x,back.z-start.z)<.001,room.type);
    const side=movePlayer(school,inside,.85,0);
    const blocked=movePlayer(school,side,0,-dir*2);
    assert.ok((blocked.z-d.z)*dir>.09,room.type);
  }
});

test('teachers cannot see runners through the empty grounds or around a solid corner',()=>{
  const s=entranceSchool();
  drawCorridor(s,{x:11,z:10},{x:11,z:19});
  drawCorridor(s,{x:11,z:10},{x:20,z:10});
  assert.equal(lineOfSight(s,{x:11.5,z:18.5},{x:11.5,z:12.5}),true);
  assert.equal(lineOfSight(s,{x:11.5,z:14.5},{x:17.5,z:10.5}),false);
  assert.equal(findPath(s,{x:11.5,z:18.5},{x:17.5,z:10.5}).length,15);
});

test('decorations cannot occupy a room, corridor, or another decoration',()=>{
  const s=createDemoSchool();
  assert.equal(addDecoration(s,'tree',9,28).ok,false);
  assert.equal(addDecoration(s,'bench',8,29).ok,false);
  assert.equal(addDecoration(s,'tree',3,3).ok,true);
  assert.equal(addDecoration(s,'flowers',3,3).ok,false);
});

test('grounds require every room and corridor connection while existing decorated drafts remain loadable',()=>{
  const s=createDemoSchool();
  assert.equal(addDecoration(s,'maple',3,3).ok,true);
  const decorations=structuredClone(s.decorations);
  const library=s.rooms.find(r=>r.type==='library');
  s.rooms=s.rooms.filter(r=>r!==library);
  assert.equal(addDecoration(s,'cherry',4,3).ok,false);
  assert.deepEqual(normalizeSchool(s).decorations,decorations);
  s.rooms.push(library);
  const corridor=key(9,25);s.corridors=s.corridors.filter(k=>k!==corridor);
  assert.equal(addDecoration(s,'wind-tree',4,3).ok,false);
  assert.deepEqual(normalizeSchool(s).decorations,decorations);
  s.corridors.push(corridor);
  assert.equal(addDecoration(s,'wind-tree',4,3).ok,true);
});

test('import rejects malformed, oversized, duplicated, and overlapping geometry',()=>{
  const cases=[null,{},createDemoSchool(),createDemoSchool(),createDemoSchool(),createDemoSchool()];
  cases[2].corridors.push(W*H);
  cases[3].rooms[1].id=cases[3].rooms[0].id;
  cases[4].rooms[1].type='__proto__';
  cases[5].rooms[1].x=cases[5].rooms[0].x;cases[5].rooms[1].z=cases[5].rooms[0].z;
  for(const value of cases)assert.throws(()=>normalizeSchool(value));
  const empty=createSchool();assert.deepEqual(normalizeSchool(empty),empty);
  const partial=entranceSchool();assert.deepEqual(normalizeSchool(partial),partial);
});

test('random destinations never select entrance and avoid immediate repeats',()=>{
  const s=createDemoSchool(),r=randomDestination(s,null,()=>0);assert.notEqual(r.type,'entrance');
  assert.notEqual(randomDestination(s,r.id,()=>0).id,r.id);
  assert.equal(randomDestination(createSchool()),null);
});
