import {BY_TYPE,W,H,roomDoor} from './core.mjs';
import {POSTER_COUNT,HALLWAY_SAFETY_POSTERS} from './poster-catalog.mjs';

function hash(text){let h=2166136261;for(const c of text){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}h^=h>>>16;h=Math.imul(h,0x85ebca6b);h^=h>>>13;h=Math.imul(h,0xc2b2ae35);return (h^(h>>>16))>>>0;}
const directions=[{dx:0,dz:-1,side:'north',roomSide:'south',rotation:0},{dx:0,dz:1,side:'south',roomSide:'north',rotation:Math.PI},{dx:1,dz:0,side:'east',roomSide:'west',rotation:-Math.PI/2},{dx:-1,dz:0,side:'west',roomSide:'east',rotation:Math.PI/2}];

// Deterministic randomness means a guide and controller see the same hallway.
// Decorations are mounted on existing solid walls and never occupy walking space.
export function hallwayDecorations(school){
 const halls=new Set(school.corridors),roomTiles=new Map(),entrance=school.rooms.find(r=>r.type==='entrance');
 for(const room of school.rooms){const d=BY_TYPE[room.type];if(!d)continue;for(let z=room.z;z<room.z+d.d;z++)for(let x=room.x;x<room.x+d.w;x++)roomTiles.set(z*W+x,room);}
 const seed=entrance?.id||'school',candidates=[];
 for(const key of [...halls].sort((a,b)=>a-b)){
  const x=key%W,z=Math.floor(key/W);
  for(const direction of directions){
   const {dx,dz,side,roomSide,rotation}=direction,nx=x+dx,nz=z+dz;
   const valid=nx>=0&&nx<W&&nz>=0&&nz<H;
   if(valid&&halls.has(nz*W+nx))continue;
   const room=valid?roomTiles.get(nz*W+nx):null;
   const wallX=x+.5+dx*.5,wallZ=z+.5+dz*.5;
   if(room){
    if(BY_TYPE[room.type].outdoor)continue;
    // Room side walls contain windows. Decorate only the solid doorway wall,
    // leaving both the doorway and the door panel's sliding pocket clear.
    if(roomSide!=='south'&&!(roomSide==='north'&&room.type==='entrance'))continue;
    const door=roomDoor(room);
    if(wallX>door.x-.70&&wallX<door.x+1.12)continue;
   }
   const value=hash(`${seed}:${x}:${z}:${side}`);
   candidates.push({id:`hall-${key}-${side}`,x:wallX-dx*.056,z:wallZ-dz*.056,y:.83,rotation,side,roomSide,roomId:room?.id||null,kind:value%13===0?'clock':value%7===0?'noticeboard':'poster',variant:(value>>>8)%POSTER_COUNT,value});
  }
 }
 const selected=candidates.filter(c=>c.value%4===0);
 if(!selected.length&&candidates.length)selected.push(candidates[0]);
 // A school with enough safe wall bays always gets both hallway rules. Keep
 // their locations deterministic for paired devices and reuse only vetted bays.
 const required=Math.min(HALLWAY_SAFETY_POSTERS.length,candidates.length);
 for(const candidate of candidates){
  if(selected.length>=required)break;
  if(!selected.includes(candidate))selected.push(candidate);
 }
 const safetySlots=[...selected].sort((a,b)=>a.value-b.value||a.id.localeCompare(b.id));
 for(let i=0;i<required;i++){safetySlots[i].kind='poster';safetySlots[i].variant=HALLWAY_SAFETY_POSTERS[i];}
 return selected.map(({value,...decoration})=>decoration);
}
