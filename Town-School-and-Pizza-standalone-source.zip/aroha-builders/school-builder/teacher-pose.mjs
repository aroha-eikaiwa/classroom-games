import * as THREE from './vendor/three.module.js';

const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const smooth=(a,b,n)=>{const t=clamp((n-a)/(b-a));return t*t*(3-2*t);};

/** The supplied teachers are vertex-animation meshes. Their low arm vertices
 * form separate connected components below the shoulders, including duplicated
 * atlas-seam vertices. Derive those components from the real neutral topology
 * instead of cutting sleeves with a moving x/y threshold. */
export function createTeacherPoseRig(data,frames,{variant=0}={}){
 const n=data.vertices,height=data.height||.64,scale=height/.64;
 const reference=new Float32Array(n*3),normals=new Float32Array(n*3),welded=new Map(),nodes=[],vertexNode=new Uint32Array(n);
 for(let i=0;i<n;i++){
  const p=Array.from(frames.subarray(i*6,i*6+3));reference.set(p,i*3);normals.set(frames.subarray(i*6+3,i*6+6),i*3);
  const key=p.map(v=>Math.round(v/(.0001*scale))).join(':');let id=welded.get(key);
  if(id===undefined){id=nodes.length;welded.set(key,id);nodes.push({p,vertices:[],neighbors:new Set()});}
  nodes[id].vertices.push(i);vertexNode[i]=id;
 }
 for(let i=0;i<data.index.length;i+=3)for(const [a,b]of [[0,1],[1,2],[2,0]]){
  const x=vertexNode[data.index[i+a]],y=vertexNode[data.index[i+b]];if(x!==y){nodes[x].neighbors.add(y);nodes[y].neighbors.add(x);}
 }
 const shoulderCut=.475*scale,seen=new Set(),components=[];
 for(let i=0;i<nodes.length;i++){
  if(seen.has(i)||nodes[i].p[1]>=shoulderCut)continue;
  const queue=[i];seen.add(i);for(let q=0;q<queue.length;q++)for(const j of nodes[queue[q]].neighbors)if(!seen.has(j)&&nodes[j].p[1]<shoulderCut){seen.add(j);queue.push(j);}
  components.push(queue);
 }
 const sides=new Int8Array(n),weights=new Float32Array(n),arms=[];
 for(const side of [-1,1]){
  const handSeeds=nodes.map((node,id)=>({node,id})).filter(({node})=>node.p[1]>.25*scale&&node.p[1]<.365*scale&&side*node.p[0]>.05*scale&&node.vertices.some(i=>data.region[i]===0));
  const seedIds=new Set(handSeeds.map(({id})=>id));
  const component=components.filter(c=>c.some(id=>seedIds.has(id))&&c.every(id=>nodes[id].p[1]>.23*scale)).sort((a,b)=>b.length-a.length)[0];
  if(!component)continue;
  const full=new Set(component),values=new Float64Array(nodes.length),fixed=new Uint8Array(nodes.length);
  for(let i=0;i<nodes.length;i++){
   if(full.has(i)){values[i]=1;fixed[i]=1;}
   else if(nodes[i].p[1]<shoulderCut||nodes[i].p[1]>.535*scale||side*nodes[i].p[0]<.025*scale)fixed[i]=1;
  }
  // Smoothly distribute shoulder influence across connected polygons. Seams
  // share one value, preventing the tearing of independent threshold masks.
  for(let pass=0;pass<100;pass++)for(let i=0;i<nodes.length;i++){
   if(fixed[i])continue;let sum=0,total=0;
   for(const j of nodes[i].neighbors){const a=nodes[i].p,b=nodes[j].p,w=1/Math.max(.001*scale,Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]));sum+=values[j]*w;total+=w;}
   if(total)values[i]=sum/total;
  }
  const indices=[];for(let id=0;id<nodes.length;id++)if(values[id]>.0001)for(const i of nodes[id].vertices){indices.push(i);sides[i]=side;weights[i]=values[id];}
  const foot=[];for(let i=0;i<n;i++){const x=reference[i*3],y=reference[i*3+1];if(side*x>0&&y<.16*scale)foot.push(i);}
  arms.push({side,indices:Uint32Array.from(indices),foot:Uint32Array.from(foot),pivot:[side*.064*scale,.498*scale,.003*scale],elbow:[side*.071*scale,.399*scale,.008*scale]});
 }
 const torso=[];for(let i=0;i<n;i++){const x=reference[i*3],y=reference[i*3+1];if(Math.abs(x)<.035*scale&&y>.38*scale&&y<.51*scale)torso.push(i);}
 const rig={reference,normals,weights,sides,arms,torso:Uint32Array.from(torso),height,scale,variant,offset:new Float32Array(3)};
 if(variant===1)relaxOutwardWrists(rig);
 return rig;
}

function rotateZ(x,y,z,pivot,angle){const c=Math.cos(angle),s=Math.sin(angle),a=x-pivot[0],b=y-pivot[1];return [pivot[0]+c*a-s*b,pivot[1]+s*a+c*b,z];}
function relaxOutwardWrists(rig){
 // The second source model's palms point sideways in its *neutral* mesh.
 // A short wrist blend relaxes each hand down, without rotating the cuff or
 // collapsing the fingers. These pivots are measured from its baked vertices.
 for(const arm of rig.arms){
  const side=arm.side,pivot=[side*.067*rig.scale,.347*rig.scale,.018*rig.scale];
  for(const i of arm.indices){
   const at=i*3,x=rig.reference[at],y=rig.reference[at+1],z=rig.reference[at+2];
   const along=side*(x-pivot[0])*.94+(pivot[1]-y)*.34;
   const weight=smooth(.001*rig.scale,.021*rig.scale,along)*(1-smooth(.362*rig.scale,.39*rig.scale,y));
   const angle=-side*.96*weight;if(!angle)continue;
   rig.reference.set(rotateZ(x,y,z,pivot,angle),at);
   const nx=rig.normals[at],ny=rig.normals[at+1],nz=rig.normals[at+2];rig.normals.set(rotateZ(nx,ny,nz,[0,0,0],angle),at);
  }
 }
}

/** Preserve the supplied torso, head and lower-body animation. The corrected
 * arm follows the opposite same-side foot, with a mild elbow bend. Translation
 * follows the sampled torso, so blending walk/idle never detaches a shoulder. */
export function applyTeacherPose(positions,normals,rig,walkWeight=0){
 if(!rig?.arms.length)return;
 const {reference,scale,offset}=rig;offset.fill(0);
 for(const i of rig.torso)for(let axis=0;axis<3;axis++)offset[axis]+=positions[i*3+axis]-reference[i*3+axis];
 if(rig.torso.length)for(let axis=0;axis<3;axis++)offset[axis]/=rig.torso.length;
 for(const arm of rig.arms){
  let advance=0;for(const i of arm.foot)advance+=positions[i*3+2]-reference[i*3+2]-offset[2];
  advance/=arm.foot.length||1;
  const swing=clamp(advance/(.105*scale),-1,1)*.25;
  const elbowAngle=-Math.max(0,-swing)*.35*clamp(walkWeight),c=Math.cos(swing),s=Math.sin(swing),ce=Math.cos(elbowAngle),se=Math.sin(elbowAngle);
  for(const i of arm.indices){
   const at=i*3,w=rig.weights[i];let x=reference[at],y=reference[at+1],z=reference[at+2];
   let nx=rig.normals[at],ny=rig.normals[at+1],nz=rig.normals[at+2];
   const elbowWeight=1-smooth(.382*scale,.416*scale,y),ey=y-arm.elbow[1],ez=z-arm.elbow[2];
   const by=arm.elbow[1]+ce*ey-se*ez,bz=arm.elbow[2]+se*ey+ce*ez;
   y+=(by-y)*elbowWeight;z+=(bz-z)*elbowWeight;
   const bny=ce*ny-se*nz,bnz=se*ny+ce*nz;ny+=(bny-ny)*elbowWeight;nz+=(bnz-nz)*elbowWeight;
   const py=y-arm.pivot[1],pz=z-arm.pivot[2],ty=arm.pivot[1]+c*py-s*pz,tz=arm.pivot[2]+s*py+c*pz;
   positions[at]+=(x+offset[0]-positions[at])*w;positions[at+1]+=(ty+offset[1]-positions[at+1])*w;positions[at+2]+=(tz+offset[2]-positions[at+2])*w;
   const tny=c*ny-s*nz,tnz=s*ny+c*nz;nx=normals[at]+(nx-normals[at])*w;ny=normals[at+1]+(tny-normals[at+1])*w;nz=normals[at+2]+(tnz-normals[at+2])*w;
   const length=Math.hypot(nx,ny,nz)||1;normals[at]=nx/length;normals[at+1]=ny/length;normals[at+2]=nz/length;
  }
 }
}

export function teacherWalkWeight(speed,{stopped=false,scolding=false}={}){
 return stopped||scolding?0:smooth(.025,.30,Number.isFinite(speed)?speed:0);
}

const uniformTextures=new WeakMap();
export function createTeacherUniformMask(data,positions,width,height){
 const mask=new Uint8Array(width*height),scale=(data.height||.64)/.64;
 // Paint in source UV space, interpolating the real mesh height inside each
 // triangle. Existing clothing-region tags cut through the blazer diagonally;
 // a material-space mask keeps its hem and cuffs coherent instead.
 for(let face=0;face<data.index.length;face+=3){
  const a=data.index[face],b=data.index[face+1],c=data.index[face+2];
  const ya=positions[a*3+1],yb=positions[b*3+1],yc=positions[c*3+1];
  if(Math.max(ya,yb,yc)<.308*scale||Math.min(ya,yb,yc)>.535*scale)continue;
  const ax=data.uv[a*2]*width,ay=data.uv[a*2+1]*height,bx=data.uv[b*2]*width,by=data.uv[b*2+1]*height,cx=data.uv[c*2]*width,cy=data.uv[c*2+1]*height;
  const denominator=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy);if(Math.abs(denominator)<1e-8)continue;
  const minX=Math.max(0,Math.floor(Math.min(ax,bx,cx))),maxX=Math.min(width-1,Math.ceil(Math.max(ax,bx,cx))),minY=Math.max(0,Math.floor(Math.min(ay,by,cy))),maxY=Math.min(height-1,Math.ceil(Math.max(ay,by,cy)));
  for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){
   const wa=((by-cy)*(x+.5-cx)+(cx-bx)*(y+.5-cy))/denominator,wb=((cy-ay)*(x+.5-cx)+(ax-cx)*(y+.5-cy))/denominator,wc=1-wa-wb;
   if(wa<-.002||wb<-.002||wc<-.002)continue;
   const bodyY=wa*ya+wb*yb+wc*yc;
   if(bodyY>=.308*scale&&bodyY<=.535*scale)mask[y*width+x]=1;
  }
 }
 // One texel of padding covers UV seam filtering without painting unrelated
 // islands; skin protection is applied after this material mask.
 const padded=mask.slice();
 for(let y=0;y<height;y++)for(let x=0;x<width;x++)if(mask[y*width+x])for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
  const px=x+dx,py=y+dy;if(px>=0&&py>=0&&px<width&&py<height)padded[py*width+px]=1;
 }
 return padded;
}

export function createTeacherUniformTexture(original,uniform,data,positions){
 if(uniform!=='nurse'||typeof document==='undefined'||!original?.image||!data||!positions)return original;
 if(uniformTextures.has(original))return uniformTextures.get(original);
 const source=original.image,width=source.naturalWidth||source.width,height=source.naturalHeight||source.height;
 const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
 const ctx=canvas.getContext('2d',{willReadFrequently:true});if(!ctx)return original;
 ctx.drawImage(source,0,0,width,height);
 const image=ctx.getImageData(0,0,width,height),pixels=image.data,mask=createTeacherUniformMask(data,positions,width,height);
 for(let pixel=0;pixel<mask.length;pixel++){
  if(!mask[pixel])continue;const i=pixel*4,r=pixels[i],g=pixels[i+1],b=pixels[i+2];
  // Keep the photographed warm skin and brown hair in collar/cuff pixels.
  if(r>g*1.12&&r>b*1.17)continue;
  const shade=.80+.20*(.2126*pixels[i]+.7152*pixels[i+1]+.0722*pixels[i+2])/255;
  pixels[i]=238*shade;pixels[i+1]=248*shade;pixels[i+2]=244*shade;
 }
 ctx.putImageData(image,0,0);
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.flipY=original.flipY;texture.anisotropy=original.anisotropy;
 texture.userData.shared=true;texture.userData.teacherUniform='nurse';uniformTextures.set(original,texture);return texture;
}

export function applyTeacherUniform(mesh,data,original,uniform){
 const texture=createTeacherUniformTexture(original,uniform,data,mesh.geometry.attributes.position.array);if(texture===original)return false;
 mesh.material.map=texture;return true;
}
