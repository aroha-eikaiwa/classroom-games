// Student-facing controls stay Japanese. Teachers retain their own language
// choice in the builder and the guide's overhead view.
export function interfaceLanguage({mode='build',session,lang='en'}={}){
 return session?.role==='student'||mode==='walk'||mode==='controller'?'ja':lang==='ja'?'ja':'en';
}
export function showLanguageSwitch({mode='build',session}={}){
 return session?.role!=='student'&&(mode==='build'||mode==='host');
}
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function roomLabelText(room){return room?.en?[room.en,room.ja].filter(Boolean).join(' / '):'';}
export function roomLabelHtml(room){
 if(!room?.en)return '';
 return `<span class="learning-name" lang="en">${escape(room.en)}</span>${room.ja?`<small class="learning-ja" lang="ja">${escape(room.ja)}</small>`:''}`;
}
