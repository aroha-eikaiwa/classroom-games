// Match Town Builder: motion shared by both fingers tilts, sideways motion
// pans, separation zooms and twisting rotates. Pointer events arrive one at
// a time; the first half of a pinch must never be interpreted as a tilt.
export function beginBuildGesture(a,b){
 return {a:{...a},b:{...b},angle:Math.atan2(b.y-a.y,b.x-a.x),distance:Math.hypot(b.x-a.x,b.y-a.y),x:(a.x+b.x)/2,tilt:0};
}
export function moveBuildGesture(g,a,b){
 const distance=Math.hypot(b.x-a.x,b.y-a.y),angle=Math.atan2(b.y-a.y,b.x-a.x);
 const valid=g.distance>=4&&distance>=4;
 const turn=valid?Math.atan2(Math.sin(angle-g.angle),Math.cos(angle-g.angle)):0;
 const ay=a.y-g.a.y,by=b.y-g.b.y;
 const common=Math.sign(ay)===Math.sign(by)?Math.sign(ay)*Math.min(Math.abs(ay),Math.abs(by)):0;
 const tilt=Math.sign(common)*Math.max(0,Math.abs(common)-4),x=(a.x+b.x)/2;
 const result={turn,tilt:tilt-g.tilt,panX:x-g.x,zoomFactor:valid?g.distance/distance:1};
 g.angle=angle;g.distance=distance;g.tilt=tilt;g.x=x;
 return result;
}
