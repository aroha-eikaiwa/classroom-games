// One physical page renderer for preview, print, PDF and Word.
// A4 portrait, long-edge duplex: every card is [outside, inside].
// Landscape cover is bottom/upright; inside is turned 180 degrees.
// Portrait spreads turn +90 outside and -90 inside for the same printer settings.
const MM = 8, W = 210 * MM, H = 297 * MM;
const encoder = new TextEncoder();
const imageCache = new Map();
function image(src) {
  if (!imageCache.has(src)) imageCache.set(src, new Promise((resolve, reject) => {
    const img = new Image(); img.onload = () => resolve(img); img.onerror = () => { imageCache.delete(src); reject(Error('An image could not load. Please try again.')); }; img.src = src;
  }));
  return imageCache.get(src);
}
function fitText(ctx, value, x, y, width, size, {align='left', family='NH, Arial, sans-serif', style='', maxLines=2}={}) {
  if (!value) return;
  const wrap = () => {
    const lines = []; let line = '';
    for (const ch of Array.from(value)) {
      if (line && ctx.measureText(line + ch).width > width) { lines.push(line.trimEnd()); line = ''; }
      line += ch;
    }
    if (line) lines.push(line.trim()); return lines;
  };
  let lines;
  do { ctx.font = `${style} ${size}px ${family}`; lines = wrap(); if (lines.length <= maxLines) break; size *= .9; } while (size > 1);
  ctx.textAlign = align; ctx.textBaseline = 'top';
  lines.forEach((line, i) => ctx.fillText(line, x, y + i * size * 1.15));
}
async function drawCover(ctx, design, width, height) {
  const E = window.CardEditor, d = E.readDesign(design);
  ctx.save(); ctx.beginPath(); ctx.rect(0,0,width,height); ctx.clip();
  const footer = d.coverTo && !!d.to;
  const aw = width * (footer ? .9 : 1), ah = height * (footer ? .9 : 1);
  let motif;
  if (d.template !== 'plain') {
    motif = await image(new URL(`art/motif-${d.template}.svg`, import.meta.url).href);
    const scale = Math.min(width*.12/motif.width, height*.14/motif.height);
    const iw = motif.width*scale, ih = motif.height*scale;
    ctx.drawImage(motif,width*.97-iw,height*.97-ih,iw,ih);
  }
  ctx.save(); ctx.translate(footer ? width*.05 : 0, 0);
  ctx.beginPath();ctx.rect(0,0,aw,ah);ctx.clip();
  if (d.template !== 'plain') {
    const img = motif;
    const scale = Math.min(aw*.12/img.width, ah*.14/img.height), iw=img.width*scale, ih=img.height*scale;
    ctx.drawImage(img, aw*.03, ah*.03, iw, ih);
  }
  // Same stacking order as the editor: corner art, greeting, then student shapes.
  ctx.fillStyle = ({christmas:'#22593f',valentine:'#a44460',newyear:'#9b4c22',thanks:'#356566'})[d.template] || '#894035';
  fitText(ctx,E.templates[d.template].greeting,aw*.5,ah*.06,aw*.7,aw*.06,{align:'center',style:'italic bold',family:'Georgia, serif'});
  for (const piece of d.pieces) {
    const svg = E.shapeIcon(piece.shape,piece.color);
    svg.setAttribute('xmlns','http://www.w3.org/2000/svg');
    const src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(new XMLSerializer().serializeToString(svg));
    const img = await image(src), size=aw*piece.size/100;
    ctx.save();ctx.translate(aw*piece.x/100,ah*piece.y/100);ctx.rotate(piece.rotation*Math.PI/180);
    ctx.drawImage(img,-size/2,-size/2,size,size);ctx.restore();
  }
  ctx.restore();
  if (footer) {
    const recipient = E.coverRecipientLayout(d), size = width * recipient.size;
    ctx.fillStyle='#283f42';
    fitText(ctx,'To '+d.to,width*recipient.left,height*(1-recipient.bottom)-size*1.15,width*recipient.width,size,{maxLines:1});
  }
  ctx.restore();
}
function drawMessage(ctx, design, w, h) {
  ctx.fillStyle='#283f42';
  fitText(ctx,'To '+(design.to || '________________'),w*.1,h*.1,w*.8,w*.045);
  fitText(ctx,'From '+(design.from || '________________'),w*.9,h*.82,w*.8,w*.045,{align:'right'});
  ctx.strokeStyle='#929292';ctx.lineWidth=.22;
  const count=design.orientation==='portrait'?8:5;
  for(let i=1;i<=count;i++){const y=h*(.28+.5*i/count);ctx.beginPath();ctx.moveTo(w*.1,y);ctx.lineTo(w*.9,y);ctx.stroke();}
}
export async function renderSheet(design, side, label='') {
  await document.fonts.load('16px Arial'); await document.fonts.ready;
  const d=window.CardEditor.readDesign(design), portrait=d.orientation==='portrait';
  const canvas=document.createElement('canvas');canvas.width=W;canvas.height=H;
  const c=canvas.getContext('2d');c.scale(MM,MM);c.fillStyle='white';c.fillRect(0,0,210,297);
  c.save();c.translate(105,148.5);
  c.rotate((portrait?(side==='inside'?-90:90):(side==='inside'?180:0))*Math.PI/180);
  const sw=portrait?297:210, sh=portrait?210:297, pw=portrait?148.5:210, ph=portrait?210:148.5;
  c.translate(-sw/2,-sh/2);
  if(side==='outside') {
    c.save();
    if(!portrait){c.translate(pw,ph);c.rotate(Math.PI);}
    c.fillStyle='#666';fitText(c,label,pw/2,ph-16,pw-20,3.2,{align:'center',family:'Arial, sans-serif'});c.restore();
    c.save();c.translate(portrait?pw:0,portrait?0:ph);c.translate(pw*.05,ph*.05);
    await drawCover(c,d,pw*.9,ph*.9);c.restore();
  } else {
    c.save();c.translate(portrait?pw:0,portrait?0:ph);drawMessage(c,d,pw,ph);c.restore();
  }
  c.restore();c.strokeStyle='#aaa';c.lineWidth=.2;
  for(const x of [5,202]){c.beginPath();c.moveTo(x,148.5);c.lineTo(x+3,148.5);c.stroke();}
  return canvas;
}
const bytes = value => typeof value==='string'?encoder.encode(value):value;
function concat(parts){const out=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let offset=0;for(const p of parts){out.set(p,offset);offset+=p.length;}return out;}
function dataBytes(url){return Uint8Array.from(atob(url.split(',')[1]),c=>c.charCodeAt(0));}
export function pdfFile(pages) {
  const parts=[bytes('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n')], offsets=[0];let length=parts[0].length;
  const push=p=>{p=bytes(p);parts.push(p);length+=p.length;};
  const obj=(id,payload)=>{offsets[id]=length;push(`${id} 0 obj\n`);for(const p of payload)push(p);push('\nendobj\n');};
  obj(1,['<< /Type /Catalog /Pages 2 0 R >>']);
  obj(2,[`<< /Type /Pages /Count ${pages.length} /Kids [${pages.map((_,i)=>`${3+i*3} 0 R`).join(' ')}] >>`]);
  pages.forEach((page,i)=>{
    const id=3+i*3, jpg=dataBytes(page.jpg);
    obj(id,[`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.27559 841.88976] /Resources << /XObject << /Im ${id+1} 0 R >> >> /Contents ${id+2} 0 R >>`]);
    obj(id+1,[`<< /Type /XObject /Subtype /Image /Width ${W} /Height ${H} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`,jpg,'\nendstream']);
    const commands=bytes('q 595.27559 0 0 841.88976 0 0 cm /Im Do Q\n');obj(id+2,[`<< /Length ${commands.length} >>\nstream\n`,commands,'endstream']);
  });
  const start=length;push(`xref\n0 ${offsets.length}\n0000000000 65535 f \n`);for(const offset of offsets.slice(1))push(`${String(offset).padStart(10,'0')} 00000 n \n`);
  push(`trailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n${start}\n%%EOF`);return new Blob(parts,{type:'application/pdf'});
}
function crc32(data){let crc=-1;for(const b of data){crc^=b;for(let j=0;j<8;j++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^-1)>>>0;}
function zip(files){
  const local=[], central=[];let offset=0;
  for(const [path,value] of Object.entries(files)){
    const name=bytes(path),data=bytes(value),crc=crc32(data);
    const header=new Uint8Array(30),v=new DataView(header.buffer);
    v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,name.length,true);
    local.push(header,name,data);
    const entry=new Uint8Array(46),e=new DataView(entry.buffer);e.setUint32(0,0x02014b50,true);e.setUint16(4,20,true);e.setUint16(6,20,true);e.setUint32(16,crc,true);e.setUint32(20,data.length,true);e.setUint32(24,data.length,true);e.setUint16(28,name.length,true);e.setUint32(42,offset,true);
    central.push(entry,name);offset+=header.length+name.length+data.length;
  }
  const size=central.reduce((n,p)=>n+p.length,0),end=new Uint8Array(22),e=new DataView(end.buffer);
  e.setUint32(0,0x06054b50,true);e.setUint16(8,Object.keys(files).length,true);e.setUint16(10,Object.keys(files).length,true);e.setUint32(12,size,true);e.setUint32(16,offset,true);
  return concat([...local,...central,end]);
}
export function wordFile(pages){
  const ns='http://schemas.openxmlformats.org',files={
    '[Content_Types].xml':`<Types xmlns="${ns}/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>`,
    '_rels/.rels':`<Relationships xmlns="${ns}/package/2006/relationships"><Relationship Id="rId1" Type="${ns}/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`
  };
  files['word/_rels/document.xml.rels']=`<Relationships xmlns="${ns}/package/2006/relationships">${pages.map((_,i)=>`<Relationship Id="rId${i+1}" Type="${ns}/officeDocument/2006/relationships/image" Target="media/page${i+1}.png"/>`).join('')}</Relationships>`;
  // Page-relative floating image avoids paragraph spacing changing the imposition.
  files['word/document.xml']=`<w:document xmlns:w="${ns}/wordprocessingml/2006/main" xmlns:r="${ns}/officeDocument/2006/relationships" xmlns:wp="${ns}/drawingml/2006/wordprocessingDrawing" xmlns:a="${ns}/drawingml/2006/main" xmlns:pic="${ns}/drawingml/2006/picture"><w:body>${pages.map((_,i)=>`<w:p><w:pPr>${i?'<w:pageBreakBefore/>':''}<w:spacing w:before="0" w:after="0" w:line="20" w:lineRule="exact"/></w:pPr><w:r><w:drawing><wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0" relativeHeight="0" behindDoc="0" locked="0" layoutInCell="1" allowOverlap="1"><wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="page"><wp:posOffset>0</wp:posOffset></wp:positionH><wp:positionV relativeFrom="page"><wp:posOffset>0</wp:posOffset></wp:positionV><wp:extent cx="7560000" cy="10692000"/><wp:wrapNone/><wp:docPr id="${i+1}" name="Card page ${i+1}"/><a:graphic><a:graphicData uri="${ns}/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="${i+1}" name="page${i+1}.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rId${i+1}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="7560000" cy="10692000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r></w:p>`).join('')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="0" w:right="0" w:bottom="0" w:left="0" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr></w:body></w:document>`;
  pages.forEach((p,i)=>files[`word/media/page${i+1}.png`]=dataBytes(p.png));
  return new Blob([zip(files)],{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});
}
function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}
export function openExport(cards,locale='en',initialMode='duplex') {
  const t=(en,ja)=>locale==='ja'?ja:en;
  const d=document.createElement('dialog');d.className='card-export';
  d.innerHTML=`<header><h2>${t('Print / save card','カードを印刷・保存')}</h2><button data-close aria-label="${t('Close','閉じる')}">×</button></header><p data-print-settings>${t('A4 · Portrait · Actual size (100%) · Double-sided: flip on LONG edge. Turn off browser headers and footers. Fold at the small marks.','A4・縦・実際のサイズ（100%）・両面印刷「長辺とじ」。ブラウザーのヘッダーとフッターをオフにし、小さな印で半分に折ります。')}</p><p>${t('The print preview below shows the flat paper. Some panels are intentionally upside down so the folded card reads correctly. Test one card before printing a class.','下の印刷プレビューは折る前の用紙です。折ったときに正しい向きになるよう、一部の面を逆さに配置しています。クラス全員分を印刷する前に、1枚試してください。')}</p><label>${t('Pages','印刷する面')} <select><option value="duplex">${t('Outside + inside (double-sided)','外面＋中面（両面）')}</option><option value="outside">${t('Outside only','外面のみ')}</option><option value="inside">${t('Inside only','中面のみ')}</option></select></label><p data-manual hidden>${t('Single-sided pass: turn duplex OFF. For manual duplex, paper refeeding and stack order depend on your printer; test one card and match the fold marks.','片面ずつ印刷する場合は両面印刷をオフにします。用紙を戻す向きと順番はプリンターによって異なるので、1枚試して折り目の印を合わせてください。')}</p><div class="card-export-actions"><button data-format="print">${t('Print…','印刷…')}</button><button data-format="pdf">${t('Download PDF','PDFを保存')}</button><button data-format="word">${t('Download Word (.docx)','Word（.docx）を保存')}</button></div><p class="card-export-status" role="status"></p><div class="card-export-preview"></div>`;
  document.body.append(d);d.showModal();
  let generation=0,ready=[],readyMode='',busy=false;
  const status=d.querySelector('[role=status]'),select=d.querySelector('select'),preview=d.querySelector('.card-export-preview'),buttons=[...d.querySelectorAll('[data-format]')];
  const enable=value=>buttons.forEach(b=>b.disabled=!value);
  const close=()=>d.close();d.querySelector('[data-close]').onclick=close;
  d.addEventListener('click',e=>{if(e.target===d)close();});d.addEventListener('close',()=>{generation++;d.remove();},{once:true});
  async function prepare(){
    const current=++generation,mode=select.value;enable(false);ready=[];preview.replaceChildren();status.textContent=t('Preparing printable pages…','印刷用のページを準備中…');
    d.querySelector('[data-manual]').hidden=mode==='duplex';
    d.querySelector('[data-print-settings]').textContent = mode==='duplex'
      ? t('A4 · Portrait · Actual size (100%) · Double-sided: flip on LONG edge. Turn off browser headers and footers. Fold at the small marks.','A4・縦・実際のサイズ（100%）・両面印刷「長辺とじ」。ブラウザーのヘッダーとフッターをオフにし、小さな印で半分に折ります。')
      : t('A4 · Portrait · Actual size (100%) · Single-sided. Turn off browser headers and footers.','A4・縦・実際のサイズ（100%）・片面印刷。ブラウザーのヘッダーとフッターをオフにします。');
    try {
      const pages=[];
      for(const card of cards) for(const side of ['outside','inside']){
        if(mode!=='duplex'&&mode!==side)continue;
        const page=await renderSheet(card.design,side,card.label||'');if(current!==generation)return;pages.push({png:page.toDataURL('image/png'),jpg:page.toDataURL('image/jpeg',.96)});
        // Keep a bounded visual preview for large class exports.
        if(pages.length<=4){const figure=document.createElement('figure'),caption=document.createElement('figcaption');caption.textContent=`${pages.length}. ${side==='outside'?t('Outside','外面'):t('Inside','中面')} ${card.label||''}`;figure.append(caption,page);preview.append(figure);} else {page.width=1;page.height=1;}
        await new Promise(resolve=>requestAnimationFrame(resolve));
      }
      ready=pages;readyMode=mode;status.textContent=t(`${cards.length} card(s) · ${pages.length} pages. Word preserves the print layout as images.`,`${cards.length}枚のカード・${pages.length}ページ。Wordはレイアウトを保つため画像で保存します。`);enable(!!pages.length);
    }catch(e){status.textContent=t('Could not prepare the card. Close this window and try again.','カードを準備できませんでした。この画面を閉じて、もう一度試してください。');}
  }
  select.value = ['duplex','outside','inside'].includes(initialMode)?initialMode:'duplex';
  select.onchange=prepare;
  buttons.forEach(b=>b.onclick=async()=>{
    if(busy||!ready.length)return;busy=true;enable(false);select.disabled=true;
    try{
      if(b.dataset.format==='pdf')download(pdfFile(ready),`Greeting_Cards_${readyMode}.pdf`);
      else if(b.dataset.format==='word')download(wordFile(ready),`Greeting_Cards_${readyMode}.docx`);
      else {
        // Print a separate document so an open modal or application CSS cannot hide cards.
        const frame=document.createElement('iframe');frame.className='card-print-frame';frame.title='Printable cards';document.body.append(frame);
        const doc=frame.contentDocument;doc.open();doc.write('<!doctype html><html><head><title>Greeting Cards</title><style>@page{size:A4 portrait;margin:0}html,body{margin:0;padding:0}img{display:block;width:210mm;height:297mm;break-after:page}img:last-child{break-after:auto}</style></head><body></body></html>');doc.close();
        for(const page of ready){const img=doc.createElement('img');img.src=page.png;doc.body.append(img);await img.decode();}
        const clean=()=>frame.remove();frame.contentWindow.addEventListener('afterprint',clean,{once:true});setTimeout(clean,300000);
        frame.contentWindow.focus();frame.contentWindow.print();
      }
    }catch(e){status.textContent=t('Export failed. Please try again.','保存・印刷できませんでした。もう一度試してください。');}
    finally{busy=false;select.disabled=false;enable(true);}
  });
  prepare();return d;
}
