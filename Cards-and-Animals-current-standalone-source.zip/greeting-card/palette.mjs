export const colors = Object.freeze({
  red: "#e54440", blue: "#2873bd", green: "#308149", yellow: "#ffce31",
  pink: "#ef87af", black: "#252837", white: "#fffdf6",
  orange: "#ef842e", purple: "#9461bc", brown: "#956040"
});

export function isCardColor(value) {
  return typeof value === "string" && (Object.hasOwn(colors, value) || /^#[0-9a-f]{6}$/.test(value));
}

// Give custom shades a familiar English name for the spoken request.
const examples = {...colors, grey: "#888888", teal: "#008080", turquoise: "#40e0d0",
  cyan: "#00ffff", lime: "#aaff00", navy: "#000080", lavender: "#decaf2",
  maroon: "#800000", beige: "#e7d7b7", gold: "#ffd700", magenta: "#ff00ff",
  "light blue": "#a3d9ff", "light green": "#a5e6ad", "dark green": "#174328"};
const channels = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
const samples = Object.entries(examples).map(([name, hex]) => [name, channels(hex)]);

export function colorName(value) {
  if (Object.hasOwn(colors, value)) return value;
  const [r, g, b] = channels(value);
  let best = "grey", distance = Infinity;
  for (const [name, [sr, sg, sb]] of samples) {
    const d = (r - sr) ** 2 + (g - sg) ** 2 + (b - sb) ** 2;
    if (d < distance) { best = name; distance = d; }
  }
  return best;
}
