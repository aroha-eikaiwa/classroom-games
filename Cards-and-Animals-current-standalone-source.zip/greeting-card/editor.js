import {colors, isCardColor, colorName} from "./palette.mjs";
(() => {
  "use strict";

  const templates = {
    plain: { en: "Plain white", ja: "白紙", greeting: "" },
    christmas: { en: "Christmas", ja: "クリスマス", greeting: "Merry Christmas!" },
    valentine: { en: "Valentine’s Day", ja: "バレンタイン", greeting: "Happy Valentine’s Day!" },
    newyear: { en: "New Year", ja: "お正月", greeting: "Happy New Year!" },
    thanks: { en: "Thank you", ja: "ありがとう", greeting: "Thank you!" }
  };
  const shapes = {
    circle: ["circle", { cx: 50, cy: 50, r: 48.5 }],
    triangle: ["polygon", { points: "50,3 99,92 1,92" }],
    heart: ["path", { d: "M50 94C41 85 2 60 2 30C2 4 34 -4 50 19C66 -4 98 4 98 30C98 60 59 85 50 94Z" }],
    star: ["polygon", { points: "50,2 62,35 98,36 70,58 80,94 50,73 20,94 30,58 2,36 38,35" }],
    square: ["rect", { x: 2, y: 2, width: 96, height: 96 }],
    rectangle: ["rect", { x: 1.5, y: 19.5, width: 97, height: 61 }],
    diamond: ["polygon", { points: "50,1.5 88.5,50 50,98.5 11.5,50" }]
  };
  const marks = {
    shop: "M3 10l2-6h14l2 6M4 10v9h16v-9M8 19v-5h4v5M3 10q2 4 4 0q2 4 5 0q3 4 5 0q2 4 4 0",
    card: "M3 5h18v14H3zM3 6l9 7 9-7",
    tag: "M3 7v10h18V7zM6 11h4m-4 3h8",
    minus: "M5 12h14", plus: "M5 12h14m-7-7v14",
    left: "M4 4v6h6M4 10a8 8 0 1 1 0 6",
    right: "M20 4v6h-6m6 0a8 8 0 1 0 0 6",
    front: "M8 8h12v12H8zM5 16H3V3h13v2",
    back: "M4 4h12v12H4zM19 8h2v13H8v-2",
    remove: "M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7",
    resize: "M5 19L19 5m-7 0h7v7M5 12v7h7",
    down: "M6 9l6 6 6-6", close: "M6 6l12 12M18 6L6 18",
    undo: "M8 4L3 9l5 5M4 9h10a6 6 0 1 1 0 12",
    redo: "M16 4l5 5-5 5m4-5h-10a6 6 0 1 0 0 12"
  };
  const svgNS = "http://www.w3.org/2000/svg";
  const artBase = new URL("art/", import.meta.url);
  const copy = value => JSON.parse(JSON.stringify(value));
  const clamp = (value, low, high) => Math.max(low, Math.min(value, high));
  const round = value => Math.round(value * 100) / 100;
  const angle = degrees => round(((degrees % 360) + 360) % 360);
  const number = (value, fallback) => Number.isFinite(Number(value)) ? Number(value) : fallback;
  const makeId = () => globalThis.crypto?.randomUUID?.() || "s" + Date.now().toString(36) + Math.random().toString(36).slice(2);
  const cleanName = value => typeof value === "string" ? value.slice(0, 60) : "";

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text) node.textContent = text;
    return node;
  }
  function vector(tag, attrs) {
    const node = document.createElementNS(svgNS, tag);
    for (const [name, value] of Object.entries(attrs)) node.setAttribute(name, value);
    return node;
  }
  function icon(name) {
    const node = vector("svg", {viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.8", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true"});
    node.append(vector("path", {d: marks[name]}));
    return node;
  }
  function cutout(shape, color) {
    const node = vector("svg", {viewBox: "0 0 100 100", "aria-hidden": "true", class: "gc-cutout"});
    const [tag, attrs] = shapes[shape];
    node.append(vector(tag, {...attrs, fill: colors[color] ?? color, stroke: colorName(color) === "white" ? "#a9a69e" : "#312a271a", "stroke-width": 1.5, "stroke-linejoin": "round"}));
    return node;
  }
  function readDesign(state = {}) {
    const seen = new Set();
    const pieces = [];
    for (const p of Array.isArray(state.pieces) ? state.pieces : []) {
      if (!p || !Object.hasOwn(shapes, p.shape) || !isCardColor(p.color)) continue;
      const id = typeof p.id === "string" && p.id && !seen.has(p.id) ? p.id : makeId();
      seen.add(id);
      pieces.push({id, shape: p.shape, color: p.color, x: clamp(number(p.x, 50), 0, 100), y: clamp(number(p.y, 50), 0, 100),
        size: clamp(number(p.size, 14), 3, 65), rotation: angle(number(p.rotation, 0))});
    }
    return {template: Object.hasOwn(templates, state.template) ? state.template : "plain", orientation: state.orientation === "portrait" ? "portrait" : "landscape", pieces, to: cleanName(state.to), from: cleanName(state.from), coverTo: state.coverTo !== false};
  }
  // All current illustrated templates decorate the lower-right corner.
  // Reserve that corner; plain cards may use the full footer width.
  function coverRecipientLayout(design) {
    const text = "To " + (design.to || "");
    const width = design.template === "plain" ? .94 : .77;
    const units = Array.from(text).reduce((n, c) => n + (c.charCodeAt(0) < 128 ? .65 : 1.1), 0);
    return {left:.03, bottom:.03, width, size:Math.min(.033, width / Math.max(1, units))};
  }
  function updatePaper(card, design) {
    card.dataset.template = design.template;
    card.dataset.orientation = design.orientation;
    for (const corner of ["first", "last"]) {
      const cls = "gc-motif-" + corner;
      let motif = card.querySelector("." + cls);
      if (design.template === "plain") {
        motif?.remove();
        continue;
      }
      if (!motif) {
        motif = el("img", "gc-motif " + cls);
        motif.alt = "";
        motif.draggable = false;
        if (corner === "last") card.insertBefore(motif, card.querySelector(".gc-artwork"));
        else card.querySelector(".gc-artwork").insertBefore(motif, card.querySelector(".gc-greeting"));
      }
      motif.src = new URL("motif-" + design.template + ".svg", artBase).href;
    }
    card.querySelector(".gc-greeting").textContent = templates[design.template].greeting;
    const names = card.querySelector(".gc-signature");
    names.replaceChildren();
    card.dataset.coverTo = String(design.coverTo && !!design.to);
    const recipient = coverRecipientLayout(design);
    names.style.left = recipient.left * 100 + "%";
    names.style.width = recipient.width * 100 + "%";
    names.style.fontSize = recipient.size * 100 + "cqw";
    if (design.coverTo && design.to) names.append(el("span", "", "To " + design.to));
  }
  function position(node, piece) {
    node.style.left = piece.x + "%";
    node.style.top = piece.y + "%";
    node.style.width = piece.size + "%";
    node.style.setProperty("--gc-rotation", piece.rotation + "deg");
  }
  function cardBase(design) {
    const card = el("div", "gc-card");
    const artwork = el("div", "gc-artwork");
    artwork.append(el("div", "gc-greeting"), el("div", "gc-pieces"));
    card.append(artwork, el("div", "gc-signature"));
    updatePaper(card, design);
    return card;
  }
  function renderCard(state = {}) {
    const design = readDesign(state);
    const card = cardBase(design);
    card.setAttribute("role", "img");
    card.setAttribute("aria-label", [templates[design.template].greeting || templates.plain.en, design.to && "To " + design.to, ].filter(Boolean).join(" "));
    const layer = card.querySelector(".gc-pieces");
    for (const piece of design.pieces) {
      const stamp = el("div", "gc-stamp");
      stamp.append(cutout(piece.shape, piece.color));
      position(stamp, piece);
      layer.append(stamp);
    }
    return card;
  }

  function renderInside(state = {}) {
    const design = readDesign(state);
    const spread = el("div", "gc-inside");
    spread.dataset.orientation = design.orientation;
    const blank = el("div", "gc-inside-blank");
    blank.setAttribute("aria-label", "Blank inside panel");
    const message = el("div", "gc-message");
    const names = [el("div", "gc-inside-to", "To " + (design.to || "________________")), el("div", "gc-inside-from", "From " + (design.from || "________________"))];
    const lines = el("div", "gc-message-lines");
    for (let i = 0; i < (design.orientation === "portrait" ? 8 : 5); i++) lines.append(el("span"));
    for (const name of names) name.style.fontSize = Math.min(4.5, 140 / Array.from(name.textContent).length) + "cqw";
    message.append(names[0], lines, names[1]);
    spread.append(blank, message);
    return spread;
  }

  function mount(root, options) {
    const {state = {}, locale = "en", onChange, onShop} = options;
    const t = (en, ja) => locale === "ja" ? ja : en;
    const controller = new AbortController();
    const listen = (node, event, callback) => node.addEventListener(event, callback, {signal: controller.signal});
    const stock = Object.fromEntries(Object.entries(state.stock || {}).filter(([key, value]) => {
      const [shape, color, extra] = key.split(":");
      return !extra && Object.hasOwn(shapes, shape) && isCardColor(color) && Number.isSafeInteger(Number(value)) && Number(value) > 0;
    }));
    let design = readDesign(state);
    let selected = null;
    let gesture = null;
    let dialog = null;
    const previous = [];
    const next = [];
    const stamps = new Map();
    const shell = el("section", "gc-editor");
    shell.setAttribute("aria-label", t("Card designer", "カードづくり"));
    const header = el("div", "gc-editor-header");
    const body = el("div", "gc-editor-body");
    const tray = el("aside", "gc-tray");
    const trayHead = el("h3", "", t("My shapes", "もっている形"));
    const inventory = el("div", "gc-inventory");
    const surface = el("div", "gc-surface");
    const card = cardBase(design);
    card.classList.add("gc-interactive");
    card.tabIndex = 0;
    card.setAttribute("role", "group");
    card.setAttribute("aria-label", t("Your card. Use arrow keys to move a selected shape.", "カード。選んだ形は矢印キーでも動かせます。"));
    const layer = card.querySelector(".gc-pieces");
    const toolbar = el("div", "gc-toolbar");
    const status = el("span", "gc-sr");
    status.setAttribute("aria-live", "polite");
    const controls = new Map();
    const button = (title, mark, action, cls = "", label = "") => {
      const b = el("button", "gc-btn " + cls);
      b.type = "button";
      b.title = title;
      b.setAttribute("aria-label", title);
      if (mark) b.append(icon(mark));
      if (label) b.append(el("span", "", label));
      listen(b, "click", action);
      return b;
    };
    const findPiece = () => design.pieces.find(p => p.id === selected);
    const announce = message => { status.textContent = message; };
    function save(before) {
      if (JSON.stringify(design) === JSON.stringify(before)) return;
      previous.push(before);
      if (previous.length > 40) previous.shift();
      next.length = 0;
      refreshControls();
      onChange?.(copy(design));
    }
    function edit(change) {
      const before = copy(design);
      change();
      save(before);
    }
    function history(back) {
      const source = back ? previous : next;
      const target = back ? next : previous;
      if (!source.length) return;
      target.push(copy(design));
      design = source.pop();
      if (!findPiece()) selected = null;
      repaint();
      onChange?.(copy(design));
    }
    function select(id) {
      selected = id;
      for (const [key, stamp] of stamps) {
        const active = key === id;
        stamp.classList.toggle("gc-picked", active);
        stamp.setAttribute("aria-pressed", String(active));
      }
      refreshControls();
    }
    function refreshControls() {
      const current = findPiece();
      for (const [key, b] of controls) {
        if (key === "undo" || key === "redo") {
          b.disabled = !(key === "undo" ? previous : next).length;
        } else {
          b.disabled = !current ||
            (key === "front" && current === design.pieces.at(-1)) ||
            (key === "back" && current === design.pieces[0]) ||
            (key === "larger" && current.size >= 65) ||
            (key === "smaller" && current.size <= 3);
        }
      }
    }
    function add(shape, color) {
      const count = design.pieces.filter(p => p.shape === shape && p.color === color).length;
      if (count >= Number(stock[shape + ":" + color] || 0)) return;
      const offset = (design.pieces.length % 5 - 2) * 3;
      const p = {id: makeId(), shape, color, x: 50 + offset, y: 50 + offset, size: 14, rotation: 0};
      edit(() => { design.pieces.push(p); selected = p.id; paintPieces(); paintTray(); });
      stamps.get(p.id)?.focus({preventScroll: true});
      announce(t("Added " + colorName(color) + " " + shape, colorName(color) + " " + shape + " をおきました"));
    }
    function paintTray() {
      inventory.replaceChildren();
      const counts = {};
      for (const p of design.pieces) {
        const key = p.shape + ":" + p.color;
        counts[key] = (counts[key] || 0) + 1;
      }
      if (!Object.keys(stock).length) inventory.append(el("p", "gc-empty", t("Get shapes from a shop to start your card.", "お店で形をもらって、カードを作ろう。")));
      for (const [key, total] of Object.entries(stock)) {
        const [shape, color] = key.split(":");
        const count = Math.max(0, Number(total) - (counts[key] || 0));
        const tile = el("button", "gc-tile");
        tile.type = "button";
        tile.disabled = !count;
        tile.dataset.stockKey = key;
        const label = colorName(color) + " " + shape;
        tile.title = color.startsWith("#") ? label + " (" + color + ")" : label;
        tile.setAttribute("aria-label", t("Add " + tile.title + ", " + count + " left", tile.title + " をおく。のこり " + count + " こ"));
        tile.append(cutout(shape, color), el("span", "gc-count", "×" + count), el("span", "gc-tile-name", label));
        inventory.append(tile);
      }
    }
    listen(inventory, "click", event => {
      const tile = event.target.closest("[data-stock-key]");
      if (tile && !tile.disabled) add(...tile.dataset.stockKey.split(":"));
    });
    function paintPieces() {
      layer.replaceChildren();
      stamps.clear();
      for (const p of design.pieces) {
        const stamp = el("div", "gc-stamp");
        stamp.dataset.piece = p.id;
        stamp.setAttribute("role", "button");
        stamp.tabIndex = 0;
        stamp.setAttribute("aria-label", colorName(p.color) + " " + p.shape);
        stamp.append(cutout(p.shape, p.color));
        for (const [mode, mark] of [["rotate","right"], ["resize","resize"]]) {
          const handle = el("span", "gc-handle gc-" + mode);
          handle.dataset.handle = mode;
          handle.setAttribute("aria-hidden", "true");
          handle.append(icon(mark));
          stamp.append(handle);
        }
        position(stamp, p);
        stamps.set(p.id, stamp);
        layer.append(stamp);
      }
      select(selected);
    }
    function applyTool(key) {
      const p = findPiece();
      if (!p) return;
      edit(() => {
        if (key === "remove") {
          design.pieces = design.pieces.filter(piece => piece !== p);
          selected = null;
          paintPieces();
          paintTray();
          announce(t("Shape returned to My shapes.", "形をもどしました。"));
        } else if (key === "front" || key === "back") {
          design.pieces.splice(design.pieces.indexOf(p), 1);
          if (key === "front") design.pieces.push(p);
          else design.pieces.unshift(p);
          paintPieces();
        } else {
          if (key === "larger" || key === "smaller") p.size = clamp(round(p.size * (key === "larger" ? 1.18 : 1 / 1.18)), 3, 65);
          if (key === "left" || key === "right") p.rotation = angle(p.rotation + (key === "left" ? -15 : 15));
          position(stamps.get(p.id), p);
        }
      });
    }

    const templateLabel = el("span");
    const templateButton = button(t("Choose a card", "カードをえらぶ"), "card", openTemplates, "gc-template-trigger");
    templateButton.append(templateLabel, icon("down"));
    const namesButton = button(t("Write To and From", "あて名と名前を書く"), "tag", openNames, "", t("To / From", "あて名・名前"));
    const orientationButton = button(t("Change card orientation", "カードの向きを変える"), null, () => {
      edit(() => {
        design.orientation = design.orientation === "portrait" ? "landscape" : "portrait";
        repaint();
      });
    }, "gc-orientation");
    const orientationIcon = el("span", "gc-orientation-icon");
    orientationIcon.setAttribute("aria-hidden", "true");
    const orientationLabel = el("span", "gc-orientation-label");
    orientationButton.append(orientationIcon, orientationLabel);
    const historyButtons = el("div", "gc-history");
    for (const [key, label] of [["undo", t("Undo", "もとにもどす")], ["redo", t("Redo", "やりなおす")]]) {
      const b = button(label, key, () => history(key === "undo"));
      controls.set(key, b);
      historyButtons.append(b);
    }
    header.append(templateButton, orientationButton, namesButton, historyButtons);
    tray.append(trayHead, inventory);
    if (onShop) {
      const title = t("Go to shop", "お店へ");
      tray.append(button(title, "shop", onShop, "gc-shop", title));
    }
    for (const [caption, entries] of [
      [t("Size", "大きさ"), [["smaller", "minus", t("Make smaller", "小さく")], ["larger", "plus", t("Make bigger", "大きく")]]],
      [t("Rotate", "回す"), [["left", "left", t("Rotate left", "左へ回す")], ["right", "right", t("Rotate right", "右へ回す")]]],
      [t("Layer", "重なり"), [["back", "back", t("Send to back", "一番うしろへ")], ["front", "front", t("Bring to front", "一番前へ")]]],
      [t("Remove", "もどす"), [["remove", "remove", t("Return shape to tray", "形をもどす")]]]
    ]) {
      const group = el("div", "gc-tool-group");
      const buttons = el("div", "gc-tool-buttons");
      for (const [key, mark, label] of entries) {
        const b = button(label, mark, () => applyTool(key));
        controls.set(key, b);
        buttons.append(b);
      }
      group.append(buttons, el("span", "gc-tool-label", caption));
      toolbar.append(group);
    }
    surface.append(card);
    body.append(tray, surface);
    shell.append(header, body, toolbar, status);
    root.replaceChildren(shell);

    function setTemplateLabel() {
      const portrait = design.orientation === "portrait";
      const direction = portrait ? t("Portrait", "縦向き") : t("Landscape", "横向き");
      orientationLabel.textContent = direction;
      orientationButton.dataset.orientation = design.orientation;
      orientationButton.setAttribute("aria-label", direction + " · " + t("Change card orientation", "カードの向きを変える"));
      templateLabel.textContent = templates[design.template][locale === "ja" ? "ja" : "en"];
    }
    function repaint() {
      updatePaper(card, design);
      setTemplateLabel();
      paintPieces();
      paintTray();
    }
    function popup(title, anchor) {
      if (dialog) return null;
      dialog = el("dialog", "gc-popup");
      const current = dialog;
      const contents = el("div", "gc-pop-content");
      const heading = el("h2", "", title);
      current.setAttribute("aria-label", title);
      const close = button(t("Close", "閉じる"), "close", () => current.close(), "gc-pop-close");
      contents.append(heading, close);
      current.append(contents);
      shell.append(current);
      current.addEventListener("close", () => {
        current.remove();
        dialog = null;
        anchor.focus({preventScroll: true});
      }, {once: true});
      current.addEventListener("click", e => { if (e.target === current) current.close(); });
      return {current, contents};
    }
    function openTemplates() {
      const view = popup(t("Choose a card", "カードをえらぶ"), templateButton);
      if (!view) return;
      const grid = el("div", "gc-choices");
      for (const [key, details] of Object.entries(templates)) {
        const choice = el("button", "gc-choice");
        const label = details[locale === "ja" ? "ja" : "en"];
        choice.type = "button";
        choice.setAttribute("aria-pressed", String(design.template === key));
        choice.setAttribute("aria-label", label);
        choice.append(renderCard({template: key}), el("span", "gc-choice-label", label));
        choice.addEventListener("click", () => {
          edit(() => { design.template = key; updatePaper(card, design); setTemplateLabel(); });
          view.current.close();
        });
        grid.append(choice);
      }
      view.contents.append(grid);
      view.current.showModal();
    }
    function openNames() {
      const view = popup(t("To / From", "あて名・名前"), namesButton);
      if (!view) return;
      const form = el("form", "gc-name-form");
      for (const [key, label] of [["to", t("To", "To（おくる相手）")], ["from", t("From", "From（自分の名前）")]]) {
        const field = el("label", "", label);
        const input = el("input");
        input.name = key;
        input.type = "text";
        input.maxLength = 60;
        input.value = design[key];
        input.autocomplete = "off";
        field.append(input);
        form.append(field);
      }
      const note = el("p", "", t("To and From appear inside the card.", "To と From はカードの中面に入ります。"));
      const coverLabel = el("label", "gc-cover-option");
      const coverToggle = el("input");
      coverToggle.type = "checkbox"; coverToggle.name = "coverTo"; coverToggle.checked = design.coverTo;
      coverLabel.append(coverToggle, document.createTextNode(t("Also show To below the cover design", "表紙の絵の下にも To を入れる")));
      form.append(note, coverLabel);
      const done = el("button", "gc-btn gc-done", t("Done", "できた"));
      done.type = "submit";
      form.append(done);
      form.addEventListener("submit", event => {
        event.preventDefault();
        edit(() => {
          design.to = form.elements.to.value.trim();
          design.from = form.elements.from.value.trim();
          design.coverTo = form.elements.coverTo.checked;
          updatePaper(card, design);
        });
        view.current.close();
      });
      view.contents.append(form);
      view.current.showModal();
    }

    function endGesture(event) {
      if (!gesture || (event && event.pointerId !== gesture.pointerId)) return;
      const {before, pointerId} = gesture;
      gesture = null;
      if (card.hasPointerCapture(pointerId)) card.releasePointerCapture(pointerId);
      save(before);
    }
    listen(card, "pointerdown", event => {
      if (gesture || event.button !== 0) return;
      const stamp = event.target.closest("[data-piece]");
      if (!stamp) { select(null); return; }
      event.preventDefault();
      const mode = event.target.closest("[data-handle]")?.dataset.handle || "move";
      select(stamp.dataset.piece);
      stamp.focus({preventScroll: true});
      const p = findPiece();
      const rect = layer.getBoundingClientRect();
      const cx = rect.left + p.x * rect.width / 100;
      const cy = rect.top + p.y * rect.height / 100;
      gesture = {before: copy(design), mode, p, pointerId: event.pointerId, rect, start: {...p}, x: event.clientX, y: event.clientY, cx, cy,
        radius: Math.max(1, Math.hypot(event.clientX - cx, event.clientY - cy)), bearing: Math.atan2(event.clientY - cy, event.clientX - cx)};
      card.setPointerCapture(event.pointerId);
    });
    listen(card, "pointermove", event => {
      if (!gesture || event.pointerId !== gesture.pointerId) return;
      const {p, start, rect, x, y, mode, cx, cy, radius, bearing} = gesture;
      if (mode === "resize") {
        p.size = round(clamp(start.size * Math.hypot(event.clientX - cx, event.clientY - cy) / radius, 3, 65));
      } else if (mode === "rotate") {
        p.rotation = angle(start.rotation + (Math.atan2(event.clientY - cy, event.clientX - cx) - bearing) * 180 / Math.PI);
      } else {
        p.x = round(clamp(start.x + (event.clientX - x) * 100 / rect.width, 0, 100));
        p.y = round(clamp(start.y + (event.clientY - y) * 100 / rect.height, 0, 100));
      }
      position(stamps.get(p.id), p);
      refreshControls();
    });
    for (const event of ["pointerup", "pointercancel", "lostpointercapture"]) listen(card, event, endGesture);
    listen(card, "focusin", event => { if (event.target.dataset.piece) select(event.target.dataset.piece); });
    listen(shell, "keydown", event => {
      if (dialog || gesture || event.isComposing || event.target.matches("input,textarea")) return;
      const key = event.key;
      if ((event.ctrlKey || event.metaKey) && ["z", "y"].includes(key.toLowerCase())) {
        event.preventDefault();
        history(key.toLowerCase() === "z" && !event.shiftKey);
        return;
      }
      if (!card.contains(event.target)) return;
      const p = findPiece();
      if (!p) return;
      const delta = event.shiftKey ? 5 : 1;
      const arrows = {ArrowUp:[0,-delta], ArrowDown:[0,delta], ArrowLeft:[-delta,0], ArrowRight:[delta,0]};
      if (Object.hasOwn(arrows, key)) {
        event.preventDefault();
        const [dx, dy] = arrows[key];
        edit(() => { p.x = round(clamp(p.x + dx, 0, 100)); p.y = round(clamp(p.y + dy, 0, 100)); position(stamps.get(p.id), p); });
      } else {
        const keys = {Delete:"remove", Backspace:"remove", "+":"larger", "=":"larger", "-":"smaller", "[":"left", "]":"right"};
        if (Object.hasOwn(keys, key)) {
          event.preventDefault();
          applyTool(keys[key]);
          if (keys[key] === "remove") card.focus({preventScroll: true});
        }
      }
    });
    repaint();
    return () => {
      endGesture();
      controller.abort();
      if (dialog?.open) dialog.close();
      if (root.contains(shell)) shell.remove();
    };
  }
  window.CardEditor = {readDesign, templates, coverRecipientLayout, mount, renderCard, renderInside, shapeIcon: cutout, colors: Object.freeze(colors)};
})();
