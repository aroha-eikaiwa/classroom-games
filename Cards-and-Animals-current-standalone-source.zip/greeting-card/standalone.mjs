import './editor.js';
import {colors} from './palette.mjs';
import {openExport} from './card-export.js';
const stock = Object.fromEntries(['circle','triangle','heart','star','square','rectangle','diamond'].flatMap(s=>Object.keys(colors).map(c=>[s+':'+c,20])));
let design = {};
let cleanup;
const language = document.getElementById('language');
function mount(){
  cleanup?.();
  document.documentElement.lang = language.value;
  cleanup = window.CardEditor.mount(document.getElementById('editor'), {
    state:{...design,stock}, locale:language.value, onChange:current=>{design=current;},
  });
}
language.addEventListener('change',mount);
document.getElementById('export').addEventListener('click',()=>openExport([{design}],language.value));
mount();
