# Aroha Eikaiwa: Greeting Card Builder and Save the Animals

These are standalone adaptations of the current game clients verified on 24 November 2026. They do not connect to Aroha classrooms, accept student names for a roster, or use external services. In this release, nothing is saved when a page is closed. This package does not grant a general redistribution license.

## Run

From this directory, serve the files locally with `python3 -m http.server 8080 --bind 127.0.0.1` (Windows: use `py` instead of `python3`), then open:

- Greeting Card Builder: http://127.0.0.1:8080/greeting-card/
- Save the Animals: http://127.0.0.1:8080/save-the-animals/

A static file server is needed for browser JavaScript imports. No package install or service credentials are needed. Run `node tests/verify.mjs` for the offline logic checks.

### Greeting Card Builder

This uses the deployed editor and physical page renderer, with four new local SVG corner decorations and system fonts in place of the original image and font files. All shape/colour combinations are available up front. The editor retains shape layering, undo/redo, adjustment controls, portrait and landscape layouts, names inside, and the optional bottom-left recipient opposite the seasonal motif. Print / PDF / Word exports outside and inside in order; on a duplex printer use A4 portrait, 100%, long-edge flip. Test one folded sheet before batching. Classroom controls and the QR shop/wallet system are not in this version; local export is available directly to the person designing the card.

### Save the Animals

This version retains the current board's 72 animal names, kana, category/search filters, English-name button, and confirm/change workflow. To demonstrate first-come reservations, there is one preselected example animal. The real classroom service is not included. Animal photographs, research profiles, and teaching slides are withheld; category symbols replace photos. Audio uses an installed English voice only and displays a notice if no local voice is available. No name audio files or cloud speech are needed.

## Verification scope

The Card Editor and export JavaScript in the source bundle matched the public versions byte-for-byte before the file-format and font changes. The animal board uses the public CSS, the actual board functions at the selection and display boundaries, and only the name/category fields from the current public catalogue. Runtime checks with a simulated DOM and canvas passed for print side rotations, no cover art on the inside, recipient placement and long-name sizing, PDF and Word containers, all 72 animal names, search, local speech selection, reserved availability and replacing an existing choice. Full browser interaction, actual installed voice and a physical duplex print are not yet verified here.
