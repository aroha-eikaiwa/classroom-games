export default [
  {
    "id": 1,
    "ja": "ジャイアントパンダ",
    "en": "Giant pandas",
    "kana": "ジャイアント・パンダズ",
    "category": "mammals",
    "singularEn": "Giant panda",
    "singularKana": "ジャイアント・パンダ"
  },
  {
    "id": 2,
    "ja": "レッサーパンダ",
    "en": "Red pandas",
    "kana": "レッド・パンダズ",
    "category": "mammals",
    "singularEn": "Red panda",
    "singularKana": "レッド・パンダ"
  },
  {
    "id": 3,
    "ja": "ラッコ",
    "en": "Sea otters",
    "kana": "シー・オターズ",
    "category": "mammals",
    "singularEn": "Sea otter",
    "singularKana": "シー・オター"
  },
  {
    "id": 4,
    "ja": "コアラ",
    "en": "Koalas",
    "kana": "コウアーラズ",
    "category": "mammals",
    "singularEn": "Koala",
    "singularKana": "コウアーラ"
  },
  {
    "id": 5,
    "ja": "クアッカワラビー",
    "en": "Quokkas",
    "kana": "クオッカズ",
    "category": "mammals",
    "singularEn": "Quokka",
    "singularKana": "クオッカ"
  },
  {
    "id": 6,
    "ja": "アカキノボリカンガルー",
    "en": "Matschie's tree-kangaroos",
    "kana": "マッチーズ・ツリーカンガルーズ",
    "category": "mammals",
    "singularEn": "Matschie's tree-kangaroo",
    "singularKana": "マッチーズ・ツリーカンガルー"
  },
  {
    "id": 7,
    "ja": "コツメカワウソ",
    "en": "Asian small-clawed otters",
    "kana": "エイジャンスモールクロード・オターズ",
    "category": "mammals",
    "singularEn": "Asian small-clawed otter",
    "singularKana": "エイジャンスモールクロード・オター"
  },
  {
    "id": 8,
    "ja": "クロアシイタチ",
    "en": "Black-footed ferrets",
    "kana": "ブラック・フッティドフェレッツ",
    "category": "mammals",
    "singularEn": "Black-footed ferret",
    "singularKana": "ブラック・フッティドフェレット"
  },
  {
    "id": 9,
    "ja": "コビトカバ",
    "en": "Pygmy hippopotamuses",
    "kana": "ピグミー・ヒポポタマスィズ",
    "category": "mammals",
    "singularEn": "Pygmy hippopotamus",
    "singularKana": "ピグミー・ヒポポタマス"
  },
  {
    "id": 10,
    "ja": "トラ",
    "en": "Tigers",
    "kana": "タイガーズ",
    "category": "mammals",
    "singularEn": "Tiger",
    "singularKana": "タイガー"
  },
  {
    "id": 11,
    "ja": "ユキヒョウ",
    "en": "Snow leopards",
    "kana": "スノー・レパーズ",
    "category": "mammals",
    "singularEn": "Snow leopard",
    "singularKana": "スノー・レパード"
  },
  {
    "id": 12,
    "ja": "アムールヒョウ",
    "en": "Amur leopards",
    "kana": "アムール・レパーズ",
    "category": "mammals",
    "singularEn": "Amur leopard",
    "singularKana": "アムール・レパード"
  },
  {
    "id": 13,
    "ja": "サバンナゾウ",
    "en": "African savanna elephants",
    "kana": "アフリカン・サバンナ・エレファンツ",
    "category": "mammals",
    "singularEn": "African savanna elephant",
    "singularKana": "アフリカン・サバンナ・エレファント"
  },
  {
    "id": 14,
    "ja": "マサイキリン",
    "en": "Masai giraffes",
    "kana": "マサイ・ジラフス",
    "category": "mammals",
    "singularEn": "Masai giraffe",
    "singularKana": "マサイ・ジラフ"
  },
  {
    "id": 15,
    "ja": "マルミミゾウ",
    "en": "African forest elephants",
    "kana": "アフリカン・フォレストエレファンツ",
    "category": "mammals",
    "singularEn": "African forest elephant",
    "singularKana": "アフリカン・フォレストエレファント"
  },
  {
    "id": 16,
    "ja": "アジアゾウ",
    "en": "Asian elephants",
    "kana": "エイジャン・エレファンツ",
    "category": "mammals",
    "singularEn": "Asian elephant",
    "singularKana": "エイジャン・エレファント"
  },
  {
    "id": 17,
    "ja": "スマトラオランウータン",
    "en": "Sumatran orangutans",
    "kana": "スマトラン・オランウータンズ",
    "category": "mammals",
    "singularEn": "Sumatran orangutan",
    "singularKana": "スマトラン・オランウータン"
  },
  {
    "id": 18,
    "ja": "ボルネオオランウータン",
    "en": "Bornean orangutans",
    "kana": "ボーニアン・オランウータンズ",
    "category": "mammals",
    "singularEn": "Bornean orangutan",
    "singularKana": "ボーニアン・オランウータン"
  },
  {
    "id": 19,
    "ja": "ゴールデンライオンタマリン",
    "en": "Golden lion tamarins",
    "kana": "ゴールデン・ライオンタマリンズ",
    "category": "mammals",
    "singularEn": "Golden lion tamarin",
    "singularKana": "ゴールデン・ライオンタマリン"
  },
  {
    "id": 20,
    "ja": "ワタボウシタマリン",
    "en": "Cotton-top tamarins",
    "kana": "コットン・トップ・タマリンズ",
    "category": "mammals",
    "singularEn": "Cotton-top tamarin",
    "singularKana": "コットン・トップ・タマリン"
  },
  {
    "id": 21,
    "ja": "ワオキツネザル",
    "en": "Ring-tailed lemurs",
    "kana": "リングテイルド・リーマーズ",
    "category": "mammals",
    "singularEn": "Ring-tailed lemur",
    "singularKana": "リングテイルド・リーマー"
  },
  {
    "id": 22,
    "ja": "アメリカアカオオカミ",
    "en": "Red wolves",
    "kana": "レッド・ウルヴズ",
    "category": "mammals",
    "singularEn": "Red wolf",
    "singularKana": "レッド・ウルフ"
  },
  {
    "id": 23,
    "ja": "リカオン",
    "en": "African wild dogs",
    "kana": "アフリカン・ワイルドドッグズ",
    "category": "mammals",
    "singularEn": "African wild dog",
    "singularKana": "アフリカン・ワイルドドッグ"
  },
  {
    "id": 24,
    "ja": "コモドオオトカゲ",
    "en": "Komodo dragons",
    "kana": "コモド・ドラゴンズ",
    "category": "reptiles",
    "singularEn": "Komodo dragon",
    "singularKana": "コモド・ドラゴン"
  },
  {
    "id": 25,
    "ja": "イリオモテヤマネコ",
    "en": "Iriomote cats",
    "kana": "イリオモテ・キャッツ",
    "category": "mammals",
    "singularEn": "Iriomote cat",
    "singularKana": "イリオモテ・キャット"
  },
  {
    "id": 26,
    "ja": "ツシマヤマネコ",
    "en": "Tsushima leopard cats",
    "kana": "ツシマ・レパード・キャッツ",
    "category": "mammals",
    "singularEn": "Tsushima leopard cat",
    "singularKana": "ツシマ・レパード・キャット"
  },
  {
    "id": 27,
    "ja": "アマミノクロウサギ",
    "en": "Amami rabbits",
    "kana": "アマミ・ラビッツ",
    "category": "mammals",
    "singularEn": "Amami rabbit",
    "singularKana": "アマミ・ラビット"
  },
  {
    "id": 28,
    "ja": "トキ",
    "en": "Crested ibises",
    "kana": "クレステッド・アイビスィズ",
    "category": "birds",
    "singularEn": "Crested ibis",
    "singularKana": "クレステッド・アイビス"
  },
  {
    "id": 29,
    "ja": "ライチョウ",
    "en": "Japanese rock ptarmigan",
    "kana": "ジャパニーズ・ロックターミガン",
    "category": "birds",
    "singularEn": "Japanese rock ptarmigan",
    "singularKana": "ジャパニーズ・ロックターミガン"
  },
  {
    "id": 30,
    "ja": "オオサンショウウオ",
    "en": "Japanese giant salamanders",
    "kana": "ジャパニーズ・ジャイアントサラマンダーズ",
    "category": "reptiles",
    "singularEn": "Japanese giant salamander",
    "singularKana": "ジャパニーズ・ジャイアントサラマンダー"
  },
  {
    "id": 31,
    "ja": "ニホンウナギ",
    "en": "Japanese eels",
    "kana": "ジャパニーズ・イールズ",
    "category": "fish",
    "singularEn": "Japanese eel",
    "singularKana": "ジャパニーズ・イール"
  },
  {
    "id": 32,
    "ja": "ヨーロッパウナギ",
    "en": "European eels",
    "kana": "ユーロピアン・イールズ",
    "category": "fish",
    "singularEn": "European eel",
    "singularKana": "ユーロピアン・イール"
  },
  {
    "id": 33,
    "ja": "ノコギリエイ",
    "en": "Largetooth sawfish",
    "kana": "ラージトゥースソーフィッシュ",
    "category": "fish",
    "singularEn": "Largetooth sawfish",
    "singularKana": "ラージトゥースソーフィッシュ"
  },
  {
    "id": 34,
    "ja": "キタタテジマキーウィ",
    "en": "North Island brown kiwi",
    "kana": "ノース・アイランドブラウン・キーウィ",
    "category": "birds",
    "singularEn": "North Island brown kiwi",
    "singularKana": "ノース・アイランドブラウン・キーウィ"
  },
  {
    "id": 35,
    "ja": "カカポ",
    "en": "Kakapo",
    "kana": "カカポ",
    "category": "birds",
    "singularEn": "Kakapo",
    "singularKana": "カカポ"
  },
  {
    "id": 36,
    "ja": "セッパリイルカ",
    "en": "Hector's dolphins",
    "kana": "ヘクターズ・ドルフィンズ",
    "category": "mammals",
    "singularEn": "Hector's dolphin",
    "singularKana": "ヘクターズ・ドルフィン"
  },
  {
    "id": 37,
    "ja": "アマゾンカワイルカ",
    "en": "Amazon river dolphins",
    "kana": "アマゾン・リバードルフィンズ",
    "category": "mammals",
    "singularEn": "Amazon river dolphin",
    "singularKana": "アマゾン・リバードルフィン"
  },
  {
    "id": 38,
    "ja": "コガシラネズミイルカ",
    "en": "Vaquitas",
    "kana": "バキータズ",
    "category": "mammals",
    "singularEn": "Vaquita",
    "singularKana": "バキータ"
  },
  {
    "id": 39,
    "ja": "タイセイヨウセミクジラ",
    "en": "North Atlantic right whales",
    "kana": "ノース・アトランティックライト・ホエールズ",
    "category": "mammals",
    "singularEn": "North Atlantic right whale",
    "singularKana": "ノース・アトランティックライト・ホエール"
  },
  {
    "id": 40,
    "ja": "タイマイ",
    "en": "Hawksbill turtles",
    "kana": "ホークスビル・タートルズ",
    "category": "reptiles",
    "singularEn": "Hawksbill turtle",
    "singularKana": "ホークスビル・タートル"
  },
  {
    "id": 41,
    "ja": "ケープペンギン",
    "en": "African penguins",
    "kana": "アフリカン・ペンギンズ",
    "category": "birds",
    "singularEn": "African penguin",
    "singularKana": "アフリカン・ペンギン"
  },
  {
    "id": 42,
    "ja": "アカシュモクザメ",
    "en": "Scalloped hammerheads",
    "kana": "スキャラプト・ハマーヘッズ",
    "category": "fish",
    "singularEn": "Scalloped hammerhead",
    "singularKana": "スキャラプト・ハマーヘッド"
  },
  {
    "id": 43,
    "ja": "ジャワサイ",
    "en": "Javan rhinoceroses",
    "kana": "ジャヴァン・ライノセラスィズ",
    "category": "mammals",
    "singularEn": "Javan rhinoceros",
    "singularKana": "ジャヴァン・ライノセラス"
  },
  {
    "id": 44,
    "ja": "スマトラサイ",
    "en": "Sumatran rhinoceroses",
    "kana": "スマトラン・ライノセラスィズ",
    "category": "mammals",
    "singularEn": "Sumatran rhinoceros",
    "singularKana": "スマトラン・ライノセラス"
  },
  {
    "id": 45,
    "ja": "クロサイ",
    "en": "Black rhinoceroses",
    "kana": "ブラック・ライノセラスィズ",
    "category": "mammals",
    "singularEn": "Black rhinoceros",
    "singularKana": "ブラック・ライノセラス"
  },
  {
    "id": 46,
    "ja": "アダックス",
    "en": "Addaxes",
    "kana": "アダクスィズ",
    "category": "mammals",
    "singularEn": "Addax",
    "singularKana": "アダックス"
  },
  {
    "id": 47,
    "ja": "ダマガゼル",
    "en": "Dama gazelles",
    "kana": "ダマ・ガゼルズ",
    "category": "mammals",
    "singularEn": "Dama gazelle",
    "singularKana": "ダマ・ガゼル"
  },
  {
    "id": 48,
    "ja": "ヒロラ",
    "en": "Hirolas",
    "kana": "ヒローラズ",
    "category": "mammals",
    "singularEn": "Hirola",
    "singularKana": "ヒローラ"
  },
  {
    "id": 49,
    "ja": "インドリ",
    "en": "Indris",
    "kana": "インドリズ",
    "category": "mammals",
    "singularEn": "Indri",
    "singularKana": "インドリ"
  },
  {
    "id": 50,
    "ja": "クロシロエリマキキツネザル",
    "en": "Black-and-white ruffed lemurs",
    "kana": "ブラック・アンド・ホワイトラフト・リーマーズ",
    "category": "mammals",
    "singularEn": "Black-and-white ruffed lemur",
    "singularKana": "ブラック・アンド・ホワイトラフト・リーマー"
  },
  {
    "id": 51,
    "ja": "アカエリマキキツネザル",
    "en": "Red ruffed lemurs",
    "kana": "レッド・ラフト・リーマーズ",
    "category": "mammals",
    "singularEn": "Red ruffed lemur",
    "singularKana": "レッド・ラフト・リーマー"
  },
  {
    "id": 52,
    "ja": "ニシローランドゴリラ",
    "en": "Western lowland gorillas",
    "kana": "ウェスタン・ローランドゴリラズ",
    "category": "mammals",
    "singularEn": "Western lowland gorilla",
    "singularKana": "ウェスタン・ローランドゴリラ"
  },
  {
    "id": 53,
    "ja": "マレーセンザンコウ",
    "en": "Sunda pangolins",
    "kana": "スンダ・パンゴリンズ",
    "category": "mammals",
    "singularEn": "Sunda pangolin",
    "singularKana": "スンダ・パンゴリン"
  },
  {
    "id": 54,
    "ja": "フィリピンワシ",
    "en": "Philippine eagles",
    "kana": "フィリピン・イーグルズ",
    "category": "birds",
    "singularEn": "Philippine eagle",
    "singularKana": "フィリピン・イーグル"
  },
  {
    "id": 55,
    "ja": "ホウシャガメ",
    "en": "Radiated tortoises",
    "kana": "レイディエイティドトータスィズ",
    "category": "reptiles",
    "singularEn": "Radiated tortoise",
    "singularKana": "レイディエイティドトータス"
  },
  {
    "id": 56,
    "ja": "ヘサキリクガメ",
    "en": "Ploughshare tortoises",
    "kana": "プラウシェア・トータスィズ",
    "category": "reptiles",
    "singularEn": "Ploughshare tortoise",
    "singularKana": "プラウシェア・トータス"
  },
  {
    "id": 57,
    "ja": "フィリピンワニ",
    "en": "Philippine crocodiles",
    "kana": "フィリピン・クロコダイルズ",
    "category": "reptiles",
    "singularEn": "Philippine crocodile",
    "singularKana": "フィリピン・クロコダイル"
  },
  {
    "id": 58,
    "ja": "メキシコサンショウウオ",
    "en": "Axolotls",
    "kana": "アクソロトルズ",
    "category": "reptiles",
    "singularEn": "Axolotl",
    "singularKana": "アクソロトル"
  },
  {
    "id": 59,
    "ja": "インドガビアル",
    "en": "Gharials",
    "kana": "ガリアルズ",
    "category": "reptiles",
    "singularEn": "Gharial",
    "singularKana": "ガリアル"
  },
  {
    "id": 60,
    "ja": "ヨウスコウワニ",
    "en": "Chinese alligators",
    "kana": "チャイニーズ・アリゲーターズ",
    "category": "reptiles",
    "singularEn": "Chinese alligator",
    "singularKana": "チャイニーズ・アリゲーター"
  },
  {
    "id": 61,
    "ja": "カリフォルニアコンドル",
    "en": "California condors",
    "kana": "カリフォルニア・コンドルズ",
    "category": "birds",
    "singularEn": "California condor",
    "singularKana": "カリフォルニア・コンドル"
  },
  {
    "id": 62,
    "ja": "カンムリシロムク",
    "en": "Bali mynas",
    "kana": "バリ・マイナズ",
    "category": "birds",
    "singularEn": "Bali myna",
    "singularKana": "バリ・マイナ"
  },
  {
    "id": 63,
    "ja": "コバタン",
    "en": "Yellow-crested cockatoos",
    "kana": "イエロークレステッドコカトゥーズ",
    "category": "birds",
    "singularEn": "Yellow-crested cockatoo",
    "singularKana": "イエロークレステッドコカトゥー"
  },
  {
    "id": 64,
    "ja": "オナガサイチョウ",
    "en": "Helmeted hornbills",
    "kana": "ヘルメテッド・ホーンビルズ",
    "category": "birds",
    "singularEn": "Helmeted hornbill",
    "singularKana": "ヘルメテッド・ホーンビル"
  },
  {
    "id": 65,
    "ja": "アカミミコンゴウインコ",
    "en": "Red-fronted macaws",
    "kana": "レッドフロンティッドマコーズ",
    "category": "birds",
    "singularEn": "Red-fronted macaw",
    "singularKana": "レッドフロンティッドマコー"
  },
  {
    "id": 66,
    "ja": "アオキコンゴウインコ",
    "en": "Blue-throated macaws",
    "kana": "ブルースローテッド・マコーズ",
    "category": "birds",
    "singularEn": "Blue-throated macaw",
    "singularKana": "ブルースローテッド・マコー"
  },
  {
    "id": 67,
    "ja": "ヘラシギ",
    "en": "Spoon-billed sandpipers",
    "kana": "スプーンビルドサンドパイパーズ",
    "category": "birds",
    "singularEn": "Spoon-billed sandpiper",
    "singularKana": "スプーンビルドサンドパイパー"
  },
  {
    "id": 68,
    "ja": "ソデグロヅル",
    "en": "Siberian cranes",
    "kana": "サイビリアン・クレーンズ",
    "category": "birds",
    "singularEn": "Siberian crane",
    "singularKana": "サイビリアン・クレーン"
  },
  {
    "id": 69,
    "ja": "シマアオジ",
    "en": "Yellow-breasted buntings",
    "kana": "イエローブレステッドバンティングズ",
    "category": "birds",
    "singularEn": "Yellow-breasted bunting",
    "singularKana": "イエローブレステッドバンティング"
  },
  {
    "id": 70,
    "ja": "コロボリーヒキガエルモドキ",
    "en": "Southern corroboree frogs",
    "kana": "サザン・コロボリーフロッグズ",
    "category": "reptiles",
    "singularEn": "Southern corroboree frog",
    "singularKana": "サザン・コロボリーフロッグ"
  },
  {
    "id": 71,
    "ja": "マウンテンチキンフロッグ",
    "en": "Mountain chicken frogs",
    "kana": "マウンテン・チキンフロッグズ",
    "category": "reptiles",
    "singularEn": "Mountain chicken frog",
    "singularKana": "マウンテン・チキンフロッグ"
  },
  {
    "id": 72,
    "ja": "レムールネコメガエル",
    "en": "Lemur leaf frogs",
    "kana": "リーマー・リーフ・フロッグズ",
    "category": "reptiles",
    "singularEn": "Lemur leaf frog",
    "singularKana": "リーマー・リーフ・フロッグ"
  }
];
