export function speakAnimalName(name) {
  if(!globalThis.speechSynthesis||typeof SpeechSynthesisUtterance!=='function')return false;
  const voice=speechSynthesis.getVoices().find(v=>v.localService&&/^en(?:[-_]|$)/i.test(v.lang));
  if(!voice)return false;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(name);
  u.voice=voice;u.lang=voice.lang;u.rate=.85;
  speechSynthesis.speak(u);return true;
}
