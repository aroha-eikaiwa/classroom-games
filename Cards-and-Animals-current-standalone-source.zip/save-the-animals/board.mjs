import animals from "./catalogue.mjs";
import {speakAnimalName} from "./speech.mjs";
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function seatLabel(n){return `${n}番`;}

const marks={mammals:'🐾',birds:'🪶',reptiles:'🥚',fish:'🐟'};
let busy=false,lastGood=0,signature='',choice=null,board=null;
const practiceBoard={student:1,round:1,claims:[{student_no:2,animal_id:2}]};
async function api(path,data){
  if(path==='/claim'){
    if(!animals.some(a=>a.id===data.animal)) throw Error('UNKNOWN_ANIMAL');
    if(practiceBoard.claims.some(c=>c.student_no!==1&&c.animal_id===data.animal))throw Error('ANIMAL_TAKEN');
    practiceBoard.claims=practiceBoard.claims.filter(c=>c.student_no!==1);
    practiceBoard.claims.push({student_no:1,animal_id:data.animal});
  } else if(path!=='/board') throw Error('UNKNOWN_REQUEST');
  return structuredClone(practiceBoard);
}
const refresh=async()=>apply(await api('/board'));
function claimLabel(c){return 'サンプル参加者';}
function message(text){$('message').textContent=text;}
function apply(data){$('studentBoard').hidden=false;const wasStale=Date.now()-lastGood>12000;board=data;lastGood=Date.now();$('counter').textContent=`${data.claims.length} / 72 の動物がえらばれました`;
 const next=JSON.stringify([data.student,data.round,data.claims]);if(wasStale||signature!==next){signature=next;render();}}
function render(){if(!board){$('studentBoard').hidden=true;$('cards').replaceChildren();$('confirm').close();$('animalInfo').close();choice=null;return;}const q=$('search').value.trim().toLowerCase(),category=$('category').value,available=$('availableOnly').checked;const claims=new Map((board?.claims??[]).map(c=>[c.animal_id,c]));const shown=animals.filter(a=>(!q||`${a.ja} ${a.en} ${a.kana} ${a.singularEn ?? ""} ${a.singularKana ?? ""}`.toLowerCase().includes(q))&&(category==='all'||a.category===category)&&(!available||!claims.has(a.id)||claims.get(a.id).student_no===board?.student));
 $('cards').innerHTML=shown.map(a=>{const claim=claims.get(a.id),mine=claim&&claim.student_no===board?.student;const status=!board?'クラスに入ると予約できます':mine?'あなたの動物':claim?`${claimLabel(claim)}がえらびました`:'えらべます！';const label=mine?'あなたの動物':claim?'えらばれました':'この動物をえらぶ';return `<article class="animal-card ${mine?'mine':claim?'reserved':''}"><div class="photo-wrap"><span class="animal-symbol" aria-hidden="true">${marks[a.category]??"🐾"}</span><span class="animal-id">${String(a.id).padStart(2,'0')}</span><div class="photo-actions"><button type="button" class="photo-speak" data-speak="${a.id}" aria-label="${esc(a.en)}の英語の名前を聞く">🔊 英語を聞く</button></div></div><div class="card-body"><h3 class="animal-en" lang="en"><button type="button" class="animal-name" data-info="${a.id}" aria-haspopup="dialog">${esc(a.en)}</button></h3><p class="animal-ja"><button type="button" class="animal-name" data-info="${a.id}" aria-haspopup="dialog">${esc(a.ja)}</button></p><p class="status ${claim?'taken':'available'}">${esc(status)}</p><button class="${claim?'secondary':'primary'}" data-animal="${a.id}" ${!board||claim||busy||false?'disabled':''}>${label}</button></div></article>`;}).join('');$('noResults').hidden=shown.length>0;}
function sayAnimal(id){const a=animals.find(a=>a.id===id);if(board&&a&&!speakAnimalName(a.en))message('このブラウザでは音声を再生できません。');}

function showAnimalInfo(id){
  const animal=animals.find(a=>a.id===id);if(!animal)return;
  $('animalInfoTitle').textContent=animal.ja;
  $('animalInfoEnglish').innerHTML=`<span lang="en">${esc(animal.en)}</span> <span lang="ja">（${esc(animal.kana)}）</span>`;
  $('animalInfo').dataset.animal=String(id);
  $('animalInfoSymbol').textContent=marks[animal.category]??'🐾';
  $('animalInfo').showModal();
}
$('closeAnimalInfo').addEventListener('click',()=>$('animalInfo').close());
$('animalInfo').addEventListener('click',e=>{if(e.target!==$('animalInfo'))return;const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();});
$('animalInfoPhotoButton').addEventListener('click',()=>sayAnimal(Number($('animalInfo').dataset.animal)));
$('animalInfoEnglish').addEventListener('click',()=>sayAnimal(Number($('animalInfo').dataset.animal)));
$('cards').addEventListener('click',async e=>{
 const speech=e.target.closest('button[data-speak]')??e.target.closest('.photo-wrap > .animal-symbol,.photo-wrap > .animal-id')?.parentElement.querySelector('button[data-speak]');if(speech){sayAnimal(Number(speech.dataset.speak));return;}
const info=e.target.closest('button[data-info]');if(info){sayAnimal(Number(info.dataset.info));showAnimalInfo(Number(info.dataset.info));return;}const button=e.target.closest('button[data-animal]');if(!button||button.disabled||!board)return;choice=animals.find(a=>a.id===Number(button.dataset.animal));const current=board.claims.find(c=>c.student_no===board.student),old=animals.find(a=>a.id===current?.animal_id);$('confirmTitle').textContent=`${choice.ja}にする？`;$('confirmText').textContent=old?`「${old.ja}」から「${choice.ja}」に変更します。新しい予約ができたときだけ、前の動物が空きます。`:`発表する動物を「${choice.ja} / ${choice.en}」に決めます。`;$('confirm').showModal();});
$('confirmChoice').addEventListener('click',async()=>{if(busy||!choice||!board)return;busy=true;$('confirmChoice').disabled=true;render();const round=board.round,animal=choice.id;try{apply(await api('/claim',{animal,round}));message('この動物に決まりました！');}catch(error){if(error.message==='ANIMAL_TAKEN')message('ほかの人が先にえらびました。別の動物をえらんでね。前の予約はそのままです。');else if(error.message==='STALE_ROUND'){message('先生がボードを更新しました。もう一度えらんでね。');if(error.board)apply(error.board);}else message('結果を確認しています。少し待ってから予約をたしかめてね。');await refresh();}finally{busy=false;$('confirmChoice').disabled=false;$('confirm').close();choice=null;render();}});
for(const id of ['search','category','availableOnly'])$(id).addEventListener(id==='search'?'input':'change',render);
await refresh();
